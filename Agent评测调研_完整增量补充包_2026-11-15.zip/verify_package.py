from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
for name,expected in manifest.items():
    path=root/name
    assert path.is_file(),f'Missing: {name}'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,f'Hash mismatch: {name}'
print(f'Verified {len(manifest)} files')
