import json
import sqlite3
from collections import Counter
from pathlib import Path
import httpx
from phoenix.client import Client

root=Path(__file__).parent
load=lambda name:json.loads((root/name).read_text(encoding='utf-8'))
checks=[]
def check(name,condition,detail):
    checks.append({'check':name,'passed':bool(condition),'detail':detail})
    print(('PASS ' if condition else 'FAIL ')+name+': '+str(detail),flush=True)

e=load('persistence-evidence.json')
before=load('persistence-before-restart.json')
for platform in ['phoenix','langfuse']:
    trials=load(platform+'-trials.json')
    check(platform+' eight real trials',len(trials)==8,len(trials))
    check(platform+' two repeats per case',Counter(t['case_id'] for t in trials)=={'eligible':2,'shipped':2,'cross_user':2,'transient':2},dict(Counter(t['case_id'] for t in trials)))
    for t in trials:
        with sqlite3.connect(root/f"world-{t['trial_id']}.sqlite") as db:
            state=db.execute('select refunded from orders').fetchone()[0]
        check(t['trial_id']+' SQLite outcome',state==t['expected_refund'] and t['error'] is None,{'actual':state,'expected':t['expected_refund']})
    transient=[t for t in trials if t['case_id']=='transient']
    check(platform+' recovery tool calls',all(sum(c['name']=='get_order' for c in t['calls'])>=2 for t in transient),'Each transient case queried again after injected failure')

lf_items=e['langfuse_items']['body']['data']
primary=[x for x in lf_items if x.get('experimentDatasetId')==e['langfuse_dataset']['body']['id']]
check('Langfuse persisted primary items',len(primary)==8,len(primary))
scores=e['langfuse_scores']['body']['data']
check('Langfuse persisted primary scores',sum(x['name'] in ['state_correct','deepseek_honesty'] for x in scores)==16,len(scores))
check('Langfuse negative correctness 0 and 1',{x['value'] for x in scores if x['name']=='correctness'}=={0,1},[x['value'] for x in scores if x['name']=='correctness'])
check('Langfuse restart retains items',e['langfuse_items']['body']==before['langfuse_items']['body'],'Exact API body equality')
check('Langfuse restart retains scores',e['langfuse_scores']['body']==before['langfuse_scores']['body'],'Exact API body equality')
px_rows=e['phoenix_export']['body']
check('Phoenix restart retains eight runs',len(px_rows)==8,len(px_rows))
check('Phoenix restart retains export',px_rows==before['phoenix_export']['body'],'Exact API export equality')
negative=load('negative-controls-result.json')
check('Phoenix evaluator recovery does not rerun task',negative['phoenix']['task_calls_before_regrade']==negative['phoenix']['task_calls_after_regrade']==3,negative['phoenix']['task_calls_after_regrade'])
http=httpx.Client(base_url='http://127.0.0.1:6006',trust_env=False,timeout=30)
client=Client(base_url='http://127.0.0.1:6006',http_client=http)
px=load('phoenix-result.json')
traces=[]
for run in px['raw']['task_runs']:
    trace_id=run.get('trace_id')
    spans=client.spans.get_spans(project_identifier=px['project_name'],trace_ids=[trace_id],limit=100) if trace_id else []
    kinds=Counter(s.get('span_kind') for s in spans)
    traces.append({'trace_id':trace_id,'span_count':len(spans),'kinds':dict(kinds),'spans':spans})
check('Phoenix all eight run traces readable',len(traces)==8 and all(x['span_count']>0 for x in traces),[x['span_count'] for x in traces])
check('Phoenix tool and model spans persisted',all(x['kinds'].get('TOOL',0)>0 and x['kinds'].get('LLM',0)>0 for x in traces),[x['kinds'] for x in traces])
annotations=[a for row in px_rows for a in row.get('annotations',[])]
check('Phoenix sixteen persisted annotations',len(annotations)==16,len(annotations))
negative_id=negative['phoenix']['experiment']['experiment_id']
negative_rows=http.get(f'/v1/experiments/{negative_id}/json').json()
check('Phoenix records intentional task error',sum(bool(row.get('error')) for row in negative_rows)==1,[row.get('error') for row in negative_rows])
negative_annotations=[a for row in negative_rows for a in row.get('annotations',[])]
check('Phoenix recovered evaluations persisted',sum(a.get('name')=='recovery_check' and a.get('error') is None for a in negative_annotations)==2,negative_annotations)
(root/'phoenix-negative-export.json').write_text(json.dumps(negative_rows,ensure_ascii=False,indent=2),encoding='utf-8')
datasets=http.get('/v1/datasets').json()['data']
harbor_datasets=[d for d in datasets if d['name']=='harbor-task']
if not harbor_datasets:
    harbor_datasets=[d for d in datasets if d['name'].startswith('harbor') or d['name']=='adhoc']
harbor_recordings=[]
for dataset in harbor_datasets:
    experiments=http.get(f"/v1/datasets/{dataset['id']}/experiments").json()['data']
    for experiment in experiments:
        rows=http.get(f"/v1/experiments/{experiment['id']}/json").json()
        harbor_recordings.append({'dataset':dataset,'experiment':experiment,'rows':rows})
(root/'harbor-phoenix-evidence.json').write_text(json.dumps(harbor_recordings,ensure_ascii=False,indent=2),encoding='utf-8')
harbor_scores=[a for recording in harbor_recordings for row in recording['rows'] for a in row.get('annotations',[])]
check('Harbor rewards persisted in Phoenix',{a.get('score') for a in harbor_scores if a.get('name')=='reward'}=={0,1},harbor_scores)
(root/'phoenix-trace-evidence.json').write_text(json.dumps(traces,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
for job,reward in [('live-oracle',1),('live-nop',0)]:
    result=load(f'harbor-jobs/{job}/result.json')
    means=[m['mean'] for v in result['stats']['evals'].values() for m in v['metrics'] if 'mean' in m]
    check('Harbor '+job+' expected reward',means==[float(reward)] and result['stats']['n_errored_trials']==0,means)
(root/'assertions.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(f"{sum(c['passed'] for c in checks)}/{len(checks)} checks passed")
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)
