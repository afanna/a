Write exactly the text verified into /app/result.txt. Do not modify any other files.
