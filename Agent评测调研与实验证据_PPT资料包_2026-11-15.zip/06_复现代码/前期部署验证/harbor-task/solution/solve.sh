#!/bin/bash
mkdir -p /app
printf verified > /app/result.txt
