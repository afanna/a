#!/bin/bash
mkdir -p /logs/verifier
if [ "$(cat /app/result.txt 2>/dev/null)" = "verified" ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
