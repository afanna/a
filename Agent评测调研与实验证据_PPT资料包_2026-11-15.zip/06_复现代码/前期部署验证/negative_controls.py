import json
import time
from pathlib import Path
from phoenix.client import Client
from langfuse import Langfuse, Evaluation

root=Path(__file__).parent
stamp=time.strftime('%Y%m%d-%H%M%S')
evidence={}
client=Client(base_url='http://localhost:6006')
dataset=client.datasets.create_dataset(name='negative-controls-'+stamp,inputs=[{'mode':'good'},{'mode':'wrong'},{'mode':'exception'}],outputs=[{'answer':4}]*3)
calls=[]
def task(input):
    calls.append(input['mode'])
    if input['mode']=='exception':
        raise RuntimeError('intentional task failure for platform validation')
    return 4 if input['mode']=='good' else 5
def check(output):
    return {'score':float(output==4),'explanation':'Known answer is 4'}
def broken(output):
    raise RuntimeError('intentional evaluator failure for recovery validation')
result=client.experiments.run_experiment(dataset=dataset,task=task,evaluators={'correctness':check,'recovery_check':broken},repetitions=1,retries=0,experiment_name='negative-controls',print_summary=False)
before=len(calls)
client.experiments.resume_evaluation(experiment_id=result['experiment_id'],evaluators={'recovery_check':check},print_summary=False,retries=0)
evidence['phoenix']={'experiment':result,'task_calls_before_regrade':before,'task_calls_after_regrade':len(calls)}

config=dict(line.split('=',1) for line in (root/'langfuse.env').read_text().splitlines() if '=' in line)
lf=Langfuse(public_key=config['LANGFUSE_INIT_PROJECT_PUBLIC_KEY'],secret_key=config['LANGFUSE_INIT_PROJECT_SECRET_KEY'],base_url='http://localhost:3000',flush_at=1)
name='negative-controls-'+stamp
lf.create_dataset(name=name)
for mode in ['good','wrong','exception']:
    lf.create_dataset_item(dataset_name=name,input={'mode':mode},expected_output=4)
def lf_task(*,item,**kwargs):
    return task(item.input)
def lf_eval(*,output,**kwargs):
    return Evaluation(name='correctness',value=float(output==4))
lf_result=lf.run_experiment(name='negative-controls',run_name=stamp,data=lf.get_dataset(name).items,task=lf_task,evaluators=[lf_eval],max_concurrency=1)
lf.flush()
evidence['langfuse']={'dataset':name,'result_attributes':{k:str(v) for k,v in vars(lf_result).items()}}
(root/'negative-controls-result.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
print('Negative controls completed; Phoenix task calls unchanged after evaluation recovery:',before==evidence['phoenix']['task_calls_after_regrade'])
