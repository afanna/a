from pathlib import Path
import secrets

root = Path(__file__).parent
values = {
    'LANGFUSE_IMAGE_TAG': '4.80.0',
    'NEXTAUTH_URL': 'http://localhost:3000',
    'NEXTAUTH_SECRET': secrets.token_hex(32),
    'SALT': secrets.token_hex(24),
    'ENCRYPTION_KEY': secrets.token_hex(32),
    'POSTGRES_PASSWORD': secrets.token_hex(16),
    'CLICKHOUSE_PASSWORD': secrets.token_hex(16),
    'REDIS_AUTH': secrets.token_hex(16),
    'MINIO_ROOT_PASSWORD': secrets.token_hex(16),
    'TELEMETRY_ENABLED': 'false',
    'LANGFUSE_INIT_ORG_ID': 'live-research-org',
    'LANGFUSE_INIT_ORG_NAME': 'Local Research',
    'LANGFUSE_INIT_PROJECT_ID': 'live-research-project',
    'LANGFUSE_INIT_PROJECT_NAME': 'Agent Evaluation Research',
    'LANGFUSE_INIT_PROJECT_PUBLIC_KEY': 'pk-lf-' + secrets.token_hex(16),
    'LANGFUSE_INIT_PROJECT_SECRET_KEY': 'sk-lf-' + secrets.token_hex(24),
    'LANGFUSE_INIT_USER_EMAIL': 'research@example.local',
    'LANGFUSE_INIT_USER_NAME': 'Research',
    'LANGFUSE_INIT_USER_PASSWORD': secrets.token_urlsafe(24),
}
values['DATABASE_URL'] = f"postgresql://postgres:{values['POSTGRES_PASSWORD']}@postgres:5432/postgres"
values['LANGFUSE_S3_EVENT_UPLOAD_SECRET_ACCESS_KEY'] = values['MINIO_ROOT_PASSWORD']
values['LANGFUSE_S3_MEDIA_UPLOAD_SECRET_ACCESS_KEY'] = values['MINIO_ROOT_PASSWORD']
values['LANGFUSE_S3_BATCH_EXPORT_SECRET_ACCESS_KEY'] = values['MINIO_ROOT_PASSWORD']
env = root / 'langfuse.env'
if not env.exists():
    env.write_text(''.join(f'{key}={value}\n' for key, value in values.items()), encoding='utf-8')
(root / 'langfuse.override.yml').write_text('''services:
  langfuse-web:
    ports: !override ["127.0.0.1:3000:3000"]
  langfuse-worker:
    ports: !override ["127.0.0.1:3030:3030"]
  minio:
    ports: !override ["127.0.0.1:9090:9000", "127.0.0.1:9091:9001"]
''', encoding='utf-8')
(root / 'phoenix.compose.yml').write_text('''services:
  phoenix:
    image: arizephoenix/phoenix:21.1.0
    ports: ["127.0.0.1:6006:6006", "127.0.0.1:4317:4317"]
    environment:
      PHOENIX_WORKING_DIR: /data
      PHOENIX_ENABLE_AUTH: "false"
      PHOENIX_ENABLE_PROMETHEUS: "false"
    volumes: ["phoenix_data:/data"]
volumes:
  phoenix_data:
''', encoding='utf-8')
print('Created isolated deployment configuration; credentials saved locally, not printed.')
