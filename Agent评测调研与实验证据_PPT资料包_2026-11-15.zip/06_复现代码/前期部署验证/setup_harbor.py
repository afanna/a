from pathlib import Path

root=Path(__file__).parent/'harbor-task'
for name in ['environment','tests','solution']:
    (root/name).mkdir(parents=True,exist_ok=True)
(root/'instruction.md').write_text('Write exactly the text verified into /app/result.txt. Do not modify any other files.\n',encoding='utf-8')
(root/'task.toml').write_text('''version = "1.0"
[metadata]
name = "local-result-verification"
[agent]
timeout_sec = 30
[verifier]
timeout_sec = 30
environment_mode = "shared"
[environment]
docker_image = "ubuntu:24.04"
cpus = 1
memory_mb = 256
''',encoding='utf-8')
(root/'environment'/'Dockerfile').write_text('FROM ubuntu:24.04\nWORKDIR /app\n',encoding='utf-8')
(root/'solution'/'solve.sh').write_text('#!/bin/bash\nmkdir -p /app\nprintf verified > /app/result.txt\n',encoding='utf-8')
(root/'tests'/'test.sh').write_text('''#!/bin/bash
mkdir -p /logs/verifier
if [ "$(cat /app/result.txt 2>/dev/null)" = "verified" ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
''',encoding='utf-8')
print('Harbor reference and no-op task created.')
