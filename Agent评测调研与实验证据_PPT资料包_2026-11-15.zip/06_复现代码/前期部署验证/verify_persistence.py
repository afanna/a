import json
from pathlib import Path
import httpx

root=Path(__file__).parent
config=dict(line.split('=',1) for line in (root/'langfuse.env').read_text().splitlines() if '=' in line)
http=httpx.Client(timeout=30,trust_env=False)
auth=(config['LANGFUSE_INIT_PROJECT_PUBLIC_KEY'],config['LANGFUSE_INIT_PROJECT_SECRET_KEY'])
evidence={}
lf=json.loads((root/'langfuse-result.json').read_text(encoding='utf-8'))
name=lf['dataset_name']
for label,path in {
    'health':'/api/public/health',
    'dataset':f'/api/public/datasets/{name}',
    'experiments':'/api/public/experiments?fromStartTime=2026-11-15T00:00:00Z&fields=core,metadata,scores',
    'items':'/api/public/experiment-items?fromStartTime=2026-11-15T00:00:00Z&fields=core,dataset,io,scores&limit=100',
    'scores':'/api/public/v3/scores?fromTimestamp=2026-11-15T00:00:00Z&limit=100',
}.items():
    r=http.get('http://127.0.0.1:3000'+path,auth=auth)
    evidence['langfuse_'+label]={'status':r.status_code,'body':r.json() if 'json' in r.headers.get('content-type','') else r.text[:200]}
    body=evidence['langfuse_'+label]['body']
    print(label,r.status_code,'count',len(body.get('data',[])) if isinstance(body,dict) else '?')
if (root/'phoenix-result.json').exists():
    px=json.loads((root/'phoenix-result.json').read_text(encoding='utf-8'))
    for label,path in {
        'experiment':f"/v1/experiments/{px['experiment_id']}",
        'runs':f"/v1/experiments/{px['experiment_id']}/runs",
        'export':f"/v1/experiments/{px['experiment_id']}/json",
        'projects':'/v1/projects',
    }.items():
        r=http.get('http://127.0.0.1:6006'+path)
        try:
            body=r.json()
        except ValueError:
            body=r.text
        evidence['phoenix_'+label]={'status':r.status_code,'body':body}
        print('phoenix',label,r.status_code)
(root/'persistence-evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
