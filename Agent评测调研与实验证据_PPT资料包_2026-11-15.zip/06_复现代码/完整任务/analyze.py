"""Independent database verification and analysis of immutable trial records."""
import csv
import json
import math
import random
import sqlite3
import statistics
import sys
from collections import Counter
from pathlib import Path
import httpx
from fixtures import BY_ID, grade

root=Path(sys.argv[1]) if len(sys.argv)>1 else sorted(Path('.').glob('results-*'))[-1]
trials=json.loads((root/'trials.json').read_text(encoding='utf-8'))
assert len(trials)==48
rows=[]
audit=[]
disagreements=[]
def percentile(values,p):
    values=sorted(values)
    position=(len(values)-1)*p
    low=int(position)
    high=min(low+1,len(values)-1)
    return values[low]+(values[high]-values[low])*(position-low)
def wilson(successes,n):
    z=1.959963984540054
    mean=successes/n
    denominator=1+z*z/n
    center=(mean+z*z/(2*n))/denominator
    half=z*math.sqrt(mean*(1-mean)/n+z*z/(4*n*n))/denominator
    return [center-half,center+half]
for t in trials:
    with sqlite3.connect(root/(t['trial_id']+'.sqlite')) as db:
        after={r[0]:dict(owner=r[1],status=r[2],amount=r[3],refunded=r[4]) for r in db.execute('select * from orders order by id')}
    assert after==t['after'],t['trial_id']
    metrics=grade(BY_ID[t['case_id']],t['before'],after,t['events'],t['answer'],t['error'])
    assert metrics==t['metrics'],t['trial_id']
    # Exploratory diagnostic added after observing non-JSON preambles; strict metric is unchanged.
    business_success=int(all(metrics[k] for k in ['outcome_correct','no_invalid_refund_attempt','clarification_correct','recovery_correct']) and bool(t['answer_text']) and not t['error'])
    def usage(calls,key):
        return sum(c['response'].get('usage',{}).get(key,0) for c in calls)
    judge_calls=[t['judge_call']] if t['judge_call'] else []
    row=dict(trial_id=t['trial_id'],variant=t['variant'],case_id=t['case_id'],repetition=t['repetition'],**metrics,business_success=business_success,judge_score=t['judge']['score'] if t['judge'] else None,error=t['error'],judge_error=t['judge_error'],agent_seconds=t['agent_seconds'],task_seconds=t['task_seconds'],llm_calls=len(t['model_calls']),tool_calls=len(t['events']),agent_input_tokens=usage(t['model_calls'],'prompt_tokens'),agent_output_tokens=usage(t['model_calls'],'completion_tokens'),agent_cache_hit_tokens=usage(t['model_calls'],'prompt_cache_hit_tokens'),judge_input_tokens=usage(judge_calls,'prompt_tokens'),judge_output_tokens=usage(judge_calls,'completion_tokens'),judge_cache_hit_tokens=usage(judge_calls,'prompt_cache_hit_tokens'))
    rows.append(row)
    audit.append(dict(trial_id=t['trial_id'],sqlite_state_matches=True,metrics_recomputed_match=True))
    if row['judge_score'] is not None and row['judge_score']!=metrics['strict_success']:
        disagreements.append(dict(trial_id=t['trial_id'],strict_success=metrics['strict_success'],business_success=business_success,judge=t['judge'],answer=t['answer_text'],metrics=metrics))
with (root/'trials.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
summary={}
for variant in ['full_budget6','short_budget2']:
    group=[r for r in rows if r['variant']==variant]
    n=len(group)
    assert n==24
    percase={case:[r for r in group if r['case_id']==case] for case in BY_ID}
    assert all(len(v)==3 for v in percase.values())
    successes=sum(r['strict_success'] for r in group)
    case_means=[statistics.mean(r['strict_success'] for r in values) for values in percase.values()]
    rng=random.Random(20261115)
    boot=[statistics.mean(rng.choices(case_means,k=len(case_means))) for _ in range(10000)]
    summary[variant]=dict(n=n,strict_successes=successes,strict_rate=successes/n,exploratory_business_successes=sum(r['business_success'] for r in group),outcome_correct=sum(r['outcome_correct'] for r in group),judge_passes=sum(r['judge_score']==1 for r in group),judge_disagreements=sum(r['judge_score']!=r['strict_success'] for r in group if r['judge_score'] is not None),wilson95_naive=wilson(successes,n),task_cluster_bootstrap95=[percentile(boot,.025),percentile(boot,.975)],empirical_any_success_at_3=sum(any(r['strict_success'] for r in v) for v in percase.values())/8,empirical_all_success_3=sum(all(r['strict_success'] for r in v) for v in percase.values())/8,agent_latency_mean=statistics.mean(r['agent_seconds'] for r in group),agent_latency_p50=statistics.median(r['agent_seconds'] for r in group),agent_latency_p90=percentile([r['agent_seconds'] for r in group],.9),tool_calls=sum(r['tool_calls'] for r in group),llm_calls=sum(r['llm_calls'] for r in group),error_counts=dict(Counter(r['error'] or 'none' for r in group)),token_totals={key:sum(r[key] for r in group) for key in ['agent_input_tokens','agent_output_tokens','agent_cache_hit_tokens','judge_input_tokens','judge_output_tokens','judge_cache_hit_tokens']},cases={case:dict(strict_successes=sum(r['strict_success'] for r in values),business_successes=sum(r['business_success'] for r in values),outcome_correct=sum(r['outcome_correct'] for r in values),judge_passes=sum(r['judge_score']==1 for r in values)) for case,values in percase.items()})
http=httpx.Client(trust_env=False,timeout=30)
px=json.loads((root/'phoenix-experiments.json').read_text(encoding='utf-8'))
platform_audit=[]
for experiment in px['experiments']:
    exported=http.get(f"http://127.0.0.1:6006/v1/experiments/{experiment['id']}/json").json()
    assert len(exported)==24
    annotations=[a for run in exported for a in run['annotations']]
    assert len(annotations)==168
    for run in exported:
        original=next(r for r in rows if r['trial_id']==run['output']['trial_id'])
        assert original['repetition']==run['repetition_number']
        persisted={a['name']:a['score'] for a in run['annotations']}
        assert all(persisted[k]==original[k] for k in ['outcome_correct','no_invalid_refund_attempt','clarification_correct','recovery_correct','final_status_correct','strict_success'])
        assert persisted['llm_judge']==original['judge_score']
    (root/('phoenix-export-'+experiment['name']+'.json')).write_text(json.dumps(exported,ensure_ascii=False,indent=2),encoding='utf-8')
    platform_audit.append(dict(platform='phoenix',experiment_id=experiment['id'],runs=len(exported),scores=len(annotations),values_match=True))
config=dict(line.split('=',1) for line in (Path(__file__).parent.parent/'langfuse.env').read_text().splitlines() if '=' in line)
auth=(config['LANGFUSE_INIT_PROJECT_PUBLIC_KEY'],config['LANGFUSE_INIT_PROJECT_SECRET_KEY'])
lf_runs=json.loads((root/'langfuse-experiments.json').read_text(encoding='utf-8'))
for experiment in lf_runs:
    params={'fromStartTime':'2026-11-15T00:00:00Z','experimentId':experiment['experiment_id'],'fields':'core,dataset,io,scores','limit':100}
    response=http.get('http://127.0.0.1:3000/api/public/experiment-items',params=params,auth=auth)
    response.raise_for_status()
    items=response.json()['data']
    assert len(items)==8,(experiment,len(items))
    score_count=0
    for item in items:
        output=json.loads(item['output']) if isinstance(item['output'],str) else item['output']
        original=next(r for r in rows if r['trial_id']==output['trial_id'])
        persisted={a['name']:a.get('value') for a in item['scores']}
        score_count+=len(item['scores'])
        assert all(persisted[k]==original[k] for k in ['outcome_correct','no_invalid_refund_attempt','clarification_correct','recovery_correct','final_status_correct','strict_success'])
        assert persisted['llm_judge']==original['judge_score']
    (root/('langfuse-export-'+experiment['variant']+'-r'+str(experiment['repetition'])+'.json')).write_text(json.dumps(response.json(),ensure_ascii=False,indent=2),encoding='utf-8')
    platform_audit.append(dict(platform='langfuse',experiment_id=experiment['experiment_id'],runs=len(items),scores=score_count,values_match=True))
(root/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(root/'grader-disagreements.json').write_text(json.dumps(disagreements,ensure_ascii=False,indent=2),encoding='utf-8')
(root/'audit.json').write_text(json.dumps({'trials':audit,'platforms':platform_audit},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
