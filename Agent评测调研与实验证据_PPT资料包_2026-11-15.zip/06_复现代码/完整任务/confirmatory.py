"""Exploratory follow-up: make the output contract explicit. Main data unchanged."""
import json
from datetime import datetime,timezone
import httpx
from phoenix.client import Client
from langfuse import Evaluation
import run

run.POLICY+='\n输出格式是机器接口契约：最终回复必须只包含一个完整合法JSON对象，不得加任何前言、尾注、Markdown或代码围栏。'
cases=[run.BY_ID[name] for name in ['shipped','foreign','wrong_code']]
run.ROOT.joinpath('followup-manifest.json').write_text(json.dumps({'type':'post-hoc exploratory followup','cases':[c['id'] for c in cases],'repetitions':2,'variant':'full_budget6','policy':run.POLICY,'main_experiment_unchanged':True},ensure_ascii=False,indent=2),encoding='utf-8')
name=run.ROOT.name+'-explicit-json-followup'
run.LF.create_dataset(name=name)
for case in cases:
    run.LF.create_dataset_item(dataset_name=name,input={'case_id':case['id']},expected_output={'refund_delta':case['delta']})
dataset=run.LF.get_dataset(name)
lf_experiments=[]
def evals(*,output,**kwargs):
    return [Evaluation(name=k,value=v) for k,v in output['metrics'].items()]+[Evaluation(name='llm_judge',value=output['judge']['score'])]
for repetition in [1,2]:
    def task(*,item,**kwargs):
        return run.execute(run.BY_ID[item.input['case_id']],'full_budget6',repetition)
    result=run.LF.run_experiment(name='explicit-json-followup',run_name=f'{name}-r{repetition}',data=dataset.items,task=task,evaluators=[evals],max_concurrency=3)
    lf_experiments.append({'experiment_id':result.experiment_id,'url':result.experiment_url})
run.LF.flush()
px=Client(base_url='http://127.0.0.1:6006',http_client=httpx.Client(base_url='http://127.0.0.1:6006',trust_env=False,timeout=30))
ds=px.datasets.create_dataset(name=name,inputs=[{'case_id':c['id']} for c in cases],outputs=[{'refund_delta':c['delta']} for c in cases])
examples={ex['input']['case_id']:ex['id'] for ex in ds.examples}
experiment=px.experiments.create(dataset_id=ds.id,repetitions=2,experiment_name='explicit-json-followup',experiment_metadata={'post_hoc':True})
for record in run.RECORDS:
    px.spans.log_spans(project_identifier=experiment['project_name'],spans=run.phoenix_spans(record))
    logged=px.experiments.log_run(experiment_id=experiment['id'],dataset_example_id=examples[record['case_id']],output={'trial_id':record['trial_id'],'answer':record['answer_text'],'metrics':record['metrics']},start_time=datetime.fromtimestamp(record['started_ns']/1e9,timezone.utc),end_time=datetime.fromtimestamp(record['agent_end_ns']/1e9,timezone.utc),repetition_number=record['repetition'],trace_id=record['trace_id'])
    for k,v in record['metrics'].items():
        px.experiments.log_evaluation(experiment_run_id=logged['id'],name=k,score=v,annotator_kind='CODE')
    px.experiments.log_evaluation(experiment_run_id=logged['id'],name='llm_judge',score=record['judge']['score'],annotator_kind='LLM',explanation=record['judge'].get('reason'))
export=run.HTTP.get(f"http://127.0.0.1:6006/v1/experiments/{experiment['id']}/json").json()
assert len(export)==6
assert sum(len(r['annotations']) for r in export)==42
run.ROOT.joinpath('trials.json').write_text(json.dumps(run.RECORDS,ensure_ascii=False,indent=2),encoding='utf-8')
run.ROOT.joinpath('followup-summary.json').write_text(json.dumps({'runs':6,'strict_successes':sum(r['metrics']['strict_success'] for r in run.RECORDS),'judge_passes':sum(r['judge']['score'] for r in run.RECORDS),'langfuse':lf_experiments,'phoenix':experiment,'phoenix_export':export},ensure_ascii=False,indent=2),encoding='utf-8')
run.SERVER.shutdown()
print(json.dumps({'root':str(run.ROOT),'strict_successes':sum(r['metrics']['strict_success'] for r in run.RECORDS),'runs':len(run.RECORDS)}),flush=True)
