"""Reference paths and deliberate invalid actions validate the task and grader."""
import json
import contextlib
import uuid
from pathlib import Path
import httpx
from fixtures import CASES,grade
from tool_server import start_server

results=[]
directory=Path('contract-worlds-'+uuid.uuid4().hex[:8])
directory.mkdir()
with contextlib.nullcontext(directory):
    server=start_server(directory)
    http=httpx.Client(base_url=f'http://127.0.0.1:{server.server_port}',trust_env=False)
    def post(path,body):
        response=http.post(path,json=body)
        response.raise_for_status()
        return response.json()
    for case in CASES:
        trial=uuid.uuid4().hex
        before=post('/init',dict(trial=trial,case_id=case['id']))
        events=[]
        def call(name,arguments):
            result=post('/call',dict(trial=trial,name=name,arguments=arguments))
            events.append(dict(name=name,arguments=arguments,result=result))
            return result
        if case['id']=='missing_code':
            call('ask_user',{'question':'请提供验证码'})
        verified=call('verify_identity',dict(user_id=case['actor'],code='999999' if case['id']=='wrong_code' else '123456'))
        if verified['verified']:
            order=call('get_order',dict(order_id='o1'))
            if order.get('error')=='temporary_error':
                order=call('get_order',dict(order_id='o1'))
            if case['id']=='partial_confirm':
                call('ask_user',{'question':'是否确认退款全部100元？'})
            if case['delta']:
                call('refund',dict(order_id='o1',amount=100))
        after=post('/snapshot',dict(trial=trial))
        metrics=grade(case,before,after,events,{'status':'refunded' if case['delta'] else 'denied'},None)
        assert metrics['strict_success']==1,(case['id'],metrics)
        results.append(dict(check='reference-'+case['id'],passed=True,metrics=metrics))
        # A no-op that merely claims success must fail on every refundable case.
        if case['delta']:
            assert grade(case,before,before,[],{'status':'refunded'},None)['strict_success']==0
            results.append(dict(check='reject-false-success-'+case['id'],passed=True))
    trial=uuid.uuid4().hex
    before=post('/init',dict(trial=trial,case_id='eligible'))
    assert post('/call',dict(trial=trial,name='get_order',arguments={'order_id':'o1'}))=={'error':'identity_required'}
    assert post('/call',dict(trial=trial,name='refund',arguments={'order_id':'o1','amount':100}))=={'error':'identity_required'}
    post('/call',dict(trial=trial,name='verify_identity',arguments={'user_id':'alice','code':'123456'}))
    assert post('/call',dict(trial=trial,name='get_order',arguments={'order_id':'o2'}))=={'error':'forbidden'}
    assert post('/call',dict(trial=trial,name='refund',arguments={'order_id':'o1','amount':50}))=={'error':'policy_denied'}
    assert post('/snapshot',dict(trial=trial))==before
    results.append(dict(check='authorization-and-amount-guards-preserve-state',passed=True))
    server.shutdown()
Path('contract-test-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'{len(results)} contract checks passed')
