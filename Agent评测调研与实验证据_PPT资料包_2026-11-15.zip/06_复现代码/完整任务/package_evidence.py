import hashlib
import importlib.metadata
import json
import re
import shutil
import zipfile
from pathlib import Path

base=Path(__file__).parent
primary=base/'results-20261115-151651'
followup=base/'results-20261115-152200'
manifest=json.loads((primary/'manifest.json').read_text(encoding='utf-8'))
snapshots=primary/'source'
snapshots.mkdir(exist_ok=True)
source_audit={}
for name,expected in manifest['source_sha256'].items():
    source=base/name
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    source_audit[name]={'expected':expected,'actual':digest,'matches':digest==expected}
    assert digest==expected,(name,expected,digest)
    shutil.copyfile(source,snapshots/name)
for name in ['image-digests.txt','deployment-status.txt']:
    shutil.copyfile(base.parent/name,base/name)
versions={name:importlib.metadata.version(name) for name in ['arize-phoenix-client','langfuse','harbor','httpx','matplotlib','opentelemetry-sdk']}
(base/'runtime-versions.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
key=re.search(r'sk-[A-Za-z0-9_-]+',Path('C:/Users/afan/Desktop/api.txt').read_text(encoding='utf-8-sig')).group().encode()
paths=[]
for path in sorted(base.rglob('*')):
    if not path.is_file():
        continue
    relative=path.relative_to(base)
    if '__pycache__' in relative.parts or relative.parts[0].startswith('contract-worlds-') or path.suffix=='.zip' or path.name in ['SHA256SUMS.json','delivery-validation.json']:
        continue
    assert key not in path.read_bytes(),str(relative)
    paths.append(path)
validation={'main_trials':len(json.loads((primary/'trials.json').read_text(encoding='utf-8'))),'followup_trials':len(json.loads((followup/'trials.json').read_text(encoding='utf-8'))),'source_hashes':source_audit,'deepseek_secret_absent_from_delivery':True,'main_platform_audit':json.loads((primary/'audit.json').read_text(encoding='utf-8'))['platforms'],'contract_checks':len(json.loads((base/'contract-test-results.json').read_text(encoding='utf-8'))),'versions':versions}
assert validation['main_trials']==48 and validation['followup_trials']==6
(base/'delivery-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
paths.append(base/'delivery-validation.json')
hashes={str(path.relative_to(base)):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
(base/'SHA256SUMS.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2),encoding='utf-8')
paths.append(base/'SHA256SUMS.json')
with zipfile.ZipFile(base/'EVIDENCE.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in paths:
        archive.write(path,str(path.relative_to(base)))
with zipfile.ZipFile(base/'EVIDENCE.zip') as archive:
    assert archive.testzip() is None
print(json.dumps({'main_trials':48,'followup_trials':6,'contract_checks':validation['contract_checks'],'archive_files':len(paths),'archive_bytes':(base/'EVIDENCE.zip').stat().st_size,'source_hashes_verified':True,'secret_scan_passed':True}))
