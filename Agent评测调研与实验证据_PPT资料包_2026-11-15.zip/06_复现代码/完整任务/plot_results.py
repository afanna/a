import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

root=Path('results-20261115-151651')
summary=json.loads((root/'summary.json').read_text())
variants=['full_budget6','short_budget2']
labels=['6-turn budget','2-turn budget']
fig,axes=plt.subplots(1,3,figsize=(15,4.5),layout='constrained')
x=np.arange(2)
for offset,(key,label,color) in enumerate([('outcome_correct','Database outcome','#6495c6'),('strict_successes','Full contract','#287852'),('judge_passes','LLM judge','#d28a32')]):
    values=[summary[v][key]/24*100 for v in variants]
    bars=axes[0].bar(x+(offset-1)*.24,values,width=.24,label=label,color=color)
    axes[0].bar_label(bars,labels=[f'{value:.1f}%' for value in values],fontsize=8,padding=3)
axes[0].set(xticks=x,xticklabels=labels,ylim=(0,117),ylabel='Pass rate (%)',title='A. Different graders, same trials')
axes[0].legend(loc='upper right',fontsize=8)
cases=list(summary[variants[0]]['cases'])
matrix=np.array([[summary[v]['cases'][case]['strict_successes'] for case in cases] for v in variants])
axes[1].imshow(matrix,cmap='YlGn',vmin=0,vmax=3,aspect='auto')
for i in range(2):
    for j in range(8):
        axes[1].text(j,i,f'{matrix[i,j]}/3',ha='center',va='center',color='white' if matrix[i,j]>=2 else 'black')
axes[1].set(xticks=range(8),xticklabels=cases,yticks=range(2),yticklabels=labels,title='B. Full-contract success by scenario')
plt.setp(axes[1].get_xticklabels(),rotation=55,ha='right',fontsize=8)
agent=[sum(summary[v]['token_totals'][k] for k in ['agent_input_tokens','agent_output_tokens']) for v in variants]
judge=[sum(summary[v]['token_totals'][k] for k in ['judge_input_tokens','judge_output_tokens']) for v in variants]
axes[2].bar(x,agent,label='Agent',color='#6495c6')
axes[2].bar(x,judge,bottom=agent,label='Judge',color='#d28a32')
for i in range(2):
    axes[2].text(i,agent[i]+judge[i]+1500,f'{agent[i]+judge[i]:,}',ha='center',fontsize=9)
axes[2].set(xticks=x,xticklabels=labels,ylabel='API-reported input + output tokens',title='C. Token usage (cached input included)',ylim=(0,110000))
axes[2].legend(fontsize=8)
fig.suptitle('Refund HTTP Agent: 8 scenarios x 3 repeats x 2 budgets (48 measured trials)',fontsize=12)
fig.savefig(root/'results-figure.png',dpi=220)
fig.savefig(root/'results-figure.pdf')
print('Saved results-figure.png and results-figure.pdf')
