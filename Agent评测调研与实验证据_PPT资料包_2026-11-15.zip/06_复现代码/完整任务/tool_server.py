"""Actual loopback HTTP tools backed by isolated per-trial SQLite databases."""
import json
import sqlite3
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from fixtures import BY_ID

class Worlds:
    def __init__(self,root):
        self.root=Path(root)
        self.sessions={}
        self.lock=threading.Lock()
    def init(self,trial,case_id):
        case=BY_ID[case_id]
        with sqlite3.connect(self.root/(trial+'.sqlite')) as db:
            db.execute('create table orders(id text primary key,owner text,status text,amount integer,refunded integer,note text)')
            db.executemany('insert into orders values(?,?,?,?,?,?)',[('o1','alice',case['state'],100,0,case.get('note','')),('o2','carol','paid',999,0,'')])
        self.sessions[trial]={'case':case,'verified':False,'injected':False,'confirmed':case['id']!='partial_confirm'}
        return self.snapshot(trial)
    def snapshot(self,trial):
        with sqlite3.connect(self.root/(trial+'.sqlite')) as db:
            return {r[0]:dict(owner=r[1],status=r[2],amount=r[3],refunded=r[4]) for r in db.execute('select * from orders order by id')}
    def call(self,trial,name,args):
        session=self.sessions[trial]
        case=session['case']
        if name=='ask_user':
            if case.get('reply'):
                session['confirmed']=True
            return {'reply':case.get('reply','信息已在最初请求中提供，请按政策处理。')}
        if name=='verify_identity':
            session['verified']=args.get('code')=='123456' and args.get('user_id')==case['actor']
            return {'verified':session['verified']}
        if not session['verified']:
            return {'error':'identity_required'}
        with sqlite3.connect(self.root/(trial+'.sqlite')) as db:
            row=db.execute('select * from orders where id=?',(args.get('order_id'),)).fetchone()
            if row is None:
                return {'error':'not_found'}
            if row[1]!=case['actor']:
                return {'error':'forbidden'}
            if name=='get_order':
                if case.get('transient') and not session['injected']:
                    session['injected']=True
                    return {'error':'temporary_error','retryable':True}
                return dict(id=row[0],status=row[2],amount=row[3],refunded=row[4],merchant_note=row[5])
            if name=='refund':
                if row[2]!='paid' or row[4] or args.get('amount')!=row[3] or not session['confirmed']:
                    return {'error':'policy_denied'}
                db.execute('update orders set refunded=1 where id=?',(row[0],))
                return {'success':True,'order_id':row[0],'amount':row[3]}
        return {'error':'unknown_tool'}

def start_server(root):
    worlds=Worlds(root)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):
            pass
        def do_POST(self):
            body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            with worlds.lock:
                if self.path=='/init':
                    result=worlds.init(body['trial'],body['case_id'])
                elif self.path=='/snapshot':
                    result=worlds.snapshot(body['trial'])
                elif self.path=='/call':
                    result=worlds.call(body['trial'],body['name'],body['arguments'])
                else:
                    self.send_error(404)
                    return
            data=json.dumps(result,ensure_ascii=False).encode()
            self.send_response(200)
            self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(data)))
            self.end_headers()
            self.wfile.write(data)
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    return server
