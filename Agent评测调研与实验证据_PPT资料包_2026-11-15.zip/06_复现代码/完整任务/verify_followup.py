import json
from pathlib import Path
import httpx

root=Path('results-20261115-152200')
summary=json.loads((root/'followup-summary.json').read_text(encoding='utf-8'))
config=dict(line.split('=',1) for line in (Path(__file__).parent.parent/'langfuse.env').read_text().splitlines() if '=' in line)
auth=(config['LANGFUSE_INIT_PROJECT_PUBLIC_KEY'],config['LANGFUSE_INIT_PROJECT_SECRET_KEY'])
http=httpx.Client(trust_env=False,timeout=30)
checks=[]
for experiment in summary['langfuse']:
    response=http.get('http://127.0.0.1:3000/api/public/experiment-items',params={'fromStartTime':'2026-11-15T00:00:00Z','experimentId':experiment['experiment_id'],'fields':'core,io,scores','limit':100},auth=auth)
    response.raise_for_status()
    rows=response.json()['data']
    assert len(rows)==3
    assert sum(len(r['scores']) for r in rows)==21
    assert all(s['value']==1 for r in rows for s in r['scores'])
    checks.append({'experiment_id':experiment['experiment_id'],'rows':rows,'all_seven_scores_equal_one':True})
(root/'langfuse-followup-audit.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print('Follow-up verified: 6 runs and 42 scores in each platform.')
