from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'07_来源与校验/SHA256SUMS.json').read_text(encoding='utf-8'))
failed=[]
for name,expected in manifest.items():
    path=root/name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        failed.append(name)
print(f'{len(manifest)-len(failed)}/{len(manifest)} files verified')
if failed:
    print(failed)
    raise SystemExit(1)
