# Phase_2x4 —— wide（2x4）模板误触发入参集

只测一件事：**wide 模板会不会被用到它不该出现的地方**。因为当前引擎入口对 `size=="2x4"` 直接关闭模板路由
（`pipeline.py:110` 抛 `TemplateRouteNotApplicable`，且有测试锁死"必须在调用模型之前拒绝"），
Search 层同样拒绝（`template_retrieval.py:678-681`），所以端到端跑 2x4 时"没出模板"是必然结果，
真正的风险面是 **wide 模板越尺寸被用到 2x2**。

## 组成：9 个 wide 模板 × 4 组 = 36 条

| 组 | size | 候选出参 | 判分口径 |
| --- | --- | --- | --- |
| `W1-full-2x4` | 2x4 | 目标模板 required 全给 | 出现任何业务模板 = 尺寸越界（当前实现应 0 命中） |
| `W2-missing-required-2x4` | 2x4 | 故意缺一个 required | 同上；用来排除"只因缺字段才没出模板"的解释 |
| `W3-full-2x2` | 2x2 | 与 W1 同一字段集 | 该 wide 模板出现 = 误触发 |
| `W4-sibling-2x2` | 2x2 | 与 W1 同一字段集 | 只准出同族 2x2 变体；wide 出现 = 误触发 |

wide 模板来自真实注册表 `supported_card_sizes` 含 2x4 的业务模板：

- `ActivityOverviewWideFull@1`、`ActivityOverviewWideHero@1`
- `BatteryOverviewWideFull@1`
- `BluetoothDeviceOverviewCompleteWideFull@1`、`...CompletePhoneWideFull@1`、`...EarbudsDynamicWideFull@1`、`...EarbudsPhoneWideFull@1`
- `ScheduleOverviewMeetingWideFull@1`、`ScheduleOverviewMeetingSourceWideFull@1`

## 文件

- `W001.json` … `W036.json`：可直接提交的 TaskSpec 入参（形状与 `template_misfire` 一致：`content` + 顶层镜像 + `deviceInfo/pagination/session/userAuth/utterance/version`，`prdVer=11.9.9.342`、`romVersion=7.0`）
- `wide_2x4_expected.json`：每条的 `kind / size / targetTemplateId / requiredPathsOfTarget / candidateOutputFields / sameFamily2x2 / forbidden` 与判分口径
- 生成器：`../build_2x4_set.py`（改模板清单后重跑即可再生成）

## 话术约定（2026-10-06 改版）

`userQuery` **不出现"2x4 / 2x2 / 尺寸"任何字样**，尺寸只由载荷里的 `size` 字段表达；写法参照 `../Phase 1` 里 36 条 2x4 用例的真实口吻——先给场景，再列要看的内容块，例如：

```
今天目标走8000步，帮我做个活动卡片，看步数、走了多远、消耗多少热量、目标完成度，还有最近一次运动是什么时候做的。
```

`title` / `description` 同步换成业务命名（旧版的 `今日活动2x4 | 今日活动信息` 属元语言，已废弃）。生成器 `../build_2x4_set.py` 带自检：话术或标题夹带尺寸字样、"生成一张静态卡片/展示X信息"这类元语言就直接中止，写不出脏数据。

信息量按 2x4 铺满给：候选出参 = 目标 wide 模板自己的槽位 + 同业务族其他模板能渲染的字段并集（都是清单声明的合法叶子，上限 12 个）。实测各 wide 模板字段数：`ScheduleOverviewMeeting*` 12、`BatteryOverviewWideFull` 11、`BluetoothDeviceOverview*WideFull` 8、`ActivityOverviewWide*` 4（活动族在该能力下只声明 4 个可渲染槽位，再多就是模板渲染不了的字段）。字段门只比对 `candidateOutputFields` 与 `dataModelSchema`，自然语言不参与准入判定（已在 `template_retrieval.py` 核实），所以判分不受措辞影响。

## 已做的预检（2026-10-06 重生成后，不会因入参问题被拒）

- `node ../verify_declared.mjs Phase_2x4` → 36 条，出参/入参/素材全部在 rom-7.0 清单声明：**0 问题**
- `python ../check_service_rejection.py --dir=Phase_2x4` → 请求模型 / 清单解析 / 生产 preflight 三层：**0 拒绝**
- 生成器自检：尺寸字样 0 条、元语言 0 条；每条 `W2` 都比同模板 `W1` 少一个必填字段

## 怎么跑与怎么回传

在你那边提交（协议同 `widget_service/tests/pressure_test_ws.py`：`ws://<host>:<port>/api/v1/ws/tools/generateWidgetCardCompactDsl`，包络即本目录里的 json 本身）：

```powershell
cd C:\Users\afan\Desktop\卡片\query\CreateMyCard230\taskspec
python run_ws_batch.py --host <你的服务地址> --port 8855 --dir Phase_2x4 --concurrency 2
python score_ws_run.py --run wsrun_Phase_2x4_<时间戳>
```

如果你用自己的工具跑，只要把每条结果放回 `wsrun_xxx/responses/`，两种格式都能判分：

- `W001.json`（含 `streamContent`，可带 `errorCode/errorMessage`），或
- `W001.txt` / `W001.dsl`：只放返回的 DSL 文本

判分器用真实注册表的业务模板全集识别 `Template("<id>@1"`（排除 `card@1`、布局、PillAction/IconAction），按组输出
`PASS / VIOLATION / NOT-TRIGGERED / ERROR` 与误触发率；被拒或传输失败的记为 `ERROR`，不进分母。
每条的 `userQuery` / `title` / `description` 也抄在 `wide_2x4_expected.json` 里，回传后可直接对着文本核查询单是否被措辞带偏。
