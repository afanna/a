# Phase_new_assets — 新素材混池选择回归集（追加 + 模态补齐版）

用途：只测 **DSL 生成层**。输入沿用 `taskspec/Phase_emoji` 的 TaskSpec 双写格式，把 230 新注册的 12 个素材**追加**进各用例原有的 `candidateAssetIds`，考察模型在"旧素材 + 新素材"同池竞争时**选不选得到、选不选对**新素材。

## 与替换版的区别

| | 替换版（v1，已废弃） | 本版（v3，append + balance） |
| --- | --- | --- |
| 候选池 | 只放 1–4 个新素材，旧候选全删 | 旧候选原样保留，按相关性追加 1–2 个新素材，整池 ≤8 |
| 弱相关 | 堆到 2 个/类，135 槽当干扰 | 无正例时才补 1 个最高分弱相关，不硬凑 |
| 新旧同业务 | 看不到（旧素材被删了） | 显式判成"二选一"，选新/选旧都算对，另记倾向 |
| 素材模态 | 无从对比 | 整池单一模态时补至多 2 个缺失模态的对照素材 |
| 能测什么 | 用对/用错/漏用新素材 | 上面三项 + 新素材在旧素材与另一种模态双重挤压下能否被选中 |

源用例（`Phase_emoji`）一个字不改：`userQuery`、数据绑定、事件、尺寸、`deviceInfo` 与旧候选全部原样保留、顺序不动，只有候选列表变长。`Q001–Q088` 与源用例一一对应。

## 覆盖的新素材（12）

- 图片 `emoji_*`（仅允许 2x2 单业务卡片 CardHeader 右上角 20vp 主题图，PNG 保留原色）：
  `emoji_sleep`、`emoji_heartRate`、`emoji_activity`、`emoji_note`、`emoji_notebook`、`emoji_smile`、`emoji_mobileNetwork`
- 矢量 `ic_*`（可作主题图或正文辅助图标，保留注册表原始配色与比例）：
  `ic_weatherWarning`、`ic_charge`、`ic_phone`、`ic_achieve`、`ic_public_connection_filled`

注册表来源：`widget_service/cloud/data/capabilities/app-11.7.7.300_rom-7.0/asset_capabilities.json`（旧 `app-11.7.5.205_rom-6.0` 中不存在这些 ID）。`prdVer` 保持 `11.8.8.342` 才会命中该注册表。池内的 33 个旧素材同样逐个核过都在这份注册表里。

## 追加口径

`build_new_asset_candidates.mjs` 按注册表 `description` 对 12 个新素材逐一打分：**4** 唯一主业务命中 / **3** 可接受 / **1–2** 弱相关（同域但主业务不符，即注册表"不适用"清单点名的误用场景）/ **0** 无关。然后：

1. 按分数降序取 **≥3 分的正例，至多 2 个**；0 分一律不进候选，不用噪声凑配额。
2. 一条 ≥3 分都没有时，只补 **1 个**最高分弱相关当误用考点。
3. 新素材块插入下标按用例号在 `0…旧候选长度` 间轮换，避免恒定排在池尾蹭位置偏好（当前 19/88 条落在尾部）。
4. 弱相关项必须能指到注册表原文的"不适用"条款，例如 `emoji_activity`（"不适用：普通会议、步数与运动活动记录"）、`emoji_mobileNetwork`（"不适用：Wi-Fi、蓝牙"）、`ic_weatherWarning`（"无预警时不应显示"）。
5. `Q089–Q093` 是 5 条补充用例（生日纪念日 / 待办备忘 / 笔记 / 心情寄语 / 移动数据）：Phase_emoji 没有这些业务，这 5 个新 emoji 的硬正例全部来自这里；它们没有源用例旧候选，只可能被模态补齐塞进对照素材。候选同样由打分自然选出，脚本不强制注入任何素材。

## 模态补齐（`LEGACY_FIT`）

整池只有一种模态时（全是 `emoji_*` 写实 PNG，或全是线性 SVG），模型没有"PNG 还是线性图标"这层选择，考点退化成"用哪个表情"。所以再补**至多 2 个缺失模态**的对照素材，整池上限从 7 放到 8：

1. 优先取该模态下**相关性 ≥1 的新素材**，走正常判分通道（`assets[].why = "modality-balance"`）。
2. 不足 2 个再取**旧素材**，且必须命中 `LEGACY_FIT` 中注册表"适用"条款能指到本卡片业务的条目；这类只当对照（`balanceCandidates`），**不判正例也不判误用**，但在白名单内。
3. 两类都找不到就不补，保留单一模态，由 `--audit` 的 `singleModalityAfterBalance` 点名，不塞语义无关的图标凑数。
4. 挤位规则：整池装不下时砍对照项，不砍相关性选出的新素材；实测最大池 7，没有用例顶到 8。

例：`Q003` 发布会提醒（源池 `emoji_clock`/`emoji_calendar`/`emoji_time` 全 PNG）补进 `ic_achieve`（新素材，倒计时弱相关 1 分 → 误用考点）+ `bell_fill`（旧素材，注册表"备忘录提醒、闹钟响铃、日历事项提醒" → 只当对照）。

**注册表决定补不出的两类**：

- 睡眠 / 笔记 / 心情卡：33 个旧素材里没有任何一个在注册表声明适用于这些业务，5 个新 svg 又全是天气预警/充电/拨号/成就/连接，同样不搭 → 只能保持全 PNG。
- 天气 / 电量 / 导航卡：旧素材的 10 个 emoji 是日历、闹钟、耳机、健康、音乐、电话、跑步、时间、睡眠主题，新素材 7 个 emoji 也没有天气或电量的 → 只能保持全 svg。

## 新旧同业务替代关系（`LEGACY_EQUIV`）

以下新素材在源用例的旧候选里存在能表达同一主题的图标。两侧都留在池里，模型选哪边都不算错，但会记录它是"选新"还是"倾向旧素材"——这就是本集要摸的选择倾向。映射逐条对过注册表 `description` 的"适用"条款，不做名字联想。

| 新素材 | 旧素材替代品 | 依据 |
| --- | --- | --- |
| `emoji_sleep` | `emoji_z` | 均"以睡眠、就寝、午休或睡眠时长为唯一主业务" |
| `emoji_heartRate` | `emoji_health` | 均"心率/心脏健康为唯一主业务" |
| `emoji_activity` | `emoji_calendar`、`emoji_calendar2` | 旧日历图可承担生日倒数的主题图，但不表达庆祝语义 |
| `ic_charge` | `bolt_fill` | 均"正在充电/充电器连接" |
| `ic_phone` | `emoji_phone1` | 均"拨号、联系人呼叫" |
| `ic_achieve` | `emoji_run` | 运动目标/成果主题，`emoji_run` 亦可 |
| `ic_public_connection_filled` | `earphone_case_16644`、`emoji_earphone` | 设备互联与连接状态说明 |

故意**不**列为替代品：`ic_weatherWarning` vs `typhoon_fill`（台风图只在台风预警时正确，暴雨等场景选台风仍算误用，交人工复核）、`emoji_note` vs `bell_fill`（铃铛是"提醒"语义，不是清单本体）。

## 产物字段

| 字段 | 说明 |
| --- | --- |
| `legacyCandidates` | 源用例原有候选，已原样保留、顺序不动 |
| `newCandidates` | 池内新素材（按池内顺序导出） |
| `balanceCandidates` | 模态补齐进来的旧素材，带 `quote`（注册表原文依据），不判分 |
| `modality` | 该池模态：`png`、`svg` 或 `png+svg` |
| `insertedAt` | 追加块插入池中的下标（轮换，避免恒定池尾） |
| `assets[]` | 只描述新素材：`score`/`role`/`expect`/`reason`/`why`，alt 项另带 `altWith` |
| `expectedUse` | 硬性正例：产物必须出现其 `src`，否则判**漏用** |
| `altGroups[]` | 二选一：`anyOf`（新素材 + 同业务旧素材）任一出现即不算漏用 |
| `expectedOptional` | 被降级为 alt 的新素材，用了算"选新"，不用不算漏用 |
| `expectedAbsent` | 禁用项：其 `src` 出现在 `Image.src` 或 `backgroundImage` 即判**误用** |

`role` 取值：`fit` 命中主业务（硬正例）、`alt` 新旧同业务二选一、`near` 近义误用、`size-gated` 尺寸越界（2x4 用了 2x2 专属 emoji）、`multi-business-gated` 多业务卡片用了单业务专属 emoji、`fit-conflict` 一图限一主题。`why` 取值：`relevance`（相关性通道选入）或 `modality-balance`（为补模态选入）。

## 判分

对每条用例，按 **src 路径**匹配（`resources/base/media/<file>`），不按 asset id——asset id 只存在于 TaskSpec 侧。

1. `expectedUse` 每一项都必须出现，否则**漏用**。
2. `altGroups` 每组 `anyOf` 至少命中一条路径，否则**漏用**；只命中 `legacy` 项记为**倾向旧素材**（选对但未选新），不计误用；命中 `newAsset` 记为**选新**。这组统计是本集要摸的"选择倾向"，不计入通过率。
3. `expectedAbsent` 任何一项出现即**误用**。
4. **越白名单**：产物出现不在该条 `candidateAssetIds`（旧素材 + 新素材 + 对照素材）内的任何素材路径。
5. 旧素材（`legacyCandidates` 与 `balanceCandidates`）本身用得好不好不判分，只作干扰、对照与倾向统计。

仍需人工看：20vp 下是否可辨识、写实 PNG 与线性 SVG 混用是否违和、`emoji_*` 是否被放大成背景图、旧 2x2 专属 emoji 是否被放进 2x4（源用例遗留问题，如 `Q063` 池内 `emoji_z`/`emoji_clock`）。

## 重新生成与校验

```powershell
node .\CreateMyCard230\taskspec\Phase_new_assets\build_new_asset_candidates.mjs          # 生成
node .\CreateMyCard230\taskspec\Phase_new_assets\build_new_asset_candidates.mjs --audit   # 只审计相关性与模态补齐，不写文件
node .\CreateMyCard230\taskspec\Phase_new_assets\check_new_asset_candidates.mjs           # 校验
```

校验器检查：`content` 与顶层候选一致、整池 1–8、新素材 1–4（相关性 ≤2 + 补模态 ≤2）、**源用例旧候选原样保留且顺序不动**（追加而非替换的核心不变量）、除候选外与源用例零漂移、`modality` 与池内实际文件类型一致、对照素材必须带注册表原文依据且不得出现在任何判分集合里、新素材三分类恰好覆盖池内新素材、alt 组两端都在池内且不与正例/禁用冲突、无 0 分凑数、相关性通道无正例时至多 1 个弱相关、每条至多一个 emoji 判硬正例、2x4 不硬性期望也不给 alt emoji、12 个素材都有正例（含 alt）。

## 当前分布（93 条 / 池 422 槽 = 旧 291 + 新 115 + 对照旧 16）

- 模态：**混池 76 条**、纯 SVG 11 条、纯 PNG 6 条（补齐前为 61 / 11 / 21）。
- 对照素材 22 槽：新素材 6 槽（走判分）+ 旧素材 16 槽（不判分）。旧素材频次：`bell_fill` 12、`flame_fill` 2、`earphone_case_16644` 1、`cold` 1。
- 池规模：1 个 2 条、2 个 4 条、3 个 13 条、4 个 18 条、5 个 38 条、6 个 15 条、7 个 3 条、8 个 0 条。
- 新素材槽 115：4 分 45、3 分 28、弱相关 42；硬正例 25 槽、alt 41 槽、误用考点 49 槽。
- 20 条有硬正例，73 条只考"不该用什么"或"二选一"；40 条发生新旧同业务撞车（41 组）。
- 正例条数（含 alt）：`ic_charge` 19、`ic_achieve` 14、`ic_public_connection_filled` 11、`ic_weatherWarning` 8、`emoji_sleep` 4、`ic_phone` 4，其余 6 个各 1（`emoji_heartRate`、`emoji_activity`、`emoji_note`、`emoji_notebook`、`emoji_smile`、`emoji_mobileNetwork`）。

## 已知薄弱点

- **17 条补不齐模态**（注册表里没有对应业务的另一种模态图标）：纯 SVG 的 `Q001`/`Q010`/`Q016`/`Q032`/`Q034`/`Q040`/`Q044`/`Q062`/`Q074`/`Q076`/`Q080`（天气、电量、导航），纯 PNG 的 `Q012`/`Q036`/`Q038`/`Q069`（睡眠）与 `Q091`/`Q092`（笔记、心情）。要让这 17 条也有对照只能塞语义无关的图标，本集不做。
- 对照旧素材高度集中在 `bell_fill`（16 槽占 12），因为注册表里唯一百搭的线性图标就是"提醒/闹钟/备忘录"。看结果时别把它当普遍现象。
- `emoji_sleep`、`emoji_heartRate`、`ic_achieve` 的正例**全部**落在 alt 组（硬正例 0 条）：旧池里几乎总同时有 `emoji_z`/`emoji_health`/`emoji_run`。这三条只能靠倾向统计判断"新素材有没有被选中"，判分脚本不会报漏用。
- 5 个新 emoji（`activity`/`note`/`notebook`/`smile`/`mobileNetwork`）的正例各只有 1 条，全部来自 `Q089–Q093`，单条波动即影响结论。要补就补自然用例，不要改老用例的 query。
