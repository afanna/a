# Phase_new_assets — 新增素材 DSL 生成回归集

用途：只测 **DSL 生成层**。输入沿用 `taskspec/Phase_emoji` 的 TaskSpec 双写格式，把 `candidateAssetIds` 换成 230 新注册的 12 个素材，用来判定模型是否"用对 / 用错 / 漏用"新素材。候选一律按与 query 的相关性取料，**不放与业务无关的素材凑数**。

## 覆盖的新素材（12）

- 图片 `emoji_*`（仅允许 2x2 单业务卡片 CardHeader 右上角 20vp 主题图，PNG 保留原色）：
  `emoji_sleep`、`emoji_heartRate`、`emoji_activity`、`emoji_note`、`emoji_notebook`、`emoji_smile`、`emoji_mobileNetwork`
- 矢量 `ic_*`（可作主题图或正文辅助图标，保留注册表原始配色与比例）：
  `ic_weatherWarning`、`ic_charge`、`ic_phone`、`ic_achieve`、`ic_public_connection_filled`

注册表来源：`widget_service/cloud/data/capabilities/app-11.7.7.300_rom-7.0/asset_capabilities.json`（旧 `app-11.7.5.205_rom-6.0` 中不存在这些 ID）。`prdVer` 保持 `11.8.8.342` 才会命中该注册表。

## 组成

| 范围 | 条数 | 说明 |
| --- | --- | --- |
| Q001–Q088 | 88 | 与 `Phase_emoji` 一一对应，`userQuery`/数据绑定/事件/尺寸/`deviceInfo` 全部不动，只换候选素材 |
| Q089–Q093 | 5 | 补充用例：`Phase_emoji` 场景里没有"生日纪念日 / 待办备忘 / 笔记 / 心情寄语 / 移动数据"业务，这 5 个新 emoji 换候选后正例仍为 0，各补 1 条自然口语用例。候选同样由打分自然选出，脚本不强制注入任何素材 |

## 每条用例的候选构成

`build_new_asset_candidates.mjs` 按注册表 `description` 对 12 个新素材逐一打分：**4** 唯一主业务命中 / **3** 可接受 / **1–2** 弱相关（同域但主业务不符，即注册表"不适用"清单点名的误用场景）/ **0** 无关。**只保留 ≥1 分的候选，每类至多 2 个，总数 1–4 个**，0 分一律不入候选；分数相同再按已用次数均衡轮换，候选顺序按用例号交替，避免模型蹭位置偏好。

当前分布：208 个候选槽 = 强相关 73 + 弱相关 135 + 无关 **0**；每条 1 候选 26 条、2 候选 26 条、3 候选 34 条、4 候选 7 条。只有 1 个相关素材就用 1 个，不硬配第二项。

弱相关项必须能指到注册表原文的"不适用"条款，例如 `emoji_activity`（17 条，全部来自"不适用：普通会议、步数与运动活动记录"）、`emoji_mobileNetwork`（16 条，来自"不适用：Wi-Fi、蓝牙"）、`ic_weatherWarning`（17 条，来自"无预警时不应显示"）。曾有 3 处伪相关已收紧为 0 分：`emoji_notebook` 蹭"泛信息摘要"进天气卡、`ic_phone` 蹭日程详情与导航、`ic_public_connection_filled` 蹭拨号。

39 条用例没有任何命中项（模型正确行为是整卡不用新素材），这类是"抗误用"用例；另有 2x4 用例放入同业务 emoji（如 `Q063` 睡眠闹钟 → `emoji_sleep`），它相关但被 2x2 尺寸闸门拦住，是尺寸越界考点而非凑数。

## 判分

`new_assets_expected.json` 的 `cases[]` 给出每条用例每个素材的期望：

- `expect: true` → 产物中必须出现其 `resources/base/media/<file>` 路径，否则判**漏用**
- `expect: false` → 该路径出现在 `Image.src` 或 `backgroundImage` 即判**误用**
- `role` 标明期望来源：`fit` 命中主业务、`near` 近义误用、`size-gated` 尺寸越界（2x4 用了 2x2 专属 emoji）、`multi-business-gated` 多业务卡片用了单业务专属 emoji、`fit-conflict` 一图限一主题
- 断言按 **src 路径**匹配，不按 asset id（asset id 只存在于 TaskSpec 侧）
- 产物出现 `expectedUse` 与 `expectedAbsent` 之外的任何素材路径，即判越白名单（编造或凭记忆补图）

仍需人工看：20vp 下是否可辨识、写实 PNG 与线性 SVG 混用是否违和、`emoji_*` 是否被放大成背景图。

## 重新生成与校验

```powershell
node .\CreateMyCard230\taskspec\Phase_new_assets\build_new_asset_candidates.mjs          # 生成
node .\CreateMyCard230\taskspec\Phase_new_assets\build_new_asset_candidates.mjs --audit   # 只审计相关性，不写文件
node .\CreateMyCard230\taskspec\Phase_new_assets\check_new_asset_candidates.mjs           # 校验
```

校验器检查：`content` 与顶层候选一致、每条 1–4 个候选且每类至多 2 个、**无任何 0 分凑数候选**、素材全在 rom-7.0 注册表内、Q001–Q088 除候选外与源用例零漂移、每条至多一个 emoji 判正例、2x4 不期望 emoji、12 个素材都有正例。

## 已知薄弱点

`emoji_heartRate` 只有 1 条正例（`Q015` 心率复盘，来自 Phase_emoji），另有 10 条把它当弱相关干扰项。若这一条判分波动大，再单独补自然正例，不要为凑数改老用例的 query。
