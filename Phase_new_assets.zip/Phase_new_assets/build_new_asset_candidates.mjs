import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const srcRoot = path.resolve(here, "..", "Phase_emoji");
const registry = path.resolve(
  here,
  "..",
  "..",
  "widget_service",
  "cloud",
  "data",
  "capabilities",
  "app-11.7.7.300_rom-7.0",
  "asset_capabilities.json"
);

const NEW_EMOJI = [
  "asset.emoji_sleep",
  "asset.emoji_heartRate",
  "asset.emoji_activity",
  "asset.emoji_note",
  "asset.emoji_notebook",
  "asset.emoji_smile",
  "asset.emoji_mobileNetwork"
];
const NEW_SVG = [
  "asset.ic_weatherWarning",
  "asset.ic_charge",
  "asset.ic_phone",
  "asset.ic_achieve",
  "asset.ic_public_connection_filled"
];

const SLEEP_FIELDS = [
  "/sleepScore",
  "/sleepStatus",
  "/nightSleepDurationText",
  "/deepSleepDurationText",
  "/totalNapDurationText",
  "/fallAsleepTimeText",
  "/wakeupTimeText"
];
const HEART_FIELDS = ["/exerciseHeartRateAvg", "/exerciseHeartRateMax", "/exerciseHeartRateMin"];
const STEP_FIELDS = ["/dailySteps", "/dailyTotalCaloriesText", "/dailyDistanceText"];
const EXERCISE_FIELDS = [
  "/exerciseTypeName",
  "/exerciseStartTimeText",
  "/exerciseEndTimeText",
  "/exerciseDurationText",
  "/exerciseCalorieText"
];
const CHARGE_FIELDS = ["/chargingStatusDesc", "/pluggedTypeDesc", "/nowCurrentText", "/voltageText"];

const has = (list, subset) => subset.some((x) => list.includes(x));

function profileOf(spec) {
  const bindings = spec.candidateDataBindings ?? [];
  const caps = bindings.map((b) => b.capabilityId);
  const fields = bindings.flatMap((b) => b.candidateOutputFields ?? []);
  const events = (spec.candidateEventCandidates ?? []).map((e) => e.capabilityId);
  const q = (spec.userQuery ?? "").replace(/\s+/g, "");
  return {
    caps,
    fields,
    events,
    q,
    size: spec.size,
    singleBusiness: new Set(caps).size <= 1,
    weather: caps.includes("ViewWeather"),
    weatherAlert: fields.includes("/current/alertLevel"),
    calendar: caps.includes("GetCalendarEvents"),
    countdown: caps.includes("GetCountdownDays"),
    sleep: has(fields, SLEEP_FIELDS),
    heart: has(fields, HEART_FIELDS),
    steps: has(fields, STEP_FIELDS),
    exercise: has(fields, EXERCISE_FIELDS),
    earphone: caps.includes("GetEarphoneInfo"),
    battery: caps.includes("GetPhoneBatteryInfo"),
    charge: has(fields, CHARGE_FIELDS),
    call: events.includes("event.call.phone"),
    bluetooth: events.some((e) => /bluetooth/i.test(e)),
    mobileNet: events.some((e) => /mobileData|MobileData|dataUsage|simManagement|hotspot|mobileNetwork/i.test(e)),
    joinMeeting: events.some((e) => /enter\.meeting/i.test(e)),
    music: events.some((e) => /music/i.test(e)),
    noteWords: /待办|清单|备忘|任务步骤|事项|步骤|要买|买东西|购物|记下来|要做的事/.test(q),
    noteBookWords: /笔记|学习|复习|要点|知识点|提纲|读后感/.test(q),
    smileWords: /寄语|心情|鼓励|问候|祝福|早安|晚安|加油|微笑|给自己/.test(q),
    celebrateWords: /生日|纪念日|庆祝|庆典|周年/.test(q),
    goalWords: /目标|达成|完成度|打卡|成果|纪录/.test(q)
  };
}

const RULES = {
  "asset.ic_weatherWarning": (p) => (!p.weather ? 0 : p.weatherAlert ? 4 : 1),
  "asset.ic_charge": (p) =>
    p.battery && p.charge ? 4 : p.battery ? 3 : p.earphone && p.charge ? 2 : p.earphone ? 1 : 0,
  "asset.ic_phone": (p) => (p.call ? 4 : p.joinMeeting ? 1 : 0),
  "asset.ic_achieve": (p) =>
    p.steps && p.goalWords ? 4 : p.exercise ? 3 : p.steps ? 3 : p.heart ? 2 : p.countdown ? 1 : 0,
  "asset.ic_public_connection_filled": (p) =>
    p.mobileNet ? 4 : p.bluetooth ? 3 : p.earphone && /是否连接|连接状态/.test(p.q) ? 3 : 0,
  "asset.emoji_sleep": (p) =>
    p.sleep && p.singleBusiness ? 4 : /sleepMode/i.test(p.events.join()) ? 4 : p.sleep ? 2 : 0,
  "asset.emoji_heartRate": (p) => (p.heart && p.singleBusiness && !p.music ? 4 : p.heart ? 2 : p.exercise || p.steps ? 1 : 0),
  "asset.emoji_activity": (p) =>
    (p.countdown || p.calendar) && p.celebrateWords && p.singleBusiness ? 4 : p.countdown || p.calendar || p.steps ? 1 : 0,
  "asset.emoji_note": (p) => (p.noteWords && !p.calendar ? 4 : p.calendar ? 1 : 0),
  "asset.emoji_notebook": (p) => (p.noteBookWords && !p.calendar ? 4 : p.calendar ? 1 : 0),
  "asset.emoji_smile": (p) => (p.smileWords ? 4 : p.call && p.weather ? 2 : p.steps || p.exercise ? 1 : 0),
  "asset.emoji_mobileNetwork": (p) =>
    p.mobileNet && p.singleBusiness ? 4 : p.mobileNet ? 3 : p.bluetooth || p.earphone ? 1 : 0
};

const REASON = {
  fit: "命中注册表声明的唯一主业务，应被使用",
  "fit-emoji": "命中注册表声明的唯一主业务，应作为 2x2 CardHeader 右上角 20vp 主题图，PNG 保留原色",
  "fit-svg": "命中注册表声明的唯一主业务，可作为 CardHeader 主题图或正文辅助图标，保留注册表声明的配色与比例",
  "fit-conflict": "一张卡片只允许一个主题图，次高匹配素材应舍弃",
  "size-gated": "该素材仅限 2x2 卡片，当前尺寸 2x4，出现即判误用",
  "multi-business-gated": "该素材要求单业务卡片，当前卡片承载多个主业务，出现即判误用",
  near: "近义干扰：注册表声明的主业务与本卡片不符，出现即判误用",
  off: "白名单噪声：与本卡片业务无关，出现即判误用"
};

function pick(pool, p, used) {
  return [...pool]
    .map((id) => ({ id, score: RULES[id](p) }))
    .sort((a, b) => b.score - a.score || used[a.id] - used[b.id] || a.id.localeCompare(b.id));
}

function roleOf(score, p, id) {
  if (score < 3) return score >= 1 ? "near" : "off";
  if (id.startsWith("asset.emoji_")) {
    if (p.size !== "2x2") return "size-gated";
    if (!p.singleBusiness) return "multi-business-gated";
  }
  return "fit";
}

// Phase_emoji 的场景覆盖里没有这些业务，导致 5 个新 emoji 一条正例都拿不到，各补 1 条自然口语用例。
// 候选不做任何强制注入，仍由 RULES 打分自然选出，模型选错就是选错。
const COUNTDOWN = (targetDate) => ({
  capabilityId: "GetCountdownDays",
  arguments: { targetDate },
  writeResultTo: "/data/countdown",
  candidateOutputFields: ["/countdownDays"]
});

const EXTRA_CASES = [
  {
    name: "Q089",
    title: "妈妈生日倒数",
    description: "生日倒数与拨号",
    userQuery: "帮我做个卡片，10月6日是妈妈生日，看看还有几天，点一下直接给妈妈打电话，号码是13888888888。",
    bindings: [COUNTDOWN("2026-10-06")],
    events: [
      {
        capabilityId: "event.call.phone",
        action: { call: "clickToApi", args: { intentName: "CallPhone", params: { phoneNumber: "13888888888" } } }
      }
    ]
  },
  {
    name: "Q090",
    title: "购物清单",
    description: "静态购物清单",
    userQuery: "帮我做个卡片，把周末要买的东西记下来：牛奶、鸡蛋、抽纸。",
    bindings: [],
    events: []
  },
  {
    name: "Q091",
    title: "读书笔记",
    description: "静态笔记摘要",
    userQuery: "帮我把这周的读书笔记做成卡片，内容是《红楼梦》前三章的人物关系、宝黛初会和林家背景。",
    bindings: [],
    events: []
  },
  {
    name: "Q092",
    title: "给自己的话",
    description: "静态心情寄语",
    userQuery: "帮我做个卡片，放一句给自己的话：慢慢来，比较快。",
    bindings: [],
    events: []
  },
  {
    name: "Q093",
    title: "移动数据",
    description: "移动数据切换",
    userQuery: "帮我做个卡片，出门没网的时候一键开移动数据。",
    bindings: [],
    events: [
      { capabilityId: "event.setMobileData", action: { call: "clickToApi", args: { intentName: "SetMobileData", params: { switchFlag: 0 } } } }
    ]
  }
];

function envelopeFor(entry, template) {
  const content = {
    bundleName: "com.omega_w_0823.hmservice",
    userQuery: entry.userQuery,
    candidateDataBindings: entry.bindings,
    title: entry.title,
    size: "2x2",
    candidateEventCandidates: entry.events,
    description: entry.description,
    candidateAssetIds: []
  };
  const clone = JSON.parse(JSON.stringify(template));
  clone.content = content;
  clone.session.interactionId = entry.name.slice(1);
  clone.utterance.original = entry.userQuery;
  for (const key of Object.keys(content)) clone[key] = content[key];
  return clone;
}

const registryIds = new Set(JSON.parse(fs.readFileSync(registry, "utf8")).map((a) => a.id));
for (const id of [...NEW_EMOJI, ...NEW_SVG]) {
  if (!registryIds.has(id)) throw new Error(`素材未在 rom-7.0 注册表: ${id}`);
}

const used = Object.fromEntries([...NEW_EMOJI, ...NEW_SVG].map((id) => [id, 0]));
const cases = [];
let conflicts = 0;

function emit(name, raw, origin) {
  const spec = JSON.parse(raw);
  const envelope = spec;
  const p = profileOf(spec.content);
  // 只取与 query 业务相关的候选（score>=1），每类至多 2 个；不补 0 分噪声凑配额
  const svg = pick(NEW_SVG, p, used).filter((c) => c.score >= 1).slice(0, 2);
  const emo = pick(NEW_EMOJI, p, used).filter((c) => c.score >= 1).slice(0, 2);
  const chosen = [...svg, ...emo];
  if (!chosen.length) throw new Error(`${name}: 没有任何相关素材，用例应移出新增素材测试集`);
  for (const c of chosen) used[c.id] += 1;

  const assets = chosen.map((c) => ({ id: c.id, kind: c.id.includes("emoji_") ? "emoji" : "svg", score: c.score, role: roleOf(c.score, p, c.id) }));
  const fittingEmoji = assets.filter((a) => a.kind === "emoji" && a.role === "fit").sort((a, b) => b.score - a.score);
  for (const extra of fittingEmoji.slice(1)) {
    extra.role = "fit-conflict";
    conflicts += 1;
  }
  for (const a of assets) a.expect = a.role === "fit";

  const idx = Number(name.slice(1)) - 1;
  const [first, second] = idx % 2 ? [emo, svg] : [svg, emo];
  const order = [];
  for (let i = 0; i < Math.max(first.length, second.length); i++) {
    if (first[i]) order.push(first[i]);
    if (second[i]) order.push(second[i]);
  }
  const ids = order.map((r) => r.id);
  envelope.content.candidateAssetIds = ids;
  envelope.candidateAssetIds = ids;
  fs.writeFileSync(path.join(here, `${name}.json`), JSON.stringify(envelope, null, 2) + "\n", "utf8");

  cases.push({
    file: `${name}.json`,
    size: spec.content.size,
    title: spec.content.title,
    origin,
    candidates: ids.length,
    singleBusiness: p.singleBusiness,
    capabilities: [...new Set(p.caps)],
    events: p.events,
    assets: assets.map((a) => ({
      ...a,
      reason: a.role === "fit" ? (a.kind === "emoji" ? REASON["fit-emoji"] : REASON["fit-svg"]) : REASON[a.role]
    })),
    expectedUse: assets.filter((a) => a.expect).map((a) => a.id),
    expectedAbsent: assets.filter((a) => !a.expect).map((a) => a.id)
  });
}

if (process.argv.includes("--audit")) {
  const rows = [];
  for (const name of fs.readdirSync(srcRoot).filter((n) => /^Q\d+\.json$/.test(n)).sort()) {
    rows.push({ name, spec: JSON.parse(fs.readFileSync(path.join(srcRoot, name), "utf8")).content });
  }
  for (const entry of EXTRA_CASES) {
    rows.push({ name: entry.name, spec: envelopeFor(entry, JSON.parse(fs.readFileSync(path.join(srcRoot, "Q001.json"), "utf8"))).content });
  }
  const dist = { rel0: 0, rel1: 0, rel2: 0, rel3: 0, rel4plus: 0 };
  const detail = [];
  for (const r of rows) {
    const p = profileOf(r.spec);
    const ranked = [...NEW_SVG, ...NEW_EMOJI].map((id) => ({ id, score: RULES[id](p) })).sort((a, b) => b.score - a.score);
    const rel = ranked.filter((x) => x.score >= 1);
    const fit = ranked.filter((x) => x.score >= 3);
    const key = rel.length >= 4 ? "rel4plus" : `rel${rel.length}`;
    dist[key] += 1;
    detail.push({
      file: r.name.endsWith(".json") ? r.name : `${r.name}.json`,
      size: r.spec.size,
      title: r.spec.title,
      related: rel.length,
      fit: fit.length,
      noise: ranked.length - rel.length,
      top: ranked.slice(0, 4).map((x) => `${x.id.replace("asset.", "")}:${x.score}`).join(" ")
    });
  }
  const zeroFit = detail.filter((d) => !d.fit).length;
  const zeroRelated = detail.filter((d) => !d.related).length;
  console.log(
    JSON.stringify(
      {
        cases: detail.length,
        relatedCandidatesPerCase: dist,
        casesWithNoFit: zeroFit,
        casesWithNothingRelated: zeroRelated,
        avgRelated: Number((detail.reduce((s, d) => s + d.related, 0) / detail.length).toFixed(2)),
        worst: detail.filter((d) => d.related <= 1).slice(0, 14)
      },
      null,
      1
    )
  );
  process.exit(0);
}

const template = JSON.parse(fs.readFileSync(path.join(srcRoot, "Q001.json"), "utf8"));
for (const name of fs.readdirSync(srcRoot).filter((n) => /^Q\d+\.json$/.test(n)).sort()) {
  emit(name.slice(0, 4), fs.readFileSync(path.join(srcRoot, name), "utf8"), "phase_emoji_swap");
}
for (const entry of EXTRA_CASES) {
  emit(entry.name, JSON.stringify(envelopeFor(entry, template), null, 2), "new_asset_positive_supplement");
}

const manifest = {
  dataset: "phase_new_assets_v1",
  sourceDir: "taskspec/Phase_emoji",
  note: "Q001-Q088 沿用源用例的 userQuery/数据/事件/尺寸，只替换 candidateAssetIds（content 与顶层同步）；Q089-Q093 为 Phase_emoji 缺失业务的自然用例。候选一律按与 query 的相关性取料：每类至多 2 个、总数 1-4 个，与业务无关（0 分）的素材不进候选，不用噪声凑配额。",
  registry: "app-11.7.7.300_rom-7.0",
  newAssets: { emoji: NEW_EMOJI, svg: NEW_SVG },
  judging: {
    srcMapping: "断言按 DSL 中的 resources/base/media/<file> 路径匹配，不按 asset id",
    emojiGate: "emoji_* 仅允许作为 2x2 单业务卡片 CardHeader 右上角 20vp 主题图，PNG 需保留原色",
    svgGate: "ic_* 可作主题图或正文辅助图标，需保留注册表声明的原始配色与比例",
    fitRule: "expectedUse 非空时产物必须使用其中之一，否则判漏用；一张卡片只允许一个 20vp 主题图",
    absentRule: "expectedAbsent 的素材 src 不得出现在 Image.src 或 backgroundImage 中",
    whitelistRule: "产物出现任何 expectedUse/expectedAbsent 之外的素材路径即判越白名单",
    sizeGateRule: "2x4 用例里的同业务 emoji 候选是尺寸越界考点（相关但不得使用），不是凑数"
  },
  coverage: used,
  emojiFitConflicts: conflicts,
  cases
};
fs.writeFileSync(path.join(here, "new_assets_expected.json"), JSON.stringify(manifest, null, 2) + "\n", "utf8");

const positive = Object.fromEntries([...NEW_EMOJI, ...NEW_SVG].map((id) => [id, cases.filter((c) => c.expectedUse.includes(id)).length]));
console.log(JSON.stringify({ cases: cases.length, positive, coverage: used }, null, 2));
