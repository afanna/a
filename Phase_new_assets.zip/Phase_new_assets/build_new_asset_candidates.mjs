import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const srcRoot = path.resolve(here, "..", "Phase_emoji");
const registry = path.resolve(
  here,
  "..",
  "..",
  "widget_service",
  "cloud",
  "data",
  "capabilities",
  "app-11.7.7.300_rom-7.0",
  "asset_capabilities.json"
);

const NEW_EMOJI = [
  "asset.emoji_sleep",
  "asset.emoji_heartRate",
  "asset.emoji_activity",
  "asset.emoji_note",
  "asset.emoji_notebook",
  "asset.emoji_smile",
  "asset.emoji_mobileNetwork"
];
const NEW_SVG = [
  "asset.ic_weatherWarning",
  "asset.ic_charge",
  "asset.ic_phone",
  "asset.ic_achieve",
  "asset.ic_public_connection_filled"
];
const NEW = new Set([...NEW_EMOJI, ...NEW_SVG]);

// 混合池判分：某些新素材在 Phase_emoji 旧候选里存在同业务的替代图标。
// 两侧都进候选，模型选新或选旧都算选对（不判漏用），只记录倾向；旧素材本身不参与判分。
// 映射逐条对过 rom-7.0 注册表 description 的"适用"条款，不做名字联想。
const LEGACY_EQUIV = {
  "asset.emoji_sleep": ["asset.emoji_z"],
  "asset.emoji_heartRate": ["asset.emoji_health"],
  "asset.emoji_activity": ["asset.emoji_calendar", "asset.emoji_calendar2"],
  "asset.ic_charge": ["asset.bolt_fill"],
  "asset.ic_phone": ["asset.emoji_phone1"],
  "asset.ic_achieve": ["asset.emoji_run"],
  "asset.ic_public_connection_filled": ["asset.earphone_case_16644", "asset.emoji_earphone"]
};

const MAX_POOL = 8;
const MAX_NEW = 2;
const MAX_BALANCE = 2;

// 模态补齐专用：判断某个旧素材能否进池当对照（PNG 写实位图 vs 线性 SVG 图标）。
// 只回答"注册表适用条款能不能指到本卡片业务"，不参与相关性打分，也不参与新素材判分。
// 每条谓词后面引号内是 rom-7.0 注册表 description 的原文片段，作为可核对的依据。
const LEGACY_FIT = {
  "asset.airplane_departure": (p) => (/航班|飞机|机票|出行|行程|旅行|出发/.test(p.q) && "出行计划、航班出发信息、旅行日程"),
  "asset.airplane_fill_1": (p) => (/航班|飞机|机票|航空/.test(p.q) && "航空旅行、航班概览"),
  "asset.battery_leaf_fill": (p) => ((p.battery || /省电|节能/.test(p.q)) && "省电模式、节能电池"),
  "asset.bell_fill": (p) => ((p.calendar || p.countdown || p.noteWords || p.alarm || /提醒/.test(p.q)) && "备忘录提醒、闹钟响铃、日历事项提醒"),
  "asset.bell_slash_fill": (p) => ((/勿扰|静音|免打扰|关闭通知/.test(p.q) || p.silent) && "静音模式、关闭通知、勿扰设置"),
  "asset.bolt_fill": (p) => ((p.charge || /充电|快充/.test(p.q)) && "正在充电、快充、电能"),
  "asset.cold": (p) => (/口罩|防护|流感|感冒|呼吸道|就医|医院|诊所/.test(p.q) && "防护、呼吸道健康或传染风险提示"),
  "asset.drop_1": (p) => (/雨|湿度|降雨|饮水/.test(p.q) && "湿度数据展示、饮水提醒、天气降雨信息"),
  "asset.earphone_case_16644": (p) => ((p.earphone || p.bluetooth || /耳机|蓝牙/.test(p.q)) && "蓝牙耳机设备连接、音频设备管理"),
  "asset.flame_fill": (p) => ((p.exercise || p.steps || /热量|卡路里|消耗|燃烧|跑步|运动/.test(p.q)) && "运动热量消耗"),
  "asset.heat_generation": (p) => ((p.weather || /气温|温度|体感|升温/.test(p.q)) && "温度、升温、制热或体感温度"),
  "asset.house_fill": (p) => (/回家|到家|居家|智能家居/.test(p.q) && "回家提醒、智能家居入口"),
  "asset.local_fill": (p) => ((p.navigate || /位置|地点|附近|城市|定位|公园|商圈/.test(p.q)) && "当前位置、地点、地图标记"),
  "asset.location_north_up_right_fill": (p) => ((p.navigate || /导航|路线|路径|指引/.test(p.q)) && "地图导航、方向指引、路线规划"),
  "asset.sun_max": (p) => (/晴|晒|强光|紫外线|日照|亮度/.test(p.q) && "强光、晴天或亮度增大"),
  "asset.sun_min": (p) => (/亮度|柔和/.test(p.q) && "低亮度、柔和阳光、亮度减小"),
  "asset.typhoon_fill": (p) => (/台风/.test(p.q) && "台风预警、台风路径"),
  "asset.icon_left": (p) => (/左耳|左声道/.test(p.q) && "左耳、左声道、左侧耳机电量"),
  "asset.icon_right": (p) => (/右耳|右声道/.test(p.q) && "右耳、右声道、右侧耳机电量"),
  "asset.icon_weather_temperature1": (p) => ((p.weather || /气温|摄氏度|零下|多少度|体感温度/.test(p.q)) && "当前温度、最高最低温、天气温度概览"),
  "asset.icon_weather_thermometer_medium": (p) => ((p.weather || /气温|舒适温度|零下|多少度/.test(p.q)) && "中等温度、舒适温度区间、当前气温"),
  "asset.icon_weather_thermometer": (p) => ((p.weather || /气温|温差|冷热/.test(p.q)) && "天气温度、温度指标、冷热趋势"),
  "asset.icon_weather_wind": (p) => (p.weather && /风/.test(p.q) && "风速、风向、风力等级或大风提醒"),
  "asset.emoji_calendar": (p) => (p.calendar && p.singleBusiness && "日期概览、日历事项或会议安排为唯一主业务"),
  "asset.emoji_calendar2": (p) => (p.calendar && p.singleBusiness && "日历事项、明确会议或计划为唯一主业务"),
  "asset.emoji_clock": (p) => ((p.alarm || /闹钟|起床|计时/.test(p.q)) && "闹钟、起床提醒或明确计时任务"),
  "asset.emoji_earphone": (p) => (p.earphone && p.size === "2x2" && "以耳机为唯一主业务的设备卡片"),
  "asset.emoji_health": (p) => (p.heart && p.singleBusiness && "心率或心脏健康为唯一主业务"),
  "asset.emoji_music": (p) => ((p.music || /音乐|歌曲|歌单|听歌/.test(p.q)) && "音乐播放、歌曲、歌单"),
  "asset.emoji_phone1": (p) => ((p.call || /打电话|拨号|通话/.test(p.q)) && "电话、拨号、联系人呼叫"),
  "asset.emoji_run": (p) => ((p.steps || p.exercise || /跑步|步数|配速/.test(p.q)) && "跑步记录、步数、配速或运动目标"),
  "asset.emoji_time": (p) => (/几点|当前时间|时长|计时/.test(p.q) && "当前时间、计时或时长统计"),
  "asset.emoji_z": (p) => (p.sleep && p.singleBusiness && "睡眠、就寝、午休或睡眠时长为唯一主业务")
};

const SLEEP_FIELDS = [
  "/sleepScore",
  "/sleepStatus",
  "/nightSleepDurationText",
  "/deepSleepDurationText",
  "/totalNapDurationText",
  "/fallAsleepTimeText",
  "/wakeupTimeText"
];
const HEART_FIELDS = ["/exerciseHeartRateAvg", "/exerciseHeartRateMax", "/exerciseHeartRateMin"];
const STEP_FIELDS = ["/dailySteps", "/dailyTotalCaloriesText", "/dailyDistanceText"];
const EXERCISE_FIELDS = [
  "/exerciseTypeName",
  "/exerciseStartTimeText",
  "/exerciseEndTimeText",
  "/exerciseDurationText",
  "/exerciseCalorieText"
];
const CHARGE_FIELDS = ["/chargingStatusDesc", "/pluggedTypeDesc", "/nowCurrentText", "/voltageText"];

const has = (list, subset) => subset.some((x) => list.includes(x));

function profileOf(spec) {
  const bindings = spec.candidateDataBindings ?? [];
  const caps = bindings.map((b) => b.capabilityId);
  const fields = bindings.flatMap((b) => b.candidateOutputFields ?? []);
  const events = (spec.candidateEventCandidates ?? []).map((e) => e.capabilityId);
  const q = (spec.userQuery ?? "").replace(/\s+/g, "");
  return {
    caps,
    fields,
    events,
    q,
    size: spec.size,
    singleBusiness: new Set(caps).size <= 1,
    weather: caps.includes("ViewWeather"),
    weatherAlert: fields.includes("/current/alertLevel"),
    calendar: caps.includes("GetCalendarEvents"),
    countdown: caps.includes("GetCountdownDays"),
    sleep: has(fields, SLEEP_FIELDS),
    heart: has(fields, HEART_FIELDS),
    steps: has(fields, STEP_FIELDS),
    exercise: has(fields, EXERCISE_FIELDS),
    earphone: caps.includes("GetEarphoneInfo"),
    battery: caps.includes("GetPhoneBatteryInfo"),
    charge: has(fields, CHARGE_FIELDS),
    call: events.includes("event.call.phone"),
    bluetooth: events.some((e) => /bluetooth/i.test(e)),
    navigate: events.some((e) => /navigate|navigation/i.test(e)),
    alarm: events.some((e) => /alarm|clock\./i.test(e)),
    silent: events.some((e) => /sleepMode|doNotDisturb|silent|mute/i.test(e)),
    mobileNet: events.some((e) => /mobileData|MobileData|dataUsage|simManagement|hotspot|mobileNetwork/i.test(e)),
    joinMeeting: events.some((e) => /enter\.meeting/i.test(e)),
    music: events.some((e) => /music/i.test(e)),
    noteWords: /待办|清单|备忘|任务步骤|事项|步骤|要买|买东西|购物|记下来|要做的事/.test(q),
    noteBookWords: /笔记|学习|复习|要点|知识点|提纲|读后感/.test(q),
    smileWords: /寄语|心情|鼓励|问候|祝福|早安|晚安|加油|微笑|给自己/.test(q),
    celebrateWords: /生日|纪念日|庆祝|庆典|周年/.test(q),
    goalWords: /目标|达成|完成度|打卡|成果|纪录/.test(q)
  };
}

const RULES = {
  "asset.ic_weatherWarning": (p) => (!p.weather ? 0 : p.weatherAlert ? 4 : 1),
  "asset.ic_charge": (p) =>
    p.battery && p.charge ? 4 : p.battery ? 3 : p.earphone && p.charge ? 2 : p.earphone ? 1 : 0,
  "asset.ic_phone": (p) => (p.call ? 4 : p.joinMeeting ? 1 : 0),
  "asset.ic_achieve": (p) =>
    p.steps && p.goalWords ? 4 : p.exercise ? 3 : p.steps ? 3 : p.heart ? 2 : p.countdown ? 1 : 0,
  "asset.ic_public_connection_filled": (p) =>
    p.mobileNet ? 4 : p.bluetooth ? 3 : p.earphone && /是否连接|连接状态/.test(p.q) ? 3 : 0,
  "asset.emoji_sleep": (p) =>
    p.sleep && p.singleBusiness ? 4 : /sleepMode/i.test(p.events.join()) ? 4 : p.sleep ? 2 : 0,
  "asset.emoji_heartRate": (p) => (p.heart && p.singleBusiness && !p.music ? 4 : p.heart ? 2 : p.exercise || p.steps ? 1 : 0),
  "asset.emoji_activity": (p) =>
    (p.countdown || p.calendar) && p.celebrateWords && p.singleBusiness ? 4 : p.countdown || p.calendar || p.steps ? 1 : 0,
  "asset.emoji_note": (p) => (p.noteWords && !p.calendar ? 4 : p.calendar ? 1 : 0),
  "asset.emoji_notebook": (p) => (p.noteBookWords && !p.calendar ? 4 : p.calendar ? 1 : 0),
  "asset.emoji_smile": (p) => (p.smileWords ? 4 : p.call && p.weather ? 2 : p.steps || p.exercise ? 1 : 0),
  "asset.emoji_mobileNetwork": (p) =>
    p.mobileNet && p.singleBusiness ? 4 : p.mobileNet ? 3 : p.bluetooth || p.earphone ? 1 : 0
};

const REASON = {
  fit: "命中注册表声明的唯一主业务，应被使用",
  "fit-emoji": "命中注册表声明的唯一主业务，应作为 2x2 CardHeader 右上角 20vp 主题图，PNG 保留原色",
  "fit-svg": "命中注册表声明的唯一主业务，可作为 CardHeader 主题图或正文辅助图标，保留注册表声明的配色与比例",
  "fit-conflict": "一张卡片只允许一个主题图，次高匹配素材应舍弃",
  "size-gated": "该素材仅限 2x2 卡片，当前尺寸 2x4，出现即判误用",
  "multi-business-gated": "该素材要求单业务卡片，当前卡片承载多个主业务，出现即判误用",
  near: "近义干扰：注册表声明的主业务与本卡片不符，出现即判误用",
  alt: "新旧同业务：本用例候选池内已有旧素材能表达同一主题，选新或选旧都算选对，出现旧素材记为倾向旧素材",
  off: "白名单噪声：与本卡片业务无关，出现即判误用"
};

function pick(pool, p, used) {
  return [...pool]
    .map((id) => ({ id, score: RULES[id](p) }))
    .sort((a, b) => b.score - a.score || used[a.id] - used[b.id] || a.id.localeCompare(b.id));
}

// 追加而非替换：先按相关性降序取正例（至多 MAX_NEW 个、不超过总池上限）；
// 一条正例都没有时，只补 1 个最高分的弱相关素材当误用考点，不用弱相关堆数量。
function selectNewAssets(ranked, room) {
  const fit = ranked.filter((c) => c.score >= 3).slice(0, Math.min(MAX_NEW, room));
  if (fit.length) return fit;
  return ranked.filter((c) => c.score >= 1).slice(0, Math.min(1, room));
}

function roleOf(score, p, id) {
  if (score < 3) return score >= 1 ? "near" : "off";
  if (id.startsWith("asset.emoji_")) {
    if (p.size !== "2x2") return "size-gated";
    if (!p.singleBusiness) return "multi-business-gated";
  }
  return "fit";
}

// Phase_emoji 的场景覆盖里没有这些业务，导致 5 个新 emoji 一条正例都拿不到，各补 1 条自然口语用例。
// 候选不做任何强制注入，仍由 RULES 打分自然选出，模型选错就是选错。
const COUNTDOWN = (targetDate) => ({
  capabilityId: "GetCountdownDays",
  arguments: { targetDate },
  writeResultTo: "/data/countdown",
  candidateOutputFields: ["/countdownDays"]
});

const EXTRA_CASES = [
  {
    name: "Q089",
    title: "妈妈生日倒数",
    description: "生日倒数与拨号",
    userQuery: "帮我做个卡片，10月6日是妈妈生日，看看还有几天，点一下直接给妈妈打电话，号码是13888888888。",
    bindings: [COUNTDOWN("2026-10-06")],
    events: [
      {
        capabilityId: "event.call.phone",
        action: { call: "clickToApi", args: { intentName: "CallPhone", params: { phoneNumber: "13888888888" } } }
      }
    ]
  },
  {
    name: "Q090",
    title: "购物清单",
    description: "静态购物清单",
    userQuery: "帮我做个卡片，把周末要买的东西记下来：牛奶、鸡蛋、抽纸。",
    bindings: [],
    events: []
  },
  {
    name: "Q091",
    title: "读书笔记",
    description: "静态笔记摘要",
    userQuery: "帮我把这周的读书笔记做成卡片，内容是《红楼梦》前三章的人物关系、宝黛初会和林家背景。",
    bindings: [],
    events: []
  },
  {
    name: "Q092",
    title: "给自己的话",
    description: "静态心情寄语",
    userQuery: "帮我做个卡片，放一句给自己的话：慢慢来，比较快。",
    bindings: [],
    events: []
  },
  {
    name: "Q093",
    title: "移动数据",
    description: "移动数据切换",
    userQuery: "帮我做个卡片，出门没网的时候一键开移动数据。",
    bindings: [],
    events: [
      { capabilityId: "event.setMobileData", action: { call: "clickToApi", args: { intentName: "SetMobileData", params: { switchFlag: 0 } } } }
    ]
  }
];

function envelopeFor(entry, template) {
  const content = {
    bundleName: "com.omega_w_0823.hmservice",
    userQuery: entry.userQuery,
    candidateDataBindings: entry.bindings,
    title: entry.title,
    size: "2x2",
    candidateEventCandidates: entry.events,
    description: entry.description,
    candidateAssetIds: []
  };
  const clone = JSON.parse(JSON.stringify(template));
  clone.content = content;
  clone.session.interactionId = entry.name.slice(1);
  clone.utterance.original = entry.userQuery;
  for (const key of Object.keys(content)) clone[key] = content[key];
  return clone;
}

const registryEntries = JSON.parse(fs.readFileSync(registry, "utf8"));
const registryIds = new Set(registryEntries.map((a) => a.id));
// 模态 = 注册表 src 的文件类型：png 为写实位图（emoji_*），svg 为线性矢量图标
const modalityOf = Object.fromEntries(registryEntries.map((a) => [a.id, a.src.split(".").pop()]));
for (const id of [...NEW_EMOJI, ...NEW_SVG]) {
  if (!registryIds.has(id)) throw new Error(`素材未在 rom-7.0 注册表: ${id}`);
}
for (const id of Object.keys(LEGACY_FIT)) {
  if (!registryIds.has(id)) throw new Error(`LEGACY_FIT 引用了未注册素材: ${id}`);
}

const ALL_LEGACY_FIT = Object.keys(LEGACY_FIT);
const balanceUsed = {};

// 整池只有一种模态时补对照：先取本模态下相关性 ≥1 的新素材（照常判分），
// 不够再取注册表"适用"条款能指到本卡片业务的旧素材（只当对照，不参与判分）。
function selectBalance(p, pool, ranked, room) {
  const kinds = new Set(pool.map((x) => modalityOf[x]));
  if (kinds.size !== 1) return { items: [], missing: null };
  const missing = kinds.has("png") ? "svg" : "png";
  const cap = Math.min(MAX_BALANCE, room);
  const items = [];
  const isNew = (x) => NEW.has(x);
  for (const c of ranked) {
    if (items.length >= cap) break;
    if (isNew(c.id) && modalityOf[c.id] === missing && c.score >= 1 && !pool.includes(c.id)) {
      items.push({ id: c.id, source: "new", score: c.score, quote: null });
    }
  }
  const rankedLegacy = ALL_LEGACY_FIT
    .map((id) => ({ id, quote: modalityOf[id] === missing ? LEGACY_FIT[id](p) : null }))
    .filter((x) => x.quote && !pool.includes(x.id) && !items.some((i) => i.id === x.id))
    .sort((a, b) => (balanceUsed[a.id] ?? 0) - (balanceUsed[b.id] ?? 0) || a.id.localeCompare(b.id));
  for (const x of rankedLegacy) {
    if (items.length >= cap) break;
    items.push({ id: x.id, source: "legacy", score: null, quote: x.quote });
  }
  for (const i of items) balanceUsed[i.id] = (balanceUsed[i.id] ?? 0) + 1;
  return { items, missing };
}

const used = Object.fromEntries([...NEW_EMOJI, ...NEW_SVG].map((id) => [id, 0]));
const cases = [];
let conflicts = 0;
let altGroups = 0;

function emit(name, raw, origin) {
  const spec = JSON.parse(raw);
  const envelope = spec;
  const p = profileOf(spec.content);
  // 旧候选原样保留，新素材按相关性追加进同一个池子（追加不替换）
  const legacy = spec.content.candidateAssetIds ?? [];
  const ranked = pick([...NEW_SVG, ...NEW_EMOJI], p, used);
  const chosen = selectNewAssets(ranked, MAX_POOL - legacy.length).map((c) => ({ ...c, why: "relevance" }));
  if (!chosen.length) throw new Error(`${name}: 候选池已满或没有任何相关新素材`);
  for (const c of chosen) used[c.id] += 1;

  // 整池单一模态时补对照：全 PNG 补 svg、全 svg 补 emoji
  const bal = selectBalance(p, [...legacy, ...chosen.map((c) => c.id)], ranked, MAX_POOL - legacy.length - chosen.length);
  const balNew = [];
  for (const i of bal.items) {
    if (i.source !== "new") continue;
    const c = ranked.find((x) => x.id === i.id);
    balNew.push({ id: c.id, score: c.score, why: "modality-balance" });
    used[c.id] += 1;
  }
  const picked = [...chosen, ...balNew];
  const legacyBalance = bal.items.filter((i) => i.source === "legacy");

  const assets = picked.map((c) => ({ id: c.id, kind: c.id.includes("emoji_") ? "emoji" : "svg", score: c.score, role: roleOf(c.score, p, c.id), why: c.why }));
  const fittingEmoji = assets.filter((a) => a.kind === "emoji" && a.role === "fit").sort((a, b) => b.score - a.score);
  for (const extra of fittingEmoji.slice(1)) {
    extra.role = "fit-conflict";
    conflicts += 1;
  }
  for (const a of assets) a.expect = a.role === "fit";

  // 新旧同业务撞车：把硬性正例降级成"二选一"，模型选旧素材不算漏用
  const groups = [];
  for (const a of assets) {
    if (!a.expect) continue;
    const partners = (LEGACY_EQUIV[a.id] ?? []).filter((x) => legacy.includes(x));
    if (!partners.length) continue;
    a.expect = false;
    a.role = "alt";
    a.altWith = partners;
    groups.push({ newAsset: a.id, legacy: partners, anyOf: [a.id, ...partners], note: REASON.alt });
    altGroups += 1;
  }

  const svg = picked.filter((c) => c.id.startsWith("asset.ic_"));
  const emo = picked.filter((c) => c.id.startsWith("asset.emoji_"));
  const idx = Number(name.slice(1)) - 1;
  const [first, second] = idx % 2 ? [emo, svg] : [svg, emo];
  const order = [];
  for (let i = 0; i < Math.max(first.length, second.length); i++) {
    if (first[i]) order.push(first[i]);
    if (second[i]) order.push(second[i]);
  }
  const newIds = [...order.map((r) => r.id), ...legacyBalance.map((i) => i.id)];
  // 插入位置按用例号轮换，避免新素材恒定排在池尾蹭位置偏好
  const at = idx % (legacy.length + 1);
  const ids = [...legacy.slice(0, at), ...newIds, ...legacy.slice(at)];
  envelope.content.candidateAssetIds = ids;
  envelope.candidateAssetIds = ids;
  fs.writeFileSync(path.join(here, `${name}.json`), JSON.stringify(envelope, null, 2) + "\n", "utf8");

  cases.push({
    file: `${name}.json`,
    size: spec.content.size,
    title: spec.content.title,
    origin,
    candidates: ids.length,
    legacyCandidates: legacy,
    newCandidates: ids.filter((x) => NEW.has(x)),
    balanceCandidates: legacyBalance,
    modality: [...new Set(ids.map((x) => modalityOf[x]))].sort().join("+"),
    insertedAt: at,
    singleBusiness: p.singleBusiness,
    capabilities: [...new Set(p.caps)],
    events: p.events,
    assets: assets.map((a) => ({
      ...a,
      reason: a.role === "fit" ? (a.kind === "emoji" ? REASON["fit-emoji"] : REASON["fit-svg"]) : REASON[a.role]
    })),
    altGroups: groups,
    expectedUse: assets.filter((a) => a.expect).map((a) => a.id),
    expectedOptional: assets.filter((a) => a.role === "alt").map((a) => a.id),
    expectedAbsent: assets.filter((a) => !a.expect && a.role !== "alt").map((a) => a.id)
  });
}

if (process.argv.includes("--audit")) {
  const rows = [];
  for (const name of fs.readdirSync(srcRoot).filter((n) => /^Q\d+\.json$/.test(n)).sort()) {
    rows.push({ name, spec: JSON.parse(fs.readFileSync(path.join(srcRoot, name), "utf8")).content });
  }
  for (const entry of EXTRA_CASES) {
    rows.push({ name: entry.name, spec: envelopeFor(entry, JSON.parse(fs.readFileSync(path.join(srcRoot, "Q001.json"), "utf8"))).content });
  }
  const dist = { rel0: 0, rel1: 0, rel2: 0, rel3: 0, rel4plus: 0 };
  const poolHist = {};
  const detail = [];
  const auditUsed = Object.fromEntries([...NEW_EMOJI, ...NEW_SVG].map((id) => [id, 0]));
  for (const r of rows) {
    const p = profileOf(r.spec);
    const ranked = pick([...NEW_SVG, ...NEW_EMOJI], p, auditUsed);
    const rel = ranked.filter((x) => x.score >= 1);
    const fit = ranked.filter((x) => x.score >= 3);
    const key = rel.length >= 4 ? "rel4plus" : `rel${rel.length}`;
    dist[key] += 1;
    const legacy = r.spec.candidateAssetIds ?? [];
    const add = selectNewAssets(ranked, MAX_POOL - legacy.length);
    for (const a of add) auditUsed[a.id] += 1;
    const bal = selectBalance(p, [...legacy, ...add.map((a) => a.id)], ranked, MAX_POOL - legacy.length - add.length);
    const alt = add.filter((a) => a.score >= 3 && (LEGACY_EQUIV[a.id] ?? []).some((x) => legacy.includes(x)));
    const poolSize = legacy.length + add.length + bal.items.length;
    poolHist[poolSize] = (poolHist[poolSize] || 0) + 1;
    detail.push({
      file: r.name.endsWith(".json") ? r.name : `${r.name}.json`,
      size: r.spec.size,
      title: r.spec.title,
      legacy: legacy.length,
      added: add.length,
      pool: poolSize,
      alt: alt.length,
      related: rel.length,
      fit: fit.length,
      noise: ranked.length - rel.length,
      modality: [...new Set([...legacy, ...add.map((a) => a.id), ...bal.items.map((i) => i.id)].map((x) => modalityOf[x]))].sort().join("+"),
      balance: bal.items.map((i) => `${i.id.replace("asset.", "")}[${i.source}]${i.quote ? `«${i.quote}»` : `:${i.score}`}`),
      top: ranked.slice(0, 4).map((x) => `${x.id.replace("asset.", "")}:${x.score}`).join(" ")
    });
  }
  const single = detail.filter((d) => !d.modality.includes("+"));
  const zeroFit = detail.filter((d) => !d.fit).length;
  const zeroRelated = detail.filter((d) => !d.related).length;
  console.log(
    JSON.stringify(
      {
        cases: detail.length,
        relatedCandidatesPerCase: dist,
        poolSizeHist: poolHist,
        casesWithNoFit: zeroFit,
        casesWithNothingRelated: zeroRelated,
        casesWithAltCollision: detail.filter((d) => d.alt).length,
        avgPool: Number((detail.reduce((s, d) => s + d.pool, 0) / detail.length).toFixed(2)),
        singleModalityAfterBalance: {
          cases: single.length,
          balanced: detail.filter((d) => d.balance.length).length,
          list: single.map((d) => `${d.file.replace(".json", "")}(${d.size}) ${d.title} 模态${d.modality} 池${d.pool}`)
        },
        balanceDetail: detail.filter((d) => d.balance.length).map((d) => `${d.file.replace(".json", "")} ${d.title}: ${d.balance.join(" ")}`),
        worst: detail.filter((d) => d.added <= 1).slice(0, 14)
      },
      null,
      1
    )
  );
  process.exit(0);
}

const template = JSON.parse(fs.readFileSync(path.join(srcRoot, "Q001.json"), "utf8"));
for (const name of fs.readdirSync(srcRoot).filter((n) => /^Q\d+\.json$/.test(n)).sort()) {
  emit(name.slice(0, 4), fs.readFileSync(path.join(srcRoot, name), "utf8"), "phase_emoji_append");
}
for (const entry of EXTRA_CASES) {
  emit(entry.name, JSON.stringify(envelopeFor(entry, template), null, 2), "new_asset_positive_supplement");
}

const manifest = {
  dataset: "phase_new_assets_v3_append_balance",
  sourceDir: "taskspec/Phase_emoji",
  mode: "append",
  note: "Q001-Q088 沿用源用例的 userQuery/数据/事件/尺寸与原有 candidateAssetIds，新素材按相关性追加进同一候选池（不替换、不删除旧素材）；Q089-Q093 为 Phase_emoji 缺失业务的自然用例，池内只有新素材。追加口径：按相关性降序取至多 2 个新素材，没有任何 ≥3 分新素材的用例只补 1 个最高分弱相关素材当误用考点，0 分素材一律不进候选。模态补齐：整池只有一种模态（全 PNG 写实位图或全 SVG 线性图标）时再补至多 2 个缺失模态的对照素材，优先取该模态下相关性 ≥1 的新素材（照常判分），不足则取注册表『适用』条款能指到本卡片业务的旧素材（只当对照，不参与判分）。整池不超过 8 个。",
  registry: "app-11.7.7.300_rom-7.0",
  newAssets: { emoji: NEW_EMOJI, svg: NEW_SVG },
  legacyPool: "旧素材来自源用例 + 模态补齐，仅作干扰项与同业务替代品，不参与新素材判分",
  modalityBalance: {
    rule: "整池单一模态 → 补至多 2 个缺失模态素材；先新后旧；旧素材必须命中 LEGACY_FIT 的注册表原文条款",
    legacyFitTable: "见 build_new_asset_candidates.mjs 的 LEGACY_FIT，每项附注册表 description 原文片段",
    judging: "balanceCandidates 不判对错、不算漏用也不算误用，只保证在候选池内（白名单）"
  },
  judging: {
    srcMapping: "断言按 DSL 中的 resources/base/media/<file> 路径匹配，不按 asset id",
    emojiGate: "emoji_* 仅允许作为 2x2 单业务卡片 CardHeader 右上角 20vp 主题图，PNG 需保留原色",
    svgGate: "ic_* 可作主题图或正文辅助图标，需保留注册表声明的原始配色与比例",
    fitRule: "expectedUse 非空时产物必须使用其中之一，否则判漏用；一张卡片只允许一个 20vp 主题图",
    altRule: "altGroups 内 anyOf 的任一路径出现即不算漏用；只出现 legacy 项则记为倾向旧素材（选对但未选新），不计误用",
    absentRule: "expectedAbsent 的素材 src 不得出现在 Image.src 或 backgroundImage 中",
    whitelistRule: "产物素材路径必须落在该用例 candidateAssetIds（旧素材 + 新素材 + 对照素材）之内，出现池外素材即判越白名单",
    legacyRule: "旧素材（legacyCandidates / balanceCandidates）出现与否不判对错，仅用于统计新旧选择倾向",
    sizeGateRule: "2x4 用例里的同业务新 emoji 候选是尺寸越界考点（相关但不得使用），不是凑数"
  },
  coverage: used,
  emojiFitConflicts: conflicts,
  altGroupCount: altGroups,
  balanceNewSlots: cases.reduce((s, c) => s + c.assets.filter((a) => a.why === "modality-balance").length, 0),
  balanceLegacySlots: cases.reduce((s, c) => s + c.balanceCandidates.length, 0),
  cases
};
fs.writeFileSync(path.join(here, "new_assets_expected.json"), JSON.stringify(manifest, null, 2) + "\n", "utf8");

const positive = Object.fromEntries(
  [...NEW_EMOJI, ...NEW_SVG].map((id) => [
    id,
    cases.filter((c) => c.expectedUse.includes(id) || c.altGroups.some((g) => g.newAsset === id)).length
  ])
);
const poolHist = cases.reduce((acc, c) => ({ ...acc, [c.candidates]: (acc[c.candidates] || 0) + 1 }), {});
const modalityHist = cases.reduce((acc, c) => ({ ...acc, [c.modality]: (acc[c.modality] || 0) + 1 }), {});
console.log(
  JSON.stringify(
    {
      cases: cases.length,
      poolSizeHist: poolHist,
      maxPool: Math.max(...cases.map((c) => c.candidates)),
      modalityHist,
      singleModalityCases: cases.filter((c) => !c.modality.includes("+")).map((c) => `${c.file.replace(".json", "")}:${c.modality}`),
      positiveCases: positive,
      altGroups: altGroups,
      balanceNewSlots: manifest.balanceNewSlots,
      balanceLegacySlots: manifest.balanceLegacySlots,
      coverage: used
    },
    null,
    2
  )
);
