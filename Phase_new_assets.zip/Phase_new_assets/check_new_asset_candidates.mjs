import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const srcRoot = path.resolve(here, "..", "Phase_emoji");
const manifest = JSON.parse(fs.readFileSync(path.join(here, "new_assets_expected.json"), "utf8"));
const registry = JSON.parse(
  fs.readFileSync(
    path.resolve(here, "..", "..", "widget_service", "cloud", "data", "capabilities", manifest.registry, "asset_capabilities.json"),
    "utf8"
  )
);

const NEW = new Set([...manifest.newAssets.emoji, ...manifest.newAssets.svg]);
const registered = new Set(registry.map((a) => a.id));
const srcIds = new Set(fs.readdirSync(srcRoot).filter((n) => /^Q\d+\.json$/.test(n)).map((n) => n.slice(0, 4)));
const errors = [];
const files = fs.readdirSync(here).filter((n) => /^Q\d+\.json$/.test(n)).sort();
const caseIndex = new Map(manifest.cases.map((c) => [c.file, c]));

for (const name of files) {
  const spec = JSON.parse(fs.readFileSync(path.join(here, name), "utf8"));
  const top = spec.candidateAssetIds ?? [];
  const id = name.slice(0, 4);
  if (JSON.stringify(top) !== JSON.stringify(spec.content?.candidateAssetIds)) errors.push(`${name}: content 与顶层 candidateAssetIds 不一致`);
  if (top.length < 1 || top.length > 4) errors.push(`${name}: 候选数 ${top.length}`);
  const svg = top.filter((x) => x.startsWith("asset.ic_")).length;
  const emoji = top.filter((x) => x.startsWith("asset.emoji_")).length;
  if (svg > 2 || emoji > 2) errors.push(`${name}: 每类至多 2 个，实际 ${svg} svg + ${emoji} emoji`);
  for (const x of top) {
    if (!NEW.has(x)) errors.push(`${name}: 非新增素材 ${x}`);
    if (!registered.has(x)) errors.push(`${name}: 未注册 ${x}`);
  }
  if (new Set(top).size !== top.length) errors.push(`${name}: 候选重复`);

  const c = caseIndex.get(name);
  if (!c) errors.push(`${name}: manifest 缺失`);
  else {
    const fitEmoji = c.assets.filter((a) => a.kind === "emoji" && a.expect).length;
    if (fitEmoji > 1) errors.push(`${name}: ${fitEmoji} 个 emoji 同时判为正例`);
    if (c.size !== "2x2" && c.expectedUse.some((x) => x.startsWith("asset.emoji_"))) errors.push(`${name}: 2x4 却期望使用 emoji`);
    if (c.candidates !== top.length) errors.push(`${name}: manifest 候选数 ${c.candidates} 与文件 ${top.length} 不符`);
    for (const a of c.assets) if (a.score < 1) errors.push(`${name}: 无关候选凑数 ${a.id}（score ${a.score}）`);
  }

  if (srcIds.has(id)) {
    const src = JSON.parse(fs.readFileSync(path.join(srcRoot, name), "utf8"));
    const same =
      src.userQuery === spec.userQuery &&
      src.size === spec.size &&
      src.title === spec.title &&
      JSON.stringify(src.candidateDataBindings) === JSON.stringify(spec.candidateDataBindings) &&
      JSON.stringify(src.candidateEventCandidates) === JSON.stringify(spec.candidateEventCandidates) &&
      JSON.stringify(src.deviceInfo) === JSON.stringify(spec.deviceInfo) &&
      JSON.stringify(Object.keys(src)) === JSON.stringify(Object.keys(spec));
    if (!same) errors.push(`${name}: 除候选外与源用例不一致`);
    if (src.candidateAssetIds.every((x) => NEW.has(x))) errors.push(`${name}: 源用例疑似已被改写`);
  }
}

const positive = Object.fromEntries([...NEW].map((x) => [x, manifest.cases.filter((c) => c.expectedUse.includes(x)).length]));
const uncovered = [...NEW].filter((x) => !positive[x]);
let sourceModified = "git 不可用";
try {
  const root = path.resolve(here, "..", "..");
  const rel = path.relative(root, srcRoot).split(path.sep).join("/");
  const lines = execFileSync("git", ["status", "--porcelain", "--", rel], { cwd: root, encoding: "utf8" })
    .split("\n")
    .filter((l) => l.trim() && !l.startsWith("??"));
  sourceModified = lines.length ? lines : "clean";
} catch {
  /* 非 git 环境跳过 */
}
const slots = manifest.cases.flatMap((c) => c.assets);
const relevance = {
  slots: slots.length,
  noiseSlots: slots.filter((a) => a.score < 1).length,
  nearMissSlots: slots.filter((a) => a.score >= 1 && a.score <= 2).length,
  fitSlots: slots.filter((a) => a.score >= 3).length,
  candidateCountHist: slots.length
    ? [1, 2, 3, 4].reduce((acc, k) => ({ ...acc, [`${k}个候选`]: manifest.cases.filter((c) => c.assets.length === k).length }), {})
    : {},
  casesWithoutFit: manifest.cases.filter((c) => !c.expectedUse.length).length
};
console.log(
  JSON.stringify(
    {
      files: files.length,
      relevance,
      sourceModified,
      errors: errors.slice(0, 15),
      errorCount: errors.length,
      positiveCasesPerAsset: positive,
      assetsWithoutPositiveCase: uncovered,
      emojiFitConflicts: manifest.emojiFitConflicts
    },
    null,
    2
  )
);
if (errors.length || uncovered.length) process.exitCode = 1;
