import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const srcRoot = path.resolve(here, "..", "Phase_emoji");
const manifest = JSON.parse(fs.readFileSync(path.join(here, "new_assets_expected.json"), "utf8"));
const registry = JSON.parse(
  fs.readFileSync(
    path.resolve(here, "..", "..", "widget_service", "cloud", "data", "capabilities", manifest.registry, "asset_capabilities.json"),
    "utf8"
  )
);

const MAX_POOL = 8;
const MAX_NEW = 4;
const NEW = new Set([...manifest.newAssets.emoji, ...manifest.newAssets.svg]);
const registered = Object.fromEntries(registry.map((a) => [a.id, a.src]));
const srcIds = new Set(fs.readdirSync(srcRoot).filter((n) => /^Q\d+\.json$/.test(n)).map((n) => n.slice(0, 4)));
const errors = [];
const files = fs.readdirSync(here).filter((n) => /^Q\d+\.json$/.test(n)).sort();
const caseIndex = new Map(manifest.cases.map((c) => [c.file, c]));
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const mod = (id) => registered[id]?.split(".").pop();

for (const name of files) {
  const spec = JSON.parse(fs.readFileSync(path.join(here, name), "utf8"));
  const top = spec.candidateAssetIds ?? [];
  const id = name.slice(0, 4);
  if (!eq(top, spec.content?.candidateAssetIds)) errors.push(`${name}: content 与顶层 candidateAssetIds 不一致`);
  if (top.length < 1 || top.length > MAX_POOL) errors.push(`${name}: 整池候选数 ${top.length} 不在 1-${MAX_POOL} 内`);
  if (new Set(top).size !== top.length) errors.push(`${name}: 候选重复`);
  for (const x of top) if (!registered[x]) errors.push(`${name}: 未注册素材 ${x}`);

  const added = top.filter((x) => NEW.has(x));
  const c = caseIndex.get(name);
  if (!c) {
    errors.push(`${name}: manifest 缺失`);
    continue;
  }
  const balance = c.balanceCandidates ?? [];
  if (added.length < 1 || added.length > MAX_NEW) errors.push(`${name}: 新素材数 ${added.length} 不在 1-${MAX_NEW} 内`);
  if (!eq(c.newCandidates, added)) errors.push(`${name}: manifest 新素材候选与文件不一致`);
  if (!eq(balance.map((b) => b.id), top.filter((x) => !NEW.has(x) && !c.legacyCandidates.includes(x))))
    errors.push(`${name}: manifest 对照素材与文件不一致`);
  if (!eq(c.legacyCandidates, top.filter((x) => !NEW.has(x) && !balance.some((b) => b.id === x))))
    errors.push(`${name}: manifest 旧候选与文件不一致`);
  if (c.candidates !== top.length) errors.push(`${name}: manifest 候选数 ${c.candidates} 与文件 ${top.length} 不符`);
  if (c.modality !== [...new Set(top.map((x) => mod(x)))].sort().join("+")) errors.push(`${name}: manifest 模态标注与文件不符`);

  // 对照素材：只当模态对照，必须带注册表原文依据，且不得进入任何判分集合
  for (const b of balance) {
    if (NEW.has(b.id)) errors.push(`${name}: 对照素材 ${b.id} 是新素材，应走相关性通道`);
    if (!registered[b.id]) errors.push(`${name}: 对照素材 ${b.id} 未注册`);
    if (!b.quote) errors.push(`${name}: 对照素材 ${b.id} 缺少注册表"适用"依据`);
    if (c.assets.some((a) => a.id === b.id)) errors.push(`${name}: 对照素材 ${b.id} 混进了新素材判分表`);
    if (c.expectedAbsent.includes(b.id) || c.expectedUse.includes(b.id)) errors.push(`${name}: 对照素材 ${b.id} 被计入判分`);
    if (c.expectedOptional.includes(b.id)) errors.push(`${name}: 对照素材 ${b.id} 不应出现在 alt 分类`);
  }

  // 旧素材必须原样保留、顺序不动：这是"追加不是替换"的核心不变量
  if (srcIds.has(id)) {
    const src = JSON.parse(fs.readFileSync(path.join(srcRoot, name), "utf8"));
    const same =
      src.userQuery === spec.userQuery &&
      src.size === spec.size &&
      src.title === spec.title &&
      eq(src.candidateDataBindings, spec.candidateDataBindings) &&
      eq(src.candidateEventCandidates, spec.candidateEventCandidates) &&
      eq(src.deviceInfo, spec.deviceInfo) &&
      eq(Object.keys(src), Object.keys(spec));
    if (!same) errors.push(`${name}: 除候选外与源用例不一致`);
    const kept = top.filter((x) => !NEW.has(x) && !balance.some((b) => b.id === x));
    if (!eq(src.candidateAssetIds, kept)) errors.push(`${name}: 源用例旧候选被删改（应原样保留，只追加新素材与对照素材）`);
    if (src.candidateAssetIds.every((x) => NEW.has(x))) errors.push(`${name}: 源用例疑似已被改写`);
  }

  const fitEmoji = c.assets.filter((a) => a.kind === "emoji" && a.expect).length;
  if (fitEmoji > 1) errors.push(`${name}: ${fitEmoji} 个 emoji 同时判为硬性正例`);
  if (c.size !== "2x2" && c.expectedUse.some((x) => x.startsWith("asset.emoji_"))) errors.push(`${name}: 2x4 却硬性期望使用 emoji`);
  if (c.size !== "2x2" && c.altGroups.some((g) => g.newAsset.startsWith("asset.emoji_")))
    errors.push(`${name}: 2x4 却给出 emoji alt 组（尺寸闸门应先拦下）`);
  for (const a of c.assets) {
    if (a.score < 1) errors.push(`${name}: 无关候选凑数 ${a.id}（score ${a.score}）`);
    if (!top.includes(a.id)) errors.push(`${name}: manifest 素材 ${a.id} 不在候选池内`);
  }
  const relCount = c.assets.filter((a) => a.why !== "modality-balance").length;
  if (c.assets.filter((a) => a.why !== "modality-balance" && a.score >= 3).length === 0 && relCount > 1)
    errors.push(`${name}: 无正例却按相关性追加了 ${relCount} 个弱相关（只允许补 1 个）`);
  if (!eq([...c.expectedUse, ...c.expectedOptional, ...c.expectedAbsent].sort(), added.sort()))
    errors.push(`${name}: 新素材三分类（硬性正例/alt/禁用）未覆盖池内全部新素材`);
  for (const g of c.altGroups) {
    if (!NEW.has(g.newAsset)) errors.push(`${name}: alt 组主体 ${g.newAsset} 不是新素材`);
    if (!top.includes(g.newAsset)) errors.push(`${name}: alt 组新素材 ${g.newAsset} 不在候选池`);
    for (const l of g.legacy) {
      if (NEW.has(l)) errors.push(`${name}: alt 组替代品 ${l} 应为旧素材`);
      if (!top.includes(l)) errors.push(`${name}: alt 组旧替代品 ${l} 不在候选池`);
    }
    if (c.expectedAbsent.includes(g.newAsset)) errors.push(`${name}: alt 素材 ${g.newAsset} 又被判禁用，口径冲突`);
    if (c.expectedUse.includes(g.newAsset)) errors.push(`${name}: alt 素材 ${g.newAsset} 又判硬性正例，口径冲突`);
  }
  for (const x of c.expectedUse) if (c.expectedAbsent.includes(x)) errors.push(`${name}: ${x} 同时判正例与禁用`);
}

const positiveIds = (c) => [...c.expectedUse, ...c.altGroups.map((g) => g.newAsset)];
const positive = Object.fromEntries([...NEW].map((x) => [x, manifest.cases.filter((c) => positiveIds(c).includes(x)).length]));
const hardPositive = Object.fromEntries([...NEW].map((x) => [x, manifest.cases.filter((c) => c.expectedUse.includes(x)).length]));
const uncovered = [...NEW].filter((x) => !positive[x]);
const poolCases = manifest.cases.filter((c) => c.origin === "phase_emoji_append");
let sourceModified = "git 不可用";
try {
  const root = path.resolve(here, "..", "..");
  const rel = path.relative(root, srcRoot).split(path.sep).join("/");
  const lines = execFileSync("git", ["status", "--porcelain", "--", rel], { cwd: root, encoding: "utf8" })
    .split("\n")
    .filter((l) => l.trim() && !l.startsWith("??"));
  sourceModified = lines.length ? lines : "clean";
} catch {
  /* 非 git 环境跳过 */
}
const slots = manifest.cases.flatMap((c) => c.assets);
const balanceSlots = manifest.cases.flatMap((c) => c.balanceCandidates ?? []);
const stats = {
  poolSlots: manifest.cases.reduce((s, c) => s + c.candidates, 0),
  legacySlots: manifest.cases.reduce((s, c) => s + c.legacyCandidates.length, 0),
  newSlots: slots.length,
  balanceLegacySlots: balanceSlots.length,
  balanceNewSlots: slots.filter((a) => a.why === "modality-balance").length,
  newSlotsByScore: {
    fit4: slots.filter((a) => a.score === 4).length,
    fit3: slots.filter((a) => a.score === 3).length,
    weak12: slots.filter((a) => a.score >= 1 && a.score < 3).length
  },
  hardPositiveSlots: slots.filter((a) => a.expect).length,
  altSlots: slots.filter((a) => a.role === "alt").length,
  misuseSlots: slots.filter((a) => !a.expect && a.role !== "alt").length,
  poolSizeHist: [1, 2, 3, 4, 5, 6, 7, 8].reduce((acc, k) => ({ ...acc, [`${k}个候选`]: manifest.cases.filter((c) => c.candidates === k).length }), {}),
  modalityHist: manifest.cases.reduce((acc, c) => ({ ...acc, [c.modality]: (acc[c.modality] || 0) + 1 }), {}),
  balanceFrequency: balanceSlots.reduce((acc, b) => ({ ...acc, [b.id.replace("asset.", "")]: (acc[b.id.replace("asset.", "")] || 0) + 1 }), {}),
  casesWithNoHardPositive: manifest.cases.filter((c) => !c.expectedUse.length).length,
  casesWithAltCollision: manifest.cases.filter((c) => c.altGroups.length).length
};
const singleModality = manifest.cases.filter((c) => !c.modality.includes("+"));
const tailBias = poolCases.filter((c) => c.insertedAt === c.legacyCandidates.length).length;
console.log(
  JSON.stringify(
    {
      mode: manifest.mode,
      files: files.length,
      stats,
      singleModalityCases: singleModality.map((c) => `${c.file.replace(".json", "")}:${c.modality}(${c.title})`),
      insertionAtTailCases: tailBias,
      emojiFitConflicts: manifest.emojiFitConflicts,
      altGroupCount: manifest.altGroupCount,
      sourceModified,
      errors: errors.slice(0, 15),
      errorCount: errors.length,
      positiveCasesPerAsset: positive,
      hardPositiveCasesPerAsset: hardPositive,
      assetsWithoutPositiveCase: uncovered
    },
    null,
    2
  )
);
if (errors.length || uncovered.length) process.exitCode = 1;
