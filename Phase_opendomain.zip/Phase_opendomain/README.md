# Phase_opendomain — 开域静态卡 DSL 回归集

只测 **DSL 生成层**：小艺联网检索并把事实写进 `userQuery`，端侧数据/事件/素材能力全部为空数组，模型不去检索、不核对世界。

与 `Phase_emoji`、`Phase_new_assets`、`Phase_template_misfire` 完全隔离。

## 数量现状（如实）

| 状态 | 条数 | 位置 | 能否判分 |
| --- | --- | --- | --- |
| `real-payload` | 1 | `Q001.json` | 是 |
| `verified-web` | 2 | `Q004.json`、`Q010.json` | 是 |
| `unverified` | 15 | `pending/Q002…Q018.json` | 否，待真实检索结果回填 |

可判分只有 3 条、9 个 fact、18 个必现 token。样本量小到这个程度，结论只能定性，不能出通过率。

## 为什么只有 3 条

此前 17 条的日期、价格、场次全是我编的，README 还写成"合成占位、不代表真实数值"来免责——按"数据要真实"的要求，这属于造数，已撤销。为回填做了实际抓取，结果记在这里：

- 成功取到数值：维基百科·上海轨道交通2号线（全长 62.2 km、已开通 31 座车站）→ `Q010`；维基百科·上海博物馆（2008-03-10 起向社会免费开放）→ `Q004`
- 抓取失败：东京动物园协会 `goo.go.jp`（ECONNRESET）、故宫博物院 `dpm.org.cn`（404）、维基百科·京沪高速铁路（ECONNRESET）
- 页面可达但条目不含运营数值：维基百科·上野动物园（开园时间、票价、休园日均未收录）

所以 `Q005` 上野动物园、`Q008` 油价、`Q009` 汇率、`Q002/Q003/Q007/Q011…Q018` 等全部留在 `pending/`，包括原先那份"上海地铁2号线首末班时刻表"——05:02/22:35 那些数是我编的，整条撤下而不是留着。

## 回填流程

1. 用真实小艺链路跑一遍（或提供真实检索结果快照），把 L2 事实与 L3 改写后的 `userQuery` 落到对应条目；
2. 在 builder 的 `CASES` 里给该条补 `status: "verified-web"`、`source`、`retrievedAt`，数值换成真值；
3. 重新生成，文件会自动从 `pending/` 移回主集；
4. `check_opendomain_dataset.mjs` 会强制：主集每条必须有来源、`verified-web` 必须有抓取日期、含年份类事实却无来源即报错。

## 契约来源

`reference_payload.json` 是那条真实线上载荷的**逐字节副本**，也是本目录唯一契约来源。

| 字段 | 开域取值 | 说明 |
| --- | --- | --- |
| `functionName` | `generateWidgetCardCompactDsl` | 线上载荷带，Phase_emoji/Phase_new_assets 不带 |
| `romVersion` | `SGT-AL10 7.0.0.105` | 同上 |
| `prdVer` | `11.8.8.512` | 按 `registry_ranges.json` 命中 `app-11.7.7.300_rom-7.0` |
| `candidateDataBindings` | `[]` | 无端侧数据，内容全部来自 `userQuery` |
| `candidateEventCandidates` | `[]` | 不得自造点击跳转 |
| `candidateAssetIds` | `[]` | 不得出现任何图片引用 |
| `utterance.original` | `""` | 原话不回传，仅存 manifest 的 `originalQuery` |
| `session.isNew` | `false` | 多轮技能触发 |
| `deviceInfo.time` | 17 位时间戳 | 上游与人工判读用的时序锚点，**模型输入里没有** |

`Q001.json` 与示例逐字符一致（含键序、单行不换行排版）。其余条目复用示例的固定字段，只换 `userQuery`/`title`/`description`/`size`/`deviceInfo.time`/`session`；`sessionId` 为编号派生的确定性 UUIDv4，可复现且互不重复。校验器把这些写成硬断言。

## 职责边界与内容边界

- 事实必须已写死在 `userQuery` 内，不得用"帮我查/上网找/核实"把检索推给模型；需要"今天"才能判定的条目必须把日期写进正文（参照样本把"最近两个月"写成"（2026年9月和10月）"就是这个手法）
- 只收网络可搜索的公开信息；备忘录、待办、日历日程、个人课程表与书单不进本集（走端侧能力链路）
- 实体与数值都必须可核对，取不到就进 `pending/`，不允许编造

## 判分口径

`opendomain_expected.json` 的 `cases[]`（主集）给出 `mustContainTokens`、`mayOmitTokens`、`forbidTokens`、`forbidAnyDate`、`status`、`source`、`retrievedAt`；`pending[]` 结构相同但明确不可判分。

- `mustContainTokens` 去空白后必须原样出现在 DSL 文本中，否则判丢信息
- `expectedAbsent`/`forbidTokens` 出现即判编造；断言按 `resources/base/media/<file>` 等 src 路径匹配，不按 asset id
- 候选全空 → DSL 出现 `${/data/` 绑定、事件动作、素材引用、`http(s)` 或 `data:` 内联资源，任一即判越权
- 产物中的日期与"数值+单位"必须能在同条 `userQuery` 中找到（数值与单位需相邻，避免跨组件误报）
- 画布尺寸：compact DSL `root` 的 `width`/`height`，2x2=160×160、2x4=320×160

```powershell
node .\CreateMyCard230\taskspec\Phase_opendomain\build_opendomain_dataset.mjs
node .\CreateMyCard230\taskspec\Phase_opendomain\check_opendomain_dataset.mjs
node .\CreateMyCard230\taskspec\Phase_opendomain\score_opendomain_dsl.mjs --out <DSL产物目录> [--case Q001] [--report r.json]
```

`score` 只遍历主集，`pending/` 不会被误判。它是文本级判定，不解析组件树：分组结构、步骤保序、长书名截断、英文专名是否被擅自翻译仍需人工或 `harmony-card-generation-offline/scripts/validate_card.py`。
