# Phase_opendomain — 开域静态卡 DSL 回归集

与 `Phase_emoji`、`Phase_new_assets` 完全隔离，不复用它们的素材判定规则。这里测的是**开域链路**：小艺触发 skill → 联网检索 → 把事实写进 `userQuery` → 调 `generateWidgetCardCompactDsl`，端侧**没有任何**数据能力、事件能力、素材能力。

## 契约要点（取自真实线上载荷）

| 字段 | 开域取值 | 含义 |
| --- | --- | --- |
| `functionName` | `generateWidgetCardCompactDsl` | 线上载荷带，Phase_emoji/Phase_new_assets 不带 |
| `romVersion` | `SGT-AL10 7.0.0.105` | 同上，两个字段是线上多出来的 |
| `candidateDataBindings` | `[]` 空数组 | 无端侧数据，卡片内容全部来自 `userQuery` 文本 |
| `candidateEventCandidates` | `[]` 空数组 | 不得自造点击跳转 |
| `candidateAssetIds` | `[]` 空数组 | 不得出现任何图片引用 |
| `utterance.original` | `""` | 原始 query 不回传，只存于 manifest 的 `originalQuery` |
| `session.isNew` | `false` | 多轮技能触发 |
| `deviceInfo.time` | 17 位时间戳 | 上游生成与人工判读的时序锚点；**模型输入里没有这个字段** |

`userQuery` 是**改写后**的版本（线上实测 220 字，我们素材集平均 34 字）：已做时间绝对化 + 检索事实结构化分组。所以本集的自变量是长 `userQuery`，不是用户那句原话。

## 职责边界

DSL 模型只收到 `userQuery`、`size`、事件候选、`dataModelSchema`、`assetCandidates`（见 `widget_service/docs/system_prompt.txt`），**看不到 `deviceInfo`，也没有检索能力**。搜索和事实整理是上游小艺做的，所以本集遵循两条硬规则：

- 全部事实必须已经写死在 `userQuery` 里，任何用例不得用"帮我查/上网找/核实"这类命令式表述把检索推给模型（脚本扫描：0 条）
- 凡是"需要知道今天才能判定"的用例（过期识别、取最近一场），必须把日期写进 query 正文（如"今天是2026年11月2日"），参照样本把"最近两个月"写成"（2026年9月和10月）"就是同一手法；校验器对 `todayStatedInQuery` 用例强制断言该日期存在

## 内容边界

本集只测**必须靠网络搜索才能拿到的公开信息**：演出/赛事/展览排期、场馆开放时间与票价、政策与公告、民生价格、汇率、交通时刻、影视排片、攻略与菜谱、资费套餐、纯英文公开榜单。

不进本集：备忘录、待办清单、日历日程、个人课程表、个人书单——这些是用户自有内容或端侧数据能力已经覆盖的场景，走 `Phase_emoji` / `Phase_new_assets` 那条链路。校验器按 `manifest.scope.outCategories` 做硬拦截，类目命中"备忘录/待办/日历/日程/课程/书目/个人计划"直接构建失败。

实体与数值分开要求：机构、作品、线路、运营商、场馆等**实体必须真实存在**（已清掉虚构书名、不存在的艺人和未发布机型）；日期、价格、场次等**具体数值为合成占位**，只用来判忠实性，不代表真实世界数值。

## 契约来源

`reference_payload.json` 是那条真实线上载荷的**逐字节副本**，也是本目录唯一的契约来源：

- `Q001.json` 直接由它产出，校验器要求与示例逐字符一致（含键序、单行不换行的排版）
- 其余 17 条复用它的固定字段（`functionName`/`romVersion`/`bundleName`/`deviceInfo` 除 time/`pagination`/`userAuth`/`utterance`/`version`/`session.isNew`），只换 `userQuery`、`title`、`description`、`size`、`deviceInfo.time`、`session`
- 所有载荷都是单行 JSON，与示例一致，不做缩进美化
- `sessionId` 用用例号派生的确定性 UUIDv4 形状（可复现、互不重复），不再使用 `0000-4000-8000` 这类填充值

校验器把这几点写成硬断言：字段骨架与键序必须和示例逐层相同、固定字段必须等值、`sessionId` 必须是合法 UUID 且全表唯一、标 `origin: real` 的那条必须与示例完全一致、合成条不得复用示例的 session 或时间戳。

## 组成：18 条

| 编号 | 类目 | 埋的坑 |
| --- | --- | --- |
| Q001 | 演出 | 真实线上载荷原样收录，作基线锚点：跨月、`9月25-26日` 区间、`MAD LOVE ULTRA` 全大写、`Whatever's Clever` 含撇号 |
| Q002 | 演出 | 8 条超 2x4 容量，取舍必须有序且不得改标题 |
| Q003 | 体育赛事 | 检索明确"场馆暂未确认"，出现任何场馆名即编造（`forbidTokens`） |
| Q004 | 展览 | 闭馆规则/免费需预约/早鸟票等附属信息易丢 |
| Q005 | 场馆信息 | 上野动物园开园时间与门票，跨年休园区间与"最后入园"截止点易丢 |
| Q006 | 政务办事 | 公积金贷款利率，三位小数（3.325%）与"5年以下含5年"边界表述 |
| Q007 | 影视 | IMAX 3D / 2D / 原版字幕 / 全大写英文片名 |
| Q008 | 民生价格 | 油价小数位（7.32 不得变 7.3） |
| Q009 | 汇率 | 4 位小数 + 日元 100 单位比价，考单位错置 |
| Q010 | 交通时刻 | HH:MM 密度最高，方向限定与"末班到达/发出"不能混 |
| Q011 | 旅游攻略 | 第几天 + 时长 + 价格 + 预约条件四要素分组 |
| Q012 | 菜谱 | 六步保序，克/毫升单位不能省 |
| Q013 | 资费套餐 | 三家运营商同类数值（元/月、GB、分钟），考张冠李戴 |
| Q014 | 演出 | query 内写明"今天是2026年11月2日"，四条已过期可舍弃、11月14日那条必现，考时间语义而非照抄 |
| Q015 | 演出 | 两个来源日期冲突，不得自行择一收敛 |
| Q016 | 无结果 | 铁路调图公告只有"下个月5日零时起"，无车次与时刻，`forbidAnyDate`：写出具体日期/车次即编造 |
| Q017 | 超长清单 | 13 条远超容量，query 内写明今天日期 → 最近一场必现，其余按时间顺序舍弃 |
| Q018 | 纯英文 | 全英文事实 + 半角分隔 + `19:30 local`，考是否擅自翻译真实艺人名 |

规模：91 个 fact、147 个必现 token。

## 判分口径

`opendomain_expected.json` 每条给出：

- `mustContainTokens` → 去空白后必须原样出现在 DSL 文本中，否则判**丢信息**
- `mayOmitTokens` → 容量不足时允许缺失（`droppable: true` 的条目）
- `forbidTokens` / `forbidAnyDate` → 出现即判**编造**
- 静态性硬约束：产物出现 `${/data/` 绑定、`asset.`/`resources/base/media` 素材引用、`http(s)://`、`data:` 内联资源，任一即判越权（候选全空时不可能合法）
- 需人工或模型判读：分组结构是否保留、标题是否因取舍失真、英文专名是否被擅自翻译、步骤是否保序

## 跑一遍

```powershell
node .\CreateMyCard230\taskspec\Phase_opendomain\build_opendomain_dataset.mjs
node .\CreateMyCard230\taskspec\Phase_opendomain\check_opendomain_dataset.mjs
node .\CreateMyCard230\taskspec\Phase_opendomain\score_opendomain_dsl.mjs --out <DSL产物目录> [--case Q001] [--report r.json]
```

`check` 校验**数据集自身**：契约字段齐备且 `content` 与顶层一致、三个候选数组必须存在且为空、每个 token 确实能在本条 `userQuery` 中找到（否则该断言不成立）、`forbidToken` 不与 `userQuery` 冲突、单 token 条目不过弱。

`score` 校验**模型产物**：产物文件按用例号匹配（`Q001.*`，compact DSL 三段 JSONL 或任意文本都行），逐条给 PASS/FAIL/MISSING，有 FAIL 或缺产物时进程非零退出。它做五类判定：

- 越权硬约束（候选全空 → 出现 `"mode":"data"`、`"/data/` 路径、`onClick`/`clickTo`、`Image` 组件、`/asset/`、`resources/base/media`、`asset.`、`http(s)://`、`data:image`、`;base64`、emoji 字符，任一即 FAIL）
- 忠实性：`mustContainTokens` 去空白后必须能在产物文本中命中，否则判丢信息
- 编造：`forbidTokens`、`forbidAnyDate`，以及产物中出现的日期时间与"数值+单位"必须能在同条 `userQuery` 中找到（数值与单位需在产物中相邻才纳入比对，避免跨组件误报）
- 画布尺寸：解析 compact DSL `root` 的 `width`/`height`，2x2 应为 160×160、2x4 应为 320×160
- 容量舍弃：`mayOmitTokens` 缺失只记 WARN 并列出被舍弃项，不算失败

已用两份合成产物自测过判分方向：合规的 Q001 得 PASS（14 个必现 token 全中），故意造错的 Q016 同时抓到编造数据绑定、编造素材引用、丢信息、无日期却出现"10月8日"四类错误。

## 已知边界

- Q002、Q014、Q017 允许缺失部分条目，但"该舍哪几条"目前只给了 `droppable` 标记，没写死取舍顺序；如果你们链路有明确的截断策略（按时间最近/按原文顺序），告我，我把它写成 `dropOrder` 参与判分。
- 除 Q001 外的 17 条事实均为**合成数据**（`origin: "synthetic"`），只做结构与时序锚定用，不可当真实检索结果引用。
- `score` 是文本级判定，不解析组件树：排版分组是否保留、步骤是否保序、长书名截断是否改变语义、英文艺名是否被擅自翻译，仍需人工或模型判读。需要结构级校验请接 `skills/harmony-card-generation-offline/scripts/validate_card.py`。
- 若产物走的是标准 A2UI（`createSurface`/`updateComponents`/`updateDataModel` 三段）而不是 compact DSL，画布尺寸一项会记 WARN 跳过，其余判定不受影响。
