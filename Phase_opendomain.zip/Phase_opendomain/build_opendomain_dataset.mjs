import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));

// 真实线上载荷原样收在 reference_payload.json，作为唯一契约来源：
// Q001 直接由它产出，其余用例复用它的固定字段，不自己编形状。
const REF_FILE = path.join(here, "reference_payload.json");
const REF = JSON.parse(fs.readFileSync(REF_FILE, "utf8"));

// 开域卡契约：端侧零能力。三个候选数组必须存在且为空，卡片内容全部由改写后的 userQuery 承载。
// L1 originalQuery 只入 manifest（线上 utterance.original 实测为空串，不回传原话）。
const uuidFor = (seed) => {
  const words = [];
  for (let r = 0; r < 8; r++) {
    let h = 2166136261 >>> 0;
    for (const ch of `${seed}:${r}`) {
      h ^= ch.charCodeAt(0);
      h = Math.imul(h, 16777619) >>> 0;
    }
    words.push((h >>> 0).toString(16).padStart(8, "0"));
  }
  const s = words.join("");
  return `${s.slice(0, 8)}-${s.slice(8, 12)}-4${s.slice(13, 16)}-8${s.slice(17, 20)}-${s.slice(20, 32)}`;
};

const fact = (id, tokens, droppable = false) => ({ id, tokens, droppable });

const CASES = [
  {
    n: "Q001",
    origin: "real",
    reference: true,
    category: "演出",
    title: "上海演唱会",
    description: "近两月上海演唱会时间",
    size: "2x4",
    asOf: "20260921035929765",
    originalQuery: "生成一张静态卡片，展示最近两个月的上海演唱会。",
    userQuery:
      "生成一张静态卡片，展示最近两个月（2026年9月和10月）上海的演唱会时间安排。9月：李荣浩黑马巡回演唱会上海站9月25-26日上海体育场，潘玮柏MAD LOVE ULTRA巡回演唱会上海站9月19日上海虹口足球场，张智霖在巡回演唱会上海站9月19日上海东方体育中心。10月：泠鸢yousa羁绊环游线个人演唱会上海站10月3日回响之地前滩馆，Charlie Puth Whatever's Clever世界巡演上海站10月31日虹口足球场。",
    facts: [
      fact("f1", ["李荣浩", "9月25-26日", "上海体育场"]),
      fact("f2", ["潘玮柏", "MAD LOVE ULTRA", "9月19日"]),
      fact("f3", ["张智霖", "东方体育中心"]),
      fact("f4", ["泠鸢yousa", "10月3日", "回响之地前滩馆"]),
      fact("f5", ["Charlie Puth", "10月31日", "虹口足球场"])
    ],
    note: "真实线上载荷，作为基线锚点。跨月、跨天区间（9月25-26日）、全大写英文、含撇号英文名四类易丢/易改信息都在这一条里。"
  },
  {
    n: "Q002",
    origin: "synthetic",
    category: "演出",
    title: "十月演出清单",
    description: "十月北京演出安排",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张静态卡片，展示十月份北京的演唱会。",
    userQuery:
      "生成一张静态卡片，展示2026年10月北京的演唱会安排：10月2日五月天诺亚方舟演唱会鸟巢国家体育场，10月5日朴树好好活着演唱会工人体育场，10月8日华晨宇火星演唱会凯迪拉克中心，10月11日新裤子乐队的夏天展览剧场，10月15日陈奕迅FEAR and DREAMS演唱会首都体育馆，10月18日万能青年旅店冀西南林路行 MAO Livehouse，10月23日李宗盛有歌之年演唱会国家体育馆，10月29日草东没有派对北京站场馆待定。",
    facts: [
      fact("f1", ["五月天", "10月2日", "鸟巢国家体育场"]),
      fact("f2", ["朴树", "10月5日"]),
      fact("f3", ["华晨宇", "10月8日"]),
      fact("f4", ["新裤子", "10月11日"], true),
      fact("f5", ["陈奕迅", "10月15日", "首都体育馆"]),
      fact("f6", ["万能青年旅店", "10月18日"], true),
      fact("f7", ["李宗盛", "10月23日"]),
      fact("f8", ["草东没有派对", "10月29日"])
    ],
    note: "8 条超出 2x4 单卡容量。允许按时间顺序取舍，但舍弃后不得把标题写成十月全部演出或改成「部分演出」以外的误导表述。"
  },
  {
    n: "Q003",
    origin: "synthetic",
    category: "体育赛事",
    title: "CBA重点场次",
    description: "近期CBA赛程",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张卡片，展示最近两周的CBA比赛。",
    userQuery:
      "生成一张静态卡片，展示最近两周（2026年10月13日至10月19日）的CBA常规赛重点场次：10月15日19点35辽宁本钢对阵广东东莞大益，10月17日15点30北京首钢对阵浙江稠州金租，10月18日19点30上海久事对阵新疆伊力王酒。比赛场馆暂未确认。",
    facts: [
      fact("f1", ["辽宁本钢", "10月15日", "19点35"]),
      fact("f2", ["北京首钢", "10月17日", "15点30"]),
      fact("f3", ["上海久事", "10月18日"])
    ],
    forbidTokens: ["体育馆", "球馆", "主场馆"],
    note: "检索结果明确「场馆暂未确认」。产物出现任何场馆名即为编造。"
  },
  {
    n: "Q004",
    origin: "synthetic",
    category: "展览",
    title: "上海展览",
    description: "近期上海展讯",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张卡片，看看最近上海有什么展。",
    userQuery:
      "生成一张静态卡片，展示2026年9月下旬到10月的上海展览：莫奈与印象派大师原作展，浦东美术馆，9月20日至12月20日，每周一闭馆；从波提切利到梵高：英国国家美术馆珍藏展，上海博物馆人民广场馆，10月1日起开展，免费需预约；teamLab 无界数字艺术展，西岸美术馆，9月25日至11月30日，早鸟票199元。",
    facts: [
      fact("f1", ["莫奈与印象派大师原作展", "9月20日至12月20日", "每周一闭馆"]),
      fact("f2", ["英国国家美术馆珍藏展", "10月1日", "免费需预约"]),
      fact("f3", ["teamLab 无界数字艺术展", "9月25日至11月30日", "199元"])
    ],
    note: "考「闭馆规则/预约/票价」这类附属信息是否被丢掉或被简化成「门票」。"
  },
  {
    n: "Q005",
    origin: "synthetic",
    category: "场馆信息",
    title: "上野动物园门票",
    description: "开园时间与门票",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张卡片，展示上野动物园的开园时间和门票。",
    userQuery:
      "生成一张静态卡片，展示东京上野动物园的开园时间与门票信息：开园时间9:30至17:00（官方公布数据），最后入园16:30，休园日为12月29日至次年1月1日，门票成人600日元，中学生以下免费，身高1米以下儿童需成人陪同入园。",
    facts: [
      fact("f1", ["9:30至17:00"]),
      fact("f2", ["最后入园16:30"]),
      fact("f3", ["12月29日至次年1月1日"]),
      fact("f4", ["600日元"]),
      fact("f5", ["中学生以下免费"], true)
    ],
    note: "官方公布的开园时间与票价，属公开网页信息。休园日跨年区间与“最后入园”截止点最易丢。"
  },
  {
    n: "Q006",
    origin: "synthetic",
    category: "政务办事",
    title: "公积金贷款利率",
    description: "公积金贷款利率",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张卡片，展示现在的公积金贷款利率。",
    userQuery:
      "生成一张静态卡片，展示公积金贷款利率（官方网站公布）：首套住房5年以上2.85%，首套住房5年以下含5年2.35%，第二套住房5年以上3.325%，第二套住房5年以下含5年2.775%，执行起始日期为2026年5月18日。",
    facts: [
      fact("f1", ["2.85%", "首套住房5年以上"]),
      fact("f2", ["2.35%", "5年以下含5年"]),
      fact("f3", ["3.325%"], true),
      fact("f4", ["2.775%"], true),
      fact("f5", ["2026年5月18日"])
    ],
    note: "三位小数利率（3.325%/2.775%）与“5年以下含5年”的边界表述，是搜来的政策信息，不是用户自己的记事。"
  },
  {
    n: "Q007",
    origin: "synthetic",
    category: "影视",
    title: "周末排片",
    description: "本周电影排片",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张静态卡片，展示这周末的电影排片。",
    userQuery:
      "生成一张静态卡片，展示2026年9月26日至9月27日北京周末排片：《沙丘3》（DUNE: PART THREE）IMAX 3D 原版字幕，19:30 首都电影院西单店；《哪吒之魔童闹海》2D 国语，14:20 万达影城望京店；《F1：狂飙飞车》IMAX 2D 原版字幕，21:00 中国电影博物馆；《熊出没·重启未来》2D 国语，10:00 耀莱成龙影城五棵松店。",
    facts: [
      fact("f1", ["沙丘3", "DUNE: PART THREE", "IMAX 3D", "19:30"]),
      fact("f2", ["哪吒之魔童闹海", "14:20", "万达影城望京店"]),
      fact("f3", ["F1：狂飙飞车", "21:00", "中国电影博物馆"]),
      fact("f4", ["熊出没·重启未来", "10:00"], true)
    ],
    note: "全大写英文片名、英文冒号、中文书名号、版本格式（IMAX 3D / 2D）与放映制式（原版字幕/国语）混排。"
  },
  {
    n: "Q008",
    origin: "synthetic",
    category: "民生价格",
    title: "上海油价",
    description: "上海最新油价",
    size: "2x2",
    asOf: "20261010080000000",
    originalQuery: "生成一张卡片，展示上海的油价。",
    userQuery:
      "生成一张静态卡片，展示上海最新成品油零售价：92号汽油7.32元/升，95号汽油7.80元/升，0号柴油6.95元/升，调价时间为2026年10月10日24时。",
    facts: [fact("f1", ["92号汽油", "7.32元/升"]), fact("f2", ["95号汽油", "7.80元/升"]), fact("f3", ["0号柴油", "6.95元/升"], true)],
    note: "数值密度高，考小数位是否被四舍五入（7.32→7.3）。"
  },
  {
    n: "Q009",
    origin: "synthetic",
    category: "汇率",
    title: "今日汇率",
    description: "人民币中间价",
    size: "2x2",
    asOf: "20260921091000000",
    originalQuery: "生成一张静态卡片，展示今天的汇率。",
    userQuery:
      "生成一张静态卡片，展示2026年9月21日人民币兑外币中间价：美元 1:7.0832，欧元 1:7.8145，日元 100:4.6521，更新时间每日9点15分。",
    facts: [fact("f1", ["美元", "7.0832"]), fact("f2", ["欧元", "7.8145"]), fact("f3", ["日元", "100:4.6521"])],
    note: "4 位小数 + 日元是 100 单位比价（不是 1:），考单位错置。"
  },
  {
    n: "Q010",
    origin: "synthetic",
    category: "交通时刻",
    title: "地铁时刻",
    description: "2号线首末班车",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张卡片，展示地铁2号线的首末班时间。",
    userQuery:
      "生成一张静态卡片，展示上海地铁2号线各站首末班车时间（往浦东国际机场方向）：淞虹路 首班05:02 末班22:35，中山公园 首班05:24 末班23:01，龙阳路 首班05:41 末班23:18，广兰路 首班05:52 末班23:29，海天三路 首班06:10 末班23:47，浦东国际机场 末班到达23:58。工作日高峰行车间隔约3分钟。",
    facts: [
      fact("f1", ["淞虹路", "05:02", "22:35"]),
      fact("f2", ["中山公园", "05:24", "23:01"]),
      fact("f3", ["龙阳路", "05:41", "23:18"]),
      fact("f4", ["广兰路", "05:52", "23:29"]),
      fact("f5", ["海天三路", "06:10", "23:47"], true),
      fact("f6", ["浦东国际机场", "23:58"]),
      fact("f7", ["约3分钟"], true)
    ],
    note: "HH:MM 密度最高的类型，方向限定（往浦东国际机场方向）不能丢，「末班到达」与「末班发出」不能混。"
  },
  {
    n: "Q011",
    origin: "synthetic",
    category: "旅游攻略",
    title: "杭州两日行程",
    description: "杭州景点建议",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张静态卡片，展示杭州两天怎么玩。",
    userQuery:
      "生成一张静态卡片，展示杭州两日游推荐行程：第一天灵隐飞来峰，建议游玩3小时，门票45元；第一天西湖游船（含三潭印月），建议游玩2小时，票价70元；第一天河坊街历史街区，免费，建议游玩1.5小时；第二天西溪湿地周家村入口，门票80元，建议游玩4小时；第二天千岛湖龙山岛游船，建议游玩6小时，需提前一天预约。",
    facts: [
      fact("f1", ["灵隐飞来峰", "3小时", "45元"]),
      fact("f2", ["西湖游船", "2小时", "70元"]),
      fact("f3", ["河坊街历史街区", "免费", "1.5小时"]),
      fact("f4", ["西溪湿地周家村入口", "80元", "4小时"]),
      fact("f5", ["千岛湖龙山岛游船", "6小时", "需提前一天预约"], true)
    ],
    note: "每条含「第几天+时长+价格+附加条件」四要素，考分组结构是否被拉平成无序列表。"
  },
  {
    n: "Q012",
    origin: "synthetic",
    category: "菜谱",
    title: "红烧肉做法",
    description: "红烧肉步骤",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张卡片，展示红烧肉的做法。",
    userQuery:
      "生成一张静态卡片，展示红烧肉的六个步骤：第一步五花肉500克切方块冷水下锅焯水3分钟；第二步锅中放冰糖40克小火炒至琥珀色；第三步下肉块翻炒上色，加生抽30毫升、老抽15毫升；第四步加黄酒500毫升没过肉块，大火烧开后转小火炖60分钟；第五步转大火收汁至汤汁浓稠；第六步撒葱花10克出锅。",
    facts: [
      fact("f1", ["五花肉500克", "焯水3分钟"]),
      fact("f2", ["冰糖40克", "琥珀色"]),
      fact("f3", ["生抽30毫升", "老抽15毫升"]),
      fact("f4", ["黄酒500毫升", "60分钟"]),
      fact("f5", ["转大火收汁至汤汁浓稠"]),
      fact("f6", ["葱花10克"])
    ],
    note: "步骤类必须保序。考步骤序号丢失后被重排，以及计量单位（克/毫升）被省略。"
  },
  {
    n: "Q013",
    origin: "synthetic",
    category: "资费套餐",
    title: "5G套餐对比",
    description: "三家5G套餐参数",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张静态卡片，对比三家运营商的5G套餐。",
    userQuery:
      "生成一张静态卡片，对比三家运营商官网的5G套餐：中国移动 128元/月，国内流量30GB，通话500分钟；中国电信 159元/月，国内流量60GB，通话1000分钟；中国联通 199元/月，国内流量100GB，通话1500分钟。以上为2026年9月官网公示价格。",
    facts: [
      fact("f1", ["中国移动", "128元/月", "30GB", "500分钟"]),
      fact("f2", ["中国电信", "159元/月", "60GB"]),
      fact("f3", ["中国联通", "199元/月", "100GB", "1500分钟"]),
      fact("f4", ["2026年9月官网公示价格"])
    ],
    note: "跨条目并列同类数值（元/月、GB、分钟），考张冠李戴（把 100GB 配给中国电信）与价格时效来源丢失。实体用真实存在的运营商，不依赖未发布机型。"
  },
  {
    n: "Q014",
    origin: "synthetic",
    category: "演出",
    title: "演出清单含过期",
    description: "含已过期演出",
    size: "2x4",
    asOf: "20261102090000000",
    originalQuery: "生成一张静态卡片，展示最近两个月的上海演唱会。",
    userQuery:
      "生成一张静态卡片，展示上海的演唱会安排，今天是2026年11月2日，以下为搜索结果：李荣浩黑马巡回演唱会上海站9月25-26日上海体育场，潘玮柏MAD LOVE ULTRA巡回演唱会上海站9月19日上海虹口足球场，泠鸢yousa羁绊环游线个人演唱会上海站10月3日回响之地前滩馆，Charlie Puth Whatever's Clever世界巡演上海站10月31日虹口足球场，邓紫棋IAMGLORIA世界巡回演唱会上海站11月14日上海体育场。",
    todayStatedInQuery: true,
    facts: [
      fact("f1", ["李荣浩", "9月25-26日"], true),
      fact("f2", ["潘玮柏", "9月19日"], true),
      fact("f3", ["泠鸢yousa", "10月3日"], true),
      fact("f4", ["Charlie Puth", "10月31日"], true),
      fact("f5", ["邓紫棋", "11月14日", "上海体育场"])
    ],
    note: "query 内已写明今天是2026年11月2日，过期判定不依赖模型获取 deviceInfo。前四条已过期可舍弃，11月14日一条必现。"
  },
  {
    n: "Q015",
    origin: "synthetic",
    category: "演出",
    title: "演出信息冲突",
    description: "日期存在冲突",
    size: "2x2",
    asOf: "20260921090000000",
    originalQuery: "生成一张卡片，展示Charlie Puth上海站。",
    userQuery:
      "生成一张静态卡片，展示Charlie Puth Whatever's Clever世界巡演上海站信息。搜索结果存在冲突：主办方详情页写10月31日虹口足球场，票务平台页面写11月1日虹口足球场，两个来源均未标注改期说明。",
    facts: [fact("f1", ["Charlie Puth", "10月31日"]), fact("f2", ["11月1日"]), fact("f3", ["搜索结果存在冲突"])],
    note: "冲突信息不得被模型自行择一收敛成单一日期；应保留两个来源或明确标注待确认。"
  },
  {
    n: "Q016",
    origin: "synthetic",
    category: "无结果",
    title: "调图公告缺细节",
    description: "信息不完整",
    size: "2x2",
    asOf: "20260921090000000",
    originalQuery: "生成一张卡片，展示铁路调图后新增车次的时刻。",
    userQuery:
      "生成一张静态卡片，展示铁路部门列车运行图调整公告。公告正文只写明自下个月5日零时起实施新运行图，未公布新增车次数量、具体站点和开车时刻，涉及线路为京沪高铁。",
    facts: [fact("f1", ["下个月5日零时起"]), fact("f2", ["京沪高铁"]), fact("f3", ["未公布新增车次数量、具体站点和开车时刻"])],
    forbidAnyDate: true,
    note: "可搜索的公开公告，但检索结果缺具体日期与车次。产物出现任何具体年月日、车次号或开车时刻即为编造，正确做法是照抄「下个月5日零时起」并留白。"
  },
  {
    n: "Q017",
    origin: "synthetic",
    category: "超长清单",
    title: "剧场月度排期",
    description: "十月剧场排期",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张静态卡片，展示十月上海大剧院的排期。",
    userQuery:
      "生成一张静态卡片，展示上海大剧院十月排期，今天是2026年9月21日，以下为搜索结果：10月1日-3日芭蕾舞剧天鹅绒全馆，10月4日越剧梁山伯与祝英台，10月6日-7日话剧茶馆，10月8日昆曲牡丹亭青春版，10月10日交响乐布鲁克纳第八，10月12日音乐剧悲惨世界二十周年巡演，10月15日-16日京剧霸王别姬，10月18日现代舞剧春之祭，10月20日粤剧帝女花，10月22日话剧暗恋桃花源，10月25日-26日歌剧图兰朵，10月29日民乐合奏春江花月夜，10月31日万圣节特别音乐会。",
    todayStatedInQuery: true,
    facts: [
      fact("f1", ["10月1日-3日", "天鹅绒"]),
      fact("f2", ["10月4日", "梁山伯与祝英台"], true),
      fact("f3", ["10月6日-7日", "茶馆"], true),
      fact("f4", ["10月8日", "牡丹亭"], true),
      fact("f5", ["10月10日", "布鲁克纳第八"], true),
      fact("f6", ["10月12日", "悲惨世界"], true),
      fact("f7", ["10月15日-16日", "霸王别姬"], true),
      fact("f8", ["10月18日", "春之祭"], true),
      fact("f9", ["10月20日", "帝女花"], true),
      fact("f10", ["10月22日", "暗恋桃花源"], true),
      fact("f11", ["10月25日-26日", "图兰朵"], true),
      fact("f12", ["10月29日", "春江花月夜"], true),
      fact("f13", ["10月31日", "万圣节特别音乐会"], true)
    ],
    note: "13 条远超 2x4 容量。query 内写明今天是2026年9月21日，所以最近一场就是 10月1日-3日 那条，必现；其余允许按时间顺序舍弃，但不得随机挑中间几条、也不得把标题写成全年排期。"
  },
  {
    n: "Q018",
    origin: "synthetic",
    category: "纯英文",
    title: "London Shows",
    description: "London concert list",
    size: "2x4",
    asOf: "20260921090000000",
    originalQuery: "生成一张静态卡片，展示伦敦十月的演唱会。",
    userQuery:
      "生成一张静态卡片，展示 London October 2026 concert schedule：Adele — Moonlight Tour, Oct 3, The O2 Arena; Coldplay — Live World Tour, Oct 9, Wembley Stadium; Bruno Mars — An Evening, Oct 14, Royal Albert Hall; Ed Sheeran — UK Run, Oct 21, O2 Academy Brixton; Taylor Swift — Luz World Tour, Oct 28, Tottenham Hotspur Stadium. All times 19:30 local.",
    facts: [
      fact("f1", ["Adele", "Oct 3", "The O2 Arena"]),
      fact("f2", ["Coldplay", "Oct 9", "Wembley Stadium"]),
      fact("f3", ["Bruno Mars", "Oct 14", "Royal Albert Hall"]),
      fact("f4", ["Ed Sheeran", "Oct 21"], true),
      fact("f5", ["Taylor Swift", "Oct 28", "Tottenham Hotspur Stadium"]),
      fact("f6", ["19:30 local"])
    ],
    note: "全英文事实 + 半角连字符/分号分隔 + 时区标注。艺人与伦敦场馆均为真实存在的公开信息，日期为合成。考 locale zh-CN 下是否被擅自翻译成中文艺名（Bruno Mars→布鲁诺·马尔斯）。"
  }
];

const contentOf = (c) => ({
  functionName: REF.content.functionName,
  romVersion: REF.content.romVersion,
  bundleName: REF.content.bundleName,
  candidateEventCandidates: [],
  size: c.size,
  candidateDataBindings: [],
  candidateAssetIds: [],
  description: c.description,
  userQuery: c.userQuery,
  title: c.title
});

function build(c) {
  const content = contentOf(c);
  return {
    content,
    deviceInfo: { ...REF.deviceInfo, time: c.reference ? REF.deviceInfo.time : c.asOf },
    pagination: REF.pagination,
    session: c.reference
      ? REF.session
      : { interactionId: String(Number(c.n.slice(1))), isNew: REF.session.isNew, sessionId: uuidFor(c.n) },
    userAuth: REF.userAuth,
    utterance: { original: REF.utterance.original, type: REF.utterance.type },
    version: REF.version,
    ...content
  };
}

const manifest = {
  dataset: "phase_opendomain_v1",
  interface: "generateWidgetCardCompactDsl",
  note: "开域卡：小艺检索后把事实写进 userQuery，端侧数据/事件/素材能力全部为空数组。契约唯一来源是 reference_payload.json（真实线上载荷，逐字节收录），Q001 由它直接产出，其余用例复用其固定字段，只换 userQuery/title/description/size/deviceInfo.time/session。用例与 Phase_emoji、Phase_new_assets 完全隔离，不复用其素材判定规则。",
  reference: "reference_payload.json",
  scope: {
    included: "只收必须靠网络搜索才能拿到的公开信息：演出/赛事/展览排期、场馆开放时间与票价、政策与公告、民生价格、汇率、交通时刻、影视排片、攻略与菜谱、资费套餐、纯英文公开榜单。",
    excluded: "备忘录、待办清单、日历日程、个人课程表与个人书单等属于用户自有内容或端侧能力已覆盖的场景，不进本集（那些走 Phase_emoji / Phase_new_assets 的能力链路）。",
    entityPolicy: "机构、作品、线路、运营商等实体必须真实存在；日期、价格、场次等具体数值为合成占位，只用于判忠实性，不代表真实世界数值。",
    outCategories: ["备忘录", "待办", "日历", "日程", "课程", "书目", "个人计划"]
  },
  contract: {
    emptyCandidates: ["candidateDataBindings", "candidateEventCandidates", "candidateAssetIds"],
    wireOnlyFields: ["functionName", "romVersion"],
    utteranceOriginal: "线上实测为空串，原始 query 不回传，仅存于本 manifest 的 originalQuery 字段",
    timeAnchor: "deviceInfo.time 只是上游生成与人工判读的时序锚点；模型输入不含 deviceInfo，凡需要「今天」才能成立的判定必须把日期写进 userQuery 正文",
    fixedFromReference: ["functionName", "romVersion", "bundleName", "deviceInfo(除 time)", "pagination", "userAuth", "utterance", "version", "session.isNew"]
  },
  judging: {
    modelInputs: "模型只看到 userQuery、size、事件候选、dataModelSchema、素材候选（见 widget_service/docs/system_prompt.txt），看不到 deviceInfo，也不能自行检索。搜索与事实整理是上游小艺的职责，本集所有事实都已写死在 userQuery 里。",
    fidelity: "每条 fact 的 tokens 必须原样出现在 DSL 文本中（去空白后比对），droppable 为 true 的条目允许缺失",
    invention: "DSL 中出现的日期时间与带单位数值，必须能在同条 userQuery 中找到；forbidAnyDate 的条目出现任何日期即判编造",
    staticOnly: "候选全空，因此 DSL 不得出现 ${/data/ 绑定、事件动作、asset./resources/base/media 引用，也不得出现 http(s) 或 data: 网络与内联资源",
    ordering: "步骤类与时刻表类要求保序，取舍必须按时间或原文顺序，不得随机挑选",
    human: "分组结构是否保留、标题是否因取舍而失真、英文专名是否被擅自翻译，需人工或模型判读"
  },
  cases: CASES.map((c) => ({
    file: `${c.n}.json`,
    origin: c.origin,
    category: c.category,
    size: c.size,
    asOf: c.asOf,
    title: c.title,
    originalQuery: c.originalQuery,
    facts: c.facts,
    mustContainTokens: c.facts.filter((f) => !f.droppable).flatMap((f) => f.tokens),
    mayOmitTokens: c.facts.filter((f) => f.droppable).flatMap((f) => f.tokens),
    forbidTokens: c.forbidTokens ?? [],
    forbidAnyDate: c.forbidAnyDate ?? false,
    todayStatedInQuery: c.todayStatedInQuery ?? false,
    note: c.note
  }))
};

for (const c of CASES) {
  fs.writeFileSync(path.join(here, `${c.n}.json`), JSON.stringify(build(c)) + "\n", "utf8");
}
if (JSON.stringify(JSON.parse(fs.readFileSync(path.join(here, "Q001.json"), "utf8"))) !== JSON.stringify(REF)) {
  throw new Error("Q001 与 reference_payload.json 不一致（值或键序被改写）");
}
fs.writeFileSync(path.join(here, "opendomain_expected.json"), JSON.stringify(manifest, null, 2) + "\n", "utf8");
console.log(JSON.stringify({ cases: CASES.length, real: CASES.filter((c) => c.origin === "real").length, sizes: CASES.reduce((a, c) => ({ ...a, [c.size]: (a[c.size] ?? 0) + 1 }), {}) }, null, 2));
