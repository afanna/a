import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(fs.readFileSync(path.join(here, "opendomain_expected.json"), "utf8"));
const REF = JSON.parse(fs.readFileSync(path.join(here, "reference_payload.json"), "utf8"));
const files = fs.readdirSync(here).filter((n) => /^Q\d+\.json$/.test(n)).sort();
const strip = (s) => (s ?? "").replace(/\s+/g, "");
const shape = (o, p = "") =>
  Object.entries(o).flatMap(([k, v]) => {
    const t = Array.isArray(v) ? "array" : v === null ? "null" : typeof v;
    const at = `${p}/${k}=${t}`;
    return v && typeof v === "object" && !Array.isArray(v) ? [at, ...shape(v, at)] : [at];
  });
const REF_SHAPE = shape(REF).join("\n");
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const CONTENT_KEYS = [
  "functionName",
  "romVersion",
  "bundleName",
  "candidateEventCandidates",
  "size",
  "candidateDataBindings",
  "candidateAssetIds",
  "description",
  "userQuery",
  "title"
];
const DATE_SRC = String.raw`\d{1,2}月\d{1,2}[-到至]?\d{0,2}日?|\d{4}年|\d{1,2}:\d{2}|\d{1,2}点\d{1,2}分?`;
const hasDate = (s) => new RegExp(DATE_SRC).test(s);
const errors = [];
const warnings = [];

if (files.length !== manifest.cases.length) errors.push(`文件数 ${files.length} 与 manifest ${manifest.cases.length} 不符`);

for (const c of manifest.cases) {
  const spec = JSON.parse(fs.readFileSync(path.join(here, c.file), "utf8"));
  const content = spec.content ?? {};

  for (const key of CONTENT_KEYS) {
    if (!(key in content)) errors.push(`${c.file}: content 缺字段 ${key}`);
    if (JSON.stringify(content[key]) !== JSON.stringify(spec[key])) errors.push(`${c.file}: 顶层 ${key} 与 content 不一致`);
  }
  if (content.functionName !== manifest.interface) errors.push(`${c.file}: functionName 应为 ${manifest.interface}`);
  for (const key of manifest.contract.emptyCandidates) {
    if (!Array.isArray(content[key]) || content[key].length) errors.push(`${c.file}: ${key} 必须是空数组`);
  }
  if (spec.utterance?.original !== "") errors.push(`${c.file}: 线上开域载荷 utterance.original 为空串`);
  if (spec.session?.isNew !== false) errors.push(`${c.file}: 开域为多轮技能触发，isNew 应为 false`);
  if (!/^[0-9]{17}$/.test(spec.deviceInfo?.time ?? "")) errors.push(`${c.file}: deviceInfo.time 非 17 位时间戳`);
  if (!["2x2", "2x4"].includes(content.size)) errors.push(`${c.file}: size ${content.size} 非法`);
  if (c.size !== content.size) errors.push(`${c.file}: manifest size 与载荷不符`);

  if (shape(spec).join("\n") !== REF_SHAPE) errors.push(`${c.file}: 字段骨架或键序偏离真实示例载荷`);
  const fixed = [
    ["functionName", REF.content.functionName, content.functionName],
    ["romVersion", REF.content.romVersion, content.romVersion],
    ["bundleName", REF.content.bundleName, content.bundleName],
    ["version", REF.version, spec.version],
    ["pagination", JSON.stringify(REF.pagination), JSON.stringify(spec.pagination)],
    ["userAuth", JSON.stringify(REF.userAuth), JSON.stringify(spec.userAuth)],
    ["utterance", JSON.stringify(REF.utterance), JSON.stringify(spec.utterance)],
    ["session.isNew", REF.session.isNew, spec.session?.isNew]
  ];
  for (const [label, want, got] of fixed) {
    if (want !== got) errors.push(`${c.file}: ${label} 与示例不一致（示例 ${want} / 本条 ${got}）`);
  }
  for (const k of Object.keys(REF.deviceInfo)) {
    if (k === "time") continue;
    if (spec.deviceInfo?.[k] !== REF.deviceInfo[k]) errors.push(`${c.file}: deviceInfo.${k} 与示例不一致`);
  }
  if (!UUID_RE.test(spec.session?.sessionId ?? "")) errors.push(`${c.file}: sessionId 不是示例那种 UUID 形状`);
  if (c.origin === "real" && JSON.stringify(spec) !== JSON.stringify(REF)) {
    errors.push(`${c.file}: 标为真实示例但载荷与 reference_payload.json 不逐字段一致`);
  }
  if (c.origin !== "real" && JSON.stringify(spec) === JSON.stringify(REF)) {
    errors.push(`${c.file}: 合成用例复用了示例的 session/设备时间戳`);
  }

  const uq = strip(content.userQuery);
  for (const bad of manifest.scope.outCategories) {
    if (c.category.includes(bad)) errors.push(`${c.file}: 类目「${c.category}」命中排除项「${bad}」，开域集只收网络可搜索的公开信息`);
  }
  if (c.todayStatedInQuery && !/今天是\d{4}年\d{1,2}月\d{1,2}日/.test(uq)) {
    errors.push(`${c.file}: 判分依赖「今天」，但 userQuery 未写明日期（模型看不到 deviceInfo）`);
  }
  if (!c.facts.length) errors.push(`${c.file}: 没有 fact 锚点`);
  for (const f of c.facts) {
    if (!f.tokens.length) errors.push(`${c.file}/${f.id}: 无 token`);
    for (const t of f.tokens) {
      if (!uq.includes(strip(t))) errors.push(`${c.file}/${f.id}: token「${t}」不在本条 userQuery 内，判分不成立`);
      if (strip(t).length < 3 && f.tokens.length === 1) warnings.push(`${c.file}/${f.id}: 该条目只有一个短 token「${t}」，判分太弱`);
    }
  }
  for (const t of c.forbidTokens) {
    if (uq.includes(strip(t))) errors.push(`${c.file}: forbidToken「${t}」出现在 userQuery 内，规则自相矛盾`);
  }
  if (c.forbidAnyDate && hasDate(uq)) {
    warnings.push(`${c.file}: 标了 forbidAnyDate 但 userQuery 含绝对日期，编造检测会漏判`);
  }
  if (!c.mustContainTokens.length) warnings.push(`${c.file}: 无必现 token`);
  if (c.note && !/。|）|\)/.test(c.note)) warnings.push(`${c.file}: note 过短`);
}

const dup = manifest.cases.map((c) => c.file).filter((x, i, a) => a.indexOf(x) !== i);
if (dup.length) errors.push(`manifest 重复条目: ${dup.join(",")}`);
const sids = manifest.cases.map((c) => JSON.parse(fs.readFileSync(path.join(here, c.file), "utf8")).session.sessionId);
const dupSid = [...new Set(sids.filter((x, i, a) => a.indexOf(x) !== i))];
if (dupSid.length) errors.push(`sessionId 重复，回放会串会话: ${dupSid.join(",")}`);

console.log(
  JSON.stringify(
    {
      files: files.length,
      contractSource: "reference_payload.json",
      realCaseAligned: manifest.cases.filter((c) => c.origin === "real").length,
      errors: errors.slice(0, 20),
      errorCount: errors.length,
      warnings: warnings.slice(0, 20),
      warningCount: warnings.length,
      categories: manifest.cases.reduce((a, c) => ({ ...a, [c.category]: (a[c.category] ?? 0) + 1 }), {}),
      factsTotal: manifest.cases.reduce((s, c) => s + c.facts.length, 0),
      mustContainTokens: manifest.cases.reduce((s, c) => s + c.mustContainTokens.length, 0),
      inventionGuardCases: manifest.cases.filter((c) => c.forbidAnyDate).length
    },
    null,
    2
  )
);
if (errors.length) process.exitCode = 1;
