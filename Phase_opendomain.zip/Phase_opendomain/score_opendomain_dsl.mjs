import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const arg = (name, fallback) => {
  const i = argv.indexOf(`--${name}`);
  return i >= 0 && argv[i + 1] ? argv[i + 1] : fallback;
};

const outArg = arg("out", null);
if (!outArg) {
  console.error("用法: node score_opendomain_dsl.mjs --out <DSL产物目录或单文件> [--case Q001] [--report report.json]");
  process.exit(2);
}
if (!fs.existsSync(outArg)) {
  console.error(`找不到 --out 路径: ${outArg}`);
  process.exit(2);
}

const manifest = JSON.parse(fs.readFileSync(path.join(here, "opendomain_expected.json"), "utf8"));
const strip = (s) => (s ?? "").replace(/\s+/g, "");
const DATE_SRC =
  String.raw`\d{1,2}月\d{1,2}(?:[-到至]\d{1,2})?日?|\d{4}年\d{1,2}月(?:\d{1,2}日)?|\d{1,2}:\d{2}|\d{1,2}点\d{1,2}分?|\d{1,2}点|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}\b`;
const UNIT_SRC = String.raw`\d+(?:\.\d+)?\s*(?:元|升|%|折|小时|分钟|公里|毫升|克|kg|GB|TB|mAh|英寸|寸)`;
const EMOJI_RE = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}]/u;

const CANVAS = { "2x2": { width: 160, height: 160 }, "2x4": { width: 320, height: 160 } };

function collectFiles(root) {
  const st = fs.statSync(root);
  if (st.isFile()) return [root];
  const walk = (dir) =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]));
  return walk(root);
}

const files = collectFiles(outArg);
const caseOnly = arg("case", null);
const results = [];

for (const c of manifest.cases) {
  const id = c.file.replace(/\.json$/, "");
  if (caseOnly && caseOnly !== id) continue;
  const spec = JSON.parse(fs.readFileSync(path.join(here, c.file), "utf8"));
  const candidates = files.filter((f) => path.basename(f).startsWith(id));
  if (!candidates.length) {
    results.push({ case: id, title: c.title, category: c.category, verdict: "MISSING", errors: ["未找到 DSL 产物文件"], warnings: [] });
    continue;
  }
  const raw = fs.readFileSync(candidates[0], "utf8");
  const flat = strip(raw);
  const uq = strip(spec.userQuery);
  const errors = [];
  const warnings = [];

  const hit = (label, re) => {
    const m = raw.match(re);
    if (m) errors.push(`${label}：候选全空时不允许出现 ${JSON.stringify(m[0]).slice(0, 60)}`);
    return !!m;
  };

  hit("编造数据绑定", /"mode"\s*:\s*"data"|"path"\s*:\s*"\/data\//);
  hit("编造事件", /"onClick"|"clickTo[A-Za-z]+"/);
  hit("编造素材引用", /resources\/base\/media|"\/asset\/|"component"\s*:\s*"Image"|,"Image",|"asset\./);
  hit("网络或内联资源", /https?:\/\/|data:image|;base64/);
  if (EMOJI_RE.test(raw)) errors.push(`禁用 emoji 字符：${JSON.stringify(raw.match(EMOJI_RE)[0])}`);

  for (const t of c.mustContainTokens) if (!flat.includes(strip(t))) errors.push(`丢信息：必现内容「${t}」未出现在产物中`);
  const dropped = c.mayOmitTokens.filter((t) => !flat.includes(strip(t)));
  if (dropped.length) warnings.push(`按容量舍弃 ${dropped.length} 项：${dropped.join("、")}`);

  for (const t of c.forbidTokens) if (flat.includes(strip(t))) errors.push(`编造：禁止内容「${t}」出现在产物中`);

  const datesIn = (s) => [...new Set((s.match(new RegExp(DATE_SRC, "g")) || []).map(strip))];
  const newDates = datesIn(raw).filter((d) => !uq.includes(d));
  if (c.forbidAnyDate && datesIn(raw).length) errors.push(`编造：该条 userQuery 无任何日期，产物却出现 ${datesIn(raw).join("、")}`);
  else if (newDates.length) errors.push(`编造：产物日期 ${newDates.join("、")} 无法在 userQuery 中找到`);

  const units = [...new Set((raw.match(new RegExp(UNIT_SRC, "g")) || []).map(strip))];
  const newUnits = units.filter((u) => !uq.includes(u));
  if (newUnits.length) errors.push(`编造/篡改数值：产物中的 ${newUnits.join("、")} 与 userQuery 不一致`);

  const root = raw.match(/\[\s*"root"\s*,\s*"?[A-Za-z]+"?\s*,\s*\{[^{}]*"width"\s*:\s*(\d+)[^{}]*"height"\s*:\s*(\d+)/);
  if (root) {
    const want = CANVAS[c.size];
    if (Number(root[1]) !== want.width || Number(root[2]) !== want.height)
      errors.push(`画布尺寸 ${root[1]}x${root[2]} 与期望 ${c.size}（${want.width}x${want.height}）不符`);
  } else {
    warnings.push("未解析到 compact DSL 的 root width/height，跳过画布尺寸校验");
  }

  results.push({
    case: id,
    title: c.title,
    category: c.category,
    file: path.relative(process.cwd(), candidates[0]),
    verdict: errors.length ? "FAIL" : "PASS",
    errors,
    warnings,
    facts: c.facts.length,
    mustContain: c.mustContainTokens.length,
    dropped
  });
}

const fails = results.filter((r) => r.verdict === "FAIL");
const summary = {
  dataset: manifest.dataset,
  scored: results.length,
  total: manifest.cases.length,
  pass: results.filter((r) => r.verdict === "PASS").length,
  fail: fails.length,
  missing: results.filter((r) => r.verdict === "MISSING").length,
  errorKinds: results.flatMap((r) => r.errors).reduce((a, e) => {
    const k = e.split("：")[0];
    a[k] = (a[k] ?? 0) + 1;
    return a;
  }, {})
};
const report = { summary, results };
const reportPath = arg("report", null);
if (reportPath) fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + "\n", "utf8");
console.log(JSON.stringify(report, null, 2));
process.exitCode = fails.length || summary.missing ? 1 : 0;
