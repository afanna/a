---
name: card-runtime-capture
description: 在 CreateMyCard 微服务运行或批跑时采集 L1/L2 候选测试资产，导出可移交的 Trace、模型消息、原始输出、诊断和缺失清单；用于采集数据，不执行评测或生成正确答案。
---

# 卡片微服务运行数据采集

在用户授权的本地调试运行期间读取现有 Trace，生成一个可交给其他 Agent 分析的 ZIP。原始数据不修改、不自动重试请求、不增加模型调用、不自动判定语义正确。

## 执行前

1. 定位项目根目录，阅读其 AGENTS.md 和云侧方案；阶段与采集点见 [references/capture.md](references/capture.md)。本 Skill 附带脚本只依赖标准库及项目的 TraceImporter，不需安装模型依赖。
2. 用户已经安排运行时，附着采集即可；没有请求来源时不要自行发起付费生成。采集授权不代表允许停止共享服务、改变生成策略或重跑失败请求。
3. 检查实际进程的 `enable_generation_trace_recording`、`generation_trace_root` 和工作目录。相对 Trace 路径按服务进程工作目录解析，不按当前终端猜测。批跑可从 `request.json`、`response.json`、`result.json` 关联 UID。不要替用户编造 UID。
4. Trace 关闭时，只在本次授权的独立调试进程/配置中开启；配置在启动时加载，已有进程不一定热生效。复用项目启动方式，不改默认配置、业务开关、预算和模型。共享进程需要重启时先报告影响；已有 Trace 可直接导出。不能通过补请求弥补缺失数据。

## 自动采集

使用脚本实际绝对路径；下面命令从项目根目录执行，输出到已忽略的 `output/`，每次选择新的目录。

```powershell
# 先启动监听，再进行用户原本计划的微服务请求；监听 10 分钟后自动打包。
python skills/card-runtime-capture/scripts/capture.py --repo . --trace-root <实际Trace绝对目录> --output output/capture-20261123-01 --duration 600

# 指定一个真实 UID，等待它结束；--until-terminal 提前结束，不等待整个窗口。
python skills/card-runtime-capture/scripts/capture.py --repo . --trace-root <实际Trace绝对目录> --output output/capture-one --uid <真实UID> --duration 600 --until-terminal

# 已结束的请求立即导出，可附加本次请求、响应和人工整理的运行上下文。
python skills/card-runtime-capture/scripts/capture.py --repo . --trace-root <实际Trace绝对目录> --output output/capture-existing --uid <真实UID> --request <request.json> --response <response.json> --context <context.json>
```

全根监听默认忽略启动前已经结束的请求；`--include-existing` 才纳入旧请求。启动时仍在记录的请求会被采集。指定 UID 不受此过滤。等待超时会导出已观察到的未结束请求并明确标记；按 Ctrl+C 会结束监听并导出已发现的数据。不要强杀采集进程。

Agent 使用异步终端会话运行监听，定期查看简短进度并处理用户输入；不要在工具调用中阻塞等待数分钟。不打印提示词正文。脚本只输出发现/完成计数与结果路径。

## 补齐、检查和交付

- 读导出的 `capture_manifest.json`、`requests/*/artifact_index.json`、`coverage.json` 和 importer warnings。`complete` 只表示 Trace 导入情况，不证明 L1/L2 输入完整、业务成功或语义正确。
- 仅从实际运行取补充数据：原始请求及显式字段、实际生效的白名单设置、版本/代码摘要、编辑来源等。不要收集整个 `.env`、全局环境、设备安装清单或完整服务日志。填写来源和缺失原因，不从最终卡片倒造历史。
- `--context` 建议使用 JSON：代码版本、是否有本地改动、模型公开名称、生效重试设置、注册表/协议标识及摘要、资源摘要、显式测试尺寸、来源说明；不存在的数据填 missing，不猜测。多个请求的补充材料用独立目录导出，避免关联错误。
- 导出包含原始模型消息、身份及业务内容，默认 `privacyReviewRequired=true`。交付前在本地检查这些文件，移除凭据、签名参数、身份与不宜分享的个人事实。需要替换时使用 `--redactions <本地JSON文件>` 重新导出：对象键为精确原字符串，值为仅含字母数字、下划线或连字符的占位符。映射文件不能放进导出目录或发给用户。程序不会保证自动识别全部敏感内容。
- 脱敏版保留原附件摘要作为来源证据，`exported_files.json` 是导出后字节摘要；替换可能使原始协议/摘要关系不再可重放。`sanitized=true` 的包只能作为候选素材，后续必须重新校验。不要把原摘要改成新摘要伪装原始证据。
- 确认 ZIP 内只有明确允许的文件；原始未脱敏目录和包不作为分享链接。交付审核后的 ZIP，说明捕获请求数量、各 Trace 状态、缺失材料、是否脱敏及仍需人工标注的预期。不自动上传或发送到外部服务。
- 没有可用 Trace 时如实交付缺失报告，不称采集成功。恢复本次临时配置，不停止用户仍需使用的服务。

## 验证边界

本 Skill 收集观察证据，不建设 L2 运行器，不替代生产校验器。模型消息可供历史回放；评估新提示词还需要生产重建上下文。测试预期、语义标准和基线必须另行确认。导出只包含实际经过的分支，不能声称成功请求覆盖修复、主备和所有编辑路径。
