# 采集依据和移交清单

适用于当前 `generation-trace-v2`。发生格式变化先核对生产 recorder 与 Debug Tools importer，不自行兼容未知格式。

## 真实来源

| 数据 | 位置或附件名 | 限制 |
| --- | --- | --- |
| 归一化请求 | `normalized_generation_request` | 不替代入口原始请求及显式字段 |
| Plan | `plan_prompt`、`plan_extracted_output`、`accepted_plan`、`plan_validation_errors` | 接受计划并非每个分支都会产生同名附件 |
| DSL | `dsl_prompt_final`、`dsl_extracted_output` | 提取后文本不等于原始模型响应 |
| 转换与检查 | `dsl_processing_input`、`dsl_processing_output`、`dsl_processing_issues` | 仍需协议与能力版本才能重跑 |
| 修复 | `repair_invalid_source_dsl`、`repair_strategy`、`repair_extracted_output` | 每轮消息和反馈要完整，不只保存末轮 |
| 模型边界 | `{phase}_model_messages`、`{phase}_assistant_raw` | 通过事件、span、attempts 和 details 关联逻辑/物理调用 |
| 静态复核 | `static_plan_review_candidate`、`static_plan_review_prompt`、`static_plan_review_output` | phase 可能仍为 plan，按附件和事件识别子任务 |
| 编辑 | `edit_intent`、`edit_diagnostics`、`edit_final_artifact`；phase 为 edit_intent/edit_execute | 另取真实来源原卡；不下载猜测来源 |
| 主题 | phase=theme 的消息/响应及主题事件 | 若前景、overrides 未完整保存，登记缺失 |
| 交付 | `final_artifact`、`generation_response` | 实际存储/上传字节可能需要额外取得 |

微服务 `generation_trace_recorder.py` 将 UID 映射为 `task_type/identifier/request_sequence/retry_count`，附件描述含路径、SHA-256、字节数。复用 `debug_tools.batch_testing.trace_parser.TraceImporter` 的公开 `read/import_trace/directory_for_uid`，由它校验结构、附件路径和摘要并生成视图；不复制校验实现。

## 导出目录

```text
capture_manifest.json      # 采集状态，不是业务评测通过与否
coverage.json              # 附件存在性和不可自动取得的数据清单
exported_files.json        # 导出文件的字节数与 SHA-256
requests/<uid>/
  source/manifest.json     # 原始 Trace manifest
  source/trace.jsonl       # 原始事件
  view.json               # 生产 importer 归一化视图
  import_manifest.json
  artifact_index.json     # 事件、阶段、attempt、附件名到 blob 的映射
trace_blobs/<sha256>       # importer 校验后复制的内容，可共享去重
trace_blob_manifest.json
supplements/               # 仅显式传入的请求、响应及 context
```

ZIP 放在导出目录旁边。未进入已校验 blob 的损坏附件不复制；warnings 保留原因。目录是原始本地证据，交付需隐私复核；精准替换后导出的索引保留来源摘要，导出摘要另存，不视为直接可运行的金样本。

## 对后续 L1/L2 的可用程度

- L1 候选：请求＋固定模型响应＋配置＋来源/存储依赖；当前观察结果不是期望，预算和终态另按方案确认。
- L2 历史回放候选：目标阶段实际消息＋原始响应＋生产诊断。
- L2 当前生产重建候选：还需要原始业务输入、任务上下文、固定合法 Plan/意图、能力/协议和提示词资源版本。
- 需要人工提供：核心目标、允许差异、禁止修改、正确答案或语义标准。
- 只能从工具/设备取得：批跑状态、评分证据、截图、真实设备边界，不属于微服务 Trace。

`coverage.json` 的“存在”只检查名称是否出现且附件可读，不证明内容足够、正确或适用于全部阶段。对于未经过的分支，缺少输出属于正常情况；不要为凑齐字段额外调用模型。
