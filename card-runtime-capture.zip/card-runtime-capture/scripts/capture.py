"""导出微服务 Trace 候选资产；复用项目 importer，不调用模型。"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import shutil
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def read_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"需要 JSON 对象：{path.name}")
    return value


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_importer(repo: Path):
    sys.path.insert(0, str(repo.resolve()))
    from debug_tools.batch_testing.trace_parser import TraceImporter

    return TraceImporter


def discover(importer: Any) -> dict[str, str]:
    found: dict[str, str] = {}
    root = importer.trace_root
    for path in root.glob("*/*/*/*/manifest.json"):
        if not path.resolve().is_relative_to(root):
            continue
        try:
            manifest = read_object(path)
        except (OSError, ValueError):
            continue
        uid = manifest.get("uid")
        if not isinstance(uid, str):
            continue
        directory = importer.directory_for_uid(uid)
        if directory is None:
            continue
        if directory.resolve() != path.parent.resolve():
            continue
        found[uid] = str(manifest.get("state", "unknown"))
    return found


def observe(
    importer: Any,
    duration: float,
    uid: str | None,
    include_existing: bool,
    until_terminal: bool,
) -> dict[str, str]:
    initial = discover(importer)
    excluded = set()
    if duration > 0 and not include_existing and uid is None:
        for key, state in initial.items():
            if state in {"complete", "partial"}:
                excluded.add(key)
    observed: dict[str, str] = {}
    deadline = time.monotonic() + duration
    previous = None
    try:
        while True:
            for key, state in discover(importer).items():
                if key in excluded:
                    continue
                if uid is not None and key != uid:
                    continue
                observed[key] = state
            terminal = sum(state in {"complete", "partial"} for state in observed.values())
            progress = (len(observed), terminal)
            if progress != previous:
                print(f"observed={progress[0]} terminal={terminal}", flush=True)
                previous = progress
            if until_terminal and uid is not None and terminal == 1:
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(1.0, remaining))
    except KeyboardInterrupt:
        print("监听结束，导出已发现请求。", flush=True)
    return observed


def artifact_index(destination: Path, blobs: Path) -> list[dict[str, Any]]:
    source = destination / "source" / "trace.jsonl"
    index: list[dict[str, Any]] = []
    if not source.is_file():
        return index
    for line in source.read_text(encoding="utf-8").splitlines():
        try:
            record = json.loads(line)
        except ValueError:
            continue  # importer 的 warnings 已登记非法记录，不能当作完整数据。
        if not isinstance(record, dict):
            continue
        artifacts = record.get("artifacts")
        if not isinstance(artifacts, dict):
            continue
        for name, reference in artifacts.items():
            if not isinstance(reference, dict):
                continue
            digest = reference.get("sha256")
            available = False
            blob_path = None
            if isinstance(digest, str) and re.fullmatch(r"[a-f0-9]{64}", digest):
                blob = blobs / digest
                if blob.is_file():
                    available = blob.stat().st_size == reference.get("bytes")
                    if available:
                        blob_path = f"trace_blobs/{digest}"
            index.append({
                "name": name,
                "event": record.get("event"),
                "stage": record.get("stage"),
                "operation": record.get("operation"),
                "spanId": record.get("spanId"),
                "sequence": record.get("sequence"),
                "attempts": record.get("attempts", {}),
                "details": record.get("details", {}),
                "sourceSha256": digest,
                "available": available,
                "file": blob_path,
            })
    return index


def export_request(importer: Any, uid: str, output: Path) -> dict[str, Any]:
    directory = importer.directory_for_uid(uid)
    if directory is None:
        raise ValueError("UID 格式不合法")
    if not directory.resolve().is_relative_to(importer.trace_root):
        raise ValueError("Trace 目录越界")
    for name in ("manifest.json", "trace.jsonl"):
        if not (directory / name).resolve().is_relative_to(directory.resolve()):
            raise ValueError("Trace 文件路径越界")
    destination = output / "requests" / uid
    view = importer.import_trace(uid, destination, output / "trace_blobs")
    index = artifact_index(destination, output / "trace_blobs")
    write_json(destination / "artifact_index.json", index)
    names = sorted({entry.get("name") for entry in index if entry.get("available")})
    return {
        "uid": uid,
        "traceStatus": view.get("status"),
        "warnings": view.get("warnings", []),
        "artifactNames": names,
    }


def load_redactions(path: Path | None) -> dict[str, str]:
    if path is None:
        return {}
    mapping = read_object(path)
    for original, replacement in mapping.items():
        if not original or not isinstance(replacement, str):
            raise ValueError("脱敏映射需要非空原文和字符串占位符")
        if not re.fullmatch(r"[A-Za-z0-9_-]+", replacement):
            raise ValueError("占位符仅允许字母数字、下划线和连字符")
    return mapping


def seal(output: Path, redactions: dict[str, str]) -> Path:
    entries = []
    for path in sorted(output.rglob("*")):
        if not path.is_file():
            continue
        if redactions:
            content = path.read_text(encoding="utf-8")
            for original, replacement in redactions.items():
                content = content.replace(original, replacement)
            path.write_text(content, encoding="utf-8", newline="")
        payload = path.read_bytes()
        entries.append({
            "file": path.relative_to(output).as_posix(),
            "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(),
        })
    write_json(output / "exported_files.json", entries)
    return Path(shutil.make_archive(str(output), "zip", root_dir=output))


def run(args: argparse.Namespace) -> Path:
    if not math.isfinite(args.duration) or args.duration < 0:
        raise ValueError("duration 不能小于零")
    if args.until_terminal and args.uid is None:
        raise ValueError("until-terminal 必须指定 UID")
    output = args.output.resolve()
    root = args.trace_root.resolve()
    if output.is_relative_to(root) or root.is_relative_to(output):
        raise ValueError("导出与 Trace 目录不能互相包含")
    if output.exists() or Path(str(output) + ".zip").exists():
        raise ValueError("导出目录或 ZIP 已存在，请选择新目录")
    redactions = load_redactions(args.redactions)
    importer = load_importer(args.repo)(root)
    if args.uid is not None and importer.directory_for_uid(args.uid) is None:
        raise ValueError("UID 格式不合法")
    output.mkdir(parents=True)
    observed = observe(
        importer, args.duration, args.uid, args.include_existing, args.until_terminal,
    )
    requests = []
    for uid in sorted(observed):
        requests.append(export_request(importer, uid, output))
    for key in ("request", "response", "context"):
        source = getattr(args, key)
        if source is not None:
            if len(requests) != 1:
                raise ValueError("补充材料必须关联唯一请求，请指定 UID 单独导出")
            target = output / "supplements" / f"{key}.json"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
    manifest = {
        "schemaVersion": "card-runtime-capture-v1",
        "createdAt": datetime.now(UTC).isoformat(),
        "requestCount": len(requests),
        "requestedUid": args.uid,
        "observedStates": observed,
        "requests": requests,
        "privacyReviewRequired": True,
        "sanitized": bool(redactions),
        "replayReadiness": "not-assessed",
    }
    write_json(output / "capture_manifest.json", manifest)
    write_json(output / "coverage.json", {
        "requests": requests,
        "notAutomaticallyProven": [
            "原始入口请求及字段省略语义是否完整",
            "实际配置、注册表和协议资源快照是否完整",
            "编辑来源、主题前景和每轮历史是否足够重建阶段",
            "用户预期、语义标准和基线，需要人工确认",
        ],
        "emptyCapture": not requests,
    })
    archive = seal(output, redactions)
    print(f"captured={len(requests)} archive={archive}", flush=True)
    return archive


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--trace-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--uid")
    parser.add_argument("--duration", type=float, default=0.0)
    parser.add_argument("--include-existing", action="store_true")
    parser.add_argument("--until-terminal", action="store_true")
    for key in ("request", "response", "context", "redactions"):
        parser.add_argument(f"--{key}", type=Path)
    args = parser.parse_args()
    archive = run(args)
    if archive.is_file():
        manifest = read_object(args.output / "capture_manifest.json")
        if not manifest.get("requestCount"):
            raise SystemExit(2)


if __name__ == "__main__":
    main()
