"""使用真实 Trace writer/importer 验证采集，不访问网络或模型。"""

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "widget_service" / "cloud"))

import capture  # noqa: E402
from services.generation_trace_recorder import GenerationTraceRecorder  # noqa: E402

UID = "batch-1234abcd-00001-000"
REPO = Path(__file__).resolve().parents[3]


def make_trace(root):
    recorder = GenerationTraceRecorder()
    recorder.bind_request(UID, enabled=True, trace_root=root)
    recorder.record(
        "plan.prompt.built",
        stage="plan.promptBuild",
        json_artifacts={"plan_prompt": [{"role": "user", "content": "private-user-42"}]},
    )
    recorder.finalize(status="failed")
    return root / "batch" / "1234abcd" / "00001" / "000"


def arguments(tmp_path, **changes):
    values = {
        "repo": REPO,
        "trace_root": tmp_path / "traces",
        "output": tmp_path / "export",
        "uid": UID,
        "duration": 0.0,
        "include_existing": False,
        "until_terminal": False,
        "request": None,
        "response": None,
        "context": None,
        "redactions": None,
    }
    values.update(changes)
    return argparse.Namespace(**values)


def test_real_trace_exports_verified_blob_and_stage_index(tmp_path):
    args = arguments(tmp_path)
    make_trace(args.trace_root)
    archive = capture.run(args)
    manifest = capture.read_object(args.output / "capture_manifest.json")
    assert manifest.get("requestCount") == 1
    assert manifest.get("privacyReviewRequired") is True
    index = json.loads((args.output / "requests" / UID / "artifact_index.json").read_text())
    item = index[0]
    assert item.get("stage") == "plan.promptBuild"
    assert item.get("available") is True
    path_value = item.get("file")
    assert isinstance(path_value, str)
    digest = hashlib.sha256((args.output / path_value).read_bytes()).hexdigest()
    assert digest == item.get("sourceSha256")
    with zipfile.ZipFile(archive) as package:
        assert path_value in package.namelist()


@pytest.mark.parametrize("damage", ["missing", "digest", "escape"])
def test_bad_attachment_is_not_exported_as_available(tmp_path, damage):
    args = arguments(tmp_path)
    directory = make_trace(args.trace_root)
    artifact = next((directory / "artifacts").iterdir())
    if damage == "missing":
        artifact.unlink()
    elif damage == "digest":
        artifact.write_text("damaged", encoding="utf-8")
    else:
        trace = directory / "trace.jsonl"
        records = [json.loads(line) for line in trace.read_text().splitlines()]
        for record in records:
            for reference in record.get("artifacts", {}).values():
                reference["path"] = "../../../../outside.txt"
        trace.write_text("\n".join(json.dumps(record) for record in records) + "\n")
    capture.run(args)
    manifest = capture.read_object(args.output / "capture_manifest.json")
    requests = manifest.get("requests")
    assert requests and requests[0].get("warnings")
    index = json.loads((args.output / "requests" / UID / "artifact_index.json").read_text())
    assert all(not item.get("available") for item in index)


def test_redaction_changes_export_only_and_keeps_new_digest(tmp_path):
    args = arguments(tmp_path)
    directory = make_trace(args.trace_root)
    mapping = tmp_path / "redactions.json"
    capture.write_json(mapping, {"private-user-42": "USER_1"})
    args.redactions = mapping
    archive = capture.run(args)
    with zipfile.ZipFile(archive) as package:
        for name in package.namelist():
            if not name.endswith("/"):
                assert b"private-user-42" not in package.read(name)
        files = json.loads(package.read("exported_files.json"))
        for item in files:
            name = item.get("file")
            assert name
            assert hashlib.sha256(package.read(name)).hexdigest() == item.get("sha256")
    original = next((directory / "artifacts").iterdir()).read_text()
    assert "private-user-42" in original


def test_observer_filters_history_but_includes_new_and_recording_requests(monkeypatch):
    snapshots = iter([
        {"old": "complete", "live": "recording"},
        {"old": "complete", "live": "recording", "new": "complete"},
        {"old": "complete", "live": "complete", "new": "complete"},
    ])
    times = iter([0.0, 0.0, 2.0])
    monkeypatch.setattr(capture, "discover", lambda _importer: next(snapshots))
    monkeypatch.setattr(capture.time, "monotonic", lambda: next(times))
    monkeypatch.setattr(capture.time, "sleep", lambda _seconds: None)
    result = capture.observe(None, 1.0, None, False, False)
    assert result == {"live": "complete", "new": "complete"}


def test_explicit_uid_can_finish_early_even_when_trace_already_exists(monkeypatch):
    monkeypatch.setattr(capture, "discover", lambda _importer: {UID: "complete"})
    monkeypatch.setattr(capture.time, "monotonic", lambda: 0.0)

    def unexpected_sleep(_seconds):
        pytest.fail("指定请求已经结束，不应继续等待")

    monkeypatch.setattr(capture.time, "sleep", unexpected_sleep)
    assert capture.observe(None, 600.0, UID, False, True) == {UID: "complete"}


def test_interrupt_preserves_already_observed_requests(monkeypatch):
    monkeypatch.setattr(capture, "discover", lambda _importer: {UID: "recording"})
    monkeypatch.setattr(capture.time, "monotonic", lambda: 0.0)

    def interrupt(_seconds):
        raise KeyboardInterrupt

    monkeypatch.setattr(capture.time, "sleep", interrupt)
    assert capture.observe(None, 600.0, None, False, False) == {UID: "recording"}


def test_output_cannot_overwrite_or_contain_trace_root(tmp_path):
    args = arguments(tmp_path, output=tmp_path)
    with pytest.raises(ValueError, match="互相包含"):
        capture.run(args)


def test_empty_capture_explicitly_reports_missing_data(tmp_path):
    args = arguments(tmp_path)
    capture.run(args)
    coverage = capture.read_object(args.output / "coverage.json")
    assert coverage.get("emptyCapture") is True


def test_recording_trace_stays_nonterminal_in_capture(tmp_path):
    args = arguments(tmp_path)
    directory = make_trace(args.trace_root)
    manifest_path = directory / "manifest.json"
    manifest = capture.read_object(manifest_path)
    manifest["state"] = "recording"
    capture.write_json(manifest_path, manifest)
    capture.run(args)
    exported = capture.read_object(args.output / "capture_manifest.json")
    assert exported.get("observedStates") == {UID: "recording"}
