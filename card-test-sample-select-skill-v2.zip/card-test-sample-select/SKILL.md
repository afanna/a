---
name: card-test-sample-select
description: 供内网 Agent 联合检索 card-runtime-capture 采集包和微服务全量日志，按 L1/L2 目标场景确认候选、关联日志证据，再限额导出小包供跨环境移交。
---

# 卡片测试素材筛选

使用者是能读取内网采集包、微服务全量日志和项目源码的 Agent。输入包含 `card-runtime-capture-v1` 包及日志目录，不是只压缩文件。Agent 负责场景理解、因果核对与请求关联；脚本负责完整性、证据提取与预算，不自动判断语义。不要额外运行模型或微服务、修改源包和日志。

先读 [references/targets.md](references/targets.md)：其中列出 L1/L2 目标、每类必需输入输出、实际日志检索线索和确认清单格式。只看附件名或最终状态不足以完成筛选任务。

## 操作

1. 确认项目与大包的本地路径。只读取索引、manifest 和所需的请求事件，先运行 inventory 查看可覆盖阶段与缺口：

```powershell
python skills/card-test-sample-select/scripts/select_samples.py --source <原ZIP或目录> --output output/sample-inventory --inventory-only
```

2. 用 inventory 缩小候选，再按目标任务书在**全量日志**检索触发、预算、每轮结果和终态，并回读目标请求的模型消息与附件。建立 UID 与 requestId 的真实映射，不按时间相邻或相同报错词拼接。成功、失败、部分完成都可作为候选；区分“适合评测”与“模型正确”。

3. 为每个候选填写 `selection-plan.json`：caseId、targetId、UID、选择理由、missingData 和日志证据位置。补齐可重建数据或明确降级为诊断候选。每个目标优先一条最清晰代表；未找到就报告，不为凑数触发新请求。使用确认清单导出：

```powershell
python skills/card-test-sample-select/scripts/select_samples.py --source <原ZIP或目录> --output output/selected-reviewed --plan <selection-plan.json> --log-root <微服务日志目录> --max-requests 8 --max-mib 10
```

脚本会按清单的 caseId 选择并附带原始行号日志片段；同一 UID 可支持多个目标。预算不足的候选仍可能被跳过，必须检查 missingReviewedCases。`--plan` 与 `--uids` 不同时使用；不要只交 plan 文件而遗漏真正证据。

以下自动阶段模式仅用于初筛或用户只要求阶段素材时，不可声称已完成业务场景确认。每个被选请求保留全部已索引可用附件和事件，避免删除上下文、物理重试及修复历史而使样本失真。

```powershell
# 默认：L1/L2 各类候选的联合覆盖，最多 8 个请求，解压内容及 ZIP 均不超过 10 MiB。
python skills/card-test-sample-select/scripts/select_samples.py --source <原ZIP或目录> --output output/selected-cases

# 可缩小预算或只选择某阶段。stage 为实际模型任务，不按自然语言猜测。
python skills/card-test-sample-select/scripts/select_samples.py --source <原ZIP或目录> --output output/repair-cases --mode l2 --stages repair --max-requests 3 --max-mib 5
```

支持阶段：plan、dsl、repair、theme、edit_intent、edit_execute、argument_repair、static_review。默认覆盖全部；参数恢复没有发生时报告缺口，不补调模型。`--mode l1` 只按观察到的终态、修复、主备与整轮重试证据选择。`--uids` 可明确指定请求（逗号分隔），仍必须通过完整性与预算检查。

4. 阅读 `selection_report.json`：选择理由、未覆盖类别、被拒请求、reviewedCases 与 missingReviewedCases。小包不足以覆盖全部目标时如实报告。日志或采集包缺材料的候选不能标为完整可重建。可换新输出目录单独导出缺少的阶段，不能静默截断附件，也不默认放宽预算。
5. 分享前检查模型消息及**日志片段**中的敏感内容。原包脱敏不会自动处理全量日志。保持内网原始证据，另准备已审核的分享副本；如果修改日志，重新确认该副本的行号和关联标识。此脚本不做文本替换。不要输出整份日志。
6. 只移交生成的 `<output>.zip` 与简短报告：实际大小、选中请求、caseId→目标映射、必需数据缺口、未找到场景。日志片段和附件都计入预算，不把原 330 MB 包一并传出。没有合适请求时交缺失报告，不称完成用例筛选。

## 筛选依据和限制

- L2 阶段候选至少有实际模型消息与原始响应；DSL 的真实 phase 常为 initial，映射为 dsl。静态复核使用专门的复核输入/输出附件识别。
- L1 终态来自 `request.completed` 或结构化 generation_response；不能用 Trace complete/partial 代替业务成功/失败。修复发生、备用调用、整轮次数来自阶段附件或真实事件/计数，不从报错文案推断。
- 不使用需求关键词推断动态/静态、不自动判断 Plan 是否正确。容量压力、静态关系、允许省略和语义金标留待人工复核。
- 校验已有附件是否缺失、损坏及 `available=false`；有 importer warnings、结构非法、缺附件或源包没有结束的请求列入拒绝清单。业务失败导致源状态 partial、但没有结构和附件 warnings 时仍可选，不能把业务失败样本全过滤掉。
- 精简掉重复的 view.json 与顶层全批统计，保留每个入选请求的原 manifest、原事件、完整附件索引和实际被引用的 blob。补充文件只在原包确实只有一个请求且该请求入选时携带，避免错关联。
- 默认预算按**未压缩证据总量**限制，比只限制 ZIP 更保守。最终 ZIP 也检查大小；不承诺 330 MB 必然压到某个体积，单请求过大时跳过并报告。
- 当前请求按内容摘要去重，不代表业务语义等价；最终 L1/L2 用例、预期和配置仍需要审查。导出包不冒充原始采集包，使用独立 schema。
