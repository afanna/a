"""只读采集包，按可观察证据筛选小量完整请求，不调用模型。"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

STAGES = (
    "plan", "dsl", "repair", "theme", "edit_intent", "edit_execute",
    "argument_repair", "static_review",
)
STATUSES = {"success", "failed", "unsupported", "needs_clarification", "unchanged", "degraded"}
READ_LIMIT = 32 * 1024 * 1024


def safe_name(name: str) -> str:
    path = PurePosixPath(name)
    if "\\" in name or path.is_absolute() or ":" in name:
        raise ValueError("包内路径不安全")
    if ".." in path.parts or str(path) != name or not name:
        raise ValueError("包内路径不规范")
    return name


class Source:
    def __init__(self, path: Path) -> None:
        self.root = path.resolve()
        self.archive: zipfile.ZipFile | None = None
        self.names: dict[str, Any] = {}
        self.prefix = ""
        try:
            if self.root.is_dir():
                if not (self.root / "capture_manifest.json").is_file():
                    raise ValueError("目录不是采集包根目录")
            else:
                self.archive = zipfile.ZipFile(self.root)
                for info in self.archive.infolist():
                    if info.is_dir():
                        continue
                    name = safe_name(info.filename)
                    if name in self.names:
                        raise ValueError("ZIP 中有重复文件名")
                    self.names[name] = info
                roots = []
                for name in self.names:
                    if name.endswith("capture_manifest.json"):
                        if PurePosixPath(name).name == "capture_manifest.json":
                            roots.append(name.removesuffix("capture_manifest.json"))
                if len(roots) != 1:
                    raise ValueError("ZIP 必须包含唯一采集包根目录")
                self.prefix = roots[0]
        except Exception:
            self.close()
            raise

    def close(self) -> None:
        if self.archive is not None:
            self.archive.close()

    def size(self, name: str) -> int:
        safe_name(name)
        if self.archive is not None:
            info = self.names.get(self.prefix + name)
            if info is None:
                raise FileNotFoundError(name)
            return info.file_size
        target = (self.root / name).resolve()
        if not target.is_relative_to(self.root):
            raise ValueError("目录文件路径越界")
        return target.stat().st_size

    def read(self, name: str) -> bytes:
        size = self.size(name)
        if size > READ_LIMIT:
            raise ValueError("单文件超过 32 MiB，未读取")
        if self.archive is not None:
            with self.archive.open(self.prefix + name) as stream:
                data = stream.read(READ_LIMIT + 1)
        else:
            with (self.root / name).open("rb") as stream:
                data = stream.read(READ_LIMIT + 1)
        if len(data) != size:
            raise ValueError("文件大小变化或超过读取上限")
        return data

    def json(self, name: str) -> Any:
        return json.loads(self.read(name).decode("utf-8-sig"))


def object_value(value: Any) -> dict:
    result: dict = value if isinstance(value, dict) else {}
    return result


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def exported_hashes(source: Source) -> dict[str, str]:
    result = {}
    for item in source.json("exported_files.json"):
        item = object_value(item)
        name = item.get("file")
        expected = item.get("sha256")
        if not isinstance(name, str) or not isinstance(expected, str):
            raise ValueError("导出摘要表格式错误")
        safe_name(name)
        if name in result:
            raise ValueError("导出摘要表条目重复")
        result[name] = expected
    return result


def verified(source: Source, name: str, hashes: dict) -> bytes:
    expected = hashes.get(name)
    if not isinstance(expected, str):
        raise ValueError(f"文件没有导出摘要：{name}")
    data = source.read(name)
    if digest(data) != expected:
        raise ValueError(f"导出摘要不匹配：{name}")
    return data


def classify(names: set[str], records: list[dict]) -> set[str]:
    tags: set[str] = set()
    for stage in STAGES:
        phase = "initial" if stage == "dsl" else stage
        if {f"{phase}_model_messages", f"{phase}_assistant_raw"}.issubset(names):
            tags.add(f"l2:{stage}")
    if {"static_plan_review_prompt", "static_plan_review_output"}.issubset(names):
        tags.add("l2:static_review")
    status = None
    for record in records:
        if record.get("event") == "request.completed":
            status = record.get("status")
        details = object_value(record.get("details"))
        if details.get("role") == "fallback":
            tags.add("l1:model_fallback_observed")
        attempts = object_value(record.get("attempts"))
        attempt = attempts.get("interface")
        if isinstance(attempt, int) and attempt > 1:
            tags.add("l1:interface_retry_observed")
    if status in STATUSES:
        tags.add(f"l1:terminal_{status}")
    repair_seen = "repair_invalid_source_dsl" in names
    if repair_seen and status in {"success", "failed", "degraded"}:
        tags.add(f"l1:repair_terminal_{status}")
    return tags


def inspect_request(source: Source, uid: str, hashes: dict) -> dict:
    if not re.fullmatch(r"[A-Za-z]+-[A-Za-z0-9]{8}-\d{5}-\d{3}", uid):
        raise ValueError("UID 不符合采集格式")
    base = f"requests/{uid}"
    files = {
        f"{base}/artifact_index.json",
        f"{base}/source/manifest.json",
        f"{base}/source/trace.jsonl",
        f"{base}/import_manifest.json",
    }
    manifest = object_value(json.loads(verified(source, f"{base}/source/manifest.json", hashes)))
    imported = object_value(json.loads(verified(source, f"{base}/import_manifest.json", hashes)))
    if manifest.get("state") not in {"complete", "partial"}:
        raise ValueError("请求仍在记录，不能作为完整候选")
    if imported.get("status") not in {"complete", "partial"} or imported.get("warnings"):
        raise ValueError("Trace 导入非完整，需单独排障")
    index = json.loads(verified(source, f"{base}/artifact_index.json", hashes))
    if not isinstance(index, list):
        raise ValueError("附件索引不是数组")
    names: set[str] = set()
    for item in index:
        item = object_value(item)
        if item.get("available") is not True:
            raise ValueError("请求包含不可用附件，未静默丢弃")
        path = item.get("file")
        name = item.get("name")
        if not isinstance(path, str) or not isinstance(name, str):
            raise ValueError("附件索引缺少名称或文件")
        if not re.fullmatch(r"trace_blobs/[a-f0-9]{64}", path):
            raise ValueError("附件路径不是采集 blob")
        files.add(path)
        names.add(name)
    raw = verified(source, f"{base}/source/trace.jsonl", hashes)
    records = []
    for line in raw.decode("utf-8").splitlines():
        if line.strip():
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError("Trace 事件不是对象")
            records.append(value)
    signature_parts = []
    for path in sorted(files):
        if path.startswith("trace_blobs/"):
            expected = hashes.get(path)
            if not isinstance(expected, str):
                raise ValueError("附件缺少导出摘要")
            signature_parts.append(expected)
    tags = classify(names, records)
    return {
        "uid": uid, "tags": sorted(tags), "files": sorted(files),
        "signature": digest(("".join(signature_parts) + str(sorted(tags))).encode()),
        "bytes": sum(source.size(path) for path in files),
        "artifactNames": sorted(names),
    }


def goals(mode: str, stages: list[str]) -> set[str]:
    result: set[str] = set()
    if mode in {"both", "l2"}:
        result.update(f"l2:{stage}" for stage in stages)
    if mode in {"both", "l1"}:
        result.update(f"l1:terminal_{status}" for status in STATUSES)
        result.update({
            "l1:model_fallback_observed", "l1:interface_retry_observed",
            "l1:repair_terminal_success", "l1:repair_terminal_failed",
            "l1:repair_terminal_degraded",
        })
    return result


def read_plan(path: Path | None) -> list[dict]:
    cases = []
    if path is not None:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        cases = object_value(value).get("cases")
        if not isinstance(cases, list) or not cases:
            raise ValueError("确认清单必须包含非空 cases 数组")
    identifiers: set[str] = set()
    for case in cases:
        if not isinstance(case, dict):
            raise ValueError("case 必须是对象")
        case_id = case.get("caseId")
        if not isinstance(case_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", case_id):
            raise ValueError("caseId 需要 1～80 个字母数字、下划线或连字符")
        if case_id in identifiers:
            raise ValueError("caseId 重复")
        identifiers.add(case_id)
        for key in ("uid", "targetId", "reason"):
            value = case.get(key)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"确认清单缺少非空 {key}")
        missing = case.get("missingData")
        if not isinstance(missing, list) or any(not isinstance(item, str) for item in missing):
            raise ValueError("missingData 必须是字符串数组")
        evidence = case.get("evidence")
        if not isinstance(evidence, list) or not evidence:
            raise ValueError("内网确认清单必须附日志证据")
    return cases


def log_excerpt(root: Path, spec: dict) -> dict:
    name = spec.get("logFile")
    if not isinstance(name, str):
        raise ValueError("日志证据缺少 logFile")
    path = (root / safe_name(name)).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("日志路径越界")
    start, end = spec.get("startLine"), spec.get("endLine")
    if type(start) is not int or type(end) is not int:
        raise ValueError("日志起止行必须是整数")
    if start < 1 or end < start or end - start >= 300:
        raise ValueError("单日志证据须为 1～300 行")
    encoding = spec.get("encoding", "utf-8")
    if encoding not in {"utf-8", "utf-8-sig", "gb18030"}:
        raise ValueError("不支持的日志编码")
    correlation = spec.get("correlationValue")
    if not isinstance(correlation, str) or not correlation.strip():
        raise ValueError("日志证据必须注明请求关联标识")
    lines = []
    with path.open(encoding=encoding) as stream:
        for number, line in enumerate(stream, 1):
            if number < start:
                continue
            lines.append(line)
            if sum(len(item.encode("utf-8")) for item in lines) > 64 * 1024:
                raise ValueError("日志片段超过 64 KiB，请缩小范围")
            if number == end:
                break
    if len(lines) != end - start + 1:
        raise ValueError("日志行号超出文件范围")
    text = "".join(lines)
    pattern = rf"(?<![\w&.-]){re.escape(correlation)}(?![\w&.-])"
    if not re.search(pattern, text):
        raise ValueError("日志片段未找到精确请求关联标识")
    return {**spec, "text": text, "excerptSha256": digest(text.encode("utf-8"))}


def attach_review(
    candidate: dict, cases: list[dict], log_root: Path | None, extra_files: dict,
) -> None:
    reviewed = []
    for case in cases:
        if case.get("uid") != candidate.get("uid"):
            continue
        if log_root is None:
            raise ValueError("有确认清单时必须提供 log-root")
        excerpts = []
        for spec in case.get("evidence", []):
            if not isinstance(spec, dict):
                raise ValueError("日志证据必须是对象")
            excerpts.append(log_excerpt(log_root, spec))
        case_id = case.get("caseId")
        name = f"evidence/{candidate.get('uid')}/{case_id}.json"
        content = encode({**case, "evidence": excerpts, "semanticVerdict": "not-assessed"})
        extra_files[name] = content
        candidate.get("files", []).append(name)
        candidate["bytes"] += len(content)
        candidate.get("tags", []).append(f"reviewed:{case_id}")
        reviewed.append({
            "caseId": case_id, "targetId": case.get("targetId"),
            "reason": case.get("reason"), "missingData": case.get("missingData"),
            "evidenceFile": name,
        })
    candidate["reviewedCases"] = reviewed
    candidate["signature"] = digest((candidate.get("signature", "") + str(reviewed)).encode())


def file_size(source: Source, path: str, extra_files: dict[str, bytes]) -> int:
    size: int = len(extra_files[path]) if path in extra_files else source.size(path)
    return size


def choose(
    candidates: list[dict], targets: set[str], max_requests: int, byte_budget: int,
    source: Source, hashes: dict, extra_files: dict[str, bytes],
) -> tuple[list[dict], dict[str, bytes], list[dict]]:
    selected = []
    payloads: dict[str, bytes] = {}
    rejected = []
    covered: set[str] = set()
    seen: set[str] = set()
    remaining = list(candidates)
    while remaining and len(selected) < max_requests:
        ranked = []
        for candidate in remaining:
            new_tags = set(candidate.get("tags", [])) & (targets - covered)
            if not new_tags:
                continue
            files = candidate.get("files", [])
            cost = sum(
                file_size(source, path, extra_files) for path in files if path not in payloads
            )
            ranked.append((len(new_tags) / max(cost, 1), candidate.get("uid"), candidate))
        if not ranked:
            break
        ranked.sort(key=lambda item: (-item[0], item[1]))
        candidate = ranked[0][2]
        remaining.remove(candidate)
        uid = candidate.get("uid")
        signature = candidate.get("signature")
        if signature in seen:
            rejected.append({"uid": uid, "reason": "相同附件内容已入选"})
            continue
        total = sum(len(data) for data in payloads.values())
        cost = sum(
            file_size(source, path, extra_files)
            for path in candidate.get("files", []) if path not in payloads
        )
        if total + cost > byte_budget:
            rejected.append({"uid": uid, "reason": "完整请求证据超过剩余预算"})
            continue
        addition = {}
        try:
            for path in candidate.get("files", []):
                if path not in payloads:
                    addition[path] = (
                        extra_files[path] if path in extra_files else verified(source, path, hashes)
                    )
        except (OSError, ValueError, KeyError, zipfile.BadZipFile) as exc:
            rejected.append({"uid": uid, "reason": str(exc)})
            continue
        cost = sum(len(data) for data in addition.values())
        if total + cost > byte_budget:
            rejected.append({"uid": uid, "reason": "完整请求证据超过剩余预算"})
            continue
        new_tags = set(candidate.get("tags", [])) & (targets - covered)
        selected.append({**candidate, "newCoverage": sorted(new_tags)})
        payloads.update(addition)
        covered.update(candidate.get("tags", []))
        seen.add(signature)
    return selected, payloads, rejected


def encode(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def run(args: argparse.Namespace) -> Path:
    if not math.isfinite(args.max_mib) or args.max_mib <= 0:
        raise ValueError("max-mib 必须是有限正数")
    if args.max_requests < 1:
        raise ValueError("max-requests 必须至少为 1")
    plan = read_plan(getattr(args, "plan", None))
    if plan and args.uids:
        raise ValueError("plan 和 uids 不同时使用")
    output = args.output.resolve()
    original = args.source.resolve()
    if original.is_dir() and output.is_relative_to(original):
        raise ValueError("输出不能位于原包内")
    archive = Path(str(output) + ".zip")
    if output.exists() or archive.exists():
        raise ValueError("输出已存在，请选择新目录")
    source = Source(original)
    try:
        manifest = object_value(source.json("capture_manifest.json"))
        if manifest.get("schemaVersion") != "card-runtime-capture-v1":
            raise ValueError("不支持的原采集包版本")
        hashes = exported_hashes(source)
        verified(source, "capture_manifest.json", hashes)
        candidates = []
        rejected = []
        extra_files: dict[str, bytes] = {}
        wanted = set(args.uids.split(",")) if args.uids else None
        if plan:
            wanted = {case.get("uid") for case in plan}
        requests = manifest.get("requests")
        if not isinstance(requests, list):
            raise ValueError("原包没有请求清单")
        seen_uids: set[str] = set()
        for item in requests:
            uid = object_value(item).get("uid")
            if not isinstance(uid, str):
                raise ValueError("请求清单缺少 UID")
            if uid in seen_uids:
                raise ValueError("请求 UID 重复")
            seen_uids.add(uid)
            if wanted is not None and uid not in wanted:
                continue
            try:
                candidate = inspect_request(source, uid, hashes)
                attach_review(candidate, plan, getattr(args, "log_root", None), extra_files)
                candidates.append(candidate)
            except (OSError, ValueError, KeyError, zipfile.BadZipFile) as exc:
                rejected.append({"uid": uid, "reason": str(exc)})
        if wanted:
            for uid in sorted(wanted - seen_uids):
                rejected.append({"uid": uid, "reason": "原包不存在该请求"})
        targets = goals(args.mode, args.stages.split(","))
        if plan:
            targets = {f"reviewed:{case.get('caseId')}" for case in plan}
        budget = int(args.max_mib * 1024 * 1024)
        selected, payloads, skipped = [], {}, []
        if not args.inventory_only:
            selected, payloads, skipped = choose(
                candidates, targets, args.max_requests, max(budget - 128 * 1024, 0),
                source, hashes, extra_files,
            )
        if len(requests) == 1 and selected:
            for name in ("request", "response", "context"):
                path = f"supplements/{name}.json"
                if path in hashes:
                    payloads[path] = verified(source, path, hashes)
        covered: set[str] = set()
        for item in selected:
            covered.update(item.get("tags", []))
        report = {
            "schemaVersion": "card-test-selection-v1",
            "sourceManifestSha256": digest(source.read("capture_manifest.json")),
            "mode": args.mode, "inventoryOnly": args.inventory_only,
            "budgetBytes": budget, "maxRequests": args.max_requests,
            "selected": selected, "uncovered": sorted(targets - covered),
            "missingReviewedCases": sorted(targets - covered) if plan else [],
            "selectionMethod": "agent-reviewed-plan" if plan else "automatic-stage-inventory",
            "eligible": [
                {"uid": item.get("uid"), "tags": item.get("tags"), "bytes": item.get("bytes")}
                for item in candidates
            ],
            "rejected": rejected + skipped,
            "privacyReviewRequired": True, "sourceSanitized": manifest.get("sanitized"),
            "readiness": "candidate-evidence-not-approved-test-cases",
            "limitations": [
                "不自动验证语义正确或判定动态/静态；阶段标签仅代表观察证据",
                "每个请求保留全部已索引可用证据，但原包缺失上下文仍然缺失",
                "原始请求、配置、原卡及人工标准的完整性需要进一步审核",
            ],
        }
        payloads["selection_report.json"] = encode(report)
        entries = []
        for name, data in sorted(payloads.items()):
            entries.append({"file": name, "bytes": len(data), "sha256": digest(data)})
        payloads["selected_files.json"] = encode(entries)
        if sum(len(data) for data in payloads.values()) > budget:
            raise ValueError("含报告与补充材料的总量超过预算，请缩小筛选范围")
        output.mkdir(parents=True)
        for name, data in payloads.items():
            target = output / safe_name(name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as package:
            for name in sorted(payloads):
                package.write(output / name, name)
        if archive.stat().st_size > budget:
            archive.unlink()
            raise ValueError("ZIP 超出预算，未保留过大的 ZIP；目录保留供检查")
        print(f"selected={len(selected)} missing={len(targets - covered)} zip={archive}")
        print(f"zipBytes={archive.stat().st_size} budgetBytes={budget}")
        return archive
    finally:
        source.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("both", "l1", "l2"), default="both")
    parser.add_argument("--stages", default=",".join(STAGES))
    parser.add_argument("--uids")
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--log-root", type=Path)
    parser.add_argument("--max-requests", type=int, default=8)
    parser.add_argument("--max-mib", type=float, default=10.0)
    parser.add_argument("--inventory-only", action="store_true")
    args = parser.parse_args()
    if not set(args.stages.split(",")).issubset(STAGES):
        parser.error("未知阶段")
    run(args)


if __name__ == "__main__":
    main()
