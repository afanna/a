"""使用真实 recorder/capture 产生数据，验证筛选与预算，不调用模型。"""

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "widget_service" / "cloud"))
sys.path.insert(0, str(REPO / "skills" / "card-runtime-capture" / "scripts"))

import capture  # noqa: E402
import select_samples as selector  # noqa: E402
from services.generation_trace_recorder import GenerationTraceRecorder  # noqa: E402


def make_capture(tmp_path, specifications):
    trace_root = tmp_path / "traces"
    for number, spec in enumerate(specifications, 1):
        uid = f"batch-1234abcd-{number:05d}-000"
        writer = GenerationTraceRecorder()
        writer.bind_request(uid, enabled=True, trace_root=trace_root)
        phase = spec.get("phase", "plan")
        payload = spec.get("payload", "same-input")
        writer.record("model.physical_attempt", stage="model.execution", json_artifacts={
            f"{phase}_model_messages": [{"role": "user", "content": payload}],
        }, text_artifacts={f"{phase}_assistant_raw": "model-output"})
        if spec.get("partial"):
            writer.writer.mark_failure()
        writer.finalize(status=spec.get("status", "success"))
    args = argparse.Namespace(
        repo=REPO, trace_root=trace_root, output=tmp_path / "capture",
        uid=None, duration=0.0, include_existing=False, until_terminal=False,
        request=None, response=None, context=None, redactions=None,
    )
    capture.run(args)
    return args.output


def arguments(tmp_path, source, **changes):
    values = {
        "source": source, "output": tmp_path / "selected", "mode": "both",
        "stages": ",".join(selector.STAGES), "uids": None, "max_requests": 8,
        "max_mib": 10.0, "inventory_only": False,
    }
    values.update(changes)
    return argparse.Namespace(**values)


@pytest.mark.parametrize("zipped", [False, True])
def test_covers_stages_deduplicates_requests_and_keeps_all_references(tmp_path, zipped):
    source = make_capture(tmp_path, [{}, {}, {"phase": "initial", "status": "failed"}])
    if zipped:
        source = Path(str(source) + ".zip")
    args = arguments(tmp_path, source)
    archive = selector.run(args)
    report = json.loads((args.output / "selection_report.json").read_text(encoding="utf-8"))
    selected = report.get("selected")
    assert len(selected) == 2
    tags = set()
    for item in selected:
        tags.update(item.get("tags", []))
    assert {"l2:plan", "l2:dsl", "l1:terminal_success", "l1:terminal_failed"} <= tags
    with zipfile.ZipFile(archive) as package:
        names = package.namelist()
        assert not any(name.endswith("view.json") for name in names)
        for item in selected:
            for name in item.get("files", []):
                assert name in names
        entries = json.loads(package.read("selected_files.json"))
        for entry in entries:
            name = entry.get("file")
            assert hashlib.sha256(package.read(name)).hexdigest() == entry.get("sha256")
    assert archive.stat().st_size <= 10 * 1024 * 1024


def test_budget_skips_whole_large_request_without_truncation(tmp_path, monkeypatch):
    source = make_capture(tmp_path, [
        {"phase": "initial", "payload": "a" * 400_000},
        {"phase": "plan"},
    ])
    args = arguments(tmp_path, source, max_mib=0.25)
    original_read = selector.Source.read

    def bounded_read(reader, name):
        if reader.size(name) > 300_000:
            pytest.fail("超预算大附件应在读取内容前跳过")
        return original_read(reader, name)

    monkeypatch.setattr(selector.Source, "read", bounded_read)
    archive = selector.run(args)
    report = json.loads((args.output / "selection_report.json").read_text(encoding="utf-8"))
    assert len(report.get("selected")) == 1
    assert "l2:dsl" in report.get("uncovered")
    assert any("预算" in item.get("reason", "") for item in report.get("rejected"))
    assert archive.stat().st_size <= int(0.25 * 1024 * 1024)


def test_hash_mismatch_rejects_request_not_allows_missing_blob(tmp_path):
    source = make_capture(tmp_path, [{}])
    blob = next((source / "trace_blobs").iterdir())
    blob.write_text("corrupted", encoding="utf-8")
    args = arguments(tmp_path, source)
    selector.run(args)
    report = json.loads((args.output / "selection_report.json").read_text(encoding="utf-8"))
    assert not report.get("selected")
    assert any("摘要" in item.get("reason", "") for item in report.get("rejected"))


def test_stage_filter_and_inventory_do_not_export_other_payloads(tmp_path):
    source = make_capture(tmp_path, [{"phase": "theme"}, {"phase": "plan"}])
    args = arguments(tmp_path, source, mode="l2", stages="theme")
    selector.run(args)
    report = json.loads((args.output / "selection_report.json").read_text(encoding="utf-8"))
    selected = report.get("selected")
    assert len(selected) == 1
    assert selected[0].get("tags") == ["l1:terminal_success", "l2:theme"]
    inventory_args = arguments(tmp_path, source, output=tmp_path / "inventory", inventory_only=True)
    archive = selector.run(inventory_args)
    with zipfile.ZipFile(archive) as package:
        assert not any(name.startswith("trace_blobs/") for name in package.namelist())


def test_partial_business_failure_without_integrity_warning_can_be_selected(tmp_path):
    source = make_capture(tmp_path, [{"status": "failed", "partial": True}])
    args = arguments(tmp_path, source)
    selector.run(args)
    report = json.loads((args.output / "selection_report.json").read_text(encoding="utf-8"))
    assert len(report.get("selected")) == 1
    assert "l1:terminal_failed" in report.get("selected")[0].get("tags")


def test_sanitized_source_uses_export_digest_not_original_filename_digest(tmp_path):
    source = make_capture(tmp_path, [{}])
    blob = next((source / "trace_blobs").iterdir())
    blob.write_bytes(blob.read_bytes().replace(b"same-input", b"SANITIZED_INPUT"))
    inventory = json.loads((source / "exported_files.json").read_text(encoding="utf-8"))
    for entry in inventory:
        name = entry.get("file")
        entry["sha256"] = hashlib.sha256((source / name).read_bytes()).hexdigest()
    capture.write_json(source / "exported_files.json", inventory)
    selector.run(arguments(tmp_path, source))
    report = json.loads(
        (tmp_path / "selected" / "selection_report.json").read_text(encoding="utf-8"),
    )
    assert len(report.get("selected")) == 1


@pytest.mark.parametrize("name", ["../secret", "C:/secret", "/secret", "a\\secret"])
def test_rejects_unsafe_archive_member_names(tmp_path, name):
    archive = tmp_path / "bad.zip"
    with zipfile.ZipFile(archive, "w") as package:
        package.writestr(name, "secret")
    with pytest.raises(ValueError):
        selector.Source(archive)
    with pytest.raises(ValueError, match="路径"):
        selector.safe_name(name)


def test_duplicate_zip_member_is_rejected(tmp_path):
    archive = tmp_path / "duplicate.zip"
    with zipfile.ZipFile(archive, "w") as package:
        package.writestr("capture_manifest.json", "{}")
        with pytest.warns(UserWarning):
            package.writestr("capture_manifest.json", "{}")
    with pytest.raises(ValueError, match="重复"):
        selector.Source(archive)


def reviewed_case(uid, case_id="repair-01"):
    return {
        "caseId": case_id, "targetId": "L1-repair-success", "uid": uid,
        "reason": "Agent 核对本请求的修复与终态日志；尚待业务预期评审",
        "missingData": ["原始入口包络未提供"],
        "evidence": [{
            "logFile": "service.log", "startLine": 2, "endLine": 3,
            "correlationValue": uid,
        }],
    }


def test_reviewed_plan_exports_only_selected_log_ranges_and_keeps_same_stage_cases(tmp_path):
    source = make_capture(tmp_path, [{}, {}])
    uid1, uid2 = "batch-1234abcd-00001-000", "batch-1234abcd-00002-000"
    logs = tmp_path / "logs"
    logs.mkdir()
    (logs / "service.log").write_text(
        f"unrelated-secret\nuid={uid1} repair started\nuid={uid2} final\nother-secret\n",
        encoding="utf-8",
    )
    plan_path = tmp_path / "plan.json"
    capture.write_json(plan_path, {
        "cases": [reviewed_case(uid1), reviewed_case(uid2, "repair-02")],
    })
    args = arguments(tmp_path, source, plan=plan_path, log_root=logs)
    archive = selector.run(args)
    report = json.loads((args.output / "selection_report.json").read_text(encoding="utf-8"))
    assert len(report.get("selected")) == 2
    assert not report.get("missingReviewedCases")
    assert report.get("selectionMethod") == "agent-reviewed-plan"
    with zipfile.ZipFile(archive) as package:
        evidence_names = [name for name in package.namelist() if name.startswith("evidence/")]
        assert len(evidence_names) == 2
        for name in evidence_names:
            evidence = json.loads(package.read(name))
            assert evidence.get("missingData")
            snippet = evidence.get("evidence")[0]
            assert snippet.get("startLine") == 2
            assert "unrelated-secret" not in snippet.get("text")
            assert "other-secret" not in snippet.get("text")


@pytest.mark.parametrize("problem", ["wrong-id", "out-of-range", "escape"])
def test_bad_log_evidence_cannot_be_used_to_confirm_request(tmp_path, problem):
    source = make_capture(tmp_path, [{}])
    uid = "batch-1234abcd-00001-000"
    logs = tmp_path / "logs"
    logs.mkdir()
    (logs / "service.log").write_text(f"request {uid}-extra\n", encoding="utf-8")
    case = reviewed_case(uid)
    evidence = case.get("evidence")[0]
    evidence.update(startLine=1, endLine=1)
    if problem == "out-of-range":
        evidence.update(endLine=3)
    elif problem == "escape":
        evidence.update(logFile="../outside.log")
    plan_path = tmp_path / "plan.json"
    capture.write_json(plan_path, {"cases": [case]})
    args = arguments(tmp_path, source, plan=plan_path, log_root=logs)
    selector.run(args)
    report = json.loads((args.output / "selection_report.json").read_text(encoding="utf-8"))
    assert not report.get("selected")
    assert report.get("missingReviewedCases") == ["reviewed:repair-01"]
    assert report.get("rejected")


def test_reviewed_plan_keeps_several_targets_for_one_request(tmp_path):
    source = make_capture(tmp_path, [{}])
    uid = "batch-1234abcd-00001-000"
    logs = tmp_path / "logs"
    logs.mkdir()
    (logs / "service.log").write_text(f"start\nuid={uid}\nend\n", encoding="utf-8")
    plan_path = tmp_path / "plan.json"
    capture.write_json(plan_path, {"cases": [reviewed_case(uid), reviewed_case(uid, "second")]})
    args = arguments(tmp_path, source, plan=plan_path, log_root=logs)
    selector.run(args)
    report = json.loads((args.output / "selection_report.json").read_text(encoding="utf-8"))
    assert len(report.get("selected")) == 1
    assert len(report.get("selected")[0].get("reviewedCases")) == 2
    assert not report.get("missingReviewedCases")
