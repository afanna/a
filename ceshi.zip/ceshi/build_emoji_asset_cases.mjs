import fs from 'node:fs';
import path from 'node:path';

const caseDirectory = path.resolve('taskspec/ceshi');
const assetRegistryPath = path.resolve(
  'widget_service/cloud/data/capabilities/app-11.7.7.300_rom-7.0/asset_capabilities.json',
);
const productVersion = '11.8.8.342';
const romVersion = '6.0';

// Each seed is an existing 2x2 request whose data binding and action are retained.
// The target asset is the only candidate asset so the model can choose it from its description.
const definitions = [
  ['Q089', 'Q031', 'asset.emoji_earphone', '3D 耳机状态', '做一个耳机状态卡片，展示耳机名称和连接状态，并能打开收藏歌单。请使用本轮唯一候选的香槟金 3D 头戴耳机图片作为主视觉。'],
  ['Q090', 'Q030', 'asset.emoji_calendar', '会议日程', '做一个下一场会议日程卡片，展示会议名称、开始和结束时间，并可一键入会。请使用本轮唯一候选的红白日历图片作为日程主视觉。'],
  ['Q091', 'Q039', 'asset.emoji_Fitness_Health', '训练入口', '做一个最近训练卡片，展示最近一次运动类型和时长，点击可进入运动健康锻炼页。请使用本轮唯一候选的运动健康应用图标作为主视觉。'],
  ['Q092', 'Q031', 'asset.emoji_music1', '耳机音乐', '做一个耳机听歌卡片，展示耳机名称和连接状态，并能打开收藏歌单。请使用本轮唯一候选的音乐应用图标作为主视觉。'],
  ['Q093', 'Q043', 'asset.emoji_phone1', '家人天气关怀', '做一个长沙天气关怀卡片，展示天气预警、紫外线和空气质量，点击可拨打妈妈的电话。请使用本轮唯一候选的电话应用图标作为拨号主视觉。'],
  ['Q094', 'Q030', 'asset.emoji_calendar2', '本周日程', '做一个下一场日程卡片，展示会议名称、开始和结束时间，并可一键入会。请使用本轮唯一候选的 3D 线圈日历图片作为日程主视觉。'],
  ['Q095', 'Q033', 'asset.emoji_clean', '周末清扫提醒', '做一个周末清扫提醒卡片，展示下一条清扫日程和开始时间，点击可打开闹钟。请使用本轮唯一候选的 3D 拖把图片作为清扫主视觉。'],
  ['Q096', 'Q028', 'asset.emoji_clock', '赛事倒计时', '做一个广州马拉松倒计时卡片，展示距离比赛还有几天，点击可打开闹钟。请使用本轮唯一候选的 3D 双铃闹钟图片作为倒计时主视觉。'],
  ['Q097', 'Q033', 'asset.emoji_courier_box', '快递取件提醒', '做一个快递取件提醒卡片，展示下一条取件日程和开始时间，点击可打开闹钟。请使用本轮唯一候选的 3D 快递包裹图片作为主视觉。'],
  ['Q098', 'Q015', 'asset.emoji_health', '心率复盘', '做一个跑步后的心率复盘卡片，重点展示最高心率、最低心率和健康数据更新时间。请使用本轮唯一候选的 3D 红色爱心图片作为健康主视觉。'],
  ['Q099', 'Q033', 'asset.emoji_light', '开灯提醒', '做一个回家开灯提醒卡片，展示下一条开灯日程和开始时间，点击可打开闹钟。请使用本轮唯一候选的 3D 灯泡图片作为智能家居主视觉。'],
  ['Q100', 'Q031', 'asset.emoji_music', '音乐播放', '做一个耳机音乐卡片，展示耳机名称和连接状态，并能打开收藏歌单。请使用本轮唯一候选的 3D 双音符图片作为音乐主视觉。'],
  ['Q101', 'Q031', 'asset.emoji_music_2', '音乐歌单', '做一个耳机听歌卡片，展示耳机名称和连接状态，并能打开收藏歌单。请使用本轮唯一候选的 3D 音符图片作为歌单主视觉。'],
  ['Q102', 'Q033', 'asset.emoji_notepad', '复盘笔记提醒', '做一个复盘笔记提醒卡片，展示下一条笔记日程和开始时间，点击可打开闹钟。请使用本轮唯一候选的 3D 线圈笔记本图片作为主视觉。'],
  ['Q103', 'Q037', 'asset.emoji_run', '今日跑步', '做一个今日跑步卡片，展示步数、热量消耗和距离。请使用本轮唯一候选的 3D 跑步人物图片作为运动主视觉。'],
  ['Q104', 'Q033', 'asset.emoji_study', '学习计划提醒', '做一个学习计划提醒卡片，展示下一条学习日程和开始时间，点击可打开闹钟。请使用本轮唯一候选的 3D 纸张和铅笔图片作为主视觉。'],
  ['Q105', 'Q028', 'asset.emoji_time', '考试倒计时', '做一个考试倒计时卡片，展示距离考试还有几天，点击可打开闹钟。请使用本轮唯一候选的 3D 时钟图片作为倒计时主视觉。'],
  ['Q106', 'Q036', 'asset.emoji_z', '昨夜睡眠', '做一个昨夜睡眠卡片，展示夜间睡眠时长、睡眠状态和午睡时长。请使用本轮唯一候选的 3D 月亮和 Z 字图片作为睡眠主视觉。'],
];

const assets = JSON.parse(fs.readFileSync(assetRegistryPath, 'utf8'));
const assetsById = new Map(assets.map((asset) => [asset.id, asset]));
const manifest = [];

for (const [caseId, seedId, assetId, title, userQuery] of definitions) {
  const asset = assetsById.get(assetId);
  if (!asset || !asset.src.endsWith('.png')) {
    throw new Error(`${assetId} is not an available PNG asset in the 7.0 registry`);
  }

  const seedPath = path.join(caseDirectory, `${seedId}.json`);
  const testCase = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
  if (testCase.content.size !== '2x2') {
    throw new Error(`${seedId} is not a 2x2 trigger seed`);
  }

  const description = `${title}；唯一候选资源：${assetId}；${asset.description}`;
  const fields = {
    bundleName: testCase.content.bundleName,
    userQuery,
    candidateDataBindings: testCase.content.candidateDataBindings,
    title,
    size: '2x2',
    candidateEventCandidates: testCase.content.candidateEventCandidates,
    description,
    candidateAssetIds: [assetId],
  };

  testCase.content = structuredClone(fields);
  Object.assign(testCase, structuredClone(fields));
  testCase.deviceInfo.prdVer = productVersion;
  testCase.deviceInfo.romVersion = romVersion;
  testCase.session.interactionId = caseId.slice(1);
  testCase.session.sessionId = `taskspec-emoji-${caseId.slice(1)}`;
  testCase.utterance.original = userQuery;

  fs.writeFileSync(path.join(caseDirectory, `${caseId}.json`), `${JSON.stringify(testCase, null, 2)}\n`, 'utf8');
  manifest.push({
    caseId,
    sourceCase: seedId,
    assetId,
    assetDescription: asset.description,
    dataCapabilities: fields.candidateDataBindings.map((binding) => binding.capabilityId),
    eventCapabilities: fields.candidateEventCandidates.map((event) => event.capabilityId),
    size: fields.size,
  });
}

fs.writeFileSync(
  path.join(caseDirectory, 'emoji_asset_expected.json'),
  `${JSON.stringify({ productVersion, romVersion, cases: manifest }, null, 2)}\n`,
  'utf8',
);

console.log(`Generated ${manifest.length} emoji asset cases.`);
