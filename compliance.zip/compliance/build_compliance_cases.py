"""生成遵从度测试集入参：visual_axis=Q501–Q528，chain_axis=Q529–Q536（正例与对照成对）。

包络结构对齐 `taskspec/Phase 1/Qxxx.json`，文件名匹配 `run_ws_batch.py` 的 `^[QAW]\\d+\\.json$`；
CASES 里的 Q1xx 只是源码顺序号，输出按 `new_ids()` 换算为 Q5xx，避开 `template_misfire` 的 Q082–Q414。
用法：python build_compliance_cases.py
复算：node ../verify_declared.mjs compliance
      python ../check_service_rejection.py --dir=compliance
      python ../replay_preflight_and_search.py --dir=compliance   # 再跑本脚本回填 eligible 证据
跑批：python ../run_ws_batch.py --host <地址> --dir compliance
"""
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUNDLE = "com.omega_w_0823.hmservice"
SESSION_ID = "taskspec-compliance-20261008"
REPLAY = HERE.parent / "preflight_search_replay_compliance.json"

WEATHER_URI_PREFIX = "hww://www.huawei.com/totemweather?enterType=share&cityCode="

EVENT_WEATHER = (
    "event.open.weather",
    {
        "call": "clickToDeeplink",
        "args": {
            "intentName": "Weather_CityCode",
            "bundleName": "",
            "abilityName": "",
            "uri": "{{ '" + WEATHER_URI_PREFIX + "' + ${/data/weather/location/cityCode} }}",
        },
    },
)
EVENT_MEETING = (
    "event.enter.meeting",
    {
        "call": "clickToDeeplink",
        "args": {
            "intentName": "EnterMeeting",
            "bundleName": "",
            "abilityName": "",
            "uri": "{{ ${/data/calendar/events/0/oneClickServiceLink} }}",
        },
    },
)
EVENT_NAVIGATE = (
    "event.startNavigate",
    {
        "call": "clickToIntent",
        "args": {
            "intentName": "StartNavigate",
            "params": {"dstLocation": {"location": "company", "latitude": "", "longitude": ""}},
        },
    },
)
EVENT_BATTERY = (
    "event.open.settings.battery",
    {
        "call": "clickToDeeplink",
        "args": {
            "intentName": "Settings",
            "bundleName": "com.huawei.hmos.settings",
            "abilityName": "com.huawei.hmos.settings.MainAbility",
            "uri": "battery",
        },
    },
)
EVENT_POWERSAVE = (
    "event.setPowerSavingMode",
    {
        "call": "clickToIntent",
        "args": {
            "intentName": "SetSettingSwitch",
            "params": {
                "appBundleName": "com.huawei.hmos.settings",
                "itemName": "battery_saving_mode",
                "switchFlag": 0,
            },
        },
    },
)
EVENT_BLUETOOTH = (
    "event.open.settings.bluetooth",
    {
        "call": "clickToDeeplink",
        "args": {
            "intentName": "Settings",
            "bundleName": "com.huawei.hmos.settings",
            "abilityName": "com.huawei.hmos.settings.MainAbility",
            "uri": "bluetooth_entry",
        },
    },
)
EVENT_SPORT = (
    "event.open.health.sport",
    {
        "call": "clickToDeeplink",
        "args": {
            "intentName": "Health",
            "bundleName": "",
            "abilityName": "",
            "uri": "huaweischeme://healthapp/home/sport?sportType=2",
        },
    },
)
EVENT_ALARM = (
    "event.open.clock.alarm",
    {
        "call": "clickToDeeplink",
        "args": {
            "intentName": "Clock",
            "bundleName": "com.huawei.hmos.clock",
            "abilityName": "com.huawei.hmos.clock.phone",
            "uri": "",
        },
    },
)
EVENT_VIEW_CALENDAR = (
    "event.viewCalendarEvent",
    {
        "call": "clickToIntent",
        "args": {
            "intentName": "ViewCalendarEvent",
            "params": {"entityId": "{{ ${/data/calendar/events/0/entityId} }}"},
        },
    },
)


def weather(root: str, fields: list, prefecture: str, district: str = "", days: int = 1) -> dict:
    arguments = {"prefectureName": prefecture, "forecastDays": days}
    if district:
        arguments["districtName"] = district
    return {
        "capabilityId": "ViewWeather",
        "arguments": arguments,
        "writeResultTo": root,
        "candidateOutputFields": fields,
    }


def calendar(fields: list, days: int = 29) -> dict:
    return {
        "capabilityId": "GetCalendarEvents",
        "arguments": {"futureDays": days},
        "writeResultTo": "/data/calendar",
        "candidateOutputFields": fields,
    }


def battery(fields: list) -> dict:
    return {
        "capabilityId": "GetPhoneBatteryInfo",
        "arguments": {},
        "writeResultTo": "/data/phoneBattery",
        "candidateOutputFields": fields,
    }


def earphone(fields: list) -> dict:
    return {
        "capabilityId": "GetEarphoneInfo",
        "arguments": {},
        "writeResultTo": "/data/earphone",
        "candidateOutputFields": fields,
    }


def health(fields: list, day_offset: int = 0) -> dict:
    return {
        "capabilityId": "GetHealthAndSportSummary",
        "arguments": {"targetDayOffset": day_offset},
        "writeResultTo": "/data/healthSport",
        "candidateOutputFields": fields,
    }


def countdown(fields: list, target_date: str) -> dict:
    return {
        "capabilityId": "GetCountdownDays",
        "arguments": {"targetDate": target_date},
        "writeResultTo": "/data/countdown",
        "candidateOutputFields": fields,
    }


def event(pair: tuple) -> dict:
    return {"capabilityId": pair[0], "action": pair[1]}


# title/description 会进最终 CardSpec 展示元信息，只能用业务中性词；
# 维度标签一律只留在 manifest.json，避免把测试元数据渲染进卡片。
BUSINESS_LABEL = {
    "ViewWeather": "天气",
    "GetCalendarEvents": "日程",
    "GetPhoneBatteryInfo": "电量",
    "GetEarphoneInfo": "耳机",
    "GetHealthAndSportSummary": "运动健康",
    "GetCountdownDays": "倒计时",
}


def business_label(bindings: list) -> str:
    names = []
    for binding in bindings:
        name = BUSINESS_LABEL.get(binding["capabilityId"], "")
        if name and name not in names:
            names.append(name)
    return "、".join(names) or "桌面卡片"


# (caseId, 维度, size, query, bindings, events, assets, track, 看点/期望处置)
CASES = [
    ("Q101", "颜色·整卡背景覆盖默认色板", "2x2",
     "帮我做个卡片，看杭州市西湖区现在是什么天气，点一下查看杭州天气详情。整张卡片背景要红色的。",
     [weather("/data/weather", ["/location/cityCode", "/location/districtName",
                                "/location/prefectureName", "/current/temperatureText",
                                "/current/condition"], "杭州市", "西湖区")],
     [EVENT_WEATHER], ["asset.sun_max", "asset.local_fill"], "visual",
     "背景采样为红色系；被收敛回蓝紫暖渐变即静默违规"),
    ("Q102", "颜色·指定单个对象", "2x2",
     "帮我做个天气预警卡片，重点看长沙当前天气预警和信息更新时间。预警那行文字用红色，背景别动。",
     [weather("/data/weather", ["/location/prefectureName", "/current/alertLevel",
                                "/updatedAt"], "长沙市", days=1)],
     [], ["asset.typhoon_fill", "asset.bell_fill"], "visual",
     "预警文字红色 + 背景与基线一致（范围越界即违规）"),
    ("Q103", "颜色·静态数值与指定色", "2x2",
     "帮我做个电池检查卡片，电量就显示成百分之二十，这个数字用红色，再显示充电器类型。",
     [battery(["/batterySOC", "/batterySOCText", "/pluggedTypeDesc"])],
     [EVENT_BATTERY], ["asset.bolt_fill", "asset.battery_leaf_fill"], "visual",
     "数字为红色；mock 非 20% 时改判是否使用 /batterySOCText 并告知"),
    ("Q104", "颜色·纯色 vs 默认微渐变", "2x2",
     "帮我做个睡眠分析卡片，看昨晚总睡眠时长，再看睡眠记录类型和深睡时长。背景就要纯紫色，不要渐变。",
     [health(["/nightSleepDurationText", "/sleepTypeDesc", "/deepSleepDurationText"], -1)],
     [], ["asset.moon_z_fill_1"], "visual",
     "背景三点同色（无渐变）且为紫色系"),
    ("Q105", "颜色·低对比冲突不得自动加深", "2x2",
     "帮我做个日程卡片，背景用白色，文字也要接近白色的浅浅那种，看下午两点需求评审会的标题和开始时间。",
     [calendar(["/events/0/title", "/events/0/dtStart"], 2)],
     [], ["asset.calendar_fill"], "visual",
     "保留指定色 + 背板/描边补救或告知可读性风险；静默改深灰字即违规"),
    ("Q106", "颜色·明暗偏好", "2x4",
     "帮我做个夜跑卡片，看今天走了多少步、最近一次跑了多久，整体做成深色的，暗一点看着舒服。",
     [health(["/dailySteps", "/exerciseDurationText"], 0)],
     [EVENT_SPORT], ["asset.figure_run"], "visual",
     "整卡深色底 + 浅色字配对，不得深底深字"),
    ("Q107", "颜色·素材不染色", "2x2",
     "帮我做个耳机排障卡片，看耳机名称、连接状态和左右耳机充电状态，图标保持原来颜色别染色。"
     "点击打开蓝牙设置。",
     [earphone(["/earphoneName", "/isConnected", "/leftChargingStatusDesc",
                "/rightChargingStatusDesc", "/chargingStatusDesc"])],
     [EVENT_BLUETOOTH], ["asset.icon_earphone", "asset.earphone_case_16644"], "visual",
     "彩色素材不被统一染色；单色图标可染"),
    ("Q108", "颜色·多对象同时指定", "2x2",
     "帮我做个会议提醒卡片，看会议名称、会议日期、几点开始和离会议还有几天。"
     "深蓝背景、白色标题、浅灰按钮，点击进入免打扰设置。",
     [calendar(["/events/0/title", "/events/0/startDate", "/events/0/dtStart",
                "/events/0/countdownDays"], 2)],
     [], ["asset.icon_meeting", "asset.bell_fill"], "visual",
     "root 深蓝 / 标题白 / 按钮浅灰 三处分别判，对一个不算过"),
    ("Q109", "字号·主读数放大", "2x2",
     "帮我做个充电状态卡片，看手机是否在充电、使用的充电器类型和耳机仓是否在充电，"
     "电量数字做得大大的，点一下打开电池设置。",
     [battery(["/chargingStatusDesc", "/pluggedTypeDesc", "/batterySOCText"]),
      earphone(["/batteryLevel", "/chargingStatusDesc"])],
     [EVENT_BATTERY], ["asset.bolt_fill"], "visual",
     "电量数字文本框高度为卡内最大档"),
    ("Q110", "边框·指定分区描边", "2x2",
     "帮我做个卡片，看今天最近一次运动的时长、消耗热量和平均心率，主数据那块加个描边圈起来。",
     [health(["/exerciseDurationText", "/exerciseCalorieText", "/exerciseHeartRateAvg"], 0)],
     [], ["asset.heart_fill"], "visual",
     "描边落在指定数据块四周，不是全卡乱加"),
    ("Q111", "透明度·半透明底托", "2x2",
     "帮我做个电池温度卡片，重点看现在的电池温度，再看充电器类型和信息更新时间，"
     "中间那块底托做半透明的。",
     [battery(["/batteryTemperatureText", "/pluggedTypeDesc", "/updatedAt"])],
     [], ["asset.icon_weather_thermometer", "asset.flame_fill"], "visual",
     "底托透出色相差异（需容差），文字仍清晰"),
    ("Q112", "布局·位置与顺序", "2x2",
     "明天要在广州出门办事，帮我做个降雨卡片，看明天下雨概率和温度范围，"
     "温度放最上面，下雨概率放中间，温度范围放最底下，顺序别乱。",
     [weather("/data/weather", ["/daily/1/rainProbabilityPercent", "/daily/1/temperatureRangeText",
                                "/current/temperatureText"], "广州市", days=2)],
     [], ["asset.drop_1", "asset.sun_min"], "visual",
     "三个文本框 y 中心顺序与指令一致"),
    ("Q113", "对齐·两处不同对齐", "2x2",
     "帮我做个卡片，看未来7天一共安排了几件事和最近一件的标题、开始时间、备注，"
     "标题居中，下面的时间左对齐，点一下进日程详情。",
     [calendar(["/eventCount", "/events/0/title", "/events/0/dtStart",
                "/events/0/description"], 7)],
     [EVENT_VIEW_CALENDAR], ["asset.calendar_fill"], "visual",
     "标题居中、时间左对齐；全卡同对齐即违规"),
    ("Q114", "布局·紧凑度", "2x2",
     "帮我做个卡片，就要最近一场会议的标题和开始时间，卡片做得紧凑一点，别留大片空白。",
     [calendar(["/events/0/title", "/events/0/dtStart"], 2)],
     [], ["asset.icon_meeting"], "visual",
     "非背景像素占比上升且无超预算空洞；不得删掉要求字段"),
    ("Q115", "一致性·同类元素", "2x2",
     "帮我做个耳机状态卡片，分别看左右耳机电量，再看各自是否在充电，"
     "左右两个电量的字号和颜色保持一致，点一下打开蓝牙设置。",
     [earphone(["/leftBatteryLevel", "/rightBatteryLevel", "/leftChargingStatusDesc",
                "/rightChargingStatusDesc"])],
     [EVENT_BLUETOOTH], ["asset.icon_left", "asset.icon_right"], "visual",
     "两处电量文本框高度一致、采样色 ΔE00≤3"),
    ("Q116", "组件·进度环", "2x2",
     "帮我做个电量卡片，使用进度环查看剩余电量和充电状态，环要一眼就能看出还剩多少，"
     "点击进入省电模式。",
     [battery(["/batterySOC", "/batterySOCText", "/chargingStatusDesc"])],
     [EVENT_POWERSAVE], ["asset.battery_leaf_fill"], "visual",
     "出现环形进度视觉，不得退化为百分比文本"),
    ("Q117", "组件·禁用形态替代（该拒）", "2x2",
     "帮我做个卡片用标签页切换天气和日程，一页看深圳天气和体感，"
     "一页看下午两点需求评审会的标题和开始时间。",
     [weather("/data/weather1", ["/location/prefectureName", "/current/temperatureC",
                                "/current/condition", "/current/feelsLikeC"], "深圳市"),
      calendar(["/events/0/title", "/events/0/dtStart"], 2)],
     [], ["asset.sun_min", "asset.clock_fill"], "visual",
     "图上不得出现 tab 条；期望白名单内两分区替代 + 告知"),
    ("Q118", "按钮·数量与文案", "2x2",
     "帮我做个会议提醒卡片，看会议名称、几点开始和离会议还有几天，下面放两个入口，"
     "一个写“一键入会”，一个写“导航去公司”。",
     [calendar(["/events/0/title", "/events/0/dtStart", "/events/0/countdownDays",
                "/events/0/entityId", "/events/0/oneClickServiceLink"], 2)],
     [EVENT_MEETING, EVENT_NAVIGATE],
     ["asset.icon_meeting", "asset.location_north_up_right_fill"], "visual",
     "可见入口数=2 且两段文案逐字；2x2 动作预算冲突需告知"),
    ("Q119", "按钮·可见样式", "2x2",
     "帮我做个日程卡片，看下午两点需求评审会的标题和开始时间，入会那个按钮做成蓝色胶囊、白色字。",
     [calendar(["/events/0/title", "/events/0/dtStart", "/events/0/oneClickServiceLink",
                "/events/0/entityId"], 2)],
     [EVENT_MEETING], ["asset.icon_meeting"], "visual",
     "按钮底色蓝色系 + 胶囊圆角 + 文字白色"),
    ("Q120", "按钮·置灰外观", "2x2",
     "79天后参加广州马拉松，帮我做个备赛卡片，看距离比赛还有几天，"
     "“开始训练”那个按钮做成灰色的，点一下可以打开闹钟应用。",
     [countdown(["/countdownDays"], "2026-12-26")],
     [EVENT_SPORT, EVENT_ALARM], ["asset.stopwatch_fill"], "visual",
     "按钮呈灰色外观即可，不判 enabled 真假"),
    ("Q121", "按钮·热区大小", "2x2",
     "帮我做个电量卡片，看剩余电量和充电状态，“省电模式”那个按钮做大一点，手指容易按到。",
     [battery(["/batterySOCText", "/chargingStatusDesc"])],
     [EVENT_POWERSAVE], ["asset.battery_leaf_fill"], "visual",
     "按钮高度明显大于基线（对照 ≥24vp、目标 40vp）"),
    ("Q122", "负向·无按钮", "2x2",
     "帮我做个天气卡片，看杭州市西湖区现在的温度和风力，不要按钮，右下角写一行“查看更多”就行。",
     [weather("/data/weather", ["/location/districtName", "/current/temperatureText",
                                "/current/windDirection", "/current/windLevel"], "杭州市", "西湖区")],
     [EVENT_WEATHER], ["asset.sun_min", "asset.icon_weather_wind"], "visual",
     "无按钮形态背板 + 出现指定文字入口"),
    ("Q123", "负向·无图片图标", "2x2",
     "帮我做个卡片，看杭州市西湖区现在是什么天气，点一下查看杭州天气详情。"
     "不要放任何图片和图标，纯文字就行。",
     [weather("/data/weather", ["/location/districtName", "/current/temperatureText",
                                "/current/condition"], "杭州市", "西湖区")],
     [EVENT_WEATHER], ["asset.sun_max", "asset.local_fill"], "visual",
     "无任何图像元素；不得顺手删掉动作入口"),
    ("Q124", "颜色·显式覆盖默认蓝", "2x2",
     "帮我做个天气卡片，看看成都和上海各多少度、什么天气，"
     "我知道你们默认是蓝色，这张我就要绿色背景。",
     [weather("/data/weather1", ["/location/prefectureName", "/current/temperatureC",
                                "/current/condition"], "成都市"),
      weather("/data/weather2", ["/location/prefectureName", "/current/temperatureC",
                                "/current/condition"], "上海市")],
     [], ["asset.sun_min", "asset.drop_1"], "visual",
     "背景为绿色系；出蓝即静默违规"),
    ("Q125", "内容预算硬塞（该降级告知）", "2x2",
     "帮我做个卡片，明早要去南京紫金山拍日出，先看南京的气温、湿度、风向、风力、天气预警"
     "和手机电池温度，还要两个入口，点击查看天气详情和导航去紫金山，就做2x2。",
     [weather("/data/weather", ["/location/prefectureName", "/location/cityCode",
                                "/current/temperatureText", "/current/humidityPercent",
                                "/current/windDirection", "/current/windLevel",
                                "/current/alertLevel"], "南京市"),
      battery(["/batteryTemperatureText"])],
     [EVENT_WEATHER, EVENT_NAVIGATE], ["asset.icon_weather_wind", "asset.bell_fill"], "visual",
     "截断/挤压/溢出即违规；删次要项或建议 2x4 并告知为正确处置"),
    ("Q126", "综合冲突题", "2x2",
     "帮我做个会议卡片，看会议时间、地点和离会议还有几天，红色背景、白色标题、蓝色按钮，"
     "不要图片，别动按钮的颜色，点击进入免打扰设置。",
     [calendar(["/events/0/title", "/events/0/dtStart", "/events/0/eventLocation",
                "/events/0/countdownDays"], 2)],
     [], ["asset.icon_meeting", "asset.bell_slash_fill"], "visual",
     "红底覆盖蓝默认 / 按钮蓝保留 / 无图像元素 / 白字对比度只记风险不改色"),
    ("Q127", "鲁棒·超长标题不截断", "2x2",
     "帮我做个日程卡片，标题就写“2026年度华东区重点客户项目阶段性与结项评审汇总表”，"
     "看下午两点的开始时间和地点。",
     [calendar(["/events/0/dtStart", "/events/0/eventLocation"], 2)],
     [], ["asset.calendar_fill"], "visual",
     "OCR 结果与指定标题全文一致，出现省略号或缺尾即违规"),
    ("Q128", "鲁棒·口语噪音", "2x2",
     "整一个…那个绿忽忽的底吧，看天气用，温度和风力都来一下。",
     [weather("/data/weather", ["/current/temperatureText", "/current/windDirection",
                                "/current/windLevel", "/current/condition"], "上海市", "浦东新区")],
     [], ["asset.sun_min", "asset.icon_weather_wind"], "visual",
     "与 Q124 书面版对比：意图守恒 + 背景绿色系"),
    ("Q129", "链路·否决模板（天气完备入参）", "2x2",
     "出门前帮我做个天气卡片，看看上海市浦东新区现在的温度和天气情况。不要用模板，自由生成。",
     [weather("/data/weather", ["/location/districtName", "/current/temperatureText",
                                "/current/condition"], "上海市", "浦东新区")],
     [], ["asset.sun_max", "asset.local_fill"], "chain",
     "期望链路=自由生成；出现 Template 调用式即静默忽略用户要求"),
    ("Q130", "链路·否决模板（日程完备入参）", "2x2",
     "下一项日程需要重点关注，帮我做个卡片，看看标题、开始时间、结束时间和地点，"
     "点一下查看日程详情。不要用模板，自己排一版。",
     [calendar(["/events/0/title", "/events/0/dtStart", "/events/0/dtEnd",
                "/events/0/eventLocation", "/events/0/entityId"], 7)],
     [EVENT_VIEW_CALENDAR], ["asset.calendar_fill"], "chain",
     "同 Q129，对照见 Q134"),
    ("Q131", "链路·否决模板（进度环电量）", "2x2",
     "帮我做个电量卡片，使用进度环查看剩余电量和充电状态。不要用模板，自己排一版。",
     [battery(["/batterySOC", "/batterySOCText", "/chargingStatusDesc"])],
     [], ["asset.battery_leaf_fill"], "chain",
     "同 Q129，对照见 Q135"),
    ("Q132", "链路·否决模板（天气预警）", "2x2",
     "41天后参加无锡马拉松，帮我做个备赛卡片，看距离比赛还有几天。不要走模板，自由生成。",
     [countdown(["/countdownDays"], "2026-11-18")],
     [], ["asset.stopwatch_fill", "asset.figure_run"], "chain",
     "同 Q129，对照见 Q136；预警字段集在 search 复算下候选为空，换倒计时才有对照意义"),
    ("Q133", "链路对照·天气", "2x2",
     "出门前帮我做个天气卡片，看看上海市浦东新区现在的温度和天气情况。",
     [weather("/data/weather", ["/location/districtName", "/current/temperatureText",
                                "/current/condition"], "上海市", "浦东新区")],
     [], ["asset.sun_max", "asset.local_fill"], "control",
     "期望命中天气模板，否则 Q129 的通过无意义"),
    ("Q134", "链路对照·日程", "2x2",
     "下一项日程需要重点关注，帮我做个卡片，看看标题、开始时间、结束时间和地点，点一下查看日程详情。",
     [calendar(["/events/0/title", "/events/0/dtStart", "/events/0/dtEnd",
                "/events/0/eventLocation", "/events/0/entityId"], 7)],
     [EVENT_VIEW_CALENDAR], ["asset.calendar_fill"], "control",
     "期望命中日程模板"),
    ("Q135", "链路对照·进度环电量", "2x2",
     "帮我做个电量卡片，使用进度环查看剩余电量和充电状态。",
     [battery(["/batterySOC", "/batterySOCText", "/chargingStatusDesc"])],
     [], ["asset.battery_leaf_fill"], "control",
     "期望命中电量环模板"),
    ("Q136", "链路对照·天气预警", "2x2",
     "41天后参加无锡马拉松，帮我做个备赛卡片，看距离比赛还有几天。",
     [countdown(["/countdownDays"], "2026-11-18")],
     [], ["asset.stopwatch_fill", "asset.figure_run"], "control",
     "对照 eligible 必须非空（复算为 4 张倒计时模板），否则 Q129 系正例通过无意义"),
]


def build_case(entry) -> dict:
    case_id, dimension, size, query, bindings, events, assets = entry[:7]
    label = business_label(bindings)
    content = {
        "bundleName": BUNDLE,
        "userQuery": query,
        "candidateDataBindings": bindings,
        "title": label,
        "size": size,
        "candidateEventCandidates": [event(pair) for pair in events],
        "description": label + "信息",
        "candidateAssetIds": assets,
    }
    return {
        "content": content,
        "deviceInfo": {
            "countryCode": "CN",
            "deviceFormation": "HDSpeaker",
            "deviceType": 0,
            "locale": "zh-CN",
            "phoneType": "SGT-AL10",
            "prdVer": "11.9.9.342",
            "romVersion": "7.0",
            "sysVer": "EmotionUI_9.0.0",
            "time": "20261008000000000",
        },
        "pagination": {"limit": 5, "start": ""},
        "session": {"interactionId": case_id[1:], "isNew": True, "sessionId": SESSION_ID},
        "userAuth": {"user": {"userId": ""}},
        "utterance": {"original": query, "type": "text"},
        "version": "1.0",
    } | content


# 判定元数据：按 CASES 原编号给，输出时换算成 Q5xx。
# 每条 = assertedAt（判定层）、layer（探针手段）、strength、conflictWith、expectedOutcome、ruleSource（可追溯依据）
PROOF = {
    "Q101": ("render", "png-sampling", "hard", "default-palette", "follow",
             "云侧方案设计.md L1039 用户明确配色要求优先"),
    "Q102": ("render", "png-sampling+scope", "hard", "none", "follow",
             "指令对象范围；L1039"),
    "Q103": ("render", "png-sampling+ocr", "hard", "mock-data", "follow",
             "L908 dataModelSchema 由微服务生成，数值不由 query 决定"),
    "Q104": ("render", "png-sampling(三点同色)", "hard", "default-palette", "follow",
             "L1389 用户明确要求纯色时尊重其要求"),
    "Q105": ("render", "png-sampling+contrast", "hard", "contrast-ux", "follow-with-notify",
             "L1397 不以自动加深颜色覆盖指定色值"),
    "Q106": ("render", "png-sampling(整卡明度)", "hard", "default-palette", "follow",
             "L1039"),
    "Q107": ("render", "png-sampling(素材区)", "hard", "asset-palette", "follow",
             "L1392 不给彩色素材强制染色"),
    "Q108": ("render", "png-sampling×3", "hard", "default-palette", "follow",
             "L1039；多对象逐个判，对一个不算过"),
    "Q109": ("render", "png-geometry(文本框高)", "soft", "type-scale", "follow",
             "字号阶梯 10/12/14/16/18/20/32/40；主读数默认 30fp 最大 38fp"),
    "Q110": ("render", "png-geometry(描边闭合)", "hard", "none", "follow",
             "指定分区范围遵从；未指定区不加"),
    "Q111": ("render", "png-sampling(容差)", "soft", "surface-rule", "follow",
             "L1040/L1041 浅色表面与融球表面规则"),
    "Q112": ("render", "png-geometry(y 序)", "hard", "none", "follow",
             "顺序指令 = 显式约束"),
    "Q113": ("render", "png-geometry(质心偏移)", "hard", "none", "follow",
             "局部指令不得当全局执行"),
    "Q114": ("render", "非背景像素占比+空洞高", "soft", "content-budget", "follow",
             "L807 内容预算；降级顺序不得删用户要求字段"),
    "Q115": ("render", "png-geometry+png-sampling", "hard", "none", "follow",
             "同类元素一致性"),
    "Q116": ("render", "组件形状可辨", "hard", "display-unit", "follow",
             "Progress 合法；不得退化为百分比文本"),
    "Q117": ("render", "无 tab 形态", "hard", "component-whitelist", "refuse-and-notify",
             "组件白名单（Tabs/NavContainer 禁用）"),
    "Q118": ("render", "可见入口数+ocr", "hard", "content-budget", "proper-degradation",
             "L807 2x2 一个主动作；L1554 尺寸遵从"),
    "Q119": ("render", "png-sampling+形状", "hard", "none", "follow",
             "按钮 backgroundColor/borderRadius/label 色"),
    "Q120": ("render", "png-sampling(按钮灰)", "soft", "none", "follow",
             "只判外观；enabled 属结构轨"),
    "Q121": ("render", "png-geometry(按钮高)", "soft", "touch-target", "follow",
             "可点击元素 ≥24vp，优先接近 40vp"),
    "Q122": ("render", "无按钮形态+ocr", "hard", "action-policy", "follow",
             "负向约束；不得伪造可点击暗示"),
    "Q123": ("render", "无图像元素", "hard", "asset-budget", "follow",
             "L1036 图标预算；负向不得连带删动作"),
    "Q124": ("render", "png-sampling", "hard", "default-palette", "follow",
             "L1039 用户明确配色优先"),
    "Q125": ("render", "截断/溢出检测", "hard", "content-budget", "proper-degradation",
             "L807 + 受保护文本必须完整显示"),
    "Q126": ("render", "多探针（背景/文字/按钮/无图）", "hard",
             "default-palette+asset+contrast-ux", "follow",
             "L1039/L1389/L1392/L1397 综合"),
    "Q127": ("render", "ocr 全文比对", "hard", "protected-text", "follow",
             "受保护文本不得依赖 ellipsis/clip"),
    "Q128": ("render", "同 Q124 口径", "soft", "input-noise", "follow",
             "query_agent/quality_rules.json noise 轴；与书面版对比"),
    "Q129": ("chain-template", "Template 调用式/search eligible", "hard", "template-default",
             "no-target-template", "模板为软默认，用户显式否决应生效（待确认 A/B 口径）"),
    "Q130": ("chain-template", "Template 调用式/search eligible", "hard", "template-default",
             "no-target-template", "同 Q129"),
    "Q131": ("chain-template", "Template 调用式/search eligible", "hard", "template-default",
             "no-target-template", "同 Q129"),
    "Q132": ("chain-template", "Template 调用式/search eligible", "hard", "template-default",
             "no-target-template", "同 Q129；候选非空由 replay 复算证明"),
    "Q133": ("chain-template", "search eligible 非空", "hard", "none", "target-eligible",
             "对照：证明该入参确实可命中模板，否则 Q129 通过无意义"),
    "Q134": ("chain-template", "search eligible 非空", "hard", "none", "target-eligible",
             "对照：同 Q133"),
    "Q135": ("chain-template", "search eligible 非空", "hard", "none", "target-eligible",
             "对照：同 Q133"),
    "Q136": ("chain-template", "search eligible 非空", "hard", "none", "target-eligible",
             "对照：倒计时 4 张候选非空，否则正例通过无意义"),
}

CAVEAT = {
    "Q103": "电量取端侧 mock sampleValue，若返回不是 20%，只判色与被选字段，不判数值",
    "Q105": "白底近白字需按渐变/半透明合成后取样；对比度不足记 UX 风险，不得据此改色",
    "Q111": "20% 白底托在浅渐变上像素差极小，判定时需容差",
    "Q117": "图上判“无 tab 条 + 两分区替代”；拒答话术单列一栏，不混进像素判定",
    "Q125": "图上判截断/挤压/溢出；“删了什么、建议 2x4 与否”看回复话术",
}


def new_ids() -> dict:
    """按 CASES 顺序重编号：visual Q501–Q528，chain Q529–Q536，避开 template_misfire 的 Q082–Q414。"""
    mapping, visual, chain = {}, 501, 529
    for entry in CASES:
        old, track = entry[0], entry[7]
        if track == "visual":
            mapping[old] = f"Q{visual}"
            visual += 1
        else:
            mapping[old] = f"Q{chain}"
            chain += 1
    return mapping


def remap(text: str, mapping: dict) -> str:
    for old, new in mapping.items():
        text = text.replace(old, new)
    return text


def main() -> None:
    mapping = new_ids()
    axes = {"visual": ("visual_axis", "Q501-Q528"), "chain": ("chain_axis", "Q529-Q536")}
    buckets = {name: [] for name in axes}
    replay_rows = {}
    if REPLAY.exists():
        replay_rows = {row["caseId"]: row for row in json.loads(REPLAY.read_text(encoding="utf-8"))}
    else:
        print("提示：缺 preflight_search_replay_compliance.json，先跑 "
              "python ../replay_preflight_and_search.py --dir=compliance 再重跑本脚本回填链路证据。")

    for entry in CASES:
        old, dimension, size, query, _, _, _, track, probe = entry
        case_id = mapping[old]
        payload = build_case(entry)
        payload["session"]["interactionId"] = case_id[1:]
        axis_dir, _ = axes["chain"] if track != "visual" else axes["visual"]
        folder = HERE / axis_dir
        folder.mkdir(parents=True, exist_ok=True)
        (folder / f"{case_id}.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        asserted_at, layer, strength, conflict, outcome, rule = PROOF[old]
        row = replay_rows.get(case_id, {})
        eligible = row.get("eligible") or []
        chain_evidence = {
            "preflight": row.get("preflight", ""),
            "eligibleTemplates": eligible,
            "eligibleCount": len(eligible),
            "searchMiss": row.get("searchMiss") or "",
            "templatePathAvailable": bool(eligible),
        }
        buckets["visual" if track == "visual" else "chain"].append(
            {
                "caseId": case_id,
                "file": f"{case_id}.json",
                "axis": axis_dir,
                "track": track,
                "dimension": dimension,
                "size": size,
                "userQuery": query,
                "assertedAt": asserted_at,
                "expectedOutcome": outcome,
                "templatePathAvailable": chain_evidence["templatePathAvailable"],
                "complianceProof": {
                    "judging": {"layer": layer, "ruleSource": rule},
                    "strength": strength,
                    "conflictWith": conflict,
                    "probe": remap(probe, mapping),
                    "dataValueCaveat": CAVEAT.get(old, ""),
                    "controlCase": remap(_control_of(old), mapping),
                    "chainEvidence": chain_evidence,
                    "sourceId": old,
                },
            }
        )

    for name, (axis_dir, numbering) in axes.items():
        cases = sorted(buckets[name], key=lambda item: item["caseId"])
        (HERE / axis_dir / "manifest.json").write_text(
            json.dumps(
                {
                    "version": "compliance-axis-v1",
                    "axis": axis_dir,
                    "caseCount": len(cases),
                    "numbering": numbering,
                    "assertedAt": "render" if name == "visual" else "chain-template",
                    "cases": cases,
                },
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )

    (HERE / "manifest.json").write_text(
        json.dumps(
            {
                "version": "compliance-index-v1",
                "sessionId": SESSION_ID,
                "axes": {
                    name: {
                        "directory": axis_dir,
                        "manifest": f"{axis_dir}/manifest.json",
                        "caseCount": len(buckets[name]),
                        "range": numbering,
                        "assertedAt": "render" if name == "visual" else "chain-template",
                    }
                    for name, (axis_dir, numbering) in axes.items()
                },
                "totalCaseCount": sum(len(items) for items in buckets.values()),
                "axesOrder": ["visual", "chain"],
                "chainStratification": (
                    "视觉轨中 templatePathAvailable=true 的条目共 "
                    f"{sum(1 for items in buckets.values() for it in items if it['templatePathAvailable'])} 条："
                    "这些同一指令会走模板链路（整卡主题由 CardPlan/Tersel 决定），其余走自由生成链路。"
                    "颜色、组件、图标类探针必须按 templatePathAvailable 分层统计，"
                    "否则模板默认主题会冒充成“模型不遵从”。"
                    "证据取自 preflight_search_replay_compliance.json（生产 search 复算，非人工填写）。"
                ),
                "validityPolicy": (
                    "本集只保留能通过微服务校验的合法入参：未知能力、未声明出参、未知事件、"
                    "事件 call 不一致、未登记素材、非法写入根、不支持尺寸一律不入本集。"
                    "准入用 verify_declared.mjs + check_service_rejection.py + "
                    "replay_preflight_and_search.py 三层复算证明。"
                ),
                "judgingPolicy": (
                    "visual_axis 判定层=渲染 PNG/OCR（色值、文本、几何、留白、截断、两轮 diff）；"
                    "chain_axis 判定层=响应 streamContent 的 Template(\"<id>\") 调用式与 search eligible，"
                    "口径同 taskspec/score_ws_run.py。协议合规与结构断言（三行契约、borderRadius=18、"
                    "素材来源、onClick.args 逐字、emoji 与素材区分、enabled 语义）为独立门槛，"
                    "不与本集合成分数，只在不过时一票否决。"
                ),
                "openQuestion": (
                    "“不要用模板”是软默认（用户可否决，走了即违规）还是平台强制（走了才对并需告知）？"
                    "云侧方案设计.md 只写了配色/纯色/尺寸的用户显式优先，未写模板链路可否决，"
                    "定标后回填 chain_axis 的 expectedOutcome。"
                ),
                "fieldNotes": {
                    "sourceId": "生成器 CASES 原编号，重编号后保留可追溯",
                    "controlCase": "chain 正例指向其反向对照；对照本身 search eligible 必须非空",
                    "expectedOutcome": "follow | follow-with-notify | proper-degradation | "
                                       "refuse-and-notify | no-target-template | target-eligible",
                },
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"已生成 {len(CASES)} 条用例：visual_axis {len(buckets['visual'])} / "
          f"chain_axis {len(buckets['chain'])}，含各轴 manifest 与顶层索引。")


def _control_of(case_id: str) -> str:
    """chain 正例与对照互为 Q12x/Q13x 相邻编号，这里显式给出映射。"""
    return {
        "Q129": "对照 Q133",
        "Q130": "对照 Q134",
        "Q131": "对照 Q135",
        "Q132": "对照 Q136",
    }.get(case_id, "")


if __name__ == "__main__":
    main()


if __name__ == "__main__":
    main()
