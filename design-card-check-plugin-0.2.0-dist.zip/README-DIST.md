# design-card-check-plugin 使用说明（人类阅读版）

> 这是发给协作者的分发包说明。机器/自动化消费请读同目录 `README-MACHINE.md`（结构化事实 +
> 逐条命令与预期输出 + 错误签名处置）。两份说明描述同一个包，版本 0.2.0。

## 这是什么

一个搭载在 DeepSeek Harness（dsh）上的**设计规范检查插件**：对 HarmonyOS A2UI 服务卡片的 DSL
产物做确定性检查——颜色是否在登记色集、间距密度是否合规、布局骨架是否符合 2×4 规范等，
输出分级问题清单（P0/P1/P2）+ 证据定位 + 最小修复建议。

规范真值 = `DESIGN.md`（2×2 卡）+ `DESIGN-2x4.md`（2×4 卡）双金标准，**随包分发**。
机器只做检测 + 定位 + 建议，**不下最终设计结论**——通过与否由设计师确认。

## 包内容

| 文件 | 说明 |
|---|---|
| `design-card-check-plugin-0.2.0.tgz` | 插件本体（npm bundle，92 文件；含 Python 检测核心、五规则包、双金标准） |
| `README.md`（本文件） | 人类版说明 |
| `README-MACHINE.md` | 机器版说明（指纹 / 命令 / 错误处置） |

完整性校验：`shasum -a 256 design-card-check-plugin-0.2.0.tgz` 应得
`eb81e9b885fd698cf9b05c287578886e1c1fce7b006c8ac14ae386343e71dbaf`。

## 60 秒上手

前置：node ≥ 20、python3 ≥ 3.9（**无需 pip 装任何依赖**）、已有 dsh 可用的 profile（如 headless）。

```sh
npm i -g @deepseek-ai/dsh@0.1.1-rc.2                    # 版本锁定
dsh plugin --profile headless add ./design-card-check-plugin-0.2.0.tgz
dsh --profile headless "用 design_check 工具检查 /绝对路径/xxx/card.genui.jsonl，layout 传空字符串"
```

模型会调用 `design_check` 工具并回报：`qid + findings 计数（P0/P1/P2）` 和逐条
`[层级] 严重级 规则号: 问题描述 @元素` + 修复建议。卸载：
`dsh plugin --profile headless remove design-card-check-plugin`。

## 能检查什么

- **L1 声明层（无设备，毫秒级）**：色值登记集 / 13 档 alpha / 渐变预设原样使用 / 排版档位 /
  组件契约 / 图标素材 / 密度 / 2×4 布局骨架（拓扑归位 + 槽位级 TEMPLATE_DELTA 量化）——
  五个规则包共 **69 条规则**；
- **L2 实测层（需 dump）**：传外部 dumpLayout JSON（`layout` 参数）做几何与声明↔实测对账；
- **输入形态**：裸 DSL `.jsonl` 路径、三件套目录、数据集 case id（如 `q1`/`Q034`，大小写短号都认）。

## 0.1.0 → 0.2.0 变化速览

| 类别 | 变化 |
|---|---|
| 架构 | 规则拆为五包（protocol/elements/spacing/skeleton/l2_visual）+ manifest 登记，包级可追溯 |
| 分发 | 修复打包断裂（P0）；干净 Python 环境即拆即用；零 `.pyc` 混入 |
| 入口 | 大小写 qid、短号、`--dir` 三件套目录全部正确分流 |
| 行为 | 移交同事侧的三条几何规则（重叠/基线/文字重叠）默认不再输出，`--include-delegated` 可恢复 |
| 可靠性 | 退出码契约：0=完成无 P0，1=完成有 P0，**2=检查器自身故障**（不再伪装成违规） |
| 能力 | 2×4 骨架终审（76 卡全归位）、`--cases` 统一批量入口、机器可读 problem-list JSON、可视化双视口报告 |

## 常见问题（人话版）

- **装完触发没反应？** 别装在全新空 profile 上——它没有对话运行面。装进你平时用的 headless/web
  profile 就好；一定要新 profile，需在其 `package.json` 的 `dsh.profile.bundles` 里手动加
  `"@deepseek-ai/dsh-headless"`（这个名字不在公网 npm，`dsh plugin add` 装不了）。
- **找不到某些几何规则（重叠/基线）？** 这三类已按 2026-08-24 分工移交给同事侧工具，默认静默；
  需要时加 `--include-delegated`。
- **和开发版冲突？** 同一 profile 已装本包时不能再叠同 id 的 `--patch` 开发挂载（启动报
  `duplicate loader entry id`）。要改本地源码，先 remove。
- **检查器报错 vs 卡片违规？** 退出码 2 = 检查器自己出问题（stderr 有定位），不是卡片违规。
- **批量 / 渲染 dump 自采？** 需要仓库检出 + 数据集 / `PIPELINE_DIR` 指向 CreateMyCard + 模拟器；
  包内不含数据集。详见包内 `design-check/SKILL.md`。

## 深入阅读

- 包内 `design-check/SKILL.md`：完整命令、维度、降级说明（随 tgz 分发）；
- 源仓库：`gitcode-CreateMyCard/Design-guide`（当前 main `08d0f89`）；
- 发布依据：`docs/plan-dsh-bundle-distribution.md`（分发形态）、`docs/plan-plugin-release-hardening.md`
  （0.2.0 加固清单）、`design-check/review/20260827/IDEA6-acceptance-20260827-hardening.md`（验收报告）。
