# design-card-check-plugin — 机器可读分发说明（MACHINE README）

> 本文件供接收方机器上的 agent / 自动化脚本直接消费：事实区可解析，命令区可逐行执行，
> 每条命令附预期输出与错误签名。人类阅读版 = 包内 `README.md` 与 `design-check/SKILL.md`。

## FACTS

```yaml
package: design-card-check-plugin
version: 0.2.0
kind: deepseek-harness-bundle          # npm 包 + dsh.bundle 声明（官方 publish.md 形态）
tarball: design-card-check-plugin-0.2.0.tgz
tarball_sha256: eb81e9b885fd698cf9b05c287578886e1c1fce7b006c8ac14ae386343e71dbaf
tarball_bytes: 352818
tarball_files: 92
tool_registered: design_check          # 唯一工具；参数 target + layout（均 string，均必填）
requires:
  dsh: 0.1.1-rc.2                       # npm i -g @deepseek-ai/dsh@0.1.1-rc.2（版本锁）
  node: ">=20"
  python3: ">=3.9"                      # L1 检测零第三方依赖
ships_with:
  DESIGN.md_sha256: f0306f3a647a868978f9bb56148e294cc3180e1958bd0b179577c3414d06b150      # 2×2 金标准
  DESIGN-2x4.md_sha256: d1feb4efda175682df497dc8111c0aac46c9a7d68cd3091415db38bf176c5d8a  # 2×4 金标准
  plugin_entry: design-check/plugin/src/index.mjs
env_overrides:
  DESIGN_SPEC: 金标准 2×2 路径覆盖
  DESIGN_2X4_SPEC: 金标准 2×4 路径覆盖
  PIPELINE_DIR: CreateMyCard 渲染管线目录（L2 自采渲染才需要）
```

## VERIFY-INTEGRITY（先于安装）

```sh
shasum -a 256 design-card-check-plugin-0.2.0.tgz
# 预期输出（不一致则停止，重新获取分发包）：
# eb81e9b885fd698cf9b05c287578886e1c1fce7b006c8ac14ae386343e71dbaf  design-card-check-plugin-0.2.0.tgz
tar -tzf design-card-check-plugin-0.2.0.tgz | wc -l   # 预期：92
```

## INSTALL（装进既有运行 profile；不要新建空 profile）

```sh
npm i -g @deepseek-ai/dsh@0.1.1-rc.2
dsh plugin --profile headless add ./design-card-check-plugin-0.2.0.tgz
# 预期：pnpm 输出 "+ design-card-check-plugin file:<…>.tgz" 与 "Done"；无网络 registry 访问
dsh --profile headless --dump-config | grep -A1 "design-card-check-plugin"
# 预期：出现 "# == design-card-check-plugin" 层，含 "- id: design-card-check-plugin"
```

## SMOKE-TEST（一句话触发，预期 ~60s）

```sh
dsh --profile headless "调用 design_check 工具：target 传 <任意 DSL jsonl 绝对路径>，layout 传空字符串。回报 summary。"
# 预期 stderr 首行：[design-card-check] plugin loaded (core: <profile>/node_modules/design-card-check-plugin/design-check)
# 预期模型回报：qid + findings 计数 (P0=.. P1=.. P2=..) 与若干 rule_id
```

## USE（工具契约）

- `target`（必填）：DSL jsonl 路径（绝对路径，或**相对 dsh 进程当前目录**解析）或 93 条集 case id（如 `q010`，需仓库检出+数据集）。
- `layout`（必填）：外部 dumpLayout JSON 路径（启用 L2a/L2b）；无 dump 传空字符串 `""`。
- 返回 canonical JSON：`{qid, summary:{total,p0,p1,p2}, findings:[{layer,severity,rule_id,element,message,expected,actual,fix_hint}]}`。
- 输入校验负例（路径缺失/空文件/非法 JSON）返回结构化错误，含可定位完整路径——静默跳过即异常。

## CAPABILITY-BOUNDARIES

| 能力 | 安装态 |
|---|---|
| L1 全量（--dsl/--dir 任意路径） | 可用 |
| L2 对账（--layout 外部 dump） | 可用 |
| --qdir / 评测分支批量 | 需仓库检出 + 数据集（不随包；缺省显式报错） |
| 自采渲染 dump | 需 PIPELINE_DIR + DevEco/hdc；无设备 dry-run 降级 |

## FAILURE-MODES（实测错误签名 → 处置）

| 签名 | 原因 | 处置 |
|---|---|---|
| `ERR_UNSUPPORTED_NODE_MODULES_TYPE_STRIPPING` | 入口被换回 .ts（本包已用 .mjs，不应出现） | 用回官方 tarball，勿手改包内入口 |
| 触发后长时间无响应（插件已 loaded） | 全新 profile 只含 dsh-base，无 agent 运行面 | 装进既有 headless/web profile；或手改该 profile `package.json` 的 `dsh.profile.bundles` 加入 `"@deepseek-ai/dsh-headless"`（in-box 名**不可** `dsh plugin add`，不在公网 npm） |
| `duplicate loader entry id: design-card-check-plugin` | 同 profile 已装 bundle 又叠同 id `--patch` 开发层 | 先 `dsh plugin --profile headless remove design-card-check-plugin` 再挂 --patch；两通道互斥 |
| `@deepseek-ai/dsh-tools ... not in the npm registry` | 对 in-box 包名误执行 add | 无需安装；盒内包由 dsh 安装自身提供 |

## UNINSTALL

```sh
dsh plugin --profile headless remove design-card-check-plugin
# 预期：dump-config 中本层消失，profile 正常启动
```

## VERSIONING

规则层（DESIGN.md/validators）变更后重新分发：递增 `package.json` 的 `version` → `pnpm pack` →
以新 tarball 的 sha256 更新本文件 FACTS 区。对账锚点 = 本文件 sha256 与包内 manifest。
