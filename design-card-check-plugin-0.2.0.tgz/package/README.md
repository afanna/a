# Design-Guide 工作区 — DSL 设计规范检查（Design Check Agent）

本项目（本工作区）的目标：制作一个 **设计检查 agent**，检测生成的 widget 卡片 DSL 产物
（三件套：`query.txt` / `task-spec.json` / `card.genui.jsonl`，或裸 `.jsonl`）是否符合设计规范，
并给出可解释、可复核、可追溯的检查报告。机器只做检测 + 定位 + 建议，不下最终设计结论。

- 开发计划（权威）：[`开发计划-DSL设计规范检查.md`](./开发计划-DSL设计规范检查.md)（v2.1）
- 仓库协作约定：[`AGENTS.md`](./AGENTS.md)（真值来源、检查项范式、报告命名与汇报规范）
- 阶段/目标文档：[`docs/plan.md`](./docs/plan.md) 及 `docs/goal-*.md`（各专项 goal 与 dsh 插件规划）

> 位置说明（2026-08-21 并入后）：本工作区已并入外层 CreateMyCard 仓库（`gitcode-CreateMyCard/`）
> 统一版本管理，不再自带独立 git（并入前的 3 个本地提交备份在仓库外
> `~/Desktop/2026/Design-guide-history.bundle`）。工作区内不再内置 `CreateMyCard/` 副本：
> 下文提到的渲染管线指**外层仓库根**的 `scripts/preview/`，由 `PIPELINE_DIR` 指定
> （默认自动回退到外层仓库根，也可用环境变量显式覆盖）。

## 工作区既有资产

| 资产 | 路径 | 说明 |
|---|---|---|
| DSL 生成/预览渲染管线 | 外层 CreateMyCard 仓库根（`scripts/preview/`） | 复用其预览/渲染管线 `render_dsl.py`、`render_batch_trio.py`；经 `PIPELINE_DIR` 指定，默认自动回退 |
| 93 条卡片 DSL 数据 | [`卡片8-4-v12-93条-…/`](./卡片8-4-v12-93条-query-taskspec-可渲染最终DSL-复检修复-v18-20260807%202/) | 开发语料 + 回归夹具（v2.1 口径，非检查对象、非真值来源）；只读引用，不入库 |
| 设计规范金标准 | [`DESIGN.md`](./DESIGN.md)（2×2 卡）＋ [`DESIGN-2x4.md`](./DESIGN-2x4.md)（2×4 卡） | front-matter token 系统 + 正文规则，按卡片尺寸选用；2026-08-22 登记，与外层 `docs/system_prompt.txt` 解耦 |
| 第一次评测集（四分支 299 条） | [`第一次评测/`](./第一次评测/) | A（一步走）/ B（现网）/ C（模板）/ MS（多步走）四分支批量检查对象；只读引用，不入库 |

## 检查器职责边界（2026-08-24 与同事对齐）

本检查器只做三件事（能力总表见 `design-check/review/EVAL299-capability-scope-20260824.html`，作边界记录、非规则真值）：

1. **元素合法性**：颜色（登记集 / alpha 13 档 / 对比度算子 / 渐变预设）、图标（尺寸契约 / 来源 / 染色）、素材、排版（字号字重矩阵 / 字数上限）、形状（圆角族）、组件目录；
2. **间距合法性**：12vp 安全边距（声明 + dump 双层）、槽位间距/预算；
3. **布局骨架（重点 2×4）**：`LAYOUT2X4.*` 五条契约（2026-08-24 落地）、槽区归类、结构存量、区域锚点、声明↔实测对账。

**已移出**（同事侧负责，3 项已有实现代码暂留、不再投入）：元素重叠（`GEOMETRY.OVERLAP` / `AREA_CONTENT_TEXT_OVERLAP`）、裁切、文字横向基线对齐（`GEOMETRY.BASELINE_MISMATCH`）。
语义层（L3）暂缓，当前不投入。

## 工程结构（`design-check/`）

```
design-check/
├── SKILL.md                      # dsh 技能（软链到 .dsh/skills/design-card-check/SKILL.md）
├── scripts/
│   ├── check_card.py             # 单卡检查 CLI（--dir 三件套 / --dsl 裸 DSL / --qdir 数据集 case；--layout 接外部 dump）
│   ├── check_case.py             # 一键管线：渲染 + dump + 检查 + 线框 + 双报告（--branch/--dsl/--qdir 三入口，需设备）
│   ├── check_batch.py            # 93 条批量检查 + 汇总（--with-layout 含离线 dump）
│   ├── check_eval.py             # 第一次评测四分支 L1 批量（--branch A,B,C,M；--rules 规则过滤）
│   ├── contrast_calc.py          # 对比度算子（前景 × 背景栈合成，pass/fail/uncertain 三态）
│   ├── render_dump.py            # L2 真值工序：转换 → 渲染 → dumpLayout（无设备 --dry-run 降级）
│   ├── geometry_assert.py        # L2a 几何断言独立入口
│   ├── reconcile.py              # L2b 声明↔实测对账独立入口
│   ├── wireframe.py              # 线框叠加图生成（需 dump）
│   ├── report_html.py            # 单卡可视化报告（problem-list / visual HTML）
│   ├── report_b_eval.py          # 评测分支问题清单报告
│   ├── build_color_fork_report.py# 四分支色系分叉比对报告
│   ├── regression.py             # 负例集 + 基线 diff 回归
│   ├── summarize.py              # 汇总 → summary.md / index.html / baseline.json
│   └── review_agent.py           # L2c/L3 评审编排（骨架，暂缓）
├── validators/                   # 校验库底座（L1 核心标准库 only；2026-08-26 拆包后为装载底座）
│   ├── core/                     # 树工具 / gradient 助手（包间共享；包内禁互 import）
│   ├── rules/                    # 兼容别名层（转发 packages/ 五包，存量脚本零改动）
│   ├── packages_loader.py        # 五包 manifest.yaml 装载器（一致性断言；无 PyYAML 自动降级内置解析）
│   ├── design_contract.py        # DESIGN.md front-matter → 归一化契约（allowed 集 / alpha 13 档单源）
│   ├── contrast_calc.py          # 对比度算子库（scripts/contrast_calc.py 的底座）
│   ├── dsl.py / spec.py / colors.py / layout.py / dataset.py / eval_loader.py …
│   └── render_bridge.py          # 对外层渲染管线的隔离调用
├── packages/                     # 检测规则五包（按真值来源归属；各含 manifest.yaml 规则清单）
│   ├── pkg_protocol/             # 宿主管线契约（7 规则）
│   ├── pkg_elements/             # DESIGN.md token 层（32 规则 + data/）
│   ├── pkg_spacing/              # 间距密度章（9 规则）
│   ├── pkg_skeleton/             # layout_slots 布局骨架（2×4 / 2×2 双尺寸，6 规则）
│   └── pkg_l2_visual/            # dump 真值层（15 规则；delegated_rules 三条已移交同事侧，默认静默）
├── plugin/                       # dsh 原生插件（JS 薄壳）：design_check / design_check_batch 工具
│   └── src/index.mjs             #   spawn Python CLI；入口大小写 qid / 短号 / 目录全覆盖（docs/plan-dsh-native-plugin.md）
├── composition/checker.cordis.yml# 旧占位（已被 plugin/ + plan-dsh-native-plugin.md 取代）
├── prompts/                      # L2/L3 评审 prompt 模板
├── review/                       # 检查/渲染输出（派生产物；带日期报告进 review/<YYYYMMDD>/）
├── tests/                        # 单测 + 负例集（tests/negatives）+ 金样例
└── install_skill.sh              # 安装/重装 dsh 技能软链
```

## 快速开始（Python 3.9+，L1 核心仅标准库）

以下命令在 `design-check/` 目录内执行；工作区根（本目录）可直接 `make <target>`（见 `Makefile`）。

```bash
# L1 单卡（毫秒级，无设备）
python3 scripts/check_card.py --dir <三件套目录> --format text   # 任意新产物
python3 scripts/check_card.py --dsl <card.genui.jsonl> --format text
python3 scripts/check_card.py --qdir q010 --format text           # 93 条数据集 case

# 对比度算子（模型不心算对比度，一律调算子）
python3 scripts/contrast_calc.py --fg "#FFFFFFFF" --bg "#FF317AF7"

# L2（需 dump 真值）：外部 dump 直传，或自有渲染工序
python3 scripts/check_card.py --dir <三件套目录> --layout review/dumps/q010.layout.json --format text
python3 scripts/render_dump.py --cases q010 --dry-run             # 无设备显式降级

# 一键管线（需模拟器 + hdc）：指定 case 渲染 + dump + 检查 + 线框 + 双报告
python3 scripts/check_case.py --branch B --case q1,q4,q7
python3 scripts/check_case.py --dsl <任意裸DSL> --case <卡号>

# 批量 / 评测集 / 回归
python3 scripts/check_batch.py --with-layout    # 93 条全量
python3 scripts/check_eval.py --branch A,B,C,M  # 四分支 299 条（--rules ICON.* 可过滤）
python3 scripts/regression.py --all             # 负例集 + 基线 diff

# 可视化报告 / 汇总 / 测试
python3 scripts/report_html.py --dir tests/data/q001 --out review/<日期>/q001-visual.html
python3 scripts/summarize.py
make test
```

报告产物命名与五段式汇报规范见 [`AGENTS.md`](./AGENTS.md)（`<范围>-<卡号>-<类型>-<YYYYMMDD>`，落 `review/<生成日期>/`）。

## 分层

- **L1 声明层**（程序已证实，静态，毫秒级）：结构、token、色值登记集、alpha 档、渐变预设、图标/排版/形状/间距声明、`LAYOUT2X4.*` 布局骨架（2×4）；
- **L2 真值层**（需渲染 + `uitest dumpLayout`）：
  - L2a 几何断言：安全区/间距/槽距/锚点（重叠/裁切/基线三项职责已移交同事侧）；
  - L2b 声明↔实测对账：尺寸/背景色/透明度漂移；
  - L2c 视觉评审（线框×实拍叠加，骨架已有）；
- **L3 语义评审**（模型推断）：暂缓，当前不投入。

输出范式：`[P0|P1|P2][程序已证实|模型推断|需端侧确认]` + 证据（json_pointer / dump_id）+ 最小修复建议。

## dsh 承载（DeepSeek Harness）

- **技能通道**：`SKILL.md`（软链部署于 `.dsh/skills/design-card-check/`），headless 一句话触发；
- **插件通道**：`plugin/src/index.mjs` 注册 `design_check` / `design_check_batch` 两工具（JS 薄壳
  spawn `check_card.py` / `check_case.py`；入口大小写 qid、短号、目录全覆盖）；规划中的
  `design_render_dump` / `design_semantic_review` 见 [`docs/plan-dsh-native-plugin.md`](./docs/plan-dsh-native-plugin.md)。
- **退出码契约**：0 = 检查完成且无 P0；1 = 检查完成且有 P0（批量=部分卡失败）；2 = 检查器自身故障
  （stderr 定位，不产出伪 finding）。已移交同事侧的三条几何规则默认静默，`--include-delegated` 恢复。
- 检测逻辑全部在 Python 核心，dsh 只是编排壳。

## 约束

- 不修改外层 CreateMyCard 仓库的生成管线、卡片数据集与两份规范金标准 `DESIGN.md` / `DESIGN-2x4.md`（只读引用）。
- 机器只做检测+定位+建议；最终通过与否由人类设计师确认。
- 不硬编码用户名、绝对工作区路径、批次日期；`review/` 为派生输出，不得反向成为规则事实来源。
