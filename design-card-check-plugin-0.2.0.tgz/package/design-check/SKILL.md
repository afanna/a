---
name: design-card-check
description: 检测 HarmonyOS A2UI 服务卡片 DSL 产物是否符合设计规范金标准（DESIGN.md（2×2）+ DESIGN-2x4.md（2×4））。核心是色值（COLOR.*）与 DumpLayout（GEOMETRY.*/RECONCILE.*）两个确定性维度，另有结构/文案等 L1 规则与 L3 语义启发式；输出 [P0|P1|P2][程序已证实|模型推断|需端侧确认] 分级问题、证据与最小修复建议。
whenToUse: 用户要求检查/评审/校验 widget 卡片产物、卡片 DSL、设计规范符合性，或对卡片批量摸底时。
metadata:
  owner: design-check
  version: v0.4
---

# design-card-check

对生成的 widget 卡片产物做设计规范检查。真值 = 工作区根目录双规范金标准：`DESIGN.md`（2×2 卡）+ `DESIGN-2x4.md`（2×4 卡），按卡片尺寸选用；外层 CreateMyCard 的 `docs/system_prompt.txt` 不是本检查器真值。
机器只做检测 + 定位 + 建议；最终通过与否由人类设计师确认。

## 输入形态识别

- 任意三件套目录（`query.txt` / `task-spec.json` / `card.genui.jsonl`）→ 用 `--dir <path>`；
- 裸 DSL（`.jsonl`，含 createSurface/updateComponents）→ 用 `--dsl <path>`；
- 数据集内 case id（如 `q010`）→ 用 `--qdir q010`；
- 用户只给一句话没给路径 → 请用户给路径，不要猜测。

以下命令均在 `design-check/` 目录内执行（工作区根 = 本目录的父目录，含双金标准 `DESIGN.md` / `DESIGN-2x4.md`）。

## 维度一：色值校验（L1 声明侧，无设备，毫秒级）

DSL 所有颜色（fontColor/fillColor/backgroundColor/borderColor/color + 渐变 stops）归一后必须落在
DESIGN.md 派生登记色集；透明度必须 13 档；禁用 opacity 降透明。规则：`COLOR.TOKEN_UNREGISTERED` /
`COLOR.ALPHA_STEP` / `COLOR.OPACITY_MISUSE` / `GRADIENT.*` / `VISUAL.CONTRAST`。

```sh
python3 scripts/check_card.py --dir <三件套目录> --format text     # 任意新产物
python3 scripts/check_card.py --dsl <card.genui.jsonl> --format text
python3 scripts/check_card.py --qdir q010 --format text            # 数据集内 case
```

## 对比度算子（评审工具：模型不心算对比度，一律调算子）

```sh
# 任意「前景 × 背景栈」（自底向上多层 alpha；默认 DSL 序 #AARRGGBB，--order rgba 切规范序）
python3 scripts/contrast_calc.py --fg "#FFFFFFFF" --bg "#FF317AF7"
# 从 DSL 求某文字的背景栈 + 渐变包络三态（pass / fail / uncertain=需端侧确认）
python3 scripts/contrast_calc.py --card <三件套目录> --comp text2
```

输出 JSON（ratio/verdict/逐层 trace/blended_bg）；三态语义：pass=最不利位置也 ≥3:1；
pass-suggest=过 3:1 但 <4.5:1（建议级）；fail=全位置 <3:1（P1）；
uncertain=跨 3:1 取决于文字实际位置（需端侧确认）。`VISUAL.CONTRAST` 规则即由本算子驱动。

## 维度二：DumpLayout 校验（L2a 几何 + L2b 声明↔实测对账）

需要 dump 真值（`uitest dumpLayout` 输出，`{attributes, children}` 树）：

```sh
# 通道 A：外部 dump 文件直传
python3 scripts/check_card.py --dir <三件套目录> --layout <dump.layout.json> --format text

# 通道 B：自有渲染工序（转换→渲染→aa start 重拉→dumpLayout→recv→review/dumps/）
python3 scripts/render_dump.py --cases q010 --sn <设备SN>          # 有设备
python3 scripts/render_dump.py --cases q010 --dry-run              # 无设备：显式降级，只转换
python3 scripts/check_card.py --qdir q010 --layout review/dumps/q010.layout.json --format text
```

规则：`GEOMETRY.SAFE_AREA_OVERFLOW/OVERLAP/BUTTON_SIZE/SLOT_GAP/CONTENT_ALIGN_ANCHOR`、
`RECONCILE.DIMENSION_DRIFT/COLOR_DRIFT/OPACITY_DRIFT`。
dump 拿不到 fontColor/fillColor——前景色只在维度一校验；dump 背景色缺失标「需端侧确认」，不臆报。

## 批量 / 汇总 / 回归

```sh
python3 scripts/check_batch.py --with-layout    # 93 条语料全量（含离线 dump 真值）
python3 scripts/summarize.py                    # summary.md + index.html + baseline.json
python3 scripts/regression.py --all             # 负例集 + 基线 diff
python3 -m pytest tests/ -q                     # 全套测试
```

## 输出格式

结论行（分卡）+ 每项：

```
[P0|P1|P2][程序已证实|模型推断|需端侧确认] <问题>（证据: <json_pointer / dump_id>）
最小修复建议: …
```

严重度：P0=阻塞（结构错误/内容重叠溢出）；P1=规范硬性违规（未登记色值/非法 alpha/渐变/几何违例/对账漂移）；
P2=建议或需端侧确认。

## 降级说明

- 无模拟器/hdc：维度二走通道 A（外部 dump）或跳过并声明「DumpLayout 未覆盖」；`render_dump.py --dry-run`
  显式降级（manifest 标 degraded），不得假装已渲染。
- 无模型凭据：L3 语义用启发式降级（`SEMANTIC.*`，标注「模型推断」）。
- 报告产物在 `review/`（派生输出，可覆盖重生成）；机器报告不得反向当作规则来源。

## 用法示例

web / headless（dsh，已验证版本 0.1.1-rc.2）：

```sh
dsh --profile headless "对 <三件套目录> 做设计规范检查并生成报告"   # 在 design-check/ 目录内启动
```

### bundle 安装态（正式分发，`docs/plan-dsh-bundle-distribution.md`）

```sh
npm i -g @deepseek-ai/dsh@0.1.1-rc.2                              # 版本锁定
dsh plugin --profile headless add ./design-card-check-plugin-<version>.tgz   # 装进既有运行 profile
dsh --profile headless "用 design_check 工具检查 <DSL 路径>"
dsh plugin --profile headless remove design-card-check-plugin     # 卸载
```

- **装进既有 profile**（如 headless/web）：一行安装即用，无需 setup.sh / 软链 / 改 `~/.dsh`。
- **全新 profile 注意**：`dsh plugin add` 初始化的 profile 只含 `dsh-base`（无 agent 运行面，触发会
  静默挂起）；需把 `@deepseek-ai/dsh-headless` 加进该 profile `package.json` 的
  `dsh.profile.bundles`（in-box 名不走 npm 安装，手改列表即可，参照既有 headless profile 结构）。
- **与开发挂载互斥**：同一 profile 已装本 bundle 时，不得再叠同 id 的 `--patch` 开发覆盖层
  （启动即 `duplicate loader entry id` 报错）；开发期二选一——热改本地源请先 remove bundle。
- 工具 `target` / `layout` 相对路径按 dsh 进程当前目录解析；入口识别大小写 qid（`Q034`）、
  短号（`q1`/`q01`）、三件套目录均可。
- 批量走 `design_check_batch` 工具（`check_case.py --cases` 混合语法；`include_delegated` 可选）。
- 退出码三态：0 = 完成无 P0；1 = 完成有 P0（批量=部分卡失败）；2 = 检查器自身故障（stderr 定位）。
- 已移交同事侧的三条几何规则（OVERLAP / BASELINE_MISMATCH / AREA_CONTENT_TEXT_OVERLAP）默认
  静默，`--include-delegated` 显式恢复。
- 能力边界：L1 全量 + L2（`--layout` 外部 dump）随包可用；`--qdir` / 评测分支批量需仓库检出 + 数据集
  （不随包，缺省显式报错）；自采渲染需 `PIPELINE_DIR` 指向 CreateMyCard 检出。金标准 `DESIGN.md` /
  `DESIGN-2x4.md` 随包分发（env `DESIGN_SPEC` / `DESIGN_2X4_SPEC` 可覆盖指向自有检出）。

## 约束

- 不修改宿主 CreateMyCard 仓库（工作区外层目录）、卡片数据集与两份规范金标准 `DESIGN.md` / `DESIGN-2x4.md`（只读引用）。
- 93 条历史数据集仅作开发语料与回归夹具；检查对象是任意新输入产物。
- 运行不依赖网络与模型凭据（两个确定性维度）。
