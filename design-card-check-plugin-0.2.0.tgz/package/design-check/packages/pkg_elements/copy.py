"""COPY.* —— 文案长度规则（E-06）。"""
from __future__ import annotations

import re
from typing import Any, Dict, List

from validators.dsl import GenuiCard
from validators.finding import Finding, P1
from validators.rules import register
from validators.rules._common import make

#: 去除数据绑定与空白后的有效文本
_BIND_RE = re.compile(r"\{\{\s*\$\{.*?\}\s*\}\}")


def _plain_text(value) -> str:
    if not isinstance(value, str):
        return ""
    return _BIND_RE.sub("", value).strip()


def _is_title_like(comp: Dict[str, Any]) -> bool:
    """只把有明确标题语义的 Text 当作标题，避免把所有粗体正文误报。"""
    cid = str(comp.get("id") or "").lower()
    role = str(comp.get("role") or comp.get("slot") or "").lower()
    return any(token in cid or token in role for token in ("title", "header", "subtitle"))


def _limit(contract: Dict, key: str, default: int) -> int:
    ux = contract.get("ux") or {}
    if key == "titleMaxChars":
        value = ((ux.get("title") or {}).get("maxChars"))
    elif key == "subtitleMaxChars":
        value = ((ux.get("title") or {}).get("maxChars"))
    elif key == "actionLabelMaxChars":
        value = ((ux.get("button") or {}).get("labelMaxChars"))
    else:
        value = None
    if isinstance(value, (int, float)):
        return int(value)
    return int((contract.get("copy_limits") or {}).get(key, default))


@register("COPY.TITLE_MAX_CHARS")
def check_title_max(card: GenuiCard, contract: Dict, query: str) -> List[Finding]:
    """标题类文本（小节标题，字重 500/700 的小型文本）不得超过 titleMaxChars=6（E-06）。"""
    limit = _limit(contract, "titleMaxChars", 22)
    findings: List[Finding] = []
    for comp in card.iter_components():
        if comp.get("component") != "Text":
            continue
        content = comp.get("content")
        plain = _plain_text(content)
        if not plain:
            continue
        # 标题区可选；必须有明确 title/header 语义才检查长度。
        if _is_title_like(comp) and "subtitle" not in str(comp.get("id", "")).lower() and len(plain) > limit:
            findings.append(
                make(
                    card, "COPY.TITLE_MAX_CHARS",
                    f"标题文案 {len(plain)} 字 > titleMaxChars={limit}",
                    comp.get("id"), severity=P1,
                    expected=f"≤ {limit} 字",
                    actual=f"{len(plain)} 字: {plain}",
                    fix_hint="精简标题",
                )
            )
    return findings


@register("COPY.SUBTITLE_MAX_CHARS")
def check_subtitle_max(card: GenuiCard, contract: Dict, query: str) -> List[Finding]:
    """副标题同样限制为不超过 22 字（UX 规范标题区）。"""
    limit = _limit(contract, "subtitleMaxChars", 22)
    findings: List[Finding] = []
    for comp in card.iter_components():
        if comp.get("component") != "Text" or "subtitle" not in str(comp.get("id") or "").lower():
            continue
        plain = _plain_text(comp.get("content"))
        if plain and len(plain) > limit:
            findings.append(make(
                card, "COPY.SUBTITLE_MAX_CHARS", f"副标题文案 {len(plain)} 字 > subtitleMaxChars={limit}",
                comp.get("id"), severity=P1, expected=f"≤ {limit} 字", actual=f"{len(plain)} 字: {plain}",
                fix_hint="精简副标题，或将详细说明移至目标页面",
            ))
    return findings


@register("COPY.ACTION_LABEL_MAX_CHARS")
def check_action_label_max(card: GenuiCard, contract: Dict, query: str) -> List[Finding]:
    """按钮/操作文案不得超过 actionLabelMaxChars=4（E-06）。"""
    limit = _limit(contract, "actionLabelMaxChars", 6)
    findings: List[Finding] = []
    for comp in card.iter_components():
        if comp.get("component") != "Text":
            continue
        cid = str(comp.get("id", "")).lower()
        is_action = "button" in cid or "action" in cid or comp.get("onClick")
        if not is_action:
            continue
        plain = _plain_text(comp.get("content"))
        if plain and len(plain) > limit:
            findings.append(
                make(
                    card, "COPY.ACTION_LABEL_MAX_CHARS",
                    f"操作文案 {len(plain)} 字 > actionLabelMaxChars={limit}",
                    comp.get("id"), severity=P1,
                    expected=f"≤ {limit} 字",
                    actual=f"{len(plain)} 字: {plain}",
                    fix_hint="精简操作文案",
                )
            )
    return findings
