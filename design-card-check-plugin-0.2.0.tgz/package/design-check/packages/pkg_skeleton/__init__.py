"""pkg-skeleton —— 2×4 与 UX 2×2 布局骨架契约。"""
