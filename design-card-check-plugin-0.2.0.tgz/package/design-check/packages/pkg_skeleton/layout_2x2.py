"""LAYOUT2X2.* —— 当前 UX 2×2 基础框架契约。"""
from __future__ import annotations
from typing import Any, Dict, List
from validators.dsl import GenuiCard
from validators.finding import Finding, P1
from validators.rules import register
from validators.rules._common import make
from validators.core.tree import _comp_index, _parent_map, _resolved_children

CANVAS_WIDTHS = (160, 158)
CANVAS_HEIGHT = 160
SAFE_MARGIN = 12
ROOT_RADIUS = 20

def _root(card: GenuiCard) -> Dict[str, Any] | None:
    return card._root_component()

def _is_2x2(card: GenuiCard) -> bool:
    return card.card_size == "2x2" or (card.card_size is None and card.size == "2x2")

@register("LAYOUT2X2.ROOT_CONTRACT")
def check_root_contract(card: GenuiCard, contract: Dict, query: str) -> List[Finding]:
    if not _is_2x2(card): return []
    root = _root(card)
    if root is None: return []
    styles = root.get("styles") or {}
    findings: List[Finding] = []
    checks = (("component", root.get("component"), ("Stack",)),
              ("width", styles.get("width"), CANVAS_WIDTHS),
              ("height", styles.get("height"), (CANVAS_HEIGHT,)),
              ("borderRadius", styles.get("borderRadius"), (ROOT_RADIUS,)))
    for key, actual, expected in checks:
        if actual is None: continue
        if actual in expected: continue
        exp = "/".join(str(x) for x in expected)
        findings.append(make(card, "LAYOUT2X2.ROOT_CONTRACT", f"2×2 root {key} 应为 {exp}，实际 {actual}",
            root.get("id"), severity=P1, expected=exp, actual=str(actual),
            fix_hint="按 UX 2×2 框架使用 160(或158)×160、Stack、20vp圆角"))
    return findings

@register("LAYOUT2X2.SAFE_AREA")
def check_safe_area(card: GenuiCard, contract: Dict, query: str) -> List[Finding]:
    if not _is_2x2(card): return []
    root = _root(card)
    if root is None: return []
    padding = (root.get("styles") or {}).get("padding")
    if isinstance(padding, (int, float)) and not isinstance(padding, bool) and int(padding) != SAFE_MARGIN:
        return [make(card, "LAYOUT2X2.SAFE_AREA", f"2×2 安全边距应为 12vp，实际 {padding}vp", root.get("id"), severity=P1,
            expected="padding=12vp", actual=f"padding={padding}vp", fix_hint="content_root 使用固定 12vp 安全边距")]
    return []

@register("LAYOUT2X2.TOPOLOGY")
def check_topology(card: GenuiCard, contract: Dict, query: str) -> List[Finding]:
    if not _is_2x2(card): return []
    root = _root(card)
    if root is None: return []
    index = _comp_index(card)
    container = root
    kids = _resolved_children(index, container)
    if len(kids) == 1 and kids[0].get("component") in ("Column", "Row", "Stack"):
        kids = _resolved_children(index, kids[0])
    action_indices = [i for i, child in enumerate(kids) if child.get("onClick") or any(c.get("onClick") for c in _resolved_children(index, child))]
    if action_indices and action_indices[-1] != len(kids) - 1:
        return [make(card, "LAYOUT2X2.TOPOLOGY", "2×2 操作区必须位于内容末尾", kids[action_indices[-1]].get("id"), severity=P1,
            expected="title? → content → action", actual=f"action index={action_indices[-1]}", fix_hint="将按钮移至内容区末尾并保留 12vp 安全边距")]
    return []
