"""DIVIDER.* —— UX 分割线契约。"""
from __future__ import annotations

from typing import Dict, List

from validators.dsl import GenuiCard
from validators.finding import Finding, P1
from validators.rules import register
from validators.rules._common import make, color_value_rgba


@register("DIVIDER.CONTRACT")
def check_divider_contract(card: GenuiCard, contract: Dict, query: str) -> List[Finding]:
    """分割线厚度 1vp，颜色使用 comp_divider（显式声明时检查）。"""
    findings: List[Finding] = []
    sources = contract.get("hex_sources") or {}
    expected_color = next((key for key, names in sources.items()
                           if any(name.endswith("comp_divider") for name in names)), None)
    for comp in card.iter_components():
        if comp.get("component") != "Divider":
            continue
        styles = comp.get("styles") or {}
        thickness = styles.get("strokeWidth", styles.get("height"))
        if isinstance(thickness, (int, float)) and not isinstance(thickness, bool) and abs(float(thickness) - 1) > 0.5:
            findings.append(make(card, "DIVIDER.CONTRACT", f"分割线厚度应为 1vp，实际 {thickness}vp",
                comp.get("id"), severity=P1, expected="strokeWidth/height=1vp",
                actual=f"{thickness}vp", fix_hint="将分割线厚度改为 1vp"))
        raw = styles.get("color")
        if raw is not None and expected_color:
            actual = color_value_rgba(raw)
            if actual and actual.lower() != expected_color.lower():
                findings.append(make(card, "DIVIDER.CONTRACT", "分割线颜色应使用 comp_divider token",
                    comp.get("id"), severity=P1, expected=f"color={expected_color}", actual=f"color={raw}",
                    fix_hint="改用 {colors.comp_divider}（UX 分割线规范）"))
    return findings
