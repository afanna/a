"""SPACING.* —— 间距/安全边距规则（E-05）。"""
from __future__ import annotations

from typing import Dict, List

from validators.dsl import GenuiCard
from validators.finding import Finding, P1
from validators.rules import register
from validators.rules._common import make

SAFE_MARGIN = 12


@register("SPACING.SAFE_MARGIN")
def check_safe_margin(card: GenuiCard, contract: Dict, query: str) -> List[Finding]:
    """card-root padding 必须为 safe-margin=12vp（E-05）。"""
    root = card.find_component("root")
    if root is None:
        return []
    padding = (root.get("styles") or {}).get("padding")
    if padding is not None and int(padding) != SAFE_MARGIN:
        return [
            make(
                card, "SPACING.SAFE_MARGIN",
                f"card-root padding 应为 safe-margin={SAFE_MARGIN}vp，实际 {padding}",
                "root", severity=P1,
                expected=f"{SAFE_MARGIN}vp",
                actual=f"{padding}vp",
                fix_hint="保持 root padding = 12",
            )
        ]
    return []


@register("SPACING.SCALE")
def check_spacing_scale(card: GenuiCard, contract: Dict, query: str) -> List[Finding]:
    """显式间距使用 UX 当前规范档位（4/8/10/12vp）。"""
    root = card.find_component("root")
    if root is None:
        return []
    ux_allowed = ((contract.get("ux") or {}).get("spacing") or {}).get("allowed")
    allowed = set()
    if isinstance(ux_allowed, (list, tuple)):
        for value in ux_allowed:
            try:
                allowed.add(int(float(str(value).replace("vp", ""))))
            except (TypeError, ValueError):
                pass
    if not allowed:
        allowed = set(contract.get("allowed_spacing") or [])
    findings: List[Finding] = []
    for comp in card.iter_components():
        styles = comp.get("styles") or {}
        for key in ("gap", "padding", "margin"):
            value = styles.get(key)
            values = value if isinstance(value, (list, tuple)) else [value]
            for item in values:
                if isinstance(item, bool) or not isinstance(item, (int, float)):
                    continue
                if int(item) not in allowed:
                    findings.append(make(card, "SPACING.SCALE",
                        f"{key}={item}vp 不在 UX spacing 档位",
                        comp.get("id"), severity=P1,
                        expected=" ".join(str(s) for s in sorted(allowed)), actual=f"{key}={item}vp",
                        fix_hint="改用 UX 规定的 4/8/10/12vp 间距档位"))
    return findings
