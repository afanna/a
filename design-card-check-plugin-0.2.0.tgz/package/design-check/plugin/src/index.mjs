// design-card-check 插件入口（docs/plan-dsh-bundle-distribution.md P2 修正：单一 .mjs 源）。
// 检测逻辑全部在 Python 核心（scripts/check_card.py），本插件只做壳：
// 参数校验 → 分流 → spawn → JSON 解析 → canonical 值 + render 摘要。dsh 是编排壳，不是检查逻辑载体。
// 为什么是 .mjs 而不是 .ts：Node 原生 strip-types 拒绝 node_modules 内的 .ts（2026-08-24 安装态
// 实测 ERR_UNSUPPORTED_NODE_MODULES_TYPE_STRIPPING），.mjs 在开发 --patch 态与 bundle 安装态
// 行为一致，且免构建免 allowBuilds——单源无漂移。
//
// 入口收口（Idea6-WP-E1）：target 分流不再只认小写 2-3 位 case id——
//   ① 存在的目录        → check_card --dir（三件套定位，口径同 check_case 的目录入口）
//   ② q/Q + 1-3 位编号  → check_card --qdir（统一小写，数据集目录为小写命名）
//   ③ 其余              → check_card --dsl（文件路径；缺失/非法由核心显式报错 exit 2）
import { spawn } from 'node:child_process'
import { existsSync, statSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

// defineTool 缺失时降级透传：仓库测试态/工装态（verify_tool.mjs、路由单测）无 dsh 依赖也可 import；
// dsh 运行态包在场，行为不变。
let defineTool
try {
  ({ defineTool } = await import('@deepseek-ai/dsh-tools'))
} catch {
  defineTool = (spec) => spec
}

export const name = 'design-card-check-plugin'
export const inject = ['tools']

// 插件位于 <包根>/design-check/plugin/src/，Python 核心 CLI 在 <包根>/design-check/scripts/
// （包根 = 本文件上三级的父目录；仓库态与 tarball 安装态同构）
const SRC_DIR = path.dirname(fileURLToPath(import.meta.url))
const CORE_DIR = path.resolve(SRC_DIR, '..', '..')

// 相对路径按 dsh 进程当前目录解析（bundle 安装态用户直觉）；绝对路径与 case id 原样透传。
// 仓库 --patch 开发态若沿用「相对 design-check/」的旧习惯，请改传绝对路径。
function resolveInput(p) {
  const t = p.trim()
  return path.isAbsolute(t) ? t : path.resolve(process.cwd(), t)
}

// case id：大小写 q/Q 均认 + 1-3 位编号（q1 / q01 / q001 / Q034 全覆盖）
const CASE_ID_RE = /^[qQ]\d{1,3}$/

/**
 * target 分流（纯函数，供单测断言；Idea6-WP-E1）。
 * 返回 { mode: 'dir'|'qdir'|'dsl', value }：
 *   dir  = value 为解析后的目录绝对路径（存在性判定为准，即使形如 q034）
 *   qdir = value 为小写化后的 case id（check_card --qdir 数据集口径）
 *   dsl  = value 为解析后的文件绝对路径（核心侧缺文件/空文件显式报错）
 */
export function routeTarget(target) {
  const t = String(target).trim()
  const resolved = resolveInput(t)
  if (existsSync(resolved) && statSync(resolved).isDirectory()) {
    return { mode: 'dir', value: resolved }
  }
  if (CASE_ID_RE.test(t)) {
    return { mode: 'qdir', value: t.toLowerCase() }
  }
  return { mode: 'dsl', value: resolved }
}

function runCheck(target, layout, signal) {
  return spawnCheck(['scripts/check_card.py', '--format', 'json'], target, layout, [], signal)
}

function parseFindings(parsed) {
  parsed.findings = (parsed.findings ?? []).map((f) => ({
    ...f,
    dsl_id: f.element?.dsl_id ?? null,
  }))
  return parsed
}

// check_card/check_case 约定（Idea6-WP-E3 退出码契约）：
//   0=检查完成无 P0 / 1=检查完成有 P0（均输出合法产物）；2=检查器自身故障
function failDetail(stderr) {
  return stderr.trim().split('\n').slice(-3).join(' ')
}

export function apply(ctx) {
  console.error(`[design-card-check] plugin loaded (core: ${CORE_DIR})`)
  ctx.tools.register(
    defineTool({
      name: 'design_check',
      description:
        '对 widget 卡片 DSL 产物做设计规范检查（真值 DESIGN.md(2×2)/DESIGN-2x4.md(2×4) 金标准；L1 声明层 + 可选 L2 dump 对账）。' +
        'target=卡片定位：DSL jsonl 路径（绝对路径，或相对 dsh 进程当前目录）、三件套目录路径、或 93 条数据集 case id' +
        '（大小写 q/Q 均可、1-3 位编号，如 q010/Q034/q1）。已移交同事侧的三条几何规则默认静默。' +
        'layout=dumpLayout JSON 路径（通道 A，启用 L2a/L2b，同样按当前目录解析相对路径）；无 dump 传空字符串。' +
        '返回 unified-findings/v1：[P0|P1|P2][程序已证实|模型推断|需端侧确认] + 证据 + 最小修复建议。',
      parameters: {
        target: { type: 'string', required: true, description: 'DSL jsonl 路径（绝对路径或相对当前目录）、三件套目录路径、或数据集 case id（如 q010/Q034）' },
        layout: { type: 'string', required: true, description: '外部 dumpLayout JSON 路径（绝对路径或相对当前目录）；无 dump 传空字符串' },
        include_delegated: { type: 'boolean', required: true, description: '恢复输出已移交同事侧的三条几何规则（OVERLAP/BASELINE_MISMATCH/AREA_CONTENT_TEXT_OVERLAP）；默认 false 静默' },
      },
      output: {
        // dsh value-schema DSL 约束：不支持 required；object 必须显式 additionalProperties。输出契约在 execute 内自行保证
        schema: { type: 'object', additionalProperties: true },
        render: (_args, value) => {
          const s = value.summary
          const lines = [`${value.qid} findings=${s.total} (P0=${s.p0} P1=${s.p1} P2=${s.p2})`]
          for (const f of value.findings ?? []) {
            const loc = f.dsl_id ? ` @${f.dsl_id}` : ''
            lines.push(`  [${f.layer}] ${f.severity} ${f.rule_id}: ${f.message}${loc}`)
            if (f.fix_hint) lines.push(`      fix: ${f.fix_hint}`)
          }
          return [{ type: 'text', text: lines.join('\n') }]
        },
      },
      timeoutMs: 120_000,
      async execute(args, exec) {
        const { target, layout } = args
        if (!target || !target.trim()) {
          throw new Error('参数错误：target 不能为空。传 DSL jsonl 路径（绝对路径或相对当前目录）、三件套目录路径或数据集 case id。')
        }
        const extra = []
        if (args.include_delegated) extra.push('--include-delegated')
        const { code, stdout, stderr } = await spawnCheck(['scripts/check_card.py', '--format', 'json'], target, layout || '', extra, exec?.signal)
        // 退出码契约（WP-E3）：0/1=正常检出（JSON 可解析）；2=核心自身故障
        if (code !== 0 && code !== 1) {
          throw new Error(`design_check 执行失败（${target}，退出码 ${code}——检查器自身故障口径）：${failDetail(stderr)}`)
        }
        let parsed
        try {
          parsed = JSON.parse(stdout)
        } catch {
          throw new Error(`design_check 输出解析失败（${target}）：stdout 前 200 字符 = ${stdout.slice(0, 200)}`)
        }
        return parseFindings(parsed)
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'design_check_batch',
      description:
        '批量设计检查管线（design_check 的批量入口；check_case.py 一键 a→i：归一化三件套 → 渲染+dump → L1/L2 检查 → 线框 → 问题清单 JSON + 可视化 HTML 报告）。' +
        'cases=混合语法逗号分隔："A:q42,B:q6,MS:q59,SET93:q010,DSL:/path/x.jsonl"（分支前缀 A/B/C/MS 走评测集，SET93 走 93 条数据集，DSL 为任意裸 DSL 路径）。' +
        '需要本地模拟器/设备（PIPELINE_DIR 外层渲染管线）；--reuse-dump 复用既有 dump 时离线可跑。' +
        '返回报告产物路径与摘要；失败卡记录后跳过不拖垮整批。',
      parameters: {
        cases: { type: 'string', required: true, description: '混合语法批量入口（如 "A:q42,B:q6,SET93:q010,DSL:/path/x.jsonl"）' },
        reuse_dump: { type: 'boolean', required: true, description: '已有 dump（本管线产物或数据集 render-evidence）则跳过设备采集（离线复检用）；默认 false' },
        include_delegated: { type: 'boolean', required: true, description: '恢复三条已移交同事侧几何规则的输出；默认 false 静默' },
      },
      output: {
        schema: { type: 'object', additionalProperties: true },
        render: (_args, value) => {
          const lines = [`batch exit=${value.exit_code} failures=${value.failures ?? 0}`]
          for (const a of value.artifacts ?? []) lines.push(`  ${a.kind}: ${a.path}`)
          for (const f of value.failure_details ?? []) lines.push(`  [fail] ${f}`)
          return [{ type: 'text', text: lines.join('\n') }]
        },
      },
      timeoutMs: 600_000,
      async execute(args, exec) {
        const { cases } = args
        if (!cases || !cases.trim()) {
          throw new Error('参数错误：cases 不能为空。混合语法如 "A:q42,B:q6,SET93:q010,DSL:/path/x.jsonl"。')
        }
        const extra = []
        if (args.reuse_dump) extra.push('--reuse-dump')
        if (args.include_delegated) extra.push('--include-delegated')
        const script = path.join(CORE_DIR, 'scripts', 'check_case.py')
        const { code, stdout, stderr } = await runPython([script, '--cases', cases.trim(), ...extra], exec?.signal)
        // check_case 契约：0=全成功 / 1=部分失败（报告含成功卡）/ 2=管线自身故障
        if (code === 2) {
          throw new Error(`design_check_batch 执行失败（${cases}，退出码 2——管线自身故障口径）：${failDetail(stderr)}`)
        }
        // 从五段式终端输出提取报告产物路径（「问题清单 JSON / 可视化 HTML / dump 真值」等行）
        const artifacts = []
        for (const m of stdout.matchAll(/^\s+-\s+(问题清单 JSON|可视化 HTML):\s*(\S+)\s*$/gm)) {
          artifacts.push({ kind: m[1], path: m[2] })
        }
        const failureDetails = [...stderr.matchAll(/^\s+-\s+(\S[^:\n]*:\s.*)$/gm)].map((m) => m[1].trim())
        return {
          cases: cases.trim(),
          exit_code: code,
          artifacts,
          failures: failureDetails.length,
          failure_details: failureDetails,
          note: '详细结果见 artifacts 指向的问题清单 JSON 与可视化 HTML。',
        }
      },
    }),
  )
}

/** 统一 spawn python3（cwd=CORE_DIR，捕获 stdout/stderr，透传 abort 信号）。 */
function runPython(argv, signal) {
  return new Promise((resolve, reject) => {
    const child = spawn('python3', argv, { cwd: CORE_DIR, signal })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', (d) => { stdout += d })
    child.stderr.on('data', (d) => { stderr += d })
    child.on('error', reject)
    child.on('close', (code) => resolve({ code: code ?? -1, stdout, stderr }))
  })
}

/**
 * design_check 专用：先按分流静态参数拼装，再交 runPython 执行。
 * （保留独立函数便于 verify_tool/测试按需替换入口逻辑。）
 */
function spawnCheck(baseArgv, target, layout, extra, signal) {
  const argv = [...baseArgv]
  const route = routeTarget(target)
  if (route.mode === 'dir') argv.push('--dir', route.value)
  else if (route.mode === 'qdir') argv.push('--qdir', route.value)
  else argv.push('--dsl', route.value)
  if (layout && layout.trim()) argv.push('--layout', resolveInput(layout))
  argv.push(...extra)
  return runPython(argv, signal)
}

