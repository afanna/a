# Semantic Review Prompt（L3 · 语义评审）

> 输入：query + task-spec + DSL + L1/L2 诊断（文本，不读裸布局）。

依据金标准正文规则（2×2 卡 → `DESIGN.md`；2×4 卡 → `DESIGN-2x4.md`）：
- 信息取舍 retainTest：是否只保留"任务所需 + 即时价值"信息；
- 主信息唯一：核心指标是否唯一、不冗余表达；
- 场景-渐变语义精确匹配：query 场景与 background_gradients 预设对应；
- 冗余表达：同一指标是否被状态胶囊 + 大数字 + 辅助行多处重复。

输出：严格 JSON schema：
```json
{
  "qid": "q010",
  "layer": "L3",
  "findings": [
    {
      "rule_id": "SEMANTIC.REDUNDANT_SIGNAL",
      "severity": "P2",
      "evidence_type": "模型推断",
      "element": {"dsl_id": "text2"},
      "expected": "单一主信号 + 必要辅助",
      "actual": "状态胶囊+大数字+辅助行重复",
      "fix_hint": "按 DESIGN.md content_pruning 收敛"
    }
  ]
}
```
规则：不评判 DESIGN.md 本身；不下最终设计结论。
