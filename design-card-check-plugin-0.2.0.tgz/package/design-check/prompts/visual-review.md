# Visual Review Prompt（L2c · 视觉格式塔评审）

> 输入（由程序层准备，不得让模型读裸 DSL 或做像素测量）：
> 1. 线框叠加图 `wireframe/<qid>.png`（bounds 已由 dump 真值绘制，天然注释化截图）；
> 2. L2a 几何诊断 JSON（本层只做判断与解释，数值证据全部来自程序层）；
> 3. 卡片 query 与 DSL 摘要（可选）。

检查维度：
- 对齐锚点（三类：左上 content-area / 底部 / 中心）是否与规范一致（2×2 卡对 DESIGN.md；2×4 卡对 DESIGN-2x4.md）；
- 溢出 / 重叠 / 极端留白；
- 对比度：直接引用 L1/L2 程序实测值（不自行目测）；
- 视觉层级：主数值是否唯一、装饰是否抢主信号。

输出：严格 JSON schema 约束的 findings：
```json
{
  "qid": "q010",
  "layer": "L2c",
  "findings": [
    {
      "rule_id": "VISUAL.HIERARCHY",
      "severity": "P1|P2",
      "evidence_type": "模型推断",
      "element": {"dsl_id": "heroIcon"},
      "expected": "主数值视觉占优",
      "actual": "装饰图标面积大于主数值",
      "fix_hint": "..."
    }
  ]
}
```
规则：
- 只给出格式塔/层级判断；一切数值（对比度、尺寸、间距）禁止自行测量，引用程序层证据；
- 不代表程序层重复测量；无把握的项标注 "需端侧确认"。
