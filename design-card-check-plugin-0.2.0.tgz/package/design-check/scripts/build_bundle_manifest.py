#!/usr/bin/env python3
"""bundle 打包指纹 manifest 生成器（docs/plan-dsh-bundle-distribution.md Phase P0）。

对随包分发的内容物取 sha256，连同工具链版本记入 ``review/bundle-manifest-<version>.json``，
使任一 tarball 快照可追溯到打包时的工作区状态（验收标准 A5）。

用法（在 design-check/ 目录内）：
    python3 scripts/build_bundle_manifest.py [--tarball <tgz 路径>]

产物：``<Design-guide>/review/bundle-manifest-<version>.json``（review/ 不入库）。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent            # design-check/
GUIDE_DIR = PROJECT_DIR.parent             # Design-guide/ = npm 包根


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def tool_version(argv: list[str]) -> str:
    try:
        out = subprocess.run(argv, capture_output=True, text=True, timeout=15)
        return (out.stdout or out.stderr).strip().splitlines()[0]
    except Exception as exc:  # noqa: BLE001 - 版本采集失败不阻断指纹生成
        return f"<unavailable: {exc}>"


def in_box_version(name: str) -> str:
    dsh_home = Path(os.environ.get("DSH_HOME", Path.home() / ".dsh"))
    pkg = dsh_home / "profiles" / "node_modules" / "@deepseek-ai" / name / "package.json"
    if not pkg.is_file():
        return "<not-found>"
    return json.loads(pkg.read_text(encoding="utf-8")).get("version", "<unknown>")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tarball", type=Path, default=None,
                        help="pnpm pack 产出的 tarball（可选，记录其 sha256/大小/文件数）")
    args = parser.parse_args()

    pkg_json = GUIDE_DIR / "package.json"
    if not pkg_json.is_file():
        print(f"错误: 找不到包清单 {pkg_json}", file=sys.stderr)
        return 1
    version = json.loads(pkg_json.read_text(encoding="utf-8")).get("version", "0.0.0")

    targets = {
        "DESIGN.md": GUIDE_DIR / "DESIGN.md",
        "DESIGN-2x4.md": GUIDE_DIR / "DESIGN-2x4.md",
        "plugin/src/index.mjs": PROJECT_DIR / "plugin" / "src" / "index.mjs",
        "package.json": pkg_json,
        "cordis.patch.yml": GUIDE_DIR / "cordis.patch.yml",
    }
    fingerprints: dict[str, str | None] = {}
    for label, path in targets.items():
        fingerprints[label] = sha256_of(path) if path.is_file() else None

    manifest: dict = {
        "schema": "design-check/bundle-manifest/v1",
        "package": json.loads(pkg_json.read_text(encoding="utf-8"))["name"],
        "version": version,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "toolchain": {
            "dsh": tool_version(["dsh", "--version"]),
            "node": tool_version(["node", "--version"]),
            "pnpm": tool_version(["pnpm", "--version"]),
            "python": sys.version.split()[0],
            "in_box": {
                "@deepseek-ai/cordis": in_box_version("cordis"),
                "@deepseek-ai/dsh-tools": in_box_version("dsh-tools"),
            },
        },
        "sha256": fingerprints,
    }

    if args.tarball is not None:
        tgz = args.tarball
        if not tgz.is_file():
            print(f"错误: tarball 不存在 {tgz}", file=sys.stderr)
            return 1
        import tarfile
        with tarfile.open(tgz, "r:gz") as tf:
            names = tf.getnames()
        manifest["tarball"] = {
            "name": tgz.name,
            "bytes": tgz.stat().st_size,
            "file_count": len(names),
            "sha256": sha256_of(tgz),
        }

    out_dir = GUIDE_DIR / "review"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"bundle-manifest-{version}.json"
    out.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"manifest 写入: {out}")
    for label, digest in fingerprints.items():
        print(f"  {label}: {digest or '<missing>'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
