#!/usr/bin/env python3
"""从 DESIGN.md 派生 DESIGN-2x4.md（2×4 检验金标准）。

⚠️ 已过时（2026-08-22）：DESIGN-2x4.md 的布局契约（layout_slots、正文 Layout 章节、
capsule/title bar/列表行高等几何）已改为以 Pixso「布局抽象」（item-id 60:280）为
唯一权威的人工定稿，本地快照见 Design-guide/docs/pixso-layout-abstraction.md。
本脚本的布局替换字面量仍为旧「固定骨架路由」体系（132+12+152 / 190+12+86 等已废止），
直接重跑会覆盖人工定稿。如需恢复派生流程，必须先把本脚本的 layout 相关字面量
同步为标准 Layout 组合规则后再运行。

元素部分（色板/渐变/字体/图标/圆角 token/辅助信息区域）保留；
布局部分（layout_slots、density、component_contracts 尺寸键、正文 Layout 章节）
重写为 2×4 专用契约，依据 few_shot/PROMPT24.md 第八/九节与金标集实测几何。
原 DESIGN.md 不修改。
"""
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent.parent / "DESIGN.md"
DST = Path(__file__).resolve().parent.parent.parent / "DESIGN-2x4.md"

lines = SRC.read_text(encoding="utf-8").splitlines()


def find_line(prefix, start=0):
    hits = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    if not hits:
        sys.exit(f"marker not found: {prefix!r}")
    return hits


def replace_span(start_prefix, end_prefix, new_text, include_end=False):
    """把 [start_prefix 行, end_prefix 行) 的内容替换为 new_text。"""
    global lines
    s = find_line(start_prefix)[0]
    e_candidates = [i for i in find_line(end_prefix) if i > s]
    if not e_candidates:
        sys.exit(f"end marker not found after {start_prefix!r}: {end_prefix!r}")
    e = e_candidates[0] + (1 if include_end else 0)
    lines[s:e] = new_text.strip("\n").split("\n")


def replace_line(prefix, new_text):
    global lines
    hits = find_line(prefix)
    if len(hits) != 1:
        sys.exit(f"expected 1 hit for {prefix!r}, got {len(hits)}")
    lines[hits[0]] = new_text


# ---------- frontmatter ----------

replace_line(
    "description: HarmonyOS 桌面 widget 服务卡片(",
    "description: HarmonyOS 桌面 widget 服务卡片 2×4（320×160vp 宽卡）的设计系统——一眼扫读、"
    "一个主信息组至多一个辅助信息组、浅层任务入口；本文件是 2×4 产物的检验金标准，"
    "布局契约以固定骨架路由为准，2×2 的检验仍以 DESIGN.md 为准。",
)

replace_line(
    "  # Metric tier — 40 / 32; reserved for the single hero metric in 2×2 cards",
    "  # Metric tier — 40 / 32；40vp 用于全卡唯一绝对主数值，32vp 用于双值或较长主数值（2×4 主数值常规 20-32vp）",
)

replace_span("  sizes:", "  svgClassification:", """
  sizes:
    title-leading-icon-leading: 12vp
    title-icon-trailing-2x4: 24vp
    ring-unit-center-icon: 24vp
    hero-visual: 56vp
""")

replace_span("layout_slots:", "layout_constraints:", """
layout_slots:
  canvas:
    "2x4":
      width: 320vp
      height: 160vp
      root:
        component: Stack
        width: 320
        height: 160
        borderRadius: 20
        clip: true
        background: linearGradient-required
        linearGradientAngleDefault: 180
      contentRoot:
        component: "Column | Row"
        size: matchParent
        paddingAllowed: [12, 16]
        paddingSelection: "信息较多用 12；大留白展示用 16；禁止 14/18/20"
      safeArea:
        padding12: { width: 296vp, height: 136vp }
        padding16: { width: 288vp, height: 128vp }
      layoutMode: fixed-skeleton-routing
  skeletonRouting:
    select: exactly-one-skeleton-per-card
    forbidden: [invent-new-layouts, cross-skeleton-region-splicing, add-regions-for-candidates]
    decisionOrder:
      - "判断信息关系（日程/待办/占比/进度/并列/序列/强状态/操作）"
      - "mustKeep 字段能否全部映射到骨架槽位"
      - "选择结构最简单的可用骨架；承载不下时先删 shouldKeep"
  horizontalClosure:
    padding12-safe-width-296:
      - "144 + 8 + 144 = 296（两等分）"
      - "132 + 12 + 152 = 296（主信息 + 双操作组）"
    padding16-safe-width-288:
      - "112 + 16 + 160 = 288（大环 + 说明）"
      - "190 + 12 + 86 = 288（主信息 + 右侧双条目，保留 8vp 余量）"
    rowRule: "左右 padding + 子项宽度之和 + itemMargin 之和 <= 父宽度"
  verticalClosure:
    padding12-safe-height-136:
      - "title 24 + gap 8 + content 104 = 136（无 action）"
      - "title 20 + gap 6 + weather 48 + gap 6 + todo 56 = 136"
    withBottomAction:
      - "title 24 + gap 4 + content 64 + gap 4 + action 32 = 128（底部保留 8vp 呼吸空间）"
    columnRule: "子项高度之和 + itemMargin × (子项数 - 1) <= 安全内容高度；公式逐层适用，父容器 padding 计入"
    expandedRealHeights: { progressUnit-plain: 36vp, progressUnit-numeric-single: 48vp, progressUnit-numeric-single-caption: 74vp }
  titleRow:
    height: 24vp
    titleText: { fontSize: 12fp, fontWeight: 700, maxLines: 1 }
    withIcon: { iconSize: "24x24vp", titleTextWidth: 240vp, isolationMin: 8vp }
  skeletons:
    meeting-timeline:
      aka: single-event
      fits: "日程、会议、提醒"
      structure: "content_root Column padding 16 itemMargin 8 > title_area Row + content_area Row(TimelineUnit + event_texts Column) + action_area Column 可选"
      gaps: { titleToContent: 8vp, contentToAction: 4vp }
      timeline: { width: 16vp, textColumnItemMargin: 10vp, singleEventHeight: "64-72vp", twoEventsPerItem: 46vp, eventsMax: 2 }
      eventTexts: "右侧文字列最多三行（事件名/时间/地点），三行父高度 >= 72vp；事件标题 <= 20fp，时间/地点 14-16fp"
    todo-list:
      fits: "待办事项、任务清单"
      structure: "content_root Column padding 12 itemMargin 8 > title_area Row + todo_list Column"
      item: { height: 32vp, rounded: 8vp, background: light-gray, check: circle-placeholder, text: "single-line 14fp" }
      itemsMax: 3
      requiresFullSafeWidth: true
    event-with-action:
      fits: "下一日程、会议、操作入口"
      structure: "content_root Column padding 16 itemMargin 4 > title_area Row + content_area Column(64) + action_area Column(136x32) > ActionUnit capsule"
      contentAreaHeight: { threeLines: "64vp (24+4+16+4+16)", oneToTwoLines: "48-56vp" }
      capsulePlacement: "底部安全区内靠左或靠右，不拉满 320vp 宽"
    large-ring:
      fits: "内存占用、睡眠评分、百分比总览"
      structure: "content_root Row padding 16 itemMargin 16 > visual_area Column(112, RingUnit 92) + info_area Column(160x128, itemMargin 4)"
      ringBelowTextMax: 1
      infoWithActionClosure: "title 20 + 4 + main 30 + 4 + quality 18 + 4 + status 16 + 4 + action 32 = 132"
      noRepeat: "环内读数不得在右侧重复；睡眠卡在环内评分与环内时长中二选一"
    strong-focus:
      fits: "运动倒计时、省电状态、睡眠状态等强情绪卡"
      structure: "content_root Row padding 12 itemMargin 12 > focus_area Column(132) + info_panel Column(152x112)"
      strongBackground: "右侧 15%-20% 白色透明背板，文字白色；主数字/进度/说明左右分区"
      lightPanel: "浅色卡右侧用主题色 panel（rounded 12、padding 12）；有真实比例时 panel 内加 8vp ProgressUnit"
    split-two-column:
      fits: "左侧日期或主信息 + 右侧两个日程/状态块"
      structure: "content_root Row padding 12 itemMargin 12 > left_col Column(190) + right_col Column(86)"
      rightCards: { count: 2, width: 86vp, height: "48 或 56vp", rounded: 12vp, style: same-color-size-structure }
      card48Inner: "padding 6 + label 14 + gap 2 + value_row 20 = 36"
      unitRule: "动态值与 %/°C 等单位放同一 Row，单位不得作为第三行 Text"
      rightColumnConstraint: "86vp 右栏只放无按钮短指标，禁止 ActionUnit；需按钮或三行文字改 132 + 12 + 152 宽分栏"
      weatherPlusAgenda: "天气 + 日程优先标题下方两个 140/144vp 并列面板，不纵向堆窄条"
    primary-action-pair:
      fits: "智能家居、导航、同一服务对象下两个并列操作"
      structure: "content_root Row padding 12 itemMargin 12 > primary_panel Column(132) + action_group Row(152, itemMargin 8) > 2 x ActionUnit tile(72x112)"
      requires: "左侧主状态或主读数；右侧两操作同一服务对象、均有真实事件与匹配图标"
      fallback: "不足两个真实事件时改 split-two-column 或单个 capsule，禁止伪造操作"
    linear-progress:
      fits: "应用时长、今日进度、防沉迷"
      structure: "content_root Column padding 12 itemMargin 8 > title_area Row(24) + content_area Column(104, itemMargin 8) > ProgressUnit(numeric-single, 48) + detail_row Row(48, 2 x 144 卡)"
      barOnlyClosure: "content 96 = bar 8 + 12 + row 32 + 12 + row 32；配合 title 24 + 8 + content 96 = 128"
      detailRule: "两个对比值用进度条下方两个同色背板；只有一个补充事实用单行 detail_area"
    metric-series:
      fits: "三个城市天气、三个同构设备状态、三个短指标"
      structure: "content_root Column padding 12 itemMargin 8 > title_area Row + metrics_row Row(296, itemMargin 8)"
      itemWidths: { twoItems: "144 + 8 + 144", threeItems: "93 + 8 + 93 + 8 + 93 = 295" }
      itemContract: "严格同构、同一种主题色 panel；每项最多图标 + 主值 + 短标签三层"
    quad-rings:
      fits: "四个设备电量、四个同类占比"
      structure: "content_root Column padding 12 itemMargin 10 > title_text + grid Column > grid_row x 2"
      card: { size: "144x48", ring: "RingUnit size 40", countMax: 4 }
    four-action-hub:
      eligibility: "用户逐项明确要求同一服务对象下 3-4 个同层级快捷操作（系统设置、音乐控制等）"
      structure: "content_root Column > title_text(12fp/700) + action_row Row(itemMargin 12) > 3-4 x ActionUnit tile(64x112)"
      actionRequirements: "精确 eventCandidate + 2-4 字短标签 + 可见 icon；副作用动作必须用户逐项明确要求"
      forbidden: [data-display, mixed-service-objects, fabricated-buttons, more-than-four-actions]
    info-device-card:
      aka: "信息卡/设备卡变体"
      fits: "设置、蓝牙、网络、系统入口等无真实数值主指标的卡"
      structure: "小标题 + 1-2 个浅色信息面板 + capsule"
      forbidden: "把「点击查看」「当前设置项」「调整设置」「选项」作为 30 号以上主标题"
  fullWidthSingleColumnAllowed: [meeting-timeline, todo-list, event-with-action, linear-progress]
  fullWidthRequirement: "全宽单列骨架的主内容或背板必须使用完整 288/296vp 安全宽度，不得挤在左半边"
  rightRegionRule: "其它骨架优先左右分区，右区放真实辅助信息；没有真实信息时不编造右区"
  bottomActionArea:
    height: 32vp
    carrier: "ActionUnit capsule"
    placement: "content_root 独立末尾子项；卡片底部安全区内，不贴圆角边缘、不被裁切"
    preferredClosure: "title 24 + content 64 + action 32，两处间距 4vp"
    contentAreaHeight: { oneToTwoLines: "48-56vp", threeLines: 64vp }
    forbidden: "自写 36 以上高度；塞进已塞满指标的信息 Column"
  sidebarCapsule:
    widthRange: "88-136vp"
    narrowRule: "侧栏内部安全宽度 < 88vp 时改用 132/152vp 分栏，禁止塞进 86vp 带 padding 小卡"
""")

replace_span("density:", "interaction:", """
density:
  "2x4":
    factsMax: 4
    eventsMax: 2
    todoItemsMax: 3
    metricSeriesItems: "2-3"
    seriesItemsMax: 5
    quadRingCardsMax: 4
    explicitActionsDefaultMax: 2
    explicitActionsHubMax: 4
    visibleListRowsMax: 3
    visibleListRowsMaxWithChart: 2
""")

replace_span("  numericPolicy:", "browser_preview_shell:", """
  numericPolicy:
    maxPrimaryNumbers: 1
    seriesItemValuesAllowed: true
    seriesItemValuesNote: "同构序列（2-5 项）与四对比环每项可各自携带一个数值，不计入主数值上限"
    factsMax: 4
    omitIfNotNeededForAction: true
    preferThresholdStateOverExactDelta: true
    oneNumberIsACeilingNotATarget: true
""")

replace_span("  fixedSlots:", "  requiredAttributes:", """
  fixedSlots:
    "2x4": { x: 256px, y: 48px, width: 320px, height: 160px }
""")

# component_contracts: list / action / progress
replace_span("  list:", "  snapshot:", """
  list:
    maxRowsBySize:
      "2x4": 3
    maxRowsWithChart:
      "2x4": 2
  action:
    explicitActionsBySize:
      "2x4": 2
    hubException:
      fourActionHub: "3-4 个由用户逐项明确要求、同一服务对象、同层级的快捷操作"
    carrier: "ActionUnit（state: capsule | tile），禁止基础 Button"
    actionGroupBySize:
      "2x4":
        arrangement:
          - single-capsule
          - two-tiles-horizontal
          - hub-row-3-4-tiles
    requiresClearLabelOrSymbol: true
    geometry:
      capsule: { height: 32vp, width: "88-136vp", radius: half-of-height, widthAdaptedByConverter: true }
      tile: { width: "64-80vp", height: "80-112vp", iconRequired: true }
      minimumVisualSize: 24
      minimumHotZone: 40
      unit: vp
      radiusRule: capsule-takes-half-height
    visualStyle:
      allowed:
        - ordinary-filled
      emphasizedAllowed: false
      useDirectTokenColorAssembly: true
      allowedShapes:
        - capsule
        - tile
  progress:
    allowedKinds:
      - ring
      - linear
    carriers: "RingUnit | ProgressUnit；禁止手写基础 Progress"
    ringUnit:
      allowedSizes: [40, 44, 52, 80, 92, 98]
      states: [center-text, center-icon, center-icon-below-text]
      semanticColors: [green, blue, orange, red]
      forbiddenColors: [purple]
      reading: "仅在需要显示环心或环下文字时使用"
      centerIcon: "必须来自 assetCandidates"
    progressUnit:
      states: [bar, numeric-single, numeric-single-caption, plain]
      requiresValueAndTotal: true
      captionMaxLines: 1
      expandedRealHeights: { plain: 36vp, numeric-single: 48vp, numeric-single-caption: 74vp }
    stateSelectionByDetail:
      noDetail: numeric-single-caption
      oneToTwoDetailLines: "numeric-single，且不再生成 caption"
    quadRingsNote: "quad-rings 骨架使用 4 个 40vp 对比环，不属单主焦点环"
""")

# components: 替换 4 个 2×2 系按钮为 ActionUnit 契约
replace_span("  button-primary:", "  card-root:", """
  action-unit-capsule:
    carrier: "ActionUnit state capsule"
    label: "必填短文案，优先 2-4 字，不超过 6 字"
    onClick: "必填，call/args 逐字段复用 eventCandidates；动态参数用 {path}"
    height: 32vp
    width: "88-136vp（由转换器按父容器适配）"
    rounded: "高度一半（32vp 高 → 16vp）"
    typography: "{typography.body-m-regular}"
    typographyFallback: "{typography.body-s-regular}"
    fallbackWhen: "text-length > 6"
    lightOverlayPair: "场景主色 10% 底（actionSurface）+ 100% 前景（actionInk）"
    strongBackgroundOverride: { actionInk: "#FFFFFFFF", actionSurface: "#33FFFFFF" }
    forbiddenProps: [width, height, padding, borderRadius, backgroundColor, fontColor]
    forbiddenPropsNote: "尺寸与颜色配对由转换器落地，产物侧不得手写"
  action-unit-tile:
    carrier: "ActionUnit state tile"
    width: "64-80vp"
    height: "80-112vp"
    icon: "必填，来自 assetCandidates"
    label: "2-4 字短标签"
    converterGenerates: "同色背板 + 上图标 + 下标签"
    children: forbidden
""")

replace_line(
    '    padding: "{spacing.safe-margin}"',
    '    padding: "12vp 或 16vp（由 content_root 承载：信息较多用 12，大留白展示用 16）"',
)

replace_span("  list-row:", "  progress-ring-label:", """
  list-row:
    typography: "{typography.body-m-regular}"
    height: 32vp
    padding: 10vp 12vp
    rounded: "{rounded.corner_radius_level4}"
    background: "{colors.comp_background_tertiary}"
""")

# ---------- body ----------

replace_line(
    "本系统描述 **HarmonyOS 桌面 widget 服务卡片** 的视觉身份",
    "本系统描述 **HarmonyOS 桌面 widget 服务卡片 `2×4`（320×160vp 宽卡）** 的视觉身份——可一眼扫读的横向桌面表面,"
    "承载**一条核心信息**（一个主信息组，至多一个辅助信息组），并**默认单一主操作；仅当次操作有独立且即时的用户目标时才附带**。"
    "品牌基调是**冷静、技术感、确定**:受控的场景渐变托起一个高对比的数据点,再用唯一一抹饱和强调色告诉用户\"该做什么\"。"
    "本文件是 2×4 产物的检验金标准;`2×2` 的检验以 `DESIGN.md` 为准。",
)

replace_line(
    "字体系统建立在单一字体族",
    "字体系统建立在单一字体族 **HarmonyOS Sans SC** 上,通过字号与字重两个维度表达层级。"
    "除 5 类基础文字角色外，`metric-primary-with-support`(32vp) 与 `metric-primary`(40vp) 是主数值的专用语义 token——"
    "2×4 主数值常规使用 20-32vp，40vp 仅用于全卡唯一的绝对主数值；每级各司其职。刻意避免混用字重与装饰性变体。",
)

replace_line(
    "- **单一数据点**:",
    "- **单一数据点**:2×4 主数值默认 20-32vp（`title-s`–`metric-primary-with-support`）；"
    "仅当它是全卡唯一绝对主数值且无下方辅助信息时才可用 `metric-primary`(40vp / 700)。"
    "单位与辅助信息拆分为独立 Text，使用 12-16vp；schema 只提供带单位字符串（如 `durationText:\"25分钟\"`）时不得用 30vp 以上大字展示",
)

# 正文 Layout 大章重写
replace_span("## Layout & Spacing", "## Elevation & Depth", """
## Layout & Spacing

本系统采用**固定画布 + 闭合数值预算 + 固定骨架路由**，而非流式栅格。`2×4` 逻辑画布恒为 `320×160vp`，由宿主运行时提供；卡片永不硬编码自身的外部尺寸，也不得假设可滚动、可分页或可扩展高度。桌面 widget 由宿主桌面承载和裁切；浏览器预览壳只用于模拟宿主环境。

### 画布与根容器

- `root` 必须是 `Stack`：`width: 320`、`height: 160`、`borderRadius: 20`、`clip: true`，且必须提供 `linearGradient`（`angle` 默认 180，自上而下）。不要写 `constraintSize`，转换器会自动补。
- `root` 的唯一子节点是 `content_root`（`Column` 或 `Row`，`matchParent` 撑满画布）。
- `content_root` 的 `padding` 只能是 `12` 或 `16`：信息较多用 `12`，大留白展示用 `16`；禁止 `14`、`18`、`20`。
- 由此得到两档安全内容区：`padding 12 → 296×136vp`，`padding 16 → 288×128vp`。一切内容、背板与按钮都必须完整落在安全内容区和 160vp 卡面内，不能依赖 `root.clip` 把溢出内容裁掉。

### 数值闭合预算

先按 padding 算出安全内容宽度，再选择闭合骨架。**2×4 不是加宽的 2×2**。

横向闭合式（示例）：

```text
padding 12（安全宽 296）：两等分 144 + 8 + 144 = 296；主信息 + 双操作组 132 + 12 + 152 = 296
padding 16（安全宽 288）：大环 + 说明 112 + 16 + 160 = 288；主信息 + 右侧双条目 190 + 12 + 86 = 288，保留 8vp 余量
```

纵向闭合式（示例）：

```text
无 action：title 24 + gap 8 + content 104 = 136
天气 + 底部准备项：title 20 + gap 6 + weather 48 + gap 6 + todo 56 = 136
底部 action：title 24 + gap 4 + content 64 + gap 4 + action 32 = 128，底部保留 8vp 呼吸空间
```

禁止生成 `title 20 + weather 48 + todo 72 + 两个 8vp gap = 156` 这类超过 136vp 的组合。闭合公式对**每一层**容器都适用，不只检查 `content_root`；父容器的 padding 必须计入：

```text
Column 实占高度 = top padding + bottom padding + 子项高度之和 + itemMargin × (子项数 - 1)
Row 实占高度 = top padding + bottom padding + 最高子项高度
任何 Row：左右 padding + 子项宽度之和 + itemMargin 之和 <= 父宽度
```

例如 `height:48, padding:8` 的小卡只有 32vp 内部高度，不能再竖放 `16 + 22 + 16` 三行文字；`height:32` 的 Row 也包不住实际 36vp 的两行 Column。声明较小的父高度不会自动缩小子项，只会重叠或裁切。高级组件展开后的真实高度同样计入父容器：`ProgressUnit plain` 36vp、`numeric-single` 48vp、`numeric-single-caption` 74vp。

标题行带 `24×24` 图标时，296vp 标题行推荐 `title_text width: 240` + 图标 24，至少保留 8vp 隔离空间；标题文字不得延伸到图标下方。内容指标列的子 Text 宽度不得大于父列宽度（父列 54vp 时子 Text 至多 54vp）。

浏览器 HTML 预览遵循 `browser_preview_shell` 的 `design-card-html-v1` 契约：`preview-slot[data-size=\"2x4\"]` 绝对定位在 stage 的 `(256px, 48px)`，`widget` 固定 `320×160px`，卡片相对整个文档的左上角坐标恒为 `(256px, 104px)`。主题切换、内容长度不得改变 slot 坐标；窄 viewport 允许滚动，不得通过 `transform: scale(...)`、`zoom` 或响应式重排移动、缩放卡片。

**预览壳 caption 禁令**：产物中不得输出任何 shell-level caption 节点（如 `.caption`）。尺寸、尺寸别名和点击行为的说明只能保留在 toolbar 区域（`.toolbar` 内），不得作为独立节点输出到 stage 或 slot 中。

统一的间距刻度（`xxs 2 / xs 4 / sm 6 / md 8 / lg 12 / xl 16 / xxl 24`）统御纵横向节奏；布局中的 gap/itemMargin 优先使用 `4、8、12、16`，组间距必须大于或等于组内距，不无理由交替使用多个相近间距。

### 固定骨架路由

每张卡必须且只能选择一个固定骨架。骨架规定一级 region 的几何关系、角色容量和动作上限；允许在声明范围内微调子组件对齐、字号、颜色和局部高度，不得跨骨架拼接 region，不得为了使用候选而新增一级区域，也不得自由发明复杂布局。

路由顺序：先判断信息关系（日程/待办/占比/进度/并列/序列/强状态/操作）→ 检查 `mustKeep` 字段能否全部映射到骨架槽位 → 选择结构最简单的可用骨架。没有骨架能承载时，先删除 `shouldKeep`，不自由发明页面。

#### 1. `meeting-timeline` / `single-event`

适合：日程、会议、提醒。

结构：`content_root Column padding 16 itemMargin 8 > title_area Row + content_area Row(TimelineUnit + event_texts Column) + action_area Column 可选`。

- title：小标题 + 日期/图标。
- content：左侧 `TimelineUnit`（宽 16，与右侧文字列 `itemMargin 10`），右侧事件标题 + 时间 + 地点/会议室，最多三行，三行父高度至少 72。
- `TimelineUnit` 高度按右侧文字组高度写：单条事件 64-72，两条事件每条 46；日程/会议类最多展示两条，不塞第三条导致裁切。
- 标题区到内容区固定 8vp；有底部按钮时内容区到 action 区用 4vp。
- 事件标题不超过 20fp；时间/地点用 14-16fp，避免把会议名或地点放成超大字。
- 没有操作时不生成按钮；有操作时按钮放独立 `action_area`，不挤进 timeline 行。

#### 2. `todo-list`

适合：待办事项、任务清单。

结构：`content_root Column padding 12 itemMargin 8 > title_area Row + todo_list Column > todo_item × 3`。

每个 item：高 32、圆角 8、浅灰背景、左侧圆形 check 占位、右侧单行 14fp 文字。至多 3 项。

#### 3. `event-with-action`

适合：下一日程、会议、操作入口。

结构：`content_root Column padding 16 itemMargin 4 > title_area Row + content_area Column(height 64) + action_area Column(width 136, height 32) > ActionUnit capsule`。

- `content_area` 三行时用 `24 + 4 + 16 + 4 + 16 = 64`；只有一至两行才允许 48-56。
- 按钮靠左或靠右都可以，但必须固定在底部安全区内，不拉满 320vp 宽卡。

#### 4. `large-ring`

适合：内存占用、睡眠评分、百分比总览。

结构：`content_root Row padding 16 itemMargin 16 > visual_area Column(width 112, RingUnit size 92) + info_area Column(width 160, height 128, itemMargin 4)`。

- 左侧大环下方最多保留一行说明，不能同时堆「预计可用」和「低于 20% 提醒」。
- 右侧如带 action，使用闭合式 `title 20 + gap 4 + main 30 + gap 4 + quality 18 + gap 4 + status 16 + gap 4 + action 32 = 132`（padding 12 时右列可用 136vp）。
- 环内读数不能再在右侧重复；睡眠卡在「环内评分」与「环内时长」中二选一。

#### 5. `strong-focus`

适合：运动倒计时、省电状态、睡眠状态等强情绪卡。

结构：`content_root Row padding 12 itemMargin 12 > focus_area Column(width 132) + info_panel Column(width 152, height 112)`。

- 强背景可以不用面板；需要说明文字时，右侧使用 15%-20% 白色透明背板，文字用白色。
- 主数字、进度和说明形成清晰的左右分区，不把所有文字堆成左对齐通栏。
- 浅色 `strong-focus` 的右侧必须使用当前主题色包的 `panel`（`borderRadius: 12`、`padding: 12`）；训练进度、容量或完成度存在真实比例时，在 panel 内加入 8vp 的 `ProgressUnit`，不退化成四行无背板的普通文字。

#### 6. `split-two-column`

适合：左侧日期或主信息 + 右侧两个日程/状态块。

结构：`content_root Row padding 12 itemMargin 12 > left_col Column(width 190) + right_col Column(width 86)`。

- 右侧两个小卡片：`width: 86`、`height: 48` 或 `56`、`borderRadius: 12`、当前主题色包 `panel`，两卡同色、同尺寸、同结构。
- 48vp 小卡使用 `padding: 6`，内部只能是 `label 14 + gap 2 + value_row 20 = 36`。
- 动态值和 `%`、`°C` 等单位必须放在同一个 Row，不能把单位作为第三行 Text。
- 86vp 右栏只用于无按钮的短指标，不能放 `ActionUnit`；需要按钮、三行文字或两行文字加单位时，改用 `132 + 12 + 152` 的宽分栏。
- 「天气 + 日程」优先使用标题下方两个 140/144vp 并列面板，不纵向堆成天气 48vp 加会议 32vp 的窄条。

#### 7. `primary-action-pair`

适合：智能家居、导航和同一服务对象下两个并列操作。

结构：`content_root Row padding 12 itemMargin 12 > primary_panel Column(width 132) + action_group Row(width 152, itemMargin 8) > 2 × ActionUnit tile(72×112)`。

左侧必须有主状态或主读数；右侧两个操作必须属于同一服务对象、都有真实事件和匹配图标。没有两个真实事件时改用 `split-two-column` 或单个 `capsule`，禁止伪造操作。

#### 8. `linear-progress`

适合：应用时长、今日进度、防沉迷。

结构：`content_root Column padding 12 itemMargin 8 > title_area Row(height 24) + content_area Column(height 104, itemMargin 8) > ProgressUnit(numeric-single, 48) + detail_row Row(height 48, 2 × 144 卡)`。

- 有两个容量分类或对比值时，进度条下方使用两个同色背板；只有一个补充事实时才使用单行 `detail_area`，不把两项信息散落在卡片两端。
- 只使用 `ProgressUnit state:\"bar\"` 加两条全宽详情 Row 时，必须用闭合式 `content 96 = bar 8 + gap 12 + row 32 + gap 12 + row 32`，配合 `title 24 + gap 8 + content 96 = 128`，在 136vp 安全区内保留 8vp 底部呼吸空间；两条 Row 内文字垂直居中。
- 按补充信息数量选择状态：没有其它详情可用 `numeric-single-caption`；还要显示 1-2 行详情必须用 `numeric-single` 且不再生成 caption，固定 `title 24 + gap 8 + content 104`，content 内 `progress 48 + gap 8 + detail 20 + gap 8 + detail 20 = 104`。禁止把 74vp 的 `numeric-single-caption` 与两个 20vp 详情行塞进 `height:72` 的内容区。

#### 9. `metric-series`

适合：三个城市天气、三个同构设备状态、三个短指标。

结构：`content_root Column padding 12 itemMargin 8 > title_area Row + metrics_row Row(width 296, itemMargin 8) > metric_card × N`。

2 项时用 `144 + 8 + 144`，3 项时用 `93 + 8 + 93 + 8 + 93 = 295`。每项必须严格同构，使用当前主题色包的同一种 `panel`；每项最多图标、主值、短标签三层。耳机左右电量可以使用 2 项模式，设备名放在标题区。

#### 10. `quad-rings`

适合：四个设备电量、四个同类占比。

结构：`content_root Column padding 12 itemMargin 10 > title_text Text + grid Column > grid_row Row × 2`。

每个卡片：`Row(width 144, height 48) > RingUnit(size 40) + texts Column`。最多 4 个，不要超过。

#### 扩展：`four-action-hub`

适合：用户逐项明确要求同一服务对象下 3-4 个同层级快捷操作（系统设置、音乐控制等）。

结构：`content_root Column > title_text(12fp/700) + action_row Row(itemMargin 12) > 3-4 × ActionUnit tile(64×112)`。

每个操作必须有精确 eventCandidate、2-4 字短标签和可见 icon；所有副作用动作都必须由用户逐项明确要求。禁止用它展示数据、混入不同服务对象、存在主次悬殊的操作、候选不足时伪造按钮、四个以上操作。

#### 变体：信息卡/设备卡

设置、蓝牙、网络、系统入口这类无真实数值主指标的卡，使用「小标题 + 1-2 个浅色信息面板 + capsule」的信息卡骨架；禁止把「点击查看」「当前设置项」「调整设置」「选项」作为 30 号以上主标题。

### 骨架选择规则

- 有 3 个待办：选 `todo-list`。
- 单个日程无按钮：选 `meeting-timeline / single-event`。
- 单个日程有按钮：选 `meeting-timeline / event-with-action`。
- 有百分比主指标：优先 `large-ring`。
- 四个同类百分比：选 `quad-rings`。
- 有线性进度语义：选 `linear-progress`。
- 两个并列操作且有两个真实事件：选 `primary-action-pair`。
- 左主右双事项：选 `split-two-column`。
- 强提醒、倒计时、状态突出：选 `strong-focus`。
- 2-3 个同构天气/设备指标：选 `metric-series`。
- 无真实数值主指标的设置/设备入口：选信息卡/设备卡变体。

### 全宽与左右分区

`meeting-timeline`、`todo-list`、`event-with-action`、`linear-progress` 允许使用全宽单列，但主内容或背板必须使用完整的 288/296vp 安全宽度，不能把所有信息挤在左半边后让右半边空白。其它骨架优先使用左右分区，右区放真实的辅助指标、状态、时间地点、二级列表、`RingUnit`、`ProgressUnit` 或 `ActionUnit`；没有真实信息时不编造右区。

主辅关系优先采用非对称比例；只有真实比较、同级时间序列、双事实或操作集合才允许等宽等高。所有主要文字、数值、图标和动作至少形成一条共同对齐线；辅助信息围绕主焦点聚合，不散落四角。

### 底部与侧栏 CTA

- 如果使用底部按钮，`action_area` 高度固定 `32`，按钮由 `ActionUnit` 生成，不要自己写 36 以上高度。
- 有底部胶囊按钮时，优先使用 `title_area 24 + content_area 64 + action_area 32`，两处间距均为 4vp。
- 内容只有一至两行时 `content_area` 可以降为 48-56；内容有三行时必须是 64，不能把 64vp 的子项塞进 56vp。
- 底部 action 必须是 `content_root` 的独立末尾子项，不能放进已经塞满指标的普通信息 Column。
- 按钮必须在卡片底部安全区内，不能贴到圆角边缘，也不能被裁切。
- 侧栏中的胶囊按钮优先使用 88-136vp；若侧栏内部安全宽度小于 88vp，就改用更宽的 132/152vp 分栏，禁止把胶囊按钮塞进 86vp 且带 padding 的小卡。

### 尺寸密度

`2×4`：

- 一个主信息组和一个辅助信息组；一张卡至多 4 个事实。
- 待办/普通列表最多 3 行；日程/会议最多 2 条；同构序列 2-5 项（`metric-series` 2-3 项）；对比环最多 4 个。
- 默认最多 2 个显式操作；仅四操作 hub 允许 3-4 个由用户逐项明确要求的同层级操作。
- 无按钮时整卡一个热区；有一个或两个按钮时，内容区与每个按钮分别构成独立热区。
- 可以展示短时间线、相关双列或横向媒体结构；不得演变为仪表盘或快捷入口矩阵。

### 尺寸选择与布局适配

选择 `2×4`：

- 主信息需要一个相关辅助信息组。
- 需要短时间线、媒体详情或明确操作。
- 热区都具有真实价值且容易区分。

按钮的存在不会自动要求使用 `2×4`；当主信息和一个按钮能够在安全边距内清晰呈现时，可以使用 `2×2`（以 `DESIGN.md` 为准）。

### `2×4` 收缩为 `2×2`

按以下顺序保留：

1. 主状态或主数值。
2. 理解主信息所必需的标签。
3. 如果操作属于主意图，则保留主操作。
4. 最多两条辅助信息行。

优先删除：长说明、重复的应用或服务名称、第三层元数据、额外操作、密集列表和装饰信息。

### `2×2` 扩展为 `2×4`

- 不放大原布局。
- 保持原主信息的视觉主导地位。
- 只增加相关的时间、趋势、上下文、预览或一个更清晰的操作。
- 没有有价值的辅助信息时，保留留白，不制造填充内容。

### Content Density

服务卡片不是缩小版应用页面。每张卡片只能有一个主信息对象;辅助信息必须帮助用户理解主信息或决定下一步。

卡片采用 **necessary-actionable-only** 删减策略:只呈现与用户下一步操作直接相关的必要信息,非必要不呈现。生成器必须在布局前先判断信息优先级,再决定放入卡片的内容,不得先堆满再依赖缩小字号、裁切或换行补救。

信息取舍以**主操作**为根。先确定用户此刻唯一应做的事，再从候选信息中保留能帮助其做出这个动作的最小集合。每条候选信息都必须通过这个测试：**删除它以后，用户的下一步会改变吗？不会就不呈现。**信息优先级从高到低为:主操作及其决策信号 > 操作上下文 > 会改变操作的辅助信息 > 有独立即时目标的次操作 > 解释性背景。低优先级内容只有在不挤压高优先级内容时才可出现;若同一含义已由主数值、状态色或按钮文案表达,其他位置不得重复表达。

文案必须短到可扫读:标题建议 2-6 字（12fp 单行）,主句不超过 12 字,状态标签不超过 4 字,按钮文案优先 2-4 字、不超过 6 字（确需更长且不能等义缩短时使用更宽按钮或降低到批准字号，不能裁切）。主数值默认最多 1 个——这是上限而非应凑满的配额；同构序列（2-5 项）与四对比环每项可各自携带一个数值，全卡事实总数不超过 4 个。不影响操作的精确数字、差值、示例数值、更新时间、说明性统计默认不呈现。能用\"已超时\"\"偏高\"\"待处理\"表达时,不要再同时呈现额外精确差值。

`2×4` 可使用一个主信息组和一个辅助信息组。若一侧使用图表,另一侧最多显示 1-2 条摘要列表;若需要显示 3 条以上列表,图表必须降级为单一数值或极简趋势线。

当 `action_area` 出现时,内容必须在按钮区之前结束，并保持 4-8vp 间距。按钮不得覆盖图表、列表或内容预览。

### Overflow Resolution

当内容无法在安全区内完整呈现时,必须按优先级删减,不得继续压缩、裁切或叠放。

删减顺序:

1. 缩短操作文案,如\"查看报告\"改为\"报告\",\"设目标\"改为\"目标\"。
2. 删除不影响操作判断的精确数字、差值、更新时间和说明性统计。
3. 删除解释性文案;必要说明改为短标签或并入主信息组。
4. 图表降级为 sparkline,移除坐标轴、网格线、日期标签和数据点说明。
5. 日历或列表降级为 1 条摘要,如\"2 个日程影响睡眠\"。
6. 删除次操作,保留一个主操作。
7. 删除重复信息。若一处已经呈现主数值,其他区域不再重复表达同一指标。
8. 状态胶囊可降级为图标或短标签,但不得遮挡标题或主信息。
""")

# Icons 尺寸句
replace_line(
    "资源 SVG 的 24×24 等原始尺寸是坐标系",
    "资源 SVG 的 24×24 等原始尺寸是坐标系，不是统一的最终显示尺寸。最终尺寸按场景选择：左上标题前置 `leading-icon` 12vp、"
    "2×4 标题行右侧图标 24×24vp、`RingUnit` 中心图标（`centerIcon`）24vp。图标类型的 `hero-visual` 在 56×56vp 下只能使用 `icon_weather1`，"
    "并必须同时标记 `data-resource-icon=\"icon_weather1\"` 与 `data-hero-visual=\"weather-icon\"`；普通单色或线性 catalog 图标一律不得放大到 56vp 充当 Hero。"
    "`data-dataviz` 仍可按自身组件契约使用 Hero 空间，但不属于图标。其他场景必须由对应组件契约明确尺寸，不得由原文件 width / height 决定。",
)

# Shapes 小节
replace_line(
    "- **容器与表面的主圆角**为",
    "- **卡片本体主圆角**为 `corner_radius_level10`(20vp)，即 root 固定 `borderRadius: 20`",
)
replace_line(
    "- **按钮主圆角**为",
    "- **胶囊按钮圆角取高度一半**：32vp 高胶囊 → `corner_radius_level8`(16vp)，由 ActionUnit 转换器生成",
)
replace_line(
    "- **小元素**(`corner_radius_level2`–`level4`)用于图片、徽标、标签",
    "- **小元素**(`corner_radius_level2`–`level4`)用于图片、徽标、标签；信息背板 8-12vp，主要支撑背板 12-16vp，胶囊圆角取高度一半",
)
replace_line(
    "胶囊与圆形按钮在 HarmonyOS 体系下通过",
    "胶囊按钮圆角取高度一半（32vp 高 → 16vp），由 ActionUnit 转换器落地，无需用 `9999vp` 兜底。",
)
replace_line(
    "预览壳在卡片外额外应用稍大的外圆角",
    "预览壳在卡片外额外应用稍大的外圆角(`2×4` 上 22vp),便于宿主干净裁切;该圆角不属于卡片内容。",
)

# Components 正文：Card Root / Title leading-icon / Action / List / Progress
replace_span(
    "- 接受宿主提供的运行时画布，不在组件代码中写死卡片外层宽高。",
    "- 约束安全边距、宿主裁切和整体点击行为。",
    """
- 2×4 画布恒为 `320×160vp`；root 为 `Stack`，固定 `borderRadius: 20`、`clip: true`，必须提供 `linearGradient`（angle 默认 180，自上而下）。
- 必须先使用 `comp_background_primary` 基底；场景精确命中 `background_gradients` 中已登记的遮罩预设时叠加对应渐变，未命中时叠加 `general-fallback`，不得只保留裸基底。
- 卡片本体使用 `corner_radius_level10`(20vp)圆角；安全边距由 `content_root` 的 12vp 或 16vp padding 承载（信息较多用 12，大留白展示用 16）。
- 约束安全边距、宿主裁切和整体点击行为；不得依赖 `root.clip` 裁掉溢出内容。
""",
    include_end=True,
)

replace_line(
    "- `leading-icon` 可选，左上 12×12vp 或右上 20×20vp",
    "- `leading-icon` 可选：左上 12×12vp，或 2×4 标题行右侧 24×24vp（标题行高 24vp，`title_text` 推荐宽 240vp 并保留至少 8vp 隔离）；一卡至多两个 `leading-icon`（左上 12vp 一个 + 右上 24vp 一个）",
)

replace_span("### 操作 Action", "### 列表 List", """
### 操作 Action

- 卡片操作统一使用 `ActionUnit`，禁止基础 `Button`；`taskspec.eventCandidates` 为空时不得生成 `ActionUnit`，也不得生成任何 `onClick`。
- 2×4 只使用 `state:\"capsule\"` 或 `state:\"tile\"`，不使用 `icon-round`。
- `capsule` 用于底部或侧栏短按钮：高 32vp、宽 88-136vp（由转换器按父容器适配，产物不得手写 `width/height/padding/borderRadius/backgroundColor/fontColor`）；必须有 `label` 与来自候选事件的 `onClick`。
- `tile` 只用于并列的竖向操作卡：宽 64-80vp、高 80-112vp，必须有来自 `assetCandidates` 的匹配 icon 与 2-4 字标签。
- 浅色卡必须显式写与主题色包一致的 `actionInk`；需要固定浅底时可把同色 `panel` 写入 `actionSurface`。强背景使用 `actionInk:\"#FFFFFFFF\"`、`actionSurface:\"#33FFFFFF\"`，避免纯白大胶囊。
- `onClick` 的 call 与静态 args 逐字段复用 eventCandidates；动态参数改写成 `{\"path\":\"/...\"}` 并补同路径数据样例行；禁止 `{{ }}`、`${...}` 或字符串内 path，禁止样例里的 `demo://`。
- 默认至多 2 个显式操作，且次操作必须具备独立、即时目标且不与主操作竞争；仅当用户逐项明确要求同一服务对象下 3-4 个同层级快捷操作时，才允许 four-action-hub 的 3-4 个 tile。
- 有底部胶囊时优先 `title 24 + content 64 + action 32`，两处间距 4vp；`action_area` 必须是 `content_root` 的独立末尾子项（高 32），固定在底部安全区内，不拉满 320vp 宽卡，不贴圆角边缘、不被裁切。
- 按钮文案优先 2-4 字，不超过 6 字；超过 6 字时降级到 `body-s-regular`，不得继续降低；不截断用户明确要求的 CTA，按钮宽度需覆盖文字宽度和左右至少 8vp 内边距。
- 可点击视觉尺寸至少 24vp，热区至少 40vp。
- 无按钮时，整张卡片为一个热区。
- 有一个或两个按钮时，卡片内容区与每个按钮分别构成不重叠热区，并提供独立点击反馈；点击按钮只触发按钮操作，不得同时触发内容区或整卡操作。
""")

replace_span("### 列表 List", "### 进度 Progress", """
### 列表 List

- `list-row`（如 `todo_item`）高 `32vp`，列表项文字使用 `body-m-regular`(14vp)，内边距约 `10/12vp`，行圆角 8vp、浅灰背板；左侧圆形 check 占位 + 右侧单行文字。
- `2×4` 普通列表最多 3 行；带图表时最多 2 行；日程/会议类最多 2 条（每条 `TimelineUnit` + 文字列）。
- 仅当前决策项可将一段主文案升至 subtitle 层级。
""")

replace_span("### 进度 Progress", "系统不鼓励密集按钮网格", """
### 进度 Progress

可选类型：

- 环形（`RingUnit`）：单一连续比例，一个焦点。
- 线性（`ProgressUnit`）：连续进度或多行详情组合。

禁止手写基础 `Progress` 表达环或线性进度。`RingUnit` 的 `size` 只能取 40/44/52/80/92/98；`state` 只能是 `center-text`、`center-icon`、`center-icon-below-text`；语义色只用 green/blue/orange/red，禁止紫色；`centerIcon` 必须来自 `assetCandidates`。`ProgressUnit` 的 `state` 只能是 `bar`、`numeric-single`、`numeric-single-caption`、`plain`，必须有 `value` 与 `total`，`caption` 至多一行。

高级组件展开后的真实高度必须计入父容器：`plain` 36vp、`numeric-single` 48vp、`numeric-single-caption` 74vp。若在 `plain` 外再放一个 16vp caption，外层 `progress_area` 至少 `36 + gap 4 + 16 = 56vp`，禁止只声明 40vp。

- 没有目标、总量、范围或阶段参照时，直接使用文字或数值，不为装饰而添加进度。
- 一个连续数值相对单一目标是唯一主焦点时使用大环（`large-ring` 骨架，环 92vp）；四个同类对比占比使用 `quad-rings`（4 个 40vp 环，至多 4 个）。
- 环内读数不能再在右侧重复；同一数据对象只保留一个环心读数（评分或时长二选一）。
- 环形进度必须保持正圆并使用系统或运行时进度组件；进度弧线两端必须使用圆形端帽（SVG 对应 `stroke-linecap=\"round\"`），底轨统一使用中性 `progress_ring_track`（浅色 `#00000019` / 深色 `#FFFFFF19`，随主题翻转）。
- 环心同时展示数值与单位时，数值和单位必须保持同一行，不得上下换行；空间不足时先降单位字号（最低 8vp），再降数值一个文字层级；仍不能清晰展示时将整组移至圆环旁边，不继续缩小或强行塞入圆心。
""")

replace_line(
    "系统不鼓励密集按钮网格、多步表单、隐藏手势交互。卡片操作默认保持单一主操作;卡片尺寸上限:`2×2` 最多 1 个显式操作,`2×4` 最多 2 个，但第二个操作必须具备独立即时目标。",
    "系统不鼓励密集按钮网格、多步表单、隐藏手势交互。卡片操作默认保持单一主操作;2×4 显式操作上限 2 个（第二个必须具备独立即时目标），仅四操作 hub 允许 3-4 个由用户逐项明确要求的同层级操作。",
)

# Do's and Don'ts
replace_line(
    "- 所有内容保持在 12vp 安全边距内。",
    "- 所有内容保持在安全内容区内（`content_root` padding 12 → 296×136vp，padding 16 → 288×128vp）。\n"
    "- 先按 padding 算出安全宽度，再选择闭合骨架；每张卡只选一个固定骨架，不自由发明布局。",
)
replace_line(
    "- 卡片表面用 `corner_radius_level8`(16vp)",
    "- 卡片本体用 `corner_radius_level10`(20vp，root 固定值);胶囊按钮圆角取高度一半(32vp 高 → 16vp);标签用 `corner_radius_level2`(4vp)。",
)
replace_line(
    "- 不要让 `2×2` 超过 1 个显式操作",
    "- 不要让 2×4 超过 2 个显式操作(四操作 hub 除外，且必须由用户逐项明确要求)。",
)

DST.write_text(chr(10).join(lines) + chr(10), encoding="utf-8")
print(f"written: {DST} ({len(lines)} lines)")
