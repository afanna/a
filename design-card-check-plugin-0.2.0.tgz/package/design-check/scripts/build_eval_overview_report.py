#!/usr/bin/env python3
"""EVAL299 全量总览交互报告：管线筛选/切换 + 等级筛选 + 搜索，静态自包含单 HTML。

用法:
    python3 scripts/build_eval_overview_report.py

数据源: review/cases/<qid>.json（check_case / check_eval / check_batch 统一逐卡产物，
schema design-check/case-report/v1；A7 修正 2026-08-26——原读 review/eval-l1/ 旧目录
存在过期数据 bug，旧目录只读兼容不迁移）。
L2 标注: 产物 dump.present 为 true 的卡标注「含 L2 真值」（qid 已归一 stem 口径，
如 A-q1，与 review/dumps 文件名对齐）。
产物: review/<YYYYMMDD>/EVAL299-overview-<YYYYMMDD>.html（daily_review_dir，同日覆盖）。
交互为原生 JS（无外部依赖）：管线 tab（全部/A/B/C/MS）+ 严重度复选 + 关键词搜索，
总览统计与明细随筛选联动。
"""
from __future__ import annotations

import json
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_DIR))

from validators.config import daily_review_dir, review_dir  # noqa: E402

BRANCH_TITLES = {"A": "A · 一步走", "B": "B · 现网", "C": "C · 模板", "MS": "MS · 多步走"}


def load_cards() -> list:
    cases_dir = review_dir() / "cases"
    cards = []
    for f in sorted(cases_dir.glob("*.json")):
        try:
            d = json.loads(f.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as exc:
            print(f"  [skip] {f.name}: {exc}", file=sys.stderr)
            continue
        if d.get("schema") != "design-check/case-report/v1":
            continue
        qid = d.get("qid") or f.stem
        branch = qid.split("-", 1)[0]
        if branch not in BRANCH_TITLES:  # SET93 / DSL 等非评测分支产物不进 EVAL299 总览
            continue
        findings = d.get("findings") or []
        cards.append({
            "qid": qid, "branch": branch, "n": len(findings),
            "l2": bool((d.get("dump") or {}).get("present")),
            "fs": [[f2["severity"], f2["rule_id"], f2["layer"],
                    (f2.get("element") or {}).get("json_pointer") or "",
                    f2.get("message") or ""] for f2 in findings],
        })
    return cards


def main() -> int:
    cards = load_cards()
    if not cards:
        print("错误: review/cases/ 无评测分支产物，先跑 python3 scripts/check_eval.py", file=sys.stderr)
        return 2
    date_tag = datetime.now().strftime("%Y%m%d")
    branches = sorted({c["branch"] for c in cards})
    n_cases = len(cards)
    n_l2 = sum(1 for c in cards if c["l2"])

    css = """
    body{font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;margin:0;background:#f4f6f9;color:#1c2430}
    .wrap{max-width:1240px;margin:0 auto;padding:24px 20px 70px}
    h1{font-size:21px;margin:0 0 4px} .sub{color:#5a6a7f;font-size:12.5px;margin-bottom:16px}
    .panel{background:#fff;border:1px solid #e0e2e6;border-radius:12px;padding:14px 16px;margin-bottom:14px;box-shadow:0 1px 3px rgba(0,0,0,.05)}
    .cap{font-size:13px;font-weight:600;margin-bottom:10px;color:#243244}
    table{border-collapse:collapse;width:100%;background:#fff;font-size:12.5px;border-radius:8px;overflow:hidden}
    th{background:#f2f5f9;text-align:left;padding:7px 10px;border-bottom:1px solid #e0e4ea;white-space:nowrap;position:sticky;top:0}
    td{padding:6px 10px;border-bottom:1px solid #eef1f5;vertical-align:top}
    tr:hover td{background:#f7faff}
    .badge{display:inline-block;min-width:26px;text-align:center;color:#fff;font-size:11px;border-radius:9px;padding:1px 7px}
    .b0{background:#e8402a}.b1{background:#e67e22}.b2{background:#7f8c99}
    .l2tag{display:inline-block;background:#e8f2ff;color:#0a59f7;border-radius:4px;padding:0 6px;font-size:10.5px;margin-left:6px}
    .tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}
    .tab{cursor:pointer;border:1px solid #d5dbe4;background:#fff;border-radius:18px;padding:5px 14px;font-size:13px;user-select:none}
    .tab.on{background:#0a59f7;color:#fff;border-color:#0a59f7;font-weight:600}
    .ctrl{display:flex;gap:16px;align-items:center;flex-wrap:wrap;font-size:12.5px}
    .ctrl label{display:inline-flex;align-items:center;gap:4px;cursor:pointer}
    input[type=search]{border:1px solid #d5dbe4;border-radius:8px;padding:6px 10px;font-size:12.5px;width:260px}
    .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:12px}
    .stat{background:#f8fafc;border:1px solid #e4e9f0;border-radius:10px;padding:10px 14px}
    .stat .v{font-size:20px;font-weight:700}.stat .k{font-size:11px;color:#5a6a7f;margin-top:2px}
    .card-h{font-size:14px;font-weight:700;margin:18px 0 6px;cursor:pointer;user-select:none}
    .card-h .cnt{font-weight:500;color:#5a6a7f;font-size:12px}
    .card-h:after{content:'▾';float:right;color:#9aa5b1}
    .card-h.closed:after{content:'▸'}
    .fdet{display:none}
    code{background:#f2f5f9;border-radius:4px;padding:1px 5px;font-size:11.5px}
    .ptr{font-family:ui-monospace,Menlo,monospace;font-size:10.5px;color:#48586c;word-break:break-all}
    .zero{color:#b8c2cf}.note{font-size:12px;color:#5a6a7f;margin:8px 0 0}
    """

    # JS: 内嵌 cards JSON；筛选状态 branchTab + sev set + 搜索词 → 重渲染总览+矩阵+明细
    js = r"""
    const CARDS = __CARDS__;
    const BR_TITLES = __BR_TITLES__;
    let curBranch = 'ALL', curSev = new Set(['P0','P1','P2']), curQ = '';
    function fmatch(c){
        if (curBranch!=='ALL' && c.branch!==curBranch) return false;
        if (c.n===0 && curSev.size<3) return false;
        if (!curQ) return true;
        const q = curQ.toLowerCase();
        if (c.qid.toLowerCase().includes(q)) return true;
        return c.fs.some(f => (curSev.has(f[0])) && (f[1].toLowerCase().includes(q)||f[4].toLowerCase().includes(q)));
    }
    function visFs(c){ return c.fs.filter(f=>curSev.has(f[0])); }
    function rerender(){
        // 统计卡
        const shown = CARDS.filter(fmatch);
        const sevCnt = {P0:0,P1:0,P2:0}; let total=0;
        shown.forEach(c=>visFs(c).forEach(f=>{sevCnt[f[0]]++;total++;}));
        document.getElementById('st-cards').textContent = shown.length;
        document.getElementById('st-total').textContent = total;
        document.getElementById('st-p0').textContent = sevCnt.P0;
        document.getElementById('st-p1').textContent = sevCnt.P1;
        document.getElementById('st-p2').textContent = sevCnt.P2;
        // 分支表
        const rows = [];
        const bs = curBranch==='ALL' ? Object.keys(BR_TITLES) : [curBranch];
        const allBs = Object.keys(BR_TITLES);
        bs.forEach(b=>{
            const cs = CARDS.filter(c=>c.branch===b && (curBranch!=='ALL'||true) && (curBranch==='ALL'||c.branch===curBranch));
            // 分支行在 ALL 视图下也受严重度/搜索影响
            const vis = cs.filter(c=>{
                if(!curQ) return true;
                const q=curQ.toLowerCase();
                return c.qid.toLowerCase().includes(q)||c.fs.some(f=>f[1].toLowerCase().includes(q)||f[4].toLowerCase().includes(q));
            });
            const sc={P0:0,P1:0,P2:0}; let t=0;
            vis.forEach(c=>visFs(c).forEach(f=>{sc[f[0]]++;t++;}));
            rows.push(`<tr><td><b>${BR_TITLES[b]}</b>（${vis.length} 卡）</td><td>${t}</td><td>${sc.P0||'<span class=zero>0</span>'}</td><td>${sc.P1}</td><td>${sc.P2}</td></tr>`);
        });
        document.getElementById('branch-table').innerHTML = '<tr><th>管线</th><th>findings</th><th>P0</th><th>P1</th><th>P2</th></tr>'+rows.join('');
        // 规则矩阵
        const ruleStat = {};
        shown.forEach(c=>visFs(c).forEach(f=>{
            const r = ruleStat[f[1]] = ruleStat[f[1]]||{cnt:{},sev:{}};
            r.cnt[c.branch]=(r.cnt[c.branch]||0)+1; r.sev[f[0]]=(r.sev[f[0]]||0)+1;
        }));
        const mrows = Object.keys(ruleStat).sort((a,b)=>{
            const ta=Object.values(ruleStat[a].cnt).reduce((x,y)=>x+y,0), tb=Object.values(ruleStat[b].cnt).reduce((x,y)=>x+y,0);
            return tb-ta||a.localeCompare(b);
        }).map(rule=>{
            const r=ruleStat[rule];
            const cells = allBs.map(b=> r.cnt[b]||'<span class=zero>·</span>');
            const sevs = Object.entries(r.sev).sort().map(([s,n])=>`<span class="badge b${s[1]}">${n}</span>`).join(' ');
            return `<tr><td><code>${rule}</code></td>${cells.map(c=>`<td>${c}</td>`).join('')}<td>${sevs}</td></tr>`;
        });
        document.getElementById('rule-table').innerHTML =
            '<tr><th>规则</th>'+allBs.map(b=>`<th>${BR_TITLES[b]}</th>`).join('')+'<th>等级构成</th></tr>'+mrows.join('');
        // 明细
        const det = [];
        shown.forEach((c,i)=>{
            const fs = visFs(c);
            const sc={P0:0,P1:0,P2:0}; fs.forEach(f=>sc[f[0]]++);
            const badges = Object.entries(sc).filter(([s,n])=>n>0).map(([s,n])=>`<span class="badge b${s[1]}">${s}=${n}</span>`).join(' ');
            const l2 = c.l2 ? '<span class="l2tag">含 L2 真值</span>' : '';
            det.push(`<div class="card-h closed" onclick="this.classList.toggle('closed');this.nextElementSibling.style.display=this.classList.contains('closed')?'none':'block'">${c.qid}${l2} ${badges} <span class="cnt">${fs.length} 条</span></div><div class="fdet">`+
                (fs.length? '<table><tr><th>等级</th><th>规则</th><th>层</th><th>问题 · 证据</th></tr>'+fs.map(f=>
                    `<tr><td><span class="badge b${f[0][1]}">${f[0]}</span></td><td><code>${f[1]}</code></td><td>${f[2]}</td><td>${f[4]}${f[3]?`<br><span class="ptr">${f[3]}</span>`:''}</td></tr>`).join('')+'</table>'
                : '<table><tr><td class="zero">无 findings</td></tr></table>')+'</div>');
        });
        document.getElementById('detail').innerHTML = det.join('') || '<div class="zero">无匹配卡片</div>';
    }
    function setBranch(b){
        curBranch=b;
        document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t.dataset.b===b));
        rerender();
    }
    function toggleSev(s,el){
        if(el.checked) curSev.add(s); else curSev.delete(s);
        rerender();
    }
    document.addEventListener('DOMContentLoaded',()=>{
        document.getElementById('q').addEventListener('input',e=>{curQ=e.target.value.trim();rerender();});
        rerender();
    });
    """

    payload = json.dumps(cards, ensure_ascii=False, separators=(",", ":"))
    js = js.replace("__CARDS__", payload).replace("__BR_TITLES__", json.dumps(BRANCH_TITLES, ensure_ascii=False))

    tabs = "".join(
        f'<div class="tab{" on" if b == "ALL" else ""}" data-b="{b}" onclick="setBranch(\'{b}\')">'
        f'{"全部管线" if b == "ALL" else BRANCH_TITLES[b]}</div>'
        for b in ["ALL"] + branches)

    html = f"""<!doctype html>
<html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EVAL299 全量总览 {date_tag}</title><style>{css}</style></head>
<body><div class="wrap">
<h1>EVAL299 全量总览报告（四管线可切换）</h1>
<div class="sub">生成 {datetime.now().strftime('%Y-%m-%d %H:%M')} · {n_cases} 卡全量 L1（DSL 声明 + semantic） ·
其中 {n_l2} 卡另含 L2 dump 真值（今日抽检完整管线实采，明细中以蓝标标注） ·
机器检测+定位+建议，最终通过与否由人类设计师确认</div>

<div class="panel"><div class="cap">筛选</div>
<div class="tabs">{tabs}</div>
<div class="ctrl">
<label><input type="checkbox" checked onchange="toggleSev('P0',this)"> P0</label>
<label><input type="checkbox" checked onchange="toggleSev('P1',this)"> P1</label>
<label><input type="checkbox" checked onchange="toggleSev('P2',this)"> P2</label>
<input type="search" id="q" placeholder="搜索卡号 / 规则 / 问题文本…">
</div></div>

<div class="panel"><div class="cap">当前筛选统计</div>
<div class="stats">
<div class="stat"><div class="v" id="st-cards">–</div><div class="k">命中卡片</div></div>
<div class="stat"><div class="v" id="st-total">–</div><div class="k">findings</div></div>
<div class="stat"><div class="v" id="st-p0" style="color:#e8402a">–</div><div class="k">P0</div></div>
<div class="stat"><div class="v" id="st-p1" style="color:#e67e22">–</div><div class="k">P1</div></div>
<div class="stat"><div class="v" id="st-p2" style="color:#7f8c99">–</div><div class="k">P2</div></div>
</div>
<table id="branch-table"></table></div>

<div class="panel"><div class="cap">规则 × 管线分布（随筛选联动）</div>
<table id="rule-table"></table></div>

<div class="panel"><div class="cap">逐卡明细（点击卡头展开；含 L2 真值的卡带蓝标）</div>
<div id="detail"></div>
    <div class="note">L2 标注口径：逐卡产物 review/cases/&lt;qid&gt;.json 的 dump.present 为 true（findings 以产物真值为准，A7 修正后与 review/cases/ 逐卡对账一致）。</div></div>

</div><script>{js}</script></body></html>"""

    out = daily_review_dir() / f"EVAL299-overview-{date_tag}.html"
    out.write_text(html, encoding="utf-8")
    print(f"生成: {out} {out.stat().st_size} bytes")
    total = sum(c["n"] for c in cards)
    sev = Counter(f[0] for c in cards for f in c["fs"])
    print(f"卡片: {n_cases}（含 L2: {n_l2}）· findings: {total}（P0={sev.get('P0', 0)} / "
          f"P1={sev.get('P1', 0)} / P2={sev.get('P2', 0)}）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
