#!/usr/bin/env python3
"""EVAL299 全量总览可视化报告：overview 交互筛选 + 每卡实拍/线框双视图，单文件自包含。

用法:
    python3 scripts/build_eval_overview_visual.py

数据源: review/eval-l1/<branch>/<case_id>.json（check_eval 全量 L1）+ 有 dump 的卡
check_card --layout 补 L2；实拍来自评测集 images/（缩略 480px JPEG base64 内嵌）；
线框：有 dump → wireframe_svg 实测；无 dump → report_html 声明推演（标注口径）。
产物: review/<YYYYMMDD>/EVAL299-overview-visual-<YYYYMMDD>.html（同日覆盖）。
"""
from __future__ import annotations

import base64
import io
import json
import re
import subprocess
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_DIR))
sys.path.insert(0, str(PROJECT_DIR / "scripts"))

from report_b_eval import CSS as TPL_CSS, findings_rows, wireframe_svg  # noqa: E402
from report_html import _layout, _svg  # noqa: E402
from validators.config import daily_review_dir, eval_root, review_dir  # noqa: E402
from validators.eval_loader import load_eval, load_eval_card  # noqa: E402

BRANCH_TITLES = {"A": "A · 一步走", "B": "B · 现网", "C": "C · 模板", "MS": "MS · 多步走"}
THUMB_W = 480  # 实拍缩略宽（px）


def dump_for(qid: str, dump_files: dict):
    """dump 文件名不补零（A-q1），qid 补零（A-q001）——双向兼容。"""
    if qid in dump_files:
        return dump_files[qid]
    m = re.match(r"^(.*)-([qQ])0*(\d+)$", qid)
    return dump_files.get(f"{m.group(1)}-{m.group(2)}{int(m.group(3))}") if m else None


def thumb_data_uri(path: Path) -> str:
    """实拍缩略为 THUMB_W 宽 JPEG base64（PIL 与 wireframe.py 同源依赖）。"""
    from PIL import Image
    img = Image.open(path)
    if img.mode != "RGB":
        img = img.convert("RGB")
    if img.width > THUMB_W:
        img = img.resize((THUMB_W, round(img.height * THUMB_W / img.width)))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=70)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


def shot_for(entry, branch_images: dict):
    """评测集现网实拍 images/<stem>.{png,jpg,jpeg} → data URI；无则 None。"""
    images = branch_images.get(entry.branch)
    if not images:
        return None
    for ext in ("png", "jpg", "jpeg"):
        cand = images / f"{entry.dsl_path.stem}.{ext}"
        if cand.is_file():
            try:
                return thumb_data_uri(cand)
            except Exception:  # noqa: BLE001 图片损坏不阻断
                return None
    return None


def declared_svg(entry) -> str:
    """DSL 声明推演线框（report_html 铺排），失败降级占位。"""
    try:
        card = load_eval_card(entry)
        boxes, (rw, rh) = _layout(card)
        return _svg(card, boxes, rw, rh)
    except Exception as exc:  # noqa: BLE001
        return f'<div style="color:#999;font-size:12px;padding:20px;text-align:center">声明线框生成失败：{exc!r}</div>'


def main() -> int:
    date_tag = datetime.now().strftime("%Y%m%d")
    l1_dir = review_dir() / "eval-l1"
    dumps = review_dir() / "dumps"
    dump_files = {p.name[: -len(".layout.json")]: p for p in dumps.glob("*.layout.json")}
    if not l1_dir.is_dir():
        print("错误: review/eval-l1/ 无数据，先跑 check_eval.py", file=sys.stderr)
        return 2

    entries = {e.case_id: e for e in load_eval(eval_root())}
    branch_images = {}
    for e in entries.values():
        branch_images.setdefault(e.branch, eval_root() / Path(e.branch_dir).name / "images")

    cards, n_shot, n_wf, n_decl = [], 0, 0, 0
    for branch in sorted(BRANCH_TITLES):
        for f in sorted((l1_dir / branch).glob("*.json")):
            d = json.loads(f.read_text(encoding="utf-8"))
            qid = d["qid"]
            entry = entries.get(qid)
            dump = dump_for(qid, dump_files)
            if dump is not None:
                out = subprocess.run(
                    [sys.executable, str(PROJECT_DIR / "scripts" / "check_card.py"),
                     "--dsl", str(entry.dsl_path), "--layout", str(dump), "--format", "json"],
                    capture_output=True, text=True, cwd=str(PROJECT_DIR))
                try:
                    findings = json.loads(out.stdout)["findings"]
                except (json.JSONDecodeError, KeyError):
                    findings = d.get("findings", [])
            else:
                findings = d.get("findings", [])
            shot = shot_for(entry, branch_images) if entry else None
            if shot:
                n_shot += 1
            if dump is not None:
                wf = wireframe_svg(dump)
                wf_cap = "② dumpLayout 实测线框（vp）"
                n_wf += 1
            else:
                wf = declared_svg(entry) if entry else ""
                wf_cap = "② DSL 声明线框（无 dump，声明口径非实测）"
                n_decl += 1
            cards.append({
                "qid": qid, "branch": branch, "l2": dump is not None,
                "shot": shot, "wfcap": wf_cap, "wf": wf,
                "fs": [[x["severity"], x["rule_id"], x["layer"],
                        (x.get("element") or {}).get("json_pointer") or "",
                        x.get("message") or ""] for x in findings],
                "frows": findings_rows(findings, with_fix=False),  # 库内标准表（含类别徽章）
            })
            print(f"[card] {qid}: {len(findings)} 条 shot={'Y' if shot else '-'} wf={'dump' if dump else 'decl'}")

    css = TPL_CSS + """
    /* 交互层补充（管线 tab / 统计卡 / 折叠 / 双视图行）——视觉基础组件全部来自库内模板 CSS */
    .tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}
    .tab{cursor:pointer;border:1px solid #d5dbe4;background:#fff;border-radius:18px;padding:5px 14px;font-size:13px;user-select:none}
    .tab.on{background:#0a59f7;color:#fff;border-color:#0a59f7;font-weight:600}
    .ctrl{display:flex;gap:16px;align-items:center;flex-wrap:wrap;font-size:12.5px}
    .ctrl label{display:inline-flex;align-items:center;gap:4px;cursor:pointer}
    input[type=search]{border:1px solid #d5dbe4;border-radius:8px;padding:6px 10px;font-size:12.5px;width:260px}
    .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:12px}
    .stat{background:#f8fafc;border:1px solid #e4e9f0;border-radius:10px;padding:10px 14px}
    .stat .v{font-size:20px;font-weight:700}.stat .k{font-size:11px;color:#5a6a7f;margin-top:2px}
    .badge{display:inline-block;min-width:26px;text-align:center;color:#fff;font-size:11px;border-radius:9px;padding:1px 7px}
    .b0{background:#e8402a}.b1{background:#e67e22}.b2{background:#7f8c99}
    .l2tag{display:inline-block;background:#e8f2ff;color:#0a59f7;border-radius:4px;padding:0 6px;font-size:10.5px;margin-left:6px}
    .card-h{font-size:15px;font-weight:700;margin:22px 0 8px;padding-top:10px;border-top:1px dashed #d7dee8;cursor:pointer;user-select:none}
    .card-h .cnt{font-weight:500;color:#5a6a7f;font-size:12px}
    .card-h:after{content:'▾';float:right;color:#9aa5b1}
    .card-h.closed:after{content:'▸'}
    .fdet{display:none}
    .zero{color:#b8c2cf}
    /* 双视口：实拍|线框强制左右并排（grid 两列不随窄视口换行堆叠）；
       面板可收缩（min-width:0 覆盖库内 280px 下限），实拍/线框统一高度上限对齐 */
    .card-row{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px}
    .panel{min-width:0}
    .panel img,.panel svg{max-width:100%;max-height:340px;margin:0 auto;display:block}
    """

    js = r"""
    const CARDS = __CARDS__;
    const BR_TITLES = __BR_TITLES__;
    let curBranch='ALL', curSev=new Set(['P0','P1','P2']), curQ='';
    function visFs(c){return c.fs.filter(f=>curSev.has(f[0]));}
    function cardMatch(c){
        if(curBranch!=='ALL'&&c.branch!==curBranch)return false;
        if(c.fs.length===0&&curSev.size<3)return false;
        if(!curQ)return true;
        const q=curQ.toLowerCase();
        return c.qid.toLowerCase().includes(q)||c.fs.some(f=>f[1].toLowerCase().includes(q)||f[4].toLowerCase().includes(q));
    }
    function rerender(){
        const shown=CARDS.filter(cardMatch);
        const sc={P0:0,P1:0,P2:0};let total=0;
        shown.forEach(c=>visFs(c).forEach(f=>{sc[f[0]]++;total++;}));
        st('st-cards',shown.length);st('st-total',total);st('st-p0',sc.P0);st('st-p1',sc.P1);st('st-p2',sc.P2);
        const allBs=Object.keys(BR_TITLES);
        const bs=curBranch==='ALL'?allBs:[curBranch];
        document.getElementById('branch-table').innerHTML='<tr><th>管线</th><th>findings</th><th>P0</th><th>P1</th><th>P2</th></tr>'+
            bs.map(b=>{
                const vis=CARDS.filter(c=>c.branch===b&&cardMatch(c));
                const s={P0:0,P1:0,P2:0};let t=0;
                vis.forEach(c=>visFs(c).forEach(f=>{s[f[0]]++;t++;}));
                return `<tr><td><b>${BR_TITLES[b]}</b>（${vis.length} 卡）</td><td>${t}</td><td>${s.P0||'<span class=zero>0</span>'}</td><td>${s.P1}</td><td>${s.P2}</td></tr>`;
            }).join('');
        const ruleStat={};
        shown.forEach(c=>visFs(c).forEach(f=>{
            const r=ruleStat[f[1]]=ruleStat[f[1]]||{cnt:{},sev:{}};
            r.cnt[c.branch]=(r.cnt[c.branch]||0)+1;r.sev[f[0]]=(r.sev[f[0]]||0)+1;
        }));
        document.getElementById('rule-table').innerHTML='<tr><th>规则</th>'+allBs.map(b=>`<th>${BR_TITLES[b]}</th>`).join('')+'<th>等级构成</th></tr>'+
            Object.keys(ruleStat).sort((a,b)=>{
                const ta=Object.values(ruleStat[a].cnt).reduce((x,y)=>x+y,0),tb=Object.values(ruleStat[b].cnt).reduce((x,y)=>x+y,0);
                return tb-ta||a.localeCompare(b);
            }).map(rule=>{
                const r=ruleStat[rule];
                return `<tr><td><code>${rule}</code></td>${allBs.map(b=>`<td>${r.cnt[b]||'<span class=zero>·</span>'}</td>`).join('')}<td>${Object.entries(r.sev).sort().map(([s,n])=>`<span class="badge b${s[1]}">${n}</span>`).join(' ')}</td></tr>`;
            }).join('');
        document.getElementById('detail').innerHTML=shown.map(c=>{
            const fs=visFs(c),s={P0:0,P1:0,P2:0};fs.forEach(f=>s[f[0]]++);
            const l2=c.l2?'<span class="l2tag">dump 实测</span>':'';
            const shot=c.shot?`<img src="${c.shot}" alt="${c.qid}">`:'<div style="border:1px dashed #c9ced6;border-radius:8px;padding:34px 10px;color:#999;font-size:12px;text-align:center">无现网实拍</div>';
            return `<div class="card-h closed" onclick="tg(this)">EVAL299-${c.qid}${l2} · findings ${fs.length}（P0=${s.P0} / P1=${s.P1} / P2=${s.P2}）</div>`+
            `<div class="fdet"><div class="card-row"><div class="panel"><div class="cap">① 现网真机实拍</div>${shot}</div>`+
            `<div class="panel"><div class="cap">${c.wfcap}</div>${c.wf}</div></div>`+
            c.frows+'</div>';
        }).join('')||'<div class="zero">无匹配卡片</div>';
    }
    function st(id,v){document.getElementById(id).textContent=v;}
    function tg(el){el.classList.toggle('closed');el.nextElementSibling.style.display=el.classList.contains('closed')?'none':'block';}
    function setBranch(b){curBranch=b;document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t.dataset.b===b));rerender();}
    function toggleSev(s,el){el.checked?curSev.add(s):curSev.delete(s);rerender();}
    document.addEventListener('DOMContentLoaded',()=>{
        document.getElementById('q').addEventListener('input',e=>{curQ=e.target.value.trim();rerender();});
        rerender();
    });
    """
    payload = json.dumps(cards, ensure_ascii=False, separators=(",", ":"))
    js = js.replace("__CARDS__", payload).replace("__BR_TITLES__", json.dumps(BRANCH_TITLES, ensure_ascii=False))

    branches = sorted({c["branch"] for c in cards})
    tabs = "".join(
        f'<div class="tab{" on" if b == "ALL" else ""}" data-b="{b}" onclick="setBranch(\'{b}\')">'
        f'{"全部管线" if b == "ALL" else BRANCH_TITLES[b]}</div>'
        for b in ["ALL"] + branches)

    total = sum(len(c["fs"]) for c in cards)
    sev = Counter(f[0] for c in cards for f in c["fs"])
    html = f"""<!doctype html>
<html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EVAL299 全量总览（可视化）{date_tag}</title><style>{css}</style></head>
<body><div class="wrap">
<h1>EVAL299 全量总览可视化报告（四管线可切换）</h1>
<div class="sub">生成 {datetime.now().strftime('%Y-%m-%d %H:%M')} · {len(cards)} 卡全量 L1 ·
{n_wf} 卡含 dump 实测线框 + L2 检出（蓝标），{n_decl} 卡为 DSL 声明线框（无 dump） ·
实拍 {n_shot}/{len(cards)} 命中评测集 images/ · 机器检测+定位+建议，最终通过与否由人类设计师确认</div>

<div class="panel"><div class="cap">筛选</div>
<div class="tabs">{tabs}</div>
<div class="ctrl">
<label><input type="checkbox" checked onchange="toggleSev('P0',this)"> P0</label>
<label><input type="checkbox" checked onchange="toggleSev('P1',this)"> P1</label>
<label><input type="checkbox" checked onchange="toggleSev('P2',this)"> P2</label>
<input type="search" id="q" placeholder="搜索卡号 / 规则 / 问题文本…">
</div></div>

<div class="panel"><div class="cap">当前筛选统计</div>
<div class="stats">
<div class="stat"><div class="v" id="st-cards">–</div><div class="k">命中卡片</div></div>
<div class="stat"><div class="v" id="st-total">–</div><div class="k">findings</div></div>
<div class="stat"><div class="v" id="st-p0" style="color:#e8402a">–</div><div class="k">P0</div></div>
<div class="stat"><div class="v" id="st-p1" style="color:#e67e22">–</div><div class="k">P1</div></div>
<div class="stat"><div class="v" id="st-p2" style="color:#7f8c99">–</div><div class="k">P2</div></div>
</div>
<table id="branch-table"></table></div>

<div class="panel"><div class="cap">规则 × 管线分布（随筛选联动）</div>
<table id="rule-table"></table></div>

<div class="panel"><div class="cap">逐卡明细（点卡头展开：实拍 + 线框 + findings）</div>
<div id="detail"></div>
<div class="note">实拍为评测集 images/ 缩略图（{THUMB_W}px JPEG 内嵌）；「dump 实测」蓝标卡线框为真机 dumpLayout 真值，其余为 DSL 声明推演。</div></div>

</div><script>{js}</script></body></html>"""

    out = daily_review_dir() / f"EVAL299-overview-visual-{date_tag}.html"
    out.write_text(html, encoding="utf-8")
    print(f"生成: {out} {out.stat().st_size / 1e6:.1f} MB")
    print(f"卡片: {len(cards)} · findings: {total}（P0={sev.get('P0', 0)} / P1={sev.get('P1', 0)} / "
          f"P2={sev.get('P2', 0)}）· 实拍 {n_shot} · 实测线框 {n_wf} · 声明线框 {n_decl}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
