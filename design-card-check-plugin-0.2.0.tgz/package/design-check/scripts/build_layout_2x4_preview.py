#!/usr/bin/env python3
"""从 DESIGN-2x4.md frontmatter（layout_slots）生成标准 Layout 审核页。

设计约束（用户指令）：
- 布局规范语法参考 DESIGN.md（2×2）Layout 章节 Slot Model：以 ``layout_slots`` 为
  第一层布局契约，DOM 按 title-area / content-area / button-area 槽位组织，
  不得从示意图反推绝对坐标；
- 禁止硬编码：本脚本不写死任何布局几何（尺寸 / gap / 圆角 / 段数），
  全部解析自 DESIGN-2x4.md 的 ``layout_slots``（standardVariants.structure、
  rootStructures、splitRules、canvas、verticalClosure 等），规范变更后重跑本脚本即可再生成。

structure 表达式语法（与 frontmatter 书写一致，段以 "+" 连接）：
  seg  := [prefix] [dir "gap" N "->"] item
          prefix: left/right → 横向容器；top/bottom/content → 纵向容器
          未声明 gap 时取 splitRules 对应原子的 gap（rowSplitContent / columnSplit）
  item := "kx[WxH rR]" | "WxH [rR]" | "capsule WxH rR"
        | "k rows[WxH]? each H gapN -> kx[...]"   （2×n 网格，行间 gap 取容器声明）

输出：Design-guide/review/design-2x4-layout-preview.html
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import yaml

HERE = Path(__file__).resolve()
GUIDE = HERE.parent.parent.parent          # Design-guide/
SPEC = GUIDE / "DESIGN-2x4.md"
OUT = GUIDE / "review" / "design-2x4-layout-preview.html"

DIMS_RE = re.compile(r"^(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)(?:\s*r(\d+))?$")
KBLOCK_RE = re.compile(r"^(\d+)x\[(\d+(?:\.\d+)?)x(\d+(?:\.\d+)?)(?:\s*r(\d+))?\]$")
ROWS_RE = re.compile(
    r"^(\d+)\s+rows(?:\[(\d+(?:\.\d+)?)x(\d+(?:\.\d+)?)\])?\s+each\s+([HV])\s+"
    r"gap(\d+(?:\.\d+)?)\s+->\s+(.*)$")


def load_layout_slots() -> dict:
    text = SPEC.read_text(encoding="utf-8")
    fm = text.split("---")[1]
    return yaml.safe_load(fm)["layout_slots"]


# ---------------------------------------------------------------- 布局树

class Block:
    def __init__(self, w, h, r, kind="blk"):
        self.w, self.h, self.r, self.kind = w, h, r, kind

    def render(self):
        rad = f"border-radius:{px(self.r)}px;" if self.r else ""
        return (f'<div class="{self.kind}" style="width:{px(self.w)}px;'
                f'height:{px(self.h)}px;{rad}"></div>')


class Group:
    def __init__(self, direction, gap, children):
        self.direction, self.gap, self.children = direction, gap, children

    def render(self):
        d = "row" if self.direction == "H" else "column"
        gap = f"gap:{px(self.gap)}px;" if self.gap else ""
        return (f'<div class="grp" style="flex-direction:{d};{gap}">'
                + "".join(c.render() for c in self.children) + "</div>")


def px(v) -> str:
    f = num(v)
    return str(int(f)) if f == int(f) else str(f)


def num(v) -> float:
    """'320vp' / 320 / '90.67' → float"""
    return float(re.sub(r"[^0-9.]", "", str(v))) if isinstance(v, str) else float(v)


def parse_expr(s: str, default_h_gap: float, default_v_gap: float):
    """段归属规则：left/top 通常是裸块；right/bottom/content 开启子容器，
    其后无 prefix 的段（如 "H gap8 -> kx[...]"）追加进该子容器。"""
    segs = [t.strip() for t in s.split("+")]
    direction = gap = None
    items: list = []
    cur_sub: Group | None = None
    for i, seg in enumerate(segs):
        toks = seg.split()
        idx = 0
        prefix = None
        if toks and toks[0] in ("left", "right"):
            prefix, idx = toks[0], 1
        elif toks and toks[0] in ("top", "bottom", "content"):
            prefix, idx = toks[0], 1
        seg_dir = {"left": "H", "right": "H", "top": "V", "bottom": "V", "content": "V"}.get(prefix)
        seg_gap = None
        if (idx < len(toks) and toks[idx] in ("H", "V")
                and idx + 1 < len(toks) and toks[idx + 1].startswith("gap")):
            seg_dir = toks[idx]
            seg_gap = float(toks[idx + 1][3:])
            idx += 2
            assert toks[idx] == "->", f"expected -> in {seg!r}"
            idx += 1
        seg_items = parse_items(" ".join(toks[idx:]), seg)

        if i == 0:
            direction = seg_dir or ("H" if prefix in ("left", "right") else "V" if prefix else None)
            if seg_gap is not None:
                gap = seg_gap
            elif direction == "H":
                gap = default_h_gap
            elif direction == "V":
                gap = default_v_gap
            items.extend(seg_items)
            if prefix in ("right", "bottom", "content") and (seg_gap is not None or len(seg_items) > 1):
                cur_sub = Group(seg_dir, seg_gap if seg_gap is not None else
                                (default_h_gap if seg_dir == "H" else default_v_gap), seg_items)
                items[-len(seg_items):] = [cur_sub]
            continue

        if prefix is None and cur_sub is not None:
            if seg_dir is not None and seg_gap is not None:
                cur_sub.children.append(Group(seg_dir, seg_gap, seg_items))
            else:
                cur_sub.children.extend(seg_items)
        elif prefix in ("right", "bottom", "content"):
            sub = Group(seg_dir or ("H" if prefix == "right" else "V"),
                        seg_gap if seg_gap is not None else
                        (default_h_gap if (seg_dir or "V") == "H" else default_v_gap),
                        seg_items)
            items.append(sub)
            cur_sub = sub
        else:
            items.extend(seg_items)
    if direction is None and len(items) == 1:
        return items[0]
    return Group(direction or "H", gap if gap is not None else 0.0, items)


def parse_items(s: str, seg: str) -> list:
    toks = s.split()
    if not toks:
        raise ValueError(f"empty item in seg {seg!r}")
    if toks[0] == "capsule":
        w, h, r = dims(toks[1:])
        return [Block(w, h, r, kind="capsule")]
    m = ROWS_RE.match(s)
    if m:  # 网格：k 行（行间 gap 由容器声明承载）
        k, _rw, _rh, d, g, cell = m.groups()
        cell_items = parse_items(cell.strip(), seg)
        row = Group(d, float(g), cell_items) if len(cell_items) > 1 else cell_items[0]
        return [row] * int(k)
    m = KBLOCK_RE.match(s)
    if m:  # k 个等分块
        k, w, h, r = m.groups()
        b = Block(float(w), float(h), float(r) if r else None)
        return [b] * int(k)
    if toks[0] == "1x":
        return parse_items(" ".join(toks[1:]), seg)
    w, h, r = dims(toks)
    return [Block(w, h, r)]


def dims(toks) -> tuple:
    m = DIMS_RE.match(" ".join(toks))
    if not m:
        raise ValueError(f"bad dims: {' '.join(toks)!r}")
    w, h, r = m.groups()
    return float(w), float(h), (float(r) if r else None)


def parse_dims_str(s: str):
    return dims(str(s).replace("×", "x").split())


# ---------------------------------------------------------------- 根结构渲染

def render_variant(variant: dict, roots: dict, cv: dict, splits: dict) -> str:
    root_key = variant["root"]
    root = roots[root_key]
    card_r = float(cv["root"]["borderRadius"])
    pad = float(cv["contentRoot"]["padding"])
    # 默认 gap 取自分栏原子（不硬编码）
    h_gap = float(splits["rowSplitContent"]["gap"])
    v_gap = float(splits["columnSplit"]["gap"])
    tree = parse_expr(variant["structure"], h_gap, v_gap)

    if root.get("titleBar") in (None, "none"):  # bare：content 即唯一槽
        return card(f'<div class="content-area">{tree.render()}</div>', card_r, pad)

    tw, th, tr = parse_dims_str(root["titleBar"])
    rad = f"border-radius:{px(tr)}px;" if tr else ""
    parts = [
        f'<div class="titlebar" style="width:{px(tw)}px;height:{px(th)}px;{rad}"></div>',
        f'<div class="slotgap" style="height:{root["gap"]}px"></div>',
    ]
    if root_key == "titledAction":
        # structure = content 块 + capsule；两处 gap 由 rootStructures 承载
        children = tree.children if isinstance(tree, Group) else [tree]
        body, cap = children[0], children[-1]
        parts.append(f'<div class="content-area">{body.render()}</div>')
        parts.append(f'<div class="slotgap" style="height:{root["actionGap"]}px"></div>')
        parts.append(cap.render())
        return card("".join(parts), card_r, pad, align="flex-start")
    parts.append(f'<div class="content-area">{tree.render()}</div>')
    return card("".join(parts), card_r, pad)


def card(inner: str, radius: float, pad: float, align: str = "center") -> str:
    return (f'<div class="card-root" data-size="2x4" style="border-radius:{px(radius)}px">'
            f'<div class="content-root" style="padding:{px(pad)}px;justify-content:{align}">'
            f"{inner}</div></div>")


# ---------------------------------------------------------------- 页面组装

ROOT_LABELS = {
    "bare": "bare · 无标题 · content 296×136",
    "titledCompact": "titled-compact · 标题 17 + gap 4 + content 115",
    "titledRegular": "titled-regular · 标题 20 + gap 8 + content 108",
    "titledAction": "titled-action · 标题 20 + gap 4 + content 72 + gap 4 + capsule 36",
}


def build_html(ls: dict) -> str:
    cv = ls["canvas"]["2x4"]
    roots = ls["rootStructures"]
    variants = ls["standardVariants"]
    splits = ls["splitRules"]
    mappings = ls.get("skeletonMappings", {})
    closures = ls.get("verticalClosure", {}).get("padding12-safe-height-136", [])

    by_variant: dict[str, list[str]] = {}  # 反查：变体 -> 业务骨架
    for name, m in mappings.items():
        keys = [m["variant"]] if "variant" in m else list((m.get("variants") or {}).values())
        for v in keys:
            by_variant.setdefault(v, []).append(name)

    safe = cv["safeArea"]["padding12"]
    cells = []
    for vid, v in variants.items():
        skeleton = "、".join(by_variant.get(vid, [])) or "—"
        cells.append(f'''<div class="cell">
  <div class="cell-head"><span class="vid">{vid}</span><span class="root-chip">{v["root"]}</span></div>
  <div class="stage">{render_variant(v, roots, cv, splits)}</div>
  <div class="meta">
    <div class="structure"><code>{v["structure"]}</code></div>
    <div class="skeleton">业务骨架：{skeleton}</div>
  </div>
</div>''')

    groups = []
    for root_key in ("bare", "titledCompact", "titledRegular", "titledAction"):
        if not any(v["root"] == root_key for v in variants.values()):
            continue
        cells_html = "".join(c for c, (vid, v) in zip(cells, variants.items()) if v["root"] == root_key)
        groups.append(f'<h2>{ROOT_LABELS[root_key]}</h2>\n<div class="grid">{cells_html}</div>')

    closure_html = "".join(f"<li><code>{c}</code></li>" for c in closures)
    split_rows = "".join(
        f'<tr><td><code>{k}</code></td><td>{_dump(v)}</td></tr>' for k, v in splits.items())

    return f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>DESIGN-2x4 标准 Layout · 布局抽象审核</title>
<style>
  :root{{--ink:rgba(0,0,0,.90);--ink2:rgba(0,0,0,.60);--ink3:rgba(0,0,0,.40);--brand:#0A59F7;}}
  *{{margin:0;padding:0;box-sizing:border-box;}}
  body{{background:#F1F3F5;color:var(--ink);font-family:'HarmonyOS Sans SC','PingFang SC',system-ui,sans-serif;padding:32px 40px 64px;}}
  h1{{font-size:22px;font-weight:700;}}
  .sub{{color:var(--ink2);font-size:13px;margin-top:6px;line-height:1.8;max-width:940px;}}
  h2{{font-size:16px;font-weight:700;margin:36px 0 14px;}}
  code{{background:#F1F3F5;border-radius:4px;padding:1px 6px;font-family:ui-monospace,Menlo,monospace;font-size:11.5px;color:var(--ink);}}
  .contract{{display:flex;gap:20px;align-items:flex-start;flex-wrap:wrap;margin-top:18px;}}
  .panel{{background:#fff;border-radius:12px;padding:14px 18px;font-size:12.5px;line-height:1.9;color:var(--ink2);}}
  .panel b{{color:var(--ink);}}
  .panel ul{{list-style:none;}}
  .panel table{{border-collapse:collapse;}}
  .panel td{{padding:2px 8px 2px 0;vertical-align:top;}}
  .grid{{display:grid;grid-template-columns:repeat(auto-fill,392px);gap:22px;justify-content:start;}}
  .cell{{background:#fff;border-radius:14px;padding:16px 18px 14px;box-shadow:0 1px 3px rgba(0,0,0,.05);}}
  .cell-head{{display:flex;align-items:center;gap:8px;margin-bottom:12px;}}
  .vid{{font-size:14px;font-weight:700;font-family:ui-monospace,Menlo,monospace;}}
  .root-chip{{font-size:11px;color:var(--brand);border:1px solid var(--brand);border-radius:10px;padding:1px 8px;}}
  .stage{{display:flex;justify-content:center;padding:10px 0 6px;background:repeating-conic-gradient(#eee 0 25%,#f8f8f8 0 50%) 0 0/16px 16px;border-radius:8px;}}
  .card-root{{width:{px(cv["width"])}px;height:{px(cv["height"])}px;background:#C4C4C4;overflow:hidden;}}
  .content-root{{width:100%;height:100%;display:flex;flex-direction:column;}}
  .titlebar{{background:rgba(255,255,255,.2);flex:none;}}
  .slotgap{{flex:none;}}
  .content-area{{flex:none;display:flex;}}
  .grp{{display:flex;}}
  .blk{{background:rgba(255,255,255,.2);flex:none;}}
  .capsule{{background:rgba(255,255,255,.2);flex:none;}}
  .meta{{margin-top:12px;}}
  .structure{{font-size:11.5px;color:var(--ink2);line-height:1.7;word-break:break-all;}}
  .skeleton{{font-size:11.5px;color:var(--ink3);margin-top:4px;}}
  .foot{{margin-top:40px;font-size:12px;color:var(--ink3);line-height:1.8;}}
</style>
</head>
<body>
<h1>DESIGN-2x4 标准 Layout · 布局抽象审核</h1>
<div class="sub">本页由 <code>design-check/scripts/build_layout_2x4_preview.py</code> 从
<code>DESIGN-2x4.md</code> frontmatter（<code>layout_slots</code>）解析生成，全部几何（尺寸 / gap / 圆角 / 段数）
来自规范文件，页面不硬编码任何布局数值；规范变更后重跑脚本再生成。权威来源：Pixso「布局抽象」item-id 60:280，
本地快照 <code>docs/pixso-layout-abstraction.md</code>。灰底与白 20% 块沿用布局抽象的占位语义。</div>
<div class="contract">
  <div class="panel"><b>画布契约（canvas）</b><br>
    root Stack <code>{cv["width"]}×{cv["height"]}</code> · 圆角 <code>{cv["root"]["borderRadius"]}</code> ·
    content_root padding <code>{cv["contentRoot"]["padding"]}</code><br>
    安全区 <code>{safe["width"]}×{safe["height"]}</code> · 布局模式 <code>{cv["layoutMode"]}</code></div>
  <div class="panel"><b>纵向闭合（verticalClosure · 136）</b><ul>{closure_html}</ul></div>
  <div class="panel"><b>分栏原子（splitRules）</b><table>{split_rows}</table></div>
</div>
{''.join(groups)}
<div class="foot">槽位语义参考 DESIGN.md（2×2）Slot Model：title-area / content-area / button-area，
以 layout_slots 为第一层布局契约，不从示意图反推绝对坐标。titled-action 的胶囊即 button-area 槽。</div>
</body>
</html>'''


def _dump(v) -> str:
    if isinstance(v, dict):
        return " ".join(f'<code>{k}={val}</code>' for k, val in v.items())
    return str(v)


def main():
    ls = load_layout_slots()
    html = build_html(ls)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(html, encoding="utf-8")
    print(f"OK: {len(ls['standardVariants'])} variants -> {OUT}")


if __name__ == "__main__":
    sys.exit(main())
