#!/usr/bin/env python3
"""从实际 tgz 重算 README-MACHINE.md 事实字段（Idea6-WP-R2）。

流程：pnpm pack（无 pnpm 时回退 npm pack，等价产出）→ 对 tgz 计算
sha256 / bytes / 文件数 → 重写 README-MACHINE.md 的 FACTS 区事实字段
（version / tarball / tarball_sha256 / tarball_bytes / tarball_files），
并同步 VERIFY-INTEGRITY / INSTALL 叙事区的 tgz 文件名、sha 预期行、
文件数预期——消灭手写漂移，其余文档内容不动。

用法：
    python3 design-check/scripts/build_machine_readme.py           # 重写事实字段
    python3 design-check/scripts/build_machine_readme.py --check   # 只比对，漂移退出码 1

临时 tgz 落在系统临时目录，用后即清（不在仓库根留产物）。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent  # 仓库根（Design-guide/）
README_MACHINE = ROOT / "README-MACHINE.md"

FACT_FIELDS = ("version", "tarball", "tarball_sha256", "tarball_bytes", "tarball_files")


def _clean_pycache() -> int:
    """pack 前清理 design-check/ 内 __pycache__（pnpm packlist 对 files 白名单目录内的
    排除规则一律不生效——.npmignore 与 files '!…' 否定均实测无效，2026-08-27 main 实证
    38 pyc 夹带；pack 输入不应依赖源树缓存垃圾，清缓存后重跑测试无碍）。返回清理目录数。
    """
    n = 0
    for d in (ROOT / "design-check").rglob("__pycache__"):
        if d.is_dir():
            shutil.rmtree(d, ignore_errors=True)
            n += 1
    return n


def _pack() -> tuple:
    """pnpm pack（回退 npm pack），返回 (tgz_path, 用了哪个打包器)。路径为仓库根相对名。"""
    _clean_pycache()
    for packer, cmd in (("pnpm", ["pnpm", "pack"]), ("npm", ["npm", "pack"])):
        if shutil.which(packer) is None:
            continue
        tmpdir = Path(tempfile.mkdtemp(prefix="dcp-pack-"))
        try:
            proc = subprocess.run(cmd + ["--pack-destination", str(tmpdir)],
                                  cwd=ROOT, capture_output=True, text=True)
            if proc.returncode != 0:
                raise SystemExit(
                    f"{packer} pack 失败（cwd={ROOT}）:\n{proc.stdout}\n{proc.stderr}")
            names = [ln.strip() for ln in proc.stdout.splitlines()
                     if ln.strip().endswith(".tgz")]
            if len(names) != 1:
                raise SystemExit(f"{packer} pack 输出无法定位 tgz: {proc.stdout!r}")
            return tmpdir / names[-1], packer
        except FileNotFoundError:
            shutil.rmtree(tmpdir, ignore_errors=True)
            continue
    raise SystemExit("环境内既无 pnpm 也无 npm，无法打 tgz")


def _tgz_facts(tgz: Path) -> dict:
    """从 tgz 实测：sha256 / bytes / 文件数 / 版本（文件数排除包根目录项 package/）。"""
    data = tgz.read_bytes()
    with tarfile.open(tgz, "r:gz") as tf:
        files = [m.name for m in tf.getmembers() if m.isfile()]
    version = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))["version"]
    return {
        "version": version,
        "tarball": tgz.name,
        "tarball_sha256": hashlib.sha256(data).hexdigest(),
        "tarball_bytes": str(len(data)),
        "tarball_files": str(len(files)),
        "_packer": None,
    }


def _read_current_facts(text: str) -> dict:
    """解析 FACTS 区现有事实字段（供 --check 比对）。"""
    facts = {}
    for field in FACT_FIELDS:
        m = re.search(rf"^{field}: *(.+?)\s*(?:#.*)?$", text, re.M)
        facts[field] = m.group(1).strip() if m else None
    return facts


def _sync_verify_block(text: str, measured: dict) -> str:
    """同步 VERIFY-INTEGRITY / INSTALL 叙事区：tgz 文件名（随版本）、sha 预期注释行、文件数预期。"""
    text = re.sub(r"design-card-check-plugin-\d+\.\d+\.\d+\.tgz",
                  measured["tarball"], text)
    text = re.sub(r"(?m)^# [0-9a-f]{64}(  design-card-check-plugin-[\d.]+\.tgz)$",
                  rf"# {measured['tarball_sha256']}\1", text)
    text = re.sub(r"(?m)^(tar -tzf design-card-check-plugin-[\d.]+\.tgz \| wc -l)\s*#\s*预期：\d+$",
                  rf"\1   # 预期：{measured['tarball_files']}", text)
    return text


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="不重写；只重算并与当前 FACTS 比对，漂移时打印差异并退出码 1")
    args = ap.parse_args(argv)

    tgz, packer = _pack()
    try:
        measured = _tgz_facts(tgz)
    finally:
        shutil.rmtree(tgz.parent, ignore_errors=True)

    text = README_MACHINE.read_text(encoding="utf-8")
    current = _read_current_facts(text)
    drift = {f: (current[f], measured[f]) for f in FACT_FIELDS
             if current.get(f) != measured.get(f)}
    verify_drift = _sync_verify_block(text, measured) != text
    if args.check:
        if drift or verify_drift:
            print(f"README-MACHINE 与实际 tgz 不一致（打包器={packer}）:")
            for f, (old, new) in drift.items():
                print(f"  FACTS {f}: 当前={old} 实测={new}")
            if verify_drift:
                print("  VERIFY-INTEGRITY/INSTALL 区: tgz 文件名 / sha 预期 / 文件数预期存在漂移")
            return 1
        print(f"README-MACHINE 与实际 tgz 一致（打包器={packer}，"
              f"{measured['tarball']} sha256={measured['tarball_sha256'][:12]}…）")
        return 0

    target = _sync_verify_block(text, measured)
    for field in drift:
        target = re.sub(
            rf"(?m)^{field}: .*$",
            lambda m, f=field: f"{f}: {measured[f]}" + _keep_comment(m.group(0), f),
            target)
    if target == text:
        print(f"README-MACHINE 已是最新（打包器={packer}），无需改写")
        return 0
    README_MACHINE.write_text(target, encoding="utf-8")
    print(f"已重写 README-MACHINE（打包器={packer}）: "
          + ", ".join(f"{f}: {current[f]} → {measured[f]}" for f in drift)
          + ("；VERIFY/INSTALL 叙事区已同步" if verify_drift else ""))
    return 0


def _keep_comment(old_line: str, field: str) -> str:
    """保留原行的行尾注释列（# …）。"""
    m = re.search(rf"(?m)^{field}: .*?(#.*)$", old_line)
    return f" {m.group(1)}" if m else ""


if __name__ == "__main__":
    sys.exit(main())
