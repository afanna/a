#!/usr/bin/env python3
"""四分支完整管线产物合并大报告：标准 report_b_eval 模板（build_visual）。

A3 重出不重跑（2026-08-26，Idea4-WP2）：数据源改为 review/cases/<qid>.json
逐卡产物（case_store CaseReport），不再逐卡 get_json 重跑 check_card——
秒级出报告，进程树中无 check_card.py 子进程。

用法:
    python3 scripts/build_merged_branch_report.py                # 默认抽检 12 卡
    python3 scripts/build_merged_branch_report.py --all          # review/cases/ 全量
    python3 scripts/build_merged_branch_report.py --qids "A-q42,B-q6"
    python3 scripts/build_merged_branch_report.py \
        --cases "A:q42,q61,q89;B:q6,q15,q54;C:Q006,Q069,Q071;MS:q26,q61,q78"
        （旧语法糖：分支:卡号列表 → qid 集合）

前置: 各卡已有 review/cases/<qid>.json（check_case 完整管线或 check_eval /
check_batch L1 批量写入）。产物: review/<YYYYMMDD>/<范围段>-visual-<YYYYMMDD>.html
（daily_review_dir，同日覆盖；命名走 derive_report_names，EVAL299 特判已收敛）。
内容 = 库内标准可视化模板（build_visual + CaseReport 徽章/notes/meta 推导），
dump 缺失的卡（L1 批量产物）线框为显式占位框。
"""
from __future__ import annotations

import argparse
import base64
import re
import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_DIR))
sys.path.insert(0, str(PROJECT_DIR / "scripts"))

import case_store  # noqa: E402
from report_b_eval import build_from_cases, derive_report_names  # noqa: E402
from validators.config import daily_review_dir, review_dir  # noqa: E402

DEFAULT_CASES = "A:q42,q61,q89;B:q6,q15,q54;C:Q006,Q069,Q071;MS:q26,q61,q78"


def inline_images(html: str) -> str:
    """把 ../vis-assets/* 引用替换为 base64 data URI，报告单文件自包含（可直接外发）。"""
    def repl(m):
        p = review_dir() / "vis-assets" / m.group(1)
        if not p.is_file():
            return m.group(0)
        b64 = base64.b64encode(p.read_bytes()).decode("ascii")
        return f'src="data:image/png;base64,{b64}"'
    return re.sub(r'src="\.\./vis-assets/([^"]+)"', repl, html)


def parse_cases(spec: str) -> list:
    """旧语法 'A:q42,q61;B:q6' → ['A-q42', 'A-q61', 'B-q6']（保留为语法糖）。"""
    qids = []
    for chunk in spec.split(";"):
        branch, _, cards = chunk.partition(":")
        for c in cards.split(","):
            if c.strip():
                qids.append(f"{branch.strip()}-{c.strip()}")
    return qids


def load_case_reports(qids: list) -> list:
    """逐 qid 读 review/cases/<qid>.json；缺失显式报错（含可定位路径），不静默降级。"""
    reports = []
    for qid in qids:
        try:
            reports.append(case_store.load_case_report(qid))
        except (FileNotFoundError, RuntimeError) as exc:
            print(f"错误: {exc}（先跑 check_case 完整管线或 check_eval/check_batch L1 批量）",
                  file=sys.stderr)
            raise SystemExit(2)
    return reports


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="四分支产物合并大报告（A3 重出不重跑：读 review/cases/）")
    src = parser.add_mutually_exclusive_group()
    src.add_argument("--cases", help="旧语法：分号分隔 分支:卡号列表（默认本轮抽检 12 卡）")
    src.add_argument("--qids", help="逗号分隔 qid 列表（如 A-q42,B-q6）")
    src.add_argument("--all", action="store_true", help="读 review/cases/ 全量产物")
    parser.add_argument("--scope", default=None,
                        help="范围段覆盖（缺省 derive_report_names 推导：单一来源用分支名，混合用 MIX）")
    args = parser.parse_args(argv)

    if args.all:
        cases_dir = review_dir() / "cases"
        if not cases_dir.is_dir():
            print(f"错误: {cases_dir} 不存在，先跑 check_case / check_eval / check_batch", file=sys.stderr)
            return 2
        qids = sorted(p.stem for p in cases_dir.glob("*.json"))
    elif args.qids:
        qids = [q.strip() for q in args.qids.split(",") if q.strip()]
    else:
        qids = parse_cases(args.cases or DEFAULT_CASES)
    if not qids:
        print("错误: 未解析到任何 qid", file=sys.stderr)
        return 2

    reports = load_case_reports(qids)
    for r in reports:  # 逐卡摘要与产物 JSON 一致（对账口径）
        s = r["summary"]
        print(f"[merge] {r['qid']}: {s['total']} (P0={s['p0']} P1={s['p1']} P2={s['p2']})")

    _, html = build_from_cases(reports, layout="dual", scope_label=args.scope)
    html = inline_images(html)
    fname = derive_report_names(reports, scope_label=args.scope)[1]
    out = daily_review_dir() / fname
    out.write_text(html, encoding="utf-8")
    print(f"生成: {out} {out.stat().st_size} bytes（图片已 base64 内嵌）")
    total = sum(r["summary"]["total"] for r in reports)
    print(f"findings 总数: {total}（来自 {len(reports)} 份逐卡产物，未重跑 check_card）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
