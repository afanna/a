#!/usr/bin/env python3
"""DESIGN.md 真值校准标尺渲染器（颜色校准 + 布局校准）。

从 DESIGN.md front-matter 解析全部 token（不手抄数值，保证与规范同源、可重复生成），
渲染一个自包含 HTML：review/calibration-sheet.html。

- 颜色校准：light token 分组色板（含规范 #RRGGBBAA 与 DSL #AARRGGBB 双标注）、
  themes.dark 对照、11 个渐变预设实际渲染 + 按钮配对、13 档 alpha 标尺。
- 布局校准：画布与安全区、间距刻度、圆角刻度、字号矩阵、2×2 槽位预算与高度预算、
  组件几何（按钮/列表行/进度环）。

单位约定：1vp 渲染为 1px（真实密度 3.5px/vp，仅作比例标尺）。
用法：python3 scripts/calibration_sheet.py [--out <html>]
"""
from __future__ import annotations

import argparse
import datetime
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import yaml  # type: ignore

from validators.design_contract import ALPHA_STEPS, _split_frontmatter  # noqa: E402
from validators.config import design_spec_path, review_dir  # noqa: E402

VP = lambda v: _num(v)  # noqa: E731


def _num(value):
    """'12vp' / 12 / '180deg' -> 数字（取第一个数字）。"""
    if isinstance(value, (int, float)):
        return float(value)
    m = re.search(r"-?\d+(?:\.\d+)?", str(value))
    return float(m.group(0)) if m else 0.0


def rrggbbaa_to_aarrggbb(h: str) -> str:
    """#RRGGBBAA -> #AARRGGBB（DSL 字节序）。"""
    return f"#{h[7:9]}{h[1:7]}".upper()


def parse_frontmatter() -> dict:
    fm = _split_frontmatter(design_spec_path().read_text(encoding="utf-8"))
    return yaml.safe_load(fm) or {}


def resolve(data: dict, value, depth: int = 0):
    """解析 {colors.brand} / {spacing.safe-margin} 模板引用。"""
    if depth > 4:
        return value
    if isinstance(value, str):
        m = re.fullmatch(r"\{([\w.-]+)\}", value.strip())
        if m:
            node = data
            for part in m.group(1).split("."):
                if isinstance(node, dict) and part in node:
                    node = node[part]
                else:
                    return value
            return resolve(data, node, depth + 1)
    return value


def gradient_css(spec: dict) -> tuple[str, list[str]]:
    """渐变预设 -> (css, stop 标注列表)。"""
    stops = spec.get("stops") or []
    pairs = []
    for s in stops:
        color = s["color"] if isinstance(s, dict) else s[0]
        off = s.get("offset", "") if isinstance(s, dict) else s[1]
        off = str(off).replace("%", "")
        pairs.append((color, off))
    stop_css = ", ".join(f"{c} {o}%" for c, o in pairs)
    if spec.get("type") == "radial":
        return f"background: radial-gradient(circle at 50% 0%, {stop_css});", [c for c, _ in pairs]
    return f"background: linear-gradient(180deg, {stop_css});", [c for c, _ in pairs]


def color_groups(colors: dict) -> list[tuple[str, list[str]]]:
    def group_of(name: str) -> str:
        if name in ("brand", "warning", "alert", "confirm"):
            return "语义色（brand / warning / alert / confirm）"
        for p in ("font_", "icon_", "background_", "comp_", "interactive_", "scene_"):
            if name.startswith(p):
                return {"font_": "文本 font_*", "icon_": "图标 icon_*", "background_": "宿主背景 background_*",
                        "comp_": "组件 comp_*", "interactive_": "交互态 interactive_*",
                        "scene_": "场景点缀 scene_*"}[p]
        return "其他"
    order = ["语义色（brand / warning / alert / confirm）", "文本 font_*", "图标 icon_*", "宿主背景 background_*",
             "组件 comp_*", "交互态 interactive_*", "场景点缀 scene_*", "其他"]
    grouped: dict[str, list[str]] = {}
    for name in colors:
        grouped.setdefault(group_of(name), []).append(name)
    return [(g, grouped[g]) for g in order if g in grouped]


def render_colors(data: dict) -> str:
    colors: dict = data.get("colors", {})
    dark: dict = (data.get("themes") or {}).get("dark") or {}
    h = ['<h2>一、颜色校准</h2>']

    # 1. light 分组色板
    h.append("<h3>1.1 colors（light 默认）分组色板</h3>")
    for gname, names in color_groups(colors):
        h.append(f"<div class='gname'>{gname}</div><div class='swatches'>")
        for n in names:
            v = str(colors[n])
            h.append(
                f"<div class='sw'><div class='chip' style='background:{v}'></div>"
                f"<div class='lbl'><b>{n}</b><span>{v.upper()}</span><span class='dsl'>DSL {rrggbbaa_to_aarrggbb(v)}</span></div></div>"
            )
        h.append("</div>")

    # 2. themes.dark 对照（仅列出覆盖的 token）
    h.append("<h3>1.2 themes.dark 覆盖对照</h3><table class='tbl'><tr><th>token</th><th>light</th><th>dark</th></tr>")
    for n, dv in dark.items():
        lv = colors.get(n, "—")
        h.append(f"<tr><td>{n}</td><td><span class='chip sm' style='background:{lv}'></span><code>{lv}</code></td>"
                 f"<td><span class='chip sm' style='background:{dv}'></span><code>{dv}</code></td></tr>")
    h.append("</table><p class='note'>未列出的 token 沿用 light 值。</p>")

    # 3. 渐变预设
    h.append("<h3>1.3 background_gradients（11 预设，按原 stops 渲染）</h3>")
    grads = {k: v for k, v in (data.get("background_gradients") or {}).items()
             if k != "cssVariableNaming" and isinstance(v, dict)}
    for name, spec in grads.items():
        css, stop_labels = gradient_css(spec)
        bcc = spec.get("buttonColorContext") or {}
        hue = str(bcc.get("primaryHue", ""))
        hue_rgb = hue[:7]
        if str(bcc.get("backgroundClass")) == "colored-gradient":
            btn = (f"<span class='cbtn' style='background:#FFFFFFFF;color:{hue}'>按钮</span>"
                   f"<span class='meta'>colored-gradient：白底 + {hue}</span>")
        else:
            btn = (f"<span class='cbtn' style='background:{hue_rgb}19;color:{hue_rgb}FF'>按钮</span>"
                   f"<span class='meta'>light-overlay：{hue_rgb}19 底 + {hue_rgb}FF 前景</span>")
        h.append(
            f"<div class='gradrow'><div class='gname'>{name}<span class='meta'>{spec.get('type')} · "
            f"{' / '.join(stop_labels)}</span></div><div class='gbar' style='{css}'></div>{btn}</div>"
        )
    h.append("<p class='note'>渐变 stops 必须原样使用，不得自行配对/手调/新建（Do's and Don'ts）。</p>")

    # 4. 13 档 alpha 标尺
    h.append("<h3>1.4 13 档 alpha 标尺（左黑右白双底验证）</h3><div class='alphas'>")
    for a in ALPHA_STEPS:
        pct = a / 255 * 100
        h.append(
            f"<div class='alpha'><div class='duo'><div class='onb' style='background:#000000{a:02X}'></div>"
            f"<div class='onw' style='background:#000000{a:02X}'></div></div>"
            f"<span>{a:02X} · {pct:.0f}%</span></div>"
        )
    h.append("</div>")
    return "".join(h)


def render_layout(data: dict) -> str:
    layout: dict = data.get("layout_slots") or {}
    spacing: dict = data.get("spacing") or {}
    rounded: dict = data.get("rounded") or {}
    typo: dict = data.get("typography") or {}
    hb = layout.get("heightBudget") or {}
    comps: dict = data.get("components") or {}
    h = ['<h2>二、布局校准</h2>']

    # 1. 画布与安全区
    h.append("<h3>2.1 画布与 12vp 安全区（1vp=1px）</h3><div class='canvases'>")
    for size in ("2x2", "2x4"):
        c = layout.get("canvas", {}).get(size, {})
        w, ht = int(VP(c.get("width", 160))), int(VP(c.get("height", 160)))
        sm = int(VP(resolve(data, c.get("safeMargin", 12))))
        h.append(
            f"<div class='cv' style='width:{w + 2}px;height:{ht + 2}px'>"
            f"<div class='safe' style='inset:{sm}px'></div>"
            f"<div class='cvtag'>{size} · {w}×{ht}vp · safe {sm}vp</div></div>"
        )
    h.append("</div>")

    # 2. 间距刻度
    h.append("<h3>2.2 spacing 间距刻度</h3>")
    h.append("<table class='tbl'><tr><th>token</th><th>vp</th><th>px(@3.5)</th><th>标尺</th></tr>")
    for n, v in spacing.items():
        vp = int(VP(v))
        h.append(f"<tr><td><code>{n}</code></td><td>{vp}</td><td>{vp*3.5:g}</td>"
                 f"<td><div class='rule' style='width:{vp*3}px'></div></td></tr>")
    h.append("</table>")

    # 3. 圆角刻度
    h.append("<h3>2.3 rounded 圆角刻度</h3><div class='radii'>")
    for n, v in sorted(rounded.items(), key=lambda kv: _num(kv[1])):
        r = int(VP(v))
        h.append(f"<div class='rad' style='border-radius:{r}px'><span>{n.replace('corner_radius_','')}<br>{r}vp</span></div>")
    h.append("</div><p class='note'>同功能同圆角：card-root 与按钮=level10(20)、标签=level2(4)、信息底板=level6(12)（2026-08-21 规范校准：card-root 由 level8/16vp 修正为 level10/20vp）。</p>")

    # 4. 字号矩阵
    h.append("<h3>2.4 typography 字号矩阵（45 角色，按当前字号渲染）</h3><div class='typegrid'>")
    for name, spec in sorted(typo.items(), key=lambda kv: (-_num(kv[1].get("fontSize", 0)), kv[0])):
        if not isinstance(spec, dict):
            continue
        fs, fw = int(VP(spec.get("fontSize", 12))), int(VP(spec.get("fontWeight", 400)))
        extra = " · metric" if "metric" in name else ""
        h.append(f"<div class='tcell'><div style='font-size:{fs}px;font-weight:{fw}'>永Aa56</div>"
                 f"<span>{name}<br>{fs}vp/{fw}{extra}</span></div>")
    h.append("</div>")

    # 5. 2x2 槽位预算
    h.append("<h3>2.5 2×2 槽位栅格与高度预算（安全区 126×126vp）</h3>")
    for label, parts in (("文字按钮栅格", [16, 8, 58, 8, 36]), ("图标按钮栅格", [16, 8, 64, 8, 30])):
        h.append(f"<div class='gname'>{label}（title/gap/content/gap/button）</div><div class='slots'>")
        names = ["title 16", "gap 8", "content", "gap 8", "button"]
        for part, nm in zip(parts, names):
            cls = "slot gap" if "gap" in nm else "slot"
            h.append(f"<div class='{cls}' style='height:{part}px'><span>{nm if 'gap' not in nm else ''} {part}</span></div>")
        h.append("</div>")
    h2b = hb.get("2x2", {})
    h.append("<table class='tbl'><tr><th>content-area 高度预算</th><th>vp</th></tr>")
    for k, v in h2b.items():
        h.append(f"<tr><td>{k}</td><td>{v}</td></tr>")
    h.append("</table>")

    # 6. 组件几何
    h.append("<h3>2.6 组件几何契约</h3><div class='comps'>")
    bp = comps.get("button-primary", {})
    bh = int(VP(bp.get("height", 36)))
    br = int(VP(resolve(data, bp.get("rounded", "{rounded.corner_radius_level10}"))))
    h.append(f"<div class='comp'><div class='pill' style='height:{bh}px;border-radius:{br}px;line-height:{bh}px'>主按钮</div>"
             f"<span>button-primary 高{bh}vp 圆角{br}vp</span></div>")
    bi = comps.get("button-icon-2x2", {})
    bsz = int(VP(bi.get("size", 30)))
    hot = int(VP(bi.get("minimumHotZone", 40)))
    h.append(f"<div class='comp'><div class='hotzone'><div class='iconbtn' style='width:{bsz}px;height:{bsz}px'>◎</div></div>"
             f"<span>button-icon-2x2 {bsz}×{bsz}vp（热区{hot}vp）</span></div>")
    lr = comps.get("list-row", {})
    lh = int(VP(lr.get("height", 32)))
    h.append(f"<div class='comp'><div class='listrow' style='height:{lh}px;line-height:{lh}px'>list-row · padding 0/8vp · body-s-regular</div>"
             f"<span>list-row 高{lh}vp</span></div>")
    h.append("</div><p class='note'>进度环：display-ring 外径52vp/描边6；paired-data-ring 外径44vp/描边6，两环间距固定24vp，环下标签4vp——示意按 DESIGN.md Progress 契约。</p>")
    return "".join(h)


def build_html(data: dict) -> str:
    today = datetime.date.today().isoformat()
    head = (
        "<!DOCTYPE html><html lang='zh'><head><meta charset='utf-8'>"
        "<title>DESIGN.md 真值校准标尺</title><style>"
        "body{font-family:HarmonyOS Sans SC,PingFang SC,sans-serif;margin:24px auto;max-width:1080px;color:#1a1a1a}"
        "h2{border-bottom:2px solid #0A59F7;padding-bottom:6px}h3{margin:24px 0 8px}code{background:#f4f5f7;padding:1px 5px;border-radius:3px}"
        ".swatches{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0 16px}"
        ".sw{width:150px;border:1px solid #e2e2e2;border-radius:8px;overflow:hidden}"
        ".chip{height:44px}.chip.sm{display:inline-block;width:18px;height:18px;vertical-align:-4px;border:1px solid #ccc;border-radius:4px}"
        ".lbl{padding:6px 8px;display:flex;flex-direction:column;font-size:12px;line-height:1.5}"
        ".lbl .dsl{color:#0A59F7}.gname{font-weight:600;margin:10px 0 4px}.meta{font-weight:400;color:#777;font-size:12px;margin-left:8px}"
        ".tbl{border-collapse:collapse;margin:8px 0 16px}.tbl th,.tbl td{border:1px solid #ddd;padding:4px 10px;font-size:13px;text-align:left}"
        ".gradrow{margin:10px 0}.gbar{height:40px;border-radius:8px;border:1px solid #eee}"
        ".cbtn{display:inline-block;padding:6px 16px;border-radius:20px;font-size:13px;margin-left:12px}"
        ".alphas{display:flex;flex-wrap:wrap;gap:10px}.alpha{text-align:center;font-size:12px}"
        ".duo{display:flex}.onb,.onw{width:34px;height:34px}.onb{background:#000}.onw{background:#fff}"
        ".canvases{display:flex;gap:24px;align-items:flex-end}.cv{position:relative;background:#F1F3F5;border:1px solid #999}"
        ".safe{position:absolute;border:2px dashed #E84026}.cvtag{position:absolute;left:0;bottom:-22px;font-size:12px;color:#555}"
        ".rule{height:10px;background:#0A59F7;display:inline-block;vertical-align:middle}"
        ".radii{display:flex;flex-wrap:wrap;gap:8px}.rad{width:64px;height:48px;background:#fff;border:2px solid #0A59F7;"
        "display:flex;align-items:center;justify-content:center;font-size:11px;text-align:center;color:#333}"
        ".typegrid{display:flex;flex-wrap:wrap;gap:8px}.tcell{width:108px;border:1px solid #eee;border-radius:8px;padding:8px;text-align:center}"
        ".tcell span{display:block;font-size:11px;color:#777;margin-top:6px}"
        ".slots{display:inline-flex;flex-direction:column;margin:6px 0 14px;border:2px solid #999;width:160px}"
        ".slot{width:100%;display:flex;align-items:center;justify-content:center;font-size:11px;color:#333}"
        ".slot.gap{background:#FFE9E4}.slot:not(.gap){border:1px dashed #0A59F7;background:#F5F9FF}"
        ".comps{display:flex;gap:24px;align-items:flex-end;flex-wrap:wrap}.comp{text-align:center;font-size:12px;color:#555}"
        ".pill{background:#0A59F7;color:#fff;padding:0 18px;width:max-content}"
        ".hotzone{border:2px dashed #E84026;width:40px;height:40px;display:flex;align-items:center;justify-content:center;margin:0 auto}"
        ".iconbtn{background:#0000000C;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:14px}"
        ".listrow{background:#fff;border:1px solid #ddd;padding:0 8px;font-size:12px;color:#333;width:max-content}"
        ".note{font-size:12px;color:#888}"
        "</style></head><body>"
        f"<h1>DESIGN.md 真值校准标尺</h1>"
        f"<p class='note'>来源：DESIGN.md front-matter 程序化解析生成（scripts/calibration_sheet.py），"
        f"生成日期 {today}；1vp=1px（真实密度 3.5px/vp）。DSL 色标注为 #AARRGGBB 字节序。</p>"
    )
    return head + render_colors(data) + render_layout(data) + "</body></html>"


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="DESIGN.md 真值校准标尺渲染器")
    parser.add_argument("--out", default=None, help="输出 HTML（默认 review/calibration-sheet.html）")
    args = parser.parse_args(argv)
    data = parse_frontmatter()
    out = Path(args.out) if args.out else review_dir() / "calibration-sheet.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(build_html(data), encoding="utf-8")
    print(f"校准标尺已生成: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
