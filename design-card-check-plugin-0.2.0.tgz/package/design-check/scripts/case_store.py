#!/usr/bin/env python3
"""统一逐卡落盘 review/cases/<qid>.json（docs/plan-pipeline-io-generalization.md F3）。

schema v1（唯一逐卡真值；F4 报告构建器只消费本产物，不再重跑 check_card）：

    {
      "schema": "design-check/case-report/v1",
      "qid": "B-q6",
      "source": {"kind": "branch|qdir|dsl", "label": "B", "dsl_path": "…"},
      "size": "2x4",
      "dump": {"present": true, "path": "review/dumps/B-q6.layout.json",
               "origin": "fresh|reused|render-evidence"},
      "screenshot": {"present": true, "path": "review/vis-assets/B-q6.png",
                     "kind": "net-shot|device-capture|none"},
      "summary": {"total": 12, "p0": 0, "p1": 11, "p2": 1},
      "findings": [ … Finding.to_dict() … ],
      "notes": ["…人工注记…（WP1 一律空数组，q1/q4 注记迁移属 F4）…"]
    }

写入方（本 WP）：check_case（dump 实测口径）、check_eval / check_batch（L1 批量，
dump/screenshot 字段 absent 标注，保持 schema 一致）。读方接口 load_case_report
为 F4 预留。纯函数、无副作用依赖（落盘仅 write_case_report 一处），可全离线单测。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from validators.config import review_dir

#: 产物 schema 标识（读方按此判别口径）
CASE_SCHEMA = "design-check/case-report/v1"

#: 评测集补零 qid 归一（F3 末条）：A-q001 → A-q1（stem 口径，与 review/dumps 对齐）
_PADDED_TAIL = re.compile(r"^(q|Q)0+(\d+)$")


def normalize_eval_case(case: str) -> str:
    """评测分支卡号补零归一：q001 → q1，Q004 → Q4；非补零形态原样返回。

    仅用于评测集 token/qid 归一（A/B/C/MS 分支）；SET93 qdir（q010 是数据集
    目录名）与裸 DSL stem 不做归一（review/dumps 现名 SET93-q010 / C-Q004 口径
    以文件 stem 为准，本函数不改它们——调用方自行决定是否传入）。
    """
    m = _PADDED_TAIL.match(case.strip())
    if m:
        return f"{m.group(1)}{m.group(2)}"
    return case


def normalize_eval_qid(qid: str) -> str:
    """A-q001 / MS-q003 → A-q1 / MS-q3（保留前缀，仅归一尾部补零卡号）。"""
    if "-" not in qid:
        return normalize_eval_case(qid)
    head, _, tail = qid.rpartition("-")
    return f"{head}-{normalize_eval_case(tail)}"


def case_report_path(qid: str, root: Path | None = None) -> Path:
    """逐卡产物路径 review/cases/<qid>.json（root 可注入，测试用）。"""
    base = Path(root) if root else review_dir()
    return base / "cases" / f"{qid}.json"


def dump_field(path: Path | str, origin: str) -> dict:
    """dump 在场口径：origin ∈ fresh（本次真机采集）/ reused（复用既有 dump）/
    render-evidence（数据集 render-evidence dump 借用）。"""
    if origin not in ("fresh", "reused", "render-evidence"):
        raise ValueError(f"非法 dump origin: {origin!r}（可选 fresh/reused/render-evidence）")
    return {"present": True, "path": str(path), "origin": origin}


def dump_absent() -> dict:
    """dump 缺席口径（check_eval / check_batch L1 批量，无 L2 渲染）。"""
    return {"present": False, "path": None, "origin": None}


def screenshot_field(path: Path | str, kind: str) -> dict:
    """截图在场口径：kind ∈ net-shot（现网实拍）/ device-capture（本机采集）。"""
    if kind not in ("net-shot", "device-capture"):
        raise ValueError(f"非法 screenshot kind: {kind!r}（可选 net-shot/device-capture）")
    return {"present": True, "path": str(path), "kind": kind}


def screenshot_absent() -> dict:
    return {"present": False, "path": None, "kind": "none"}


def summarize_findings(findings: list) -> dict:
    """findings（Finding.to_dict() 列表）→ {total, p0, p1, p2}。"""
    sev = {"P0": 0, "P1": 0, "P2": 0}
    for f in findings or []:
        s = f.get("severity")
        if s in sev:
            sev[s] += 1
    return {"total": len(findings or []), "p0": sev["P0"], "p1": sev["P1"], "p2": sev["P2"]}


def build_case_report(qid: str, source_kind: str, source_label: str, dsl_path: Path | str,
                      size: str, dump: dict, screenshot: dict, findings: list,
                      notes: list | None = None) -> dict:
    """组装单卡产物 dict（不落盘）。source_kind ∈ branch/qdir/dsl。"""
    if source_kind not in ("branch", "qdir", "dsl"):
        raise ValueError(f"非法 source kind: {source_kind!r}（可选 branch/qdir/dsl）")
    return {
        "schema": CASE_SCHEMA,
        "qid": qid,
        "source": {"kind": source_kind, "label": source_label, "dsl_path": str(dsl_path)},
        "size": size,
        "dump": dump,
        "screenshot": screenshot,
        "summary": summarize_findings(findings),
        "findings": list(findings or []),
        "notes": list(notes or []),
    }


def write_case_report(report: dict, root: Path | None = None) -> Path:
    """落盘 review/cases/<qid>.json（同 qid 重跑覆盖）+ 不降级保护。

    不降级保护（WP1 验收缺陷修复 + WP2 补丁扩展）：同一 qid 存在双写入方——
    check_case 完整版（dump/screenshot 实测 + notes 人工注记）与 check_eval /
    check_batch L1 批量版（absent 口径 + notes 空数组）。
    - 若目标已存在且 旧版 dump/screenshot present 为 true 而新写入为 absent，
      则继承旧版对应字段（findings/summary 照常按新写入刷新——L1 结果可更新，
      实测元数据不丢）；两版都 present 按新写入（重采场景）；
    - notes 同理（WP2 提前，原计划 WP3）：旧版 notes 非空而新写入为空 → 继承
      旧版（q1/q4 人工注记不被批量写入清空）；新写入非空则按新写入。
    """
    path = case_report_path(report["qid"], root)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        try:
            old = json.loads(path.read_text(encoding="utf-8-sig"))
        except (json.JSONDecodeError, OSError):
            old = None
        if isinstance(old, dict):
            for key in ("dump", "screenshot"):
                old_field = old.get(key) or {}
                if old_field.get("present") and not report[key].get("present"):
                    report[key] = old_field
            old_notes = old.get("notes") or []
            if old_notes and not report.get("notes"):
                report["notes"] = old_notes
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def load_case_report(qid_or_path: str | Path, root: Path | None = None) -> dict:
    """读回逐卡产物（F4 报告构建器预留入口）。

    入参可为 qid（review/cases/<qid>.json）或产物文件路径本身；缺失/非本
    schema 显式报错（含可定位路径）。
    """
    raw = str(qid_or_path)
    p = Path(raw)
    if "/" not in raw and p.suffix != ".json":  # 纯 qid（如 B-q6）→ 产物路径
        p = case_report_path(raw, root)
    if not p.is_file():
        raise FileNotFoundError(f"逐卡产物不存在: {p}")
    data = json.loads(p.read_text(encoding="utf-8-sig"))
    if data.get("schema") != CASE_SCHEMA:
        raise RuntimeError(f"非 {CASE_SCHEMA} 产物: {p}（实际 schema: {data.get('schema')!r}）")
    return data
