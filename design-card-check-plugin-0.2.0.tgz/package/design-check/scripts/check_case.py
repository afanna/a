#!/usr/bin/env python3
"""WP-PIPE 一键管线：指定 case → 自动 DumpLayout → 可视化报告（单一入口）。

2026-08-22 试跑 7 问题的固化（对应 docs/plan.md「L2 真值通道 B 端到端」遗留）：
  1. 通道 B 桥接断裂   → 复用 render_eval_dump.render_and_dump（正牌链路，
                        render_dump.py 骨架不动）；
  2. 模拟器自恢复      → device_utils.ensure_device（tconn + pgrep 自检 + 启动
                        + 轮询 ≤150s，替代手工重启）；
  3. dump 质量守卫     → device_utils.verify_dump_has_bundle + aa start 重拉
                        一次，再失败硬失败（防 b-q1 首版截到桌面无人发现）；
  4. 五步手工拼接      → 本文件单一入口；
  5. CARDS 硬编码      → report_b_eval.generate_reports(scope, cases, data) 参数化；
  6. 评测集整体 JSON 数组 → 归一化三行式 card.genui.jsonl + task-spec size
                        （root styles width ≥300 → 2x4，trio 注入 __viewport__；
                        否则 2x2）；MS 缺 updateDataModel 属合法形态（trio 直写回退）；
  7. 产物命名          → AGENTS.md <范围>-<卡号>-<类型>-<YYYYMMDD>.<ext>
                        （report_b_eval.report_names 动态日期）；
  8. 批量韧性(2026-08-25) → 单卡失败不拖垮整批（记录后跳过继续，报告只含成功卡）；
                        渲染瞬时故障（hvigor 构建抖动 / 设备瞬断，B-q27 型）自动
                        恢复设备并重试一次；卡间失联重走 ensure_device；
                        退出码 0=全成功 / 1=部分失败 / 2=环境错误或全部失败。

流水线（每步显式报错含路径/原因，不静默降级）：
  a. 解析输入：分支名映射目录 + 归一化三件套落 review/pipeline/<范围>-<卡号>/；
  b. trio 转换：subprocess 调外层 scripts/preview/render_batch_trio.py（列表参数，
     不 shell 拼接；外层仓库只读）→ review/pipeline/<范围>-<卡号>-work/；
  c. 设备前置：device_utils.ensure_device（需采集时）；
  d. 渲染 + dump：render_eval_dump.render_and_dump 逐卡 → review/dumps/<范围-卡号>.layout.json；
  e. dump 守卫：bundleName == com.example.myapplication 节点存在性，失败 aa start
     重拉再 dump 一次，仍失败硬失败退出非 0；
  f. 检查：scripts/check_card.py（93 条集走 --qdir 原路径，其余 --dsl 三件套）；
  g. 线框：scripts/wireframe.py → review/<范围-卡号>_wireframe/；
  h. 报告：report_b_eval.generate_reports → 问题清单 JSON + 可视化 HTML；
     现网截图（评测集 images/<卡号>）存在则复制 review/vis-assets/<范围-卡号>.png；
  i. 终端五段式输出（AGENTS.md 汇报规范）。

用法：
    python3 scripts/check_case.py --cases "A:q42,B:q6,SET93:q010,DSL:/path/x.jsonl"
                                                            # 混合语法（F1 统一入口）
    python3 scripts/check_case.py --branch B --case q10          # 评测集分支卡（旧入口=语法糖）
    python3 scripts/check_case.py --branch B --case q1,q4,q7    # 多卡
    python3 scripts/check_case.py --dsl <path>                  # 任意裸 DSL（自动归一化）
    python3 scripts/check_case.py --qdir q010 --reuse-dump      # 93 条集卡，已有 dump 则跳过采集
    python3 scripts/check_case.py --cases MS-q59 --reuse-dump --include-delegated

退出码契约（Idea6-WP-E3）：
    0 = 批量管线完成、全部卡成功（产物照常生成；单卡 P0 违规与否见各卡
        报告/问题清单，单卡退出码三态由 check_card.py 契约承载）；
    1 = 批量部分失败（报告只含成功卡，失败明细 stderr 列出）；
    2 = 管线自身故障（输入缺失/非法、环境错误、全部卡失败、未预期异常——stderr 输出
        异常类型与可定位路径/卡号，不生成伪违规 finding）。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from device_utils import ensure_device, load_hdc_path, verify_dump_has_bundle  # noqa: E402
from render_eval_dump import load_automation_config, render_and_dump  # noqa: E402
from case_store import (build_case_report, dump_field, load_case_report,  # noqa: E402
                        normalize_eval_case, screenshot_absent, screenshot_field,
                        write_case_report)
from report_b_eval import generate_reports  # noqa: E402
from validators.config import card_data_dir, eval_root, pipeline_dir, review_dir  # noqa: E402
from validators.dataset import render_evidence_layout_path  # noqa: E402
from validators.dsl import GENUI_OPS, parse_dsl_records  # noqa: E402

PROJECT_DIR = Path(__file__).resolve().parents[1]
#: 评测分支 → 第一次评测/ 下 DSL 目录（只读引用；B 在 dsl/ 子目录、C 大写 Q 命名）
BRANCH_DIRS = {
    "A": "A(晓峰单独分支——一步走)",
    "B": "B(现网分支)/dsl",
    "C": "C(冰心_水峰分支——模板)",
    "MS": "晓峰——多步走",
}
#: 与 render_batch_trio.parse_q_dir 一致的批内 q 目录名约束
Q_DIR_RE = re.compile(r"^q\d+$", re.IGNORECASE)


@dataclass
class CardSpec:
    """单卡全流程规格（路径均绝对，派生输出位于 review/pipeline 与 review/dumps）。"""
    scope: str            # A/B/C/MS/DSL/SET93
    card: str             # 卡号（q10 / Q004 / q010 / 裸 DSL stem）
    dsl_path: Path        # 输入裸 DSL（评测集 / 93 条集 / 任意路径）
    messages: list        # 归一化 genui message（在场 op 各一条）
    size: str             # 2x2 / 2x4（root width ≥300 → 2x4）
    case_dir: Path        # review/pipeline/<范围>-<卡号>/（三件套）
    batch_root: Path      # review/pipeline/<范围>-<卡号>-batch/（喂 render_batch_trio.py）
    work_dir: Path        # review/pipeline/<范围>-<卡号>-work/（trio 转换产物）
    dump_path: Path       # review/dumps/<范围-卡号>.layout.json
    qdir_arg: str | None  # 93 条集原 qdir（check_card --qdir 用），其余 None
    qdir_name: str = ""   # 批内 q 目录名（q10/Q004/…）
    screenshot: Path | None = None  # 采集截图（wireframe --screen）
    dump_origin: str | None = None  # dump 采集方式（fresh/reused/render-evidence，F3 落盘用）


# ---------------------------------------------------------------- 步骤 a：解析输入

def _num(v):
    """数值化（int/float/数字字符串）；无法解析返回 None。"""
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        try:
            return float(v)
        except ValueError:
            return None
    return None


def probe_size(records: list) -> str:
    """从 root 组件 styles width 探测尺寸：≥300 → 2x4，否则 2x2。

    依据：任务 6 与 docs/plan.md 2026-08-22「2×4 卡（root width ≥300vp）需在
    task-spec 写 size 让 trio 注入 __viewport__」。A 分支 root width 为
    matchParent（98/98），其尺寸在 createSurface（40 张 320×160 → 2x4），
    故 root 无数值时回退 createSurface.width。探测不到数值按 2x2（保守默认）。

    2026-08-22 修复（A 抽检 5 张 2×4 卡被误判 2x2）：root_w 只认 root 组件
    （updateComponents.root 指定的 id，回退 id=root / 首个组件）；此前实现
    取「第一个有数值 width 的组件」，A 卡 root=matchParent 时被 title_area
    等 296vp 组件截胡（<300 判 2x2），createSurface 回退不生效，2×4 卡按
    2×2 viewport 渲染产生批量 DIMENSION_DRIFT/SAFE_AREA_OVERFLOW 伪影。
    """
    root_w = surface_w = None
    for rec in records:
        if not isinstance(rec, dict):
            continue
        msg = rec.get("updateComponents")
        if isinstance(msg, dict):
            comps = [c for c in msg.get("components") or [] if isinstance(c, dict)]
            root_id = msg.get("root")
            root_c = None
            if root_id:
                root_c = next((c for c in comps if c.get("id") == root_id), None)
            if root_c is None:
                root_c = next((c for c in comps if c.get("id") == "root"), None)
            if root_c is None and comps:
                root_c = comps[0]
            if root_c is not None:
                w = _num((root_c.get("styles") or {}).get("width"))
                if w is not None:
                    root_w = w
        cs = rec.get("createSurface")
        if isinstance(cs, dict):
            surface_w = _num(cs.get("width"))
    w = root_w if root_w is not None else surface_w
    if w is None:
        return "2x2"
    return "2x4" if w >= 300 else "2x2"


def normalize_dsl(dsl_path: Path) -> tuple[list, str]:
    """裸 DSL → (在场 genui message 列表, 探测尺寸)。

    兼容两种产物形态（复用 validators.dsl.parse_dsl_records）：评测集单文件整体
    JSON 数组（createSurface/updateComponents/updateDataModel 各一条）与逐行 JSONL；
    缺某 op 只写在场条数（MS 缺 updateDataModel 合法）。
    """
    dsl_path = Path(dsl_path)
    if not dsl_path.is_file():
        raise FileNotFoundError(f"DSL 文件不存在: {dsl_path}")
    text = dsl_path.read_text(encoding="utf-8-sig")
    if not text.strip():
        raise RuntimeError(f"DSL 文件为空: {dsl_path}")
    records = parse_dsl_records(text)
    by_op = {}
    for rec in records:
        if not isinstance(rec, dict):
            continue
        for op in GENUI_OPS:
            if op in rec and op not in by_op:
                by_op[op] = rec
    messages = [by_op[op] for op in GENUI_OPS if op in by_op]
    if not messages:
        raise RuntimeError(f"DSL 中未解析到 genui message（createSurface/updateComponents/updateDataModel）: {dsl_path}")
    return messages, probe_size(records)


def write_trio(case_dir: Path, messages: list, size: str, query: str = "") -> None:
    """归一化三件套：card.genui.jsonl（逐行 JSONL）+ task-spec.json（size）+ query.txt。"""
    case_dir.mkdir(parents=True, exist_ok=True)
    (case_dir / "card.genui.jsonl").write_text(
        "\n".join(json.dumps(m, ensure_ascii=False) for m in messages) + "\n",
        encoding="utf-8")
    (case_dir / "task-spec.json").write_text(
        json.dumps({"size": size, "userQuery": query}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    (case_dir / "query.txt").write_text(query, encoding="utf-8")


def _qdir_name(card: str, idx: int) -> str:
    r"""批内 q 目录名：卡号符合 ^q\d+$（含 Q004）直接用，否则稳定改写（裸 DSL）。"""
    if Q_DIR_RE.match(card):
        return card
    base = re.sub(r"[^0-9A-Za-z]", "", card)[:24] or f"c{idx}"
    return f"q{base}"


def resolve_branch_dsl(branch: str, case: str) -> Path:
    """分支目录下定位卡片 DSL（先精确 <case>.jsonl / q<case>.jsonl，再大小写不敏感兜底）。

    精确匹配按目录清单文件名比对（macOS 默认文件系统大小写不敏感，
    ``Path.is_file()`` 会把 q004.jsonl 误匹配到 Q004.jsonl，须以文件名集合校验）。
    """
    d = eval_root() / BRANCH_DIRS[branch]
    if not d.is_dir():
        raise RuntimeError(f"分支目录不存在: {d}")
    exact = {f.name for f in d.iterdir() if f.is_file() and f.suffix == ".jsonl"}
    for name in (f"{case}.jsonl", f"q{case}.jsonl"):
        if name in exact:
            return d / name
    lower = case.lower()
    for f in sorted(d.iterdir()):
        if f.suffix == ".jsonl" and f.stem.lower() in (lower, "q" + lower):
            return f
    raise RuntimeError(f"分支 {branch} 下找不到卡片 {case!r}（目录: {d}，请核对文件名）")


def spec_from_dsl(scope: str, dsl_path: Path, card: str) -> CardSpec:
    """评测集分支卡 / 任意裸 DSL → CardSpec（尺寸探测后落盘路径）。"""
    messages, size = normalize_dsl(dsl_path)
    return CardSpec(
        scope=scope, card=card, dsl_path=dsl_path, messages=messages, size=size,
        case_dir=review_dir() / "pipeline" / f"{scope}-{card}",
        batch_root=review_dir() / "pipeline" / f"{scope}-{card}-batch",
        work_dir=review_dir() / "pipeline" / f"{scope}-{card}-work",
        dump_path=review_dir() / "dumps" / f"{scope}-{card}.layout.json",
        qdir_arg=None,
    )


def spec_from_qdir(qdir: str) -> CardSpec:
    """93 条数据集卡 → CardSpec（size 取数据集 task-spec.json，缺失再探测）。"""
    src = card_data_dir() / qdir
    genui = src / "card.genui.jsonl"
    if not genui.is_file():
        raise RuntimeError(f"case 目录不存在或缺少 DSL: {genui}")
    messages, probed = normalize_dsl(genui)
    size = "2x2"
    spec_path = src / "task-spec.json"
    if spec_path.is_file():
        try:
            cand = json.loads(spec_path.read_text(encoding="utf-8-sig")).get("size")
            if cand in ("2x2", "2x4"):
                size = cand
        except (json.JSONDecodeError, AttributeError):
            pass
    else:
        size = probed
    query = (src / "query.txt").read_text(encoding="utf-8-sig").strip() if (src / "query.txt").is_file() else ""
    return CardSpec(
        scope="SET93", card=qdir, dsl_path=genui, messages=messages, size=size,
        case_dir=review_dir() / "pipeline" / f"SET93-{qdir}",
        batch_root=review_dir() / "pipeline" / f"SET93-{qdir}-batch",
        work_dir=review_dir() / "pipeline" / f"SET93-{qdir}-work",
        dump_path=review_dir() / "dumps" / f"SET93-{qdir}.layout.json",
        qdir_arg=qdir,
    )


def parse_cases_arg(cases_str: str) -> list[CardSpec]:
    """F1 统一混合语法："A:q42,B:q6,SET93:q010,DSL:/path/x.jsonl" → list[CardSpec]。

    逐项按前缀分发（复用 resolve_branch_dsl / spec_from_dsl / spec_from_qdir）：
      - A/B/C/MS:<case>  → 评测分支卡（token 补零归一到 stem 口径，如 q001 → q1，
        产物 qid 与 review/dumps 文件名对齐——计划 F3 末条）；
      - SET93:<qdir>     → 93 条集 q 目录（qdir 是数据集目录名，不归一）；
      - DSL:<path>       → 任意裸 DSL；
      - 无前缀           → 按裸 DSL 路径容错。
    非法 token 显式报错并带原始串（可定位）。
    """
    specs: list[CardSpec] = []
    for idx, raw in enumerate(t for t in (t.strip() for t in cases_str.split(",")) if t):
        if ":" in raw:
            prefix, _, value = raw.partition(":")
            prefix_u = prefix.upper()
            if prefix_u in BRANCH_DIRS:
                if not value:
                    raise RuntimeError(f"--cases 第 {idx + 1} 项缺少卡号（原始 token: {raw!r}）")
                # 先按原 token 解析（兼容 C:q004 → Q004.jsonl 大小写兜底），
                # 再按补零归一形式（A:q001 → q1.jsonl）——产物 qid 一律取文件 stem
                candidates = [value]
                norm = normalize_eval_case(value)
                if norm != value:
                    candidates.append(norm)
                last_exc: Exception | None = None
                dsl_path = None
                for cand in candidates:
                    try:
                        dsl_path = resolve_branch_dsl(prefix_u, cand)
                        break
                    except RuntimeError as exc:
                        last_exc = exc
                if dsl_path is None:
                    raise RuntimeError(f"--cases 第 {idx + 1} 项解析失败（原始 token: {raw!r}）: {last_exc}")
                specs.append(spec_from_dsl(prefix_u, dsl_path, dsl_path.stem))
            elif prefix_u == "SET93":
                if not value:
                    raise RuntimeError(f"--cases 第 {idx + 1} 项缺少 qdir（原始 token: {raw!r}）")
                specs.append(spec_from_qdir(value))
            elif prefix_u == "DSL":
                if not value:
                    raise RuntimeError(f"--cases 第 {idx + 1} 项缺少路径（原始 token: {raw!r}）")
                p = Path(value).resolve()
                specs.append(spec_from_dsl("DSL", p, p.stem))
            else:
                raise RuntimeError(
                    f"--cases 第 {idx + 1} 项无法识别的前缀 {prefix!r}"
                    f"（原始 token: {raw!r}；可选前缀: {', '.join(BRANCH_DIRS)}/SET93/DSL）")
        else:  # 无前缀纯路径 → 裸 DSL 容错
            p = Path(raw).resolve()
            specs.append(spec_from_dsl("DSL", p, p.stem))
    if not specs:
        raise RuntimeError("--cases 为空或未解析到任何卡片")
    return specs


def build_specs(args) -> list[CardSpec]:
    """按 CLI 形态解析输入（--cases 混合语法 / --qdir / --dsl / --branch+--case）。"""
    if getattr(args, "cases", None):
        return parse_cases_arg(args.cases)
    if args.qdir:
        return [spec_from_qdir(args.qdir)]
    if args.dsl:
        dsl_path = Path(args.dsl).resolve()
        return [spec_from_dsl("DSL", dsl_path, dsl_path.stem)]
    scope = args.branch.upper()
    if scope not in BRANCH_DIRS:
        raise RuntimeError(f"未知分支 {args.branch!r}（可选: {', '.join(BRANCH_DIRS)}）")
    specs = []
    for case in (c.strip() for c in args.case.split(",")):
        if not case:
            continue
        dsl_path = resolve_branch_dsl(scope, case)
        specs.append(spec_from_dsl(scope, dsl_path, dsl_path.stem))
    return specs


def prepare_case(spec: CardSpec) -> None:
    """归一化三件套落 review/pipeline/<范围>-<卡号>/，并建 -batch/<q> 包装目录（喂 trio）。"""
    write_trio(spec.case_dir, spec.messages, spec.size)
    spec.qdir_name = _qdir_name(spec.card, 0)
    wrapper = spec.batch_root / spec.qdir_name
    wrapper.mkdir(parents=True, exist_ok=True)
    for name in ("card.genui.jsonl", "task-spec.json", "query.txt"):
        shutil.copy2(spec.case_dir / name, wrapper / name)
    print(f"  [a] 三件套: {spec.case_dir}（size={spec.size}，{len(spec.messages)} 条 message）")


# ---------------------------------------------------------------- 步骤 b：trio 转换

def write_converted(dsl_path: Path, messages: list, size: str) -> None:
    """按 render_batch_trio 同格式写转换产物：[{__viewport__: size}, *messages]。"""
    dsl_path.parent.mkdir(parents=True, exist_ok=True)
    dsl_path.write_text(
        json.dumps([{"__viewport__": size}, *messages], ensure_ascii=False, indent=2),
        encoding="utf-8")


def run_trio(spec: CardSpec) -> Path:
    """subprocess 调外层 render_batch_trio.py 转换（列表参数，不 shell 拼接）。

    外层仓库只读引用（PIPELINE_DIR 经 validators.config.pipeline_dir 解析）。
    MS 等缺 updateDataModel 形态：trio 的 parse_q_dir 要求 3 条会跳过，按同格式
    直写转换产物（显式打印，不静默降级）。
    """
    trio = pipeline_dir() / "scripts" / "preview" / "render_batch_trio.py"
    if not trio.is_file():
        raise RuntimeError(f"外层管线 render_batch_trio.py 不存在: {trio}（检查 PIPELINE_DIR/外层仓库）")
    cmd = [sys.executable, str(trio), str(spec.batch_root),
           "--tag", "pipe", "--out-dir", str(spec.work_dir)]
    print(f"  [b] trio 转换: {' '.join(cmd)}")
    sys.stdout.flush()  # 管道重定向时保证步骤进度先于子进程输出落盘
    proc = subprocess.run(cmd)
    if proc.returncode != 0:
        raise RuntimeError(f"trio 转换失败（退出码 {proc.returncode}）: {spec.batch_root}")
    dsl = spec.work_dir / "dsl" / f"pipe_{spec.qdir_name}.jsonl"
    if not dsl.is_file():
        if len(spec.messages) < len(GENUI_OPS):
            print(f"  [b] trio 跳过 {spec.qdir_name}（仅 {len(spec.messages)} 条 message，其 parse_q_dir 要求 3 条）"
                  f"——按 trio 同格式直写转换产物（__viewport__={spec.size}）")
            write_converted(dsl, spec.messages, spec.size)
        else:
            raise RuntimeError(f"trio 转换未产出 {dsl}（转换器跳过该卡，原因见其输出）")
    return dsl


# ------------------------------------------------------------ 步骤 c/d/e：采集 + 守卫

def repull_and_dump(automation_root: Path, sn: str | None, qid: str, dump_path: Path) -> Path:
    """dump 守卫失败后：aa start 重拉已注入 rawfile 的应用 → 再 dump 一次。"""
    config = load_automation_config(automation_root, sn)
    from automation.pipeline import AutomationPipeline  # noqa: E402
    pipeline = AutomationPipeline(config, None)
    print(f"  [e] 重拉: aa start -a {config.ability_name} -b {config.bundle_name} -m {config.module_name}")
    pipeline.hdc.shell("aa", "start", "-a", config.ability_name,
                       "-b", config.bundle_name, "-m", config.module_name, timeout=30)
    time.sleep(config.render_wait)
    return pipeline.hdc.dump_layout(dump_path, f"/data/local/tmp/{qid}.layout.json")


def render_and_guard(spec: CardSpec, sn: str | None, automation_root: Path, converted: Path) -> None:
    """逐卡 render + dumpLayout，随后 dump 质量守卫（aa start 重拉一次，再失败硬失败）。"""
    qid = f"{spec.scope}-{spec.card}"
    print(f"  [d] 渲染 + dump: {qid}")
    results = render_and_dump([(qid, converted)], sn, automation_root)
    r = results[0]
    if not r.get("rendered") or not r.get("dumped"):
        raise RuntimeError(f"渲染/dump 失败 {qid}: {r.get('error')}")
    spec.screenshot = Path(r["screenshot"])
    try:
        verify_dump_has_bundle(spec.dump_path)
    except RuntimeError:
        print("  [e] dump 未包含渲染应用（可能截到桌面），aa start 重拉后重试一次…")
        repull_and_dump(automation_root, sn, qid, spec.dump_path)
        try:
            verify_dump_has_bundle(spec.dump_path)
        except RuntimeError as exc:
            raise RuntimeError(
                f"dump 未包含渲染应用（{spec.dump_path}）——aa start 重拉后仍截到桌面/"
                f"应用未渲染，该卡硬失败，建议重跑本卡采集") from exc
    print(f"  [e] dump 守卫通过: {spec.dump_path}")


# ------------------------------------------------------------------- 步骤 f：检查

def run_check(spec: CardSpec, include_delegated: bool = False) -> dict:
    """subprocess 调 check_card.py（93 条集走 --qdir 原路径，其余 --dsl 三件套）。

    include_delegated（Idea6-WP-E2）：透传 --include-delegated 恢复三条已移交
    同事侧几何规则的输出（默认静默）。
    """
    cmd = [sys.executable, str(PROJECT_DIR / "scripts" / "check_card.py")]
    if spec.qdir_arg:
        cmd += ["--qdir", spec.qdir_arg]
    else:
        cmd += ["--dsl", str(spec.case_dir / "card.genui.jsonl")]
    cmd += ["--layout", str(spec.dump_path), "--format", "json"]
    if include_delegated:
        cmd.append("--include-delegated")
    print(f"  [f] 检查: {' '.join(cmd)}")
    sys.stdout.flush()
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode > 1:  # 1 = L1 存在 P0 findings（正常检出结果），仅 >1 为工具层失败
        raise RuntimeError(f"check_card 失败（退出码 {proc.returncode}）:\n{proc.stderr}")
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"check_card 输出非 JSON: {exc!r}\n{proc.stdout[:500]}") from exc


# ------------------------------------------------------------------- 步骤 g：线框

def run_wireframe(spec: CardSpec) -> None:
    """subprocess 调 wireframe.py（采集截图与 dump 坐标对齐；复用模式无截图则跳过并显式说明）。"""
    if spec.screenshot is None:
        print(f"  [g] 跳过线框: {spec.scope}-{spec.card} 无配套采集截图"
              "（--reuse-dump 复用 dump 时无截图资产；可视化报告内联 SVG 线框不受影响）")
        return
    out = review_dir() / f"{spec.scope}-{spec.card}_wireframe"
    cmd = [sys.executable, str(PROJECT_DIR / "scripts" / "wireframe.py"),
           "--qid", f"{spec.scope}-{spec.card}",
           "--dump", str(spec.dump_path),
           "--screen", str(spec.screenshot),
           "--dsl", str(spec.case_dir / "card.genui.jsonl"),
           "--out", str(out)]
    print(f"  [g] 线框: {' '.join(cmd)}")
    sys.stdout.flush()
    proc = subprocess.run(cmd)
    if proc.returncode != 0:
        raise RuntimeError(f"wireframe 失败（退出码 {proc.returncode}）: {spec.scope}-{spec.card}")


# ----------------------------------------------------------- 步骤 h：资产 + 双报告

def branch_images_dir(scope: str) -> Path:
    """分支根目录下 images/（与 BRANCH_DIRS 的 DSL 子路径对应）。

    B 分支 DSL 在 <分支>/dsl/ 而现网截图在 <分支>/images/（平级，非 dsl/images/）；
    A/C/MS 分支 DSL 直接位于分支根。返回 Path（不存在时 is_dir() 为 False，调用方跳过）。
    """
    rel = BRANCH_DIRS[scope]
    if rel.endswith("/dsl"):
        rel = rel[:-len("/dsl")]
    return eval_root() / rel / "images"


def copy_net_shot(spec: CardSpec) -> None:
    """评测集现网截图 images/<卡号>.<ext> 存在则复制 review/vis-assets/<范围-卡号>.png。

    依据：可视化报告按 review/vis-assets/<qid>.png 内嵌「① 现网真机实拍」。
    93 条集/裸 DSL 无现网 images/ 目录，跳过（存在性判断，不报错）。
    """
    if spec.scope not in BRANCH_DIRS:
        return
    images = branch_images_dir(spec.scope)
    if not images.is_dir():
        return
    hits = [f for f in sorted(images.iterdir()) if f.stem.lower() == spec.card.lower()]
    if not hits:
        return
    dst = review_dir() / "vis-assets" / f"{spec.scope}-{spec.card}.png"
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(hits[0], dst)
    print(f"  [h] 现网实拍复制: {hits[0]} -> {dst}")


# ------------------------------------------------- 步骤 h2：F3 逐卡统一落盘

def write_case_artifact(spec: CardSpec, data: dict) -> dict:
    """单卡检测结果 → review/cases/<qid>.json（schema v1，F4 报告构建器唯一真值源）。

    dump 按 process_card 实测口径（fresh/reused/render-evidence）；截图按
    vis-assets 实况（现网实拍优先，其次本机采集，均无则 absent）；notes 保留
    既有产物的人工注记（F4 数据驱动注记不被本写入清空）。返回 CaseReport dict。
    """
    qid = f"{spec.scope}-{spec.card}"
    kind = "branch" if spec.scope in BRANCH_DIRS else ("qdir" if spec.scope == "SET93" else "dsl")
    vis = review_dir() / "vis-assets" / f"{qid}.png"
    if vis.is_file():
        shot = screenshot_field(vis, "net-shot")
    elif spec.screenshot is not None:
        shot = screenshot_field(spec.screenshot, "device-capture")
    else:
        shot = screenshot_absent()
    notes: list = []
    try:  # 保留既有注记（q1/q4 人工注记迁 notes 后不得被重跑清空）
        notes = load_case_report(qid).get("notes") or []
    except Exception:  # noqa: BLE001  无既有产物属常态
        pass
    report = build_case_report(
        qid=qid, source_kind=kind, source_label=spec.scope, dsl_path=spec.dsl_path,
        size=spec.size, dump=dump_field(spec.dump_path, spec.dump_origin or "fresh"),
        screenshot=shot, findings=data.get("findings") or [], notes=notes)
    write_case_report(report)
    print(f"  [h] 逐卡产物: {review_dir() / 'cases' / (qid + '.json')}")
    return report


# -------------------------------------------------------------- 步骤 i：五段式输出

def reproduce_cmd(args) -> str:
    parts = ["python3", "scripts/check_case.py"]
    if getattr(args, "cases", None):
        parts += ["--cases", args.cases]
    elif args.qdir:
        parts += ["--qdir", args.qdir]
    elif args.dsl:
        parts += ["--dsl", str(args.dsl)]
    else:
        parts += ["--branch", args.branch, "--case", args.case]
    if args.reuse_dump:
        parts.append("--reuse-dump")
    return " ".join(parts)


def print_terminal_report(specs: list[CardSpec], data: dict,
                          problem: Path, visual: Path, args,
                          failures: list | None = None) -> None:
    """AGENTS.md 五段式汇报：①产物路径 ②检测对象 ③检测层 ④结果摘要 ⑤复现命令。"""
    bar = "=" * 66
    print("\n" + bar)
    print("设计检查报告（AGENTS.md 五段式）")
    print(bar)
    print("① 报告产物")
    print(f"   - 问题清单 JSON: {problem}")
    print(f"   - 可视化 HTML: {visual}")
    for spec in specs:
        wf = review_dir() / f"{spec.scope}-{spec.card}_wireframe" / "index.html"
        wf_state = "（已生成）" if wf.is_file() else "（未生成：复用 dump 无采集截图）"
        print(f"   - dump 真值: {spec.dump_path}")
        print(f"   - 线框页: {wf} {wf_state}")
    print("② 检测对象")
    for spec in specs:
        if spec.scope in BRANCH_DIRS:
            source = "评测集分支"
        elif spec.scope == "SET93":
            source = "93 条数据集"
        else:
            source = "任意裸 DSL"
        print(f"   - 分支/来源: {spec.scope}（{source}）  卡片号: {spec.card}  DSL: {spec.dsl_path}")
    print("③ 检测层")
    print("   - L1: DSL 声明检查（scripts/check_card.py）")
    for spec in specs:
        print(f"   - L2a/L2b: dump 真值（{spec.dump_path}）")
    print("   - L3: 语义评审（无模型凭据，留人工/后续轮次）")
    print("④ 结果摘要")
    for spec in specs:
        s = data[spec.card]["summary"]
        print(f"   - {spec.scope}-{spec.card}: findings {s['total']}"
              f"（P0={s['p0']} / P1={s['p1']} / P2={s['p2']}）")
    for qid, err in failures or []:
        print(f"   - {qid}: 失败（未入报告）: {err}")
    print("⑤ 复现命令")
    print(f"   {reproduce_cmd(args)}")
    print(bar)


# --------------------------------------------------------------------- 主流程

#: 渲染阶段视为「瞬时故障可重试」的异常类型（hvigor 构建抖动 / 设备瞬断 / 子进程超时）
TRANSIENT_ERRORS = (RuntimeError, subprocess.SubprocessError, OSError)


def process_card(spec: CardSpec, args, sn: str | None, automation_root: Path) -> tuple[str | None, dict]:
    """单卡 a–g 步骤；返回（使用后的 sn, check 结果 data）。

    渲染阶段瞬时故障自动重试一次（先重走 ensure_device 恢复序列，B-q27 型
    hvigor 抖动实测重试即过）；再失败向上抛，由批量循环记失败继续下一卡。
    """
    prepare_case(spec)                               # a. 解析输入 + 归一化
    converted = run_trio(spec)                       # b. trio 转换
    if spec.dump_path.is_file() and args.reuse_dump:
        verify_dump_has_bundle(spec.dump_path)
        spec.dump_origin = "reused"
        print(f"  [d] 复用既有 dump（--reuse-dump）: {spec.dump_path}")
    elif spec.qdir_arg and args.reuse_dump and render_evidence_layout_path(spec.qdir_arg).is_file():
        evidence = render_evidence_layout_path(spec.qdir_arg)
        shutil.copy2(evidence, spec.dump_path)
        verify_dump_has_bundle(spec.dump_path)
        spec.dump_origin = "render-evidence"
        print(f"  [d] 复用数据集 render-evidence dump: {evidence} -> {spec.dump_path}")
    else:
        if sn is None:                               # c. 设备前置（首次需要采集时）
            hdc = load_hdc_path(automation_root)
            print(f"hdc: {hdc}")
            sn = ensure_device(hdc, args.sn)
        try:
            render_and_guard(spec, sn, automation_root, converted)  # d+e. 渲染+dump+守卫
        except TRANSIENT_ERRORS as exc:
            print(f"  [retry] {spec.scope}-{spec.card} 渲染失败（{exc!r}），恢复设备后重试一次…",
                  file=sys.stderr)
            hdc = load_hdc_path(automation_root)
            sn = ensure_device(hdc, args.sn)
            render_and_guard(spec, sn, automation_root, converted)
    spec.dump_origin = spec.dump_origin or "fresh"
    data = run_check(spec, include_delegated=getattr(args, "include_delegated", False))  # f. 检查
    run_wireframe(spec)                              # g. 线框
    return sn, data


def run_pipeline(args) -> tuple[dict, list]:
    """批量主流程：逐卡 a–g，单卡失败记录后跳过（不拖垮整批）→ 成功卡统一 h/i。

    返回 (data, failures)：data = 卡号 → check 结果；failures = [(qid, 错误描述)]。
    全部失败时抛 RuntimeError（无报告可生成）。
    """
    specs = build_specs(args)
    if not specs:
        raise RuntimeError("没有待处理卡片（--case 为空或未解析到任何卡）")
    automation_root = Path(args.automation_root or
                           os.environ.get("AUTOMATION_SCREENSHOT_ROOT") or
                           Path.home() / "Downloads" / "Automation-screenshot")

    sn: str | None = None
    data: dict = {}
    failures: list[tuple[str, str]] = []
    for i, spec in enumerate(specs):
        print(f"\n===== 卡片 {i + 1}/{len(specs)}: {spec.scope}-{spec.card} =====")
        try:
            sn, result = process_card(spec, args, sn, automation_root)
            data[spec.card] = result
        except Exception as exc:  # 单卡失败不拖垮整批（2026-08-25 批量加固）
            failures.append((f"{spec.scope}-{spec.card}", f"{type(exc).__name__}: {exc}"))
            print(f"  [fail] {spec.scope}-{spec.card} 失败，跳过继续下一卡", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            # 设备可能随本卡失联：下一卡重新走 ensure_device 恢复序列（设备在场时秒回）
            sn = None
    if not data:
        detail = "\n  - ".join(f"{qid}: {err}" for qid, err in failures)
        raise RuntimeError(f"全部 {len(specs)} 卡失败，无报告可生成:\n  - {detail}")

    ok_specs = [s for s in specs if s.card in data]
    case_reports = []
    for spec in ok_specs:                            # h. 现网截图资产 + 双报告
        copy_net_shot(spec)
        case_reports.append(write_case_artifact(spec, data[spec.card]))  # h2. F3 逐卡统一落盘
    cases = [(spec.card, f"{spec.scope}-{spec.card}") for spec in ok_specs]
    problem, visual = generate_reports(ok_specs[0].scope, cases, data, reports=case_reports)
    print_terminal_report(ok_specs, data, problem, visual, args, failures)  # i. 五段式
    return data, failures


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="WP-PIPE 一键管线：指定 case → 自动 DumpLayout → 可视化报告")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--cases", help="混合语法，逗号分隔（如 \"A:q42,B:q6,SET93:q010,DSL:/path/x.jsonl\"）")
    group.add_argument("--branch", help="评测分支（A/B/C/MS）")
    group.add_argument("--dsl", help="任意裸 DSL 文件路径（自动归一化）")
    group.add_argument("--qdir", help="93 条数据集 case id（如 q010）")
    parser.add_argument("--case", help="分支内卡片号，逗号分隔（如 q10 或 q1,q4,q7）")
    parser.add_argument("--sn", default=None, help="设备 SN（缺省取第一台）")
    parser.add_argument("--automation-root", default=None,
                        help="Automation-screenshot 根目录（默认 ~/Downloads/Automation-screenshot）")
    parser.add_argument("--reuse-dump", action="store_true",
                        help="已有 dump（本管线或数据集 render-evidence）则跳过采集（用于 --qdir）")
    parser.add_argument("--include-delegated", action="store_true",
                        help="透传 check_card --include-delegated：恢复三条已移交同事侧几何规则"
                             "（GEOMETRY.OVERLAP / BASELINE_MISMATCH / AREA_CONTENT_TEXT_OVERLAP）的输出"
                             "（默认静默，Idea6-WP-E2）")
    args = parser.parse_args(argv)
    if args.branch and not args.case:
        parser.error("--branch 需要 --case（逗号分隔卡片号）")
    if args.case and not args.branch:
        parser.error("--case 仅用于 --branch 模式")
    try:
        data, failures = run_pipeline(args)
    except (FileNotFoundError, RuntimeError, ValueError) as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:  # 未预期异常：exit 2 + 定位，不生成伪 finding（Idea6-WP-E3）
        print(f"错误[管线自身故障，exit 2]: {type(exc).__name__}: {exc}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return 2
    if failures:
        print(f"\n[batch] {len(failures)} 卡失败（已跳过，报告只含成功卡），可单独重跑补齐：",
              file=sys.stderr)
        for qid, err in failures:
            print(f"  - {qid}: {err}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
