#!/usr/bin/env python3
"""第一次评测四分支 DSL 批量设计检查（L1 全量）——docs/goal-detection-plugin-target.md 第一批出口。

用法：
    python3 scripts/check_eval.py                     # 四分支全量（299 条）
    python3 scripts/check_eval.py --branch A,C        # 指定分支
    python3 scripts/check_eval.py --rules ICON.*,TYPE.VALUE_GROUP_TIER   # 只跑新规则
产物：
    review/eval/l1-report.json   统一 findings
    review/eval/<branch>/<case>.json  单卡 findings
    review/eval/summary.md       分支 × 规则命中矩阵
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.case_store import (build_case_report, dump_absent,  # noqa: E402
                                screenshot_absent, write_case_report)
from validators.config import design_spec_path, review_dir  # noqa: E402
from validators.design_contract import attach_card_size_contracts, load_design_contract  # noqa: E402
from validators.dsl import CardParseError, load_genui  # noqa: E402
from validators.eval_dataset import load_eval_manifest  # noqa: E402
from validators.finding import sort_findings  # noqa: E402
from validators.rules import run_l1  # noqa: E402


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="第一次评测四分支 L1 批量检查")
    parser.add_argument("--branch", default=None, help="逗号分隔分支短名（A/B/C/M）")
    parser.add_argument("--rules", default=None, help="逗号分隔规则 id 通配（如 ICON.*）")
    parser.add_argument("--out", default=None, help="汇总 JSON 输出路径")
    args = parser.parse_args(argv)

    try:
        contract = load_design_contract(design_spec_path())
        manifest = load_eval_manifest()
    except (FileNotFoundError, CardParseError) as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2

    branches = set(args.branch.split(",")) if args.branch else None
    rule_patterns = args.rules.split(",") if args.rules else None

    def rule_selected(rule_id: str) -> bool:
        if not rule_patterns:
            return True
        return any(fnmatch.fnmatch(rule_id, pat) for pat in rule_patterns)

    out_dir = review_dir() / "eval"
    out_dir.mkdir(parents=True, exist_ok=True)

    all_findings = {}
    branch_stat: dict = defaultdict(lambda: {"cases": 0, "total": 0, "p0": 0, "p1": 0, "p2": 0})
    rule_stat: Counter = Counter()
    branch_rule_stat: Counter = Counter()
    degraded = []

    for entry in manifest:
        if branches and entry.branch not in branches:
            continue
        if entry.notes and any("解析失败" in n or "非 JSON" in n for n in entry.notes):
            print(f"  [skip] {entry.qid}: {entry.notes}", file=sys.stderr)
            continue
        try:
            card = load_genui(entry.path, entry.qid)
        except CardParseError as exc:
            print(f"  [skip] {entry.qid}: {exc}", file=sys.stderr)
            continue
        if any("缺 updateDataModel" in n for n in entry.notes):
            degraded.append(entry.qid)
        attach_card_size_contracts(contract, card)  # Idea2-WP-B 注入收口
        findings = [f for f in run_l1(card, contract, "") if rule_selected(f.rule_id)]
        findings = sort_findings(findings)
        all_findings[entry.qid] = findings

        case_dir = out_dir / entry.branch
        case_dir.mkdir(parents=True, exist_ok=True)
        (case_dir / f"{entry.case_id}.json").write_text(
            json.dumps({"qid": entry.qid, "size": entry.size, "messages": entry.messages,
                        "notes": entry.notes, "findings": [f.to_dict() for f in findings]},
                       ensure_ascii=False, indent=2), encoding="utf-8")

        # F3 逐卡统一落盘（L1 批量口径：无 dump/截图，absent 标注保持 schema 一致）
        write_case_report(build_case_report(
            qid=f"{entry.branch}-{entry.case_id}", source_kind="branch",
            source_label=entry.branch, dsl_path=entry.path, size=entry.size,
            dump=dump_absent(), screenshot=screenshot_absent(),
            findings=[f.to_dict() for f in findings], notes=[]))

        stat = branch_stat[entry.branch]
        stat["cases"] += 1
        for f in findings:
            stat["total"] += 1
            stat[f.severity.lower()] += 1
            rule_stat[f"{f.rule_id} [{f.severity}]"] += 1
            branch_rule_stat[(entry.branch, f.rule_id)] += 1

    report = {
        "schema": "design-check/eval-findings/v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "scope": {"branches": sorted(branches) if branches else "all",
                  "rules": rule_patterns or "all"},
        "cases": {qid: [f.to_dict() for f in fs] for qid, fs in all_findings.items()},
        "degraded_no_data_model": degraded,
        "summary": {
            "cases": sum(s["cases"] for s in branch_stat.values()),
            "branches": {b: dict(s) for b, s in sorted(branch_stat.items())},
            "by_rule": dict(rule_stat.most_common()),
        },
    }
    target = Path(args.out) if args.out else out_dir / "l1-report.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    # summary.md：分支总览 + 规则命中
    lines = ["# 第一次评测 L1 检查汇总", "",
             f"生成: {report['generated_at']} · 范围: {report['scope']}", ""]
    lines += ["| 分支 | 卡数 | findings | P0 | P1 | P2 |", "|---|---|---|---|---|---|"]
    for b, s in sorted(branch_stat.items()):
        lines.append(f"| {b} | {s['cases']} | {s['total']} | {s['p0']} | {s['p1']} | {s['p2']} |")
    lines += ["", "## 规则命中（降序）", "", "| 规则 | 命中 |", "|---|---|"]
    for key, n in rule_stat.most_common():
        lines.append(f"| {key} | {n} |")
    if degraded:
        lines += ["", f"降级标注（缺 updateDataModel，分支形态）: {len(degraded)} 条"]
    (out_dir / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    total = sum(s["total"] for s in branch_stat.values())
    print(f"\n分支统计: " + " · ".join(
        f"{b}={s['cases']}卡/{s['total']}条(P0={s['p0']},P1={s['p1']},P2={s['p2']})"
        for b, s in sorted(branch_stat.items())))
    print(f"汇总写入: {target}")
    print(f"摘要写入: {out_dir / 'summary.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
