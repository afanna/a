#!/usr/bin/env python3
"""L2a 几何断言 CLI（dump 真值 → 几何规则）。"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from validators.config import design_spec_path  # noqa: E402
from validators.design_contract import load_design_contract  # noqa: E402
from validators.dsl import load_case  # noqa: E402
from validators.layout import DumpLayout  # noqa: E402
from validators.geometry import run_geometry  # noqa: E402


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="L2a 几何断言")
    parser.add_argument("--qdir", default="q010")
    parser.add_argument("--layout", required=True, help="dumpLayout JSON 路径")
    parser.add_argument("--case-dir", default=None, help="case 目录（缺省用数据集）")
    args = parser.parse_args(argv)

    layout_path = Path(args.layout)
    if not layout_path.is_file():
        print(f"错误: 找不到布局文件 {layout_path}", file=sys.stderr)
        return 2
    if args.case_dir:
        card = load_case(Path(args.case_dir))
    else:
        from validators.config import card_data_dir
        card = load_case(card_data_dir() / args.qdir)
    layout = DumpLayout.from_file(layout_path)
    findings = run_geometry(card, layout)
    print(json.dumps([f.to_dict() for f in findings], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
