#!/usr/bin/env python3
"""EVAL299 76 张 2×4 卡形态聚类 + 人审清单（WP-LAYOUT-FORMS，WP1 前置）+ 布局示意图
（WP-LAYOUT-FORMS-RENDER）。

背景（docs/plan.md 裁决记录，2026-08-24）：布局检测走「白名单+数值层」路线（路线 C）——
归纳式扩表白名单做合规判定 + 匹配失败降 P2 兜底。本工具是 WP1 前置：把评测集 76 张
2×4 卡（A 分支 40：createSurface 320×160；B 分支 36：root 宽 320）的组件树归约成结构
签名并聚类，输出人审清单 HTML——owner 逐条勾选合法形态后才入库。机器只做检测+定位+
建议，不下最终设计结论（AGENTS.md 检查项范式）。

布局示意图（2026-08-24 WP-LAYOUT-FORMS-RENDER）：人审需要看到形态才勾选——每簇代表卡
（前 3 张）由声明层简化 flex 推演引擎（infer_layout）算出每块 (x,y,w,h)，渲染成 SVG
（viewBox 320×160，显示 640×320）：安全区 296×136 红虚线框 + 语义着色块（title 蓝 /
panel 灰 / action 绿 / Text 虚线 / Image 黄）+ id 与 w×h 标注 + 越界红描边 + 未声明
尺寸「*」推演标记。推演不求像素精确，求形态可读，不落规则。

金标准骨架参照系（2026-08-24 WP-LAYOUT-FORMS-RENDER 方向修正）：人审对照标准骨架看偏差，
不孤立看产物。官方 18 变体骨架 SVG 从 validators/rules/layout_2x4.py 的 _VARIANT_TEMPLATES
结构推导槽位矩形（图与检测同源，不复制几何数字；几何与 docs/pixso-layout-abstraction.md
一致：bare 136 全高 / tc 17+4+115 / tr 20+8+108 / ta 20+4+72+4+capsule36）。清单头部
「官方 18 变体骨架图鉴」+ 每未覆盖簇「标准骨架 vs 实际产物」并排对照 + 机器算关键偏差
（title 高 / 底部余量 / 末块形态 / 分栏宽差），供人审参考，不下结论。

Pixso 补充骨架（2026-08-24 item-id 63:61「骨架补充」实读固化 + 终审同步）：7 张补充骨架
（63:57 bare 二分重申 / 63:20 ta 单按钮 144 / 63:37 ta-H2 二分+按钮 / 63:48 title20 二分 /
63:27 ta 双按钮行 / 63:62 ta-H3-dual 三列+双按钮 / ta-H2-dual 二分+双按钮，owner 指认
待 Pixso 登记）进 _SUPPLEMENT_TEMPLATES，与官方 18 共同参与拓扑覆盖判定（形态签名：
轴/方向 + title 档就近 {17,20} + 块序列含 action 按钮数；按钮宽 144/140 等价档），
被覆盖簇移入「已覆盖（官方/补充）」段，仍无法覆盖的簇保留候选骨架 + 决策点行供人审入库。
ta 系候选按钮宽按补充实证归一为 144 等分宽（=(296-8)/2，双按钮 gap8 闭合 296）。

gap 口径（2026-08-24 五卡真机 dump 实证：A-q18/19/20/62/93 顶层 itemMargin 完全生效）：
间距声明先读组件顶层 itemMargin、无则 styles.itemMargin，与 layout_2x4._gap 完全一致；
未声明按 0 参与推演与闭合验算。「含 gap」口径 = 真机渲染口径（示意图主数值），
「子和口径」为审计参考（Σ子和 vs 安全区）。

边界（本包只做分析与报告）：
- 禁改 validators/rules/**、geometry.py、report_b_eval.py 既有行为；评测数据只读；
- 官方变体匹配只读调用 validators/rules/layout_2x4.py 现有匹配逻辑（build_tree /
  _content_node / _content_sk / _find_variant / _match_sk / _VARIANT_TEMPLATES），不改；
- 不引入新依赖（stdlib + 现有 validators 包；SVG 纯字符串拼接）。

产物（AGENTS.md 报告命名规范，经 config.daily_review_dir() 落位）：
    design-check/review/<YYYYMMDD>/EVAL299-layout-forms-<YYYYMMDD>.html
    design-check/review/<YYYYMMDD>/EVAL299-layout-forms-selftest-<YYYYMMDD>.html  # --selftest

用法：
    python3 scripts/layout_forms_report.py                 # 默认落位 daily_review_dir
    python3 scripts/layout_forms_report.py --out PATH      # 自定义输出路径
    python3 scripts/layout_forms_report.py --selftest      # 正例验证（匹配 + 渲染几何），
                                                           # 并生成渲染验证页

验收锚点（本工具 stdout 会显式核对）：
- Q3（A-q3）落在「未覆盖」簇：结构式含 title24+panel+双按钮行（V[title24, panel58,
  action32×2]），初判垂直闭合缺口 22vp（=24+58+32 vs 136，子和口径）；示意图可见
  title 条 / 中间 panel / 底部两按钮并排且未贴安全区底缘（含 gap 渲染后余 6vp）；
- Q2（A-q2）落在「未覆盖」簇：H[col132, col152]，横向缺口 12vp；示意图两栏宽明显不等；
- 官方变体能命中的卡（构造正例）归入「已覆盖」段，且 --selftest 渲染几何与
  18 变体标准形态一致（bare-H2 双栏 142×2 填满 / tc-S1 17+4+115 / ta-S1 20+4+72+4+36）。
"""
from __future__ import annotations

import argparse
import html
import re
import shutil
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from validators.config import daily_review_dir, eval_root, review_dir  # noqa: E402
from validators.dsl import GenuiCard, load_genui  # noqa: E402
from validators.rules.layout_2x4 import (  # noqa: E402  （只读复用现有归约/匹配骨架，不改）
    TNode,
    build_tree,
    _content_node,
    _content_sk,
    _find_variant,
    _match_sk,
    _VARIANT_TEMPLATES,
)

#: Pixso 补充骨架（item-id 63:61「骨架补充」页 + 2026-08-24 终审同步，与
#: validators/rules/layout_2x4.py _SUPPLEMENT_TEMPLATES 两处一致；仅本清单分析用，
#: 入库检测器是 WP2 的活，本包不改 layout_2x4.py）。与官方 18 变体共同参与拓扑覆盖判定。
_SUPPLEMENT_TEMPLATES: Dict[str, tuple] = {
    # bare H 二分等分（296×136 内两个 fill 矩形）；与官方 bare-H2 同构（等分重申）
    "63:57": ("row", 12, [("box", 142, 136), ("box", 142, 136)]),
    # 单内容+Button：ta 系单按钮，等分宽 144 = (296-8)/2，≠ 官方 capsule 140（等价档差 4vp）
    "63:20": ("vseq", [("box", 296, 72), ("box", 144, 36)]),
    # 双内容+Button：新骨架 ta-H2（content 内 H 二分等分 + 单按钮 144×36）
    "63:37": ("vseq", [("row", 8, [("box", 144, 72), ("box", 144, 72)]), ("box", 144, 36)]),
    # 双内容：新骨架 title20 二分（官方 tc-H2 为 title17）
    "63:48": ("row", 8, [("box", 144, 108), ("box", 144, 108)]),
    # 单内容+双Button：ta 双按钮行 144×2+gap8=296 等分闭合（即 Q3 形态）
    "63:27": ("vseq", [("box", 296, 72), ("row", 8, [("box", 144, 36), ("box", 144, 36)])]),
    # 63:62 ta-H3-dual：content 内 H 三列等分 93.33 + 双按钮行 144×36×2（与检测器同步）
    "63:62": ("vseq", [("row", 8, [("box", 93.33, 72), ("box", 93.33, 72), ("box", 93.33, 72)]),
                       ("row", 8, [("box", 144, 36), ("box", 144, 36)])]),
    # ta-H2-dual：title20 + content 内 H 二分 72 + 双按钮行 144×36×2（2026-08-24 终审
    # owner 指认 A-q8 新固化，待 Pixso 补画登记；闭合 144×2+8=296 / 72+4+36=136）
    "ta-H2-dual": ("vseq", [("row", 8, [("box", 144, 72), ("box", 144, 72)]),
                            ("row", 8, [("box", 144, 36), ("box", 144, 36)])]),
}
_SUPPLEMENT_FAMILY: Dict[str, str] = {
    "63:57": "bare", "63:20": "ta", "63:37": "ta", "63:48": "tr", "63:27": "ta",
    "63:62": "ta", "ta-H2-dual": "ta",
}
_SUPPLEMENT_NOTE: Dict[str, str] = {
    "63:57": "左右二分（bare H 二分等分，与官方 bare-H2 同构重申）",
    "63:20": "单内容+Button（ta 单按钮 144×36；官方 capsule 140 等价档差 4vp）",
    "63:37": "双内容+Button（ta-H2：content 内 H 二分 + 单按钮 144×36）",
    "63:48": "双内容（title20 + content H 二分；官方 tc-H2 为 title17）",
    "63:27": "单内容+双Button（ta 双按钮行 144×2+gap8=296 等分闭合；即 Q3 形态）",
    "63:62": "三列+双Button（ta-H3-dual：content 内 H 三列 93.33×3 + 双按钮 144×36×2）",
    "ta-H2-dual": "二分+双Button（ta-H2-dual：content 内 H 二分 144×72×2 + 双按钮 144×36×2；"
                  "owner 2026-08-24 指认，待 Pixso 登记）",
}


def _tpl_family(name: str) -> str:
    """模板名（官方/补充）→ 根结构家族 bare/tc/tr/ta。"""
    if name in _SUPPLEMENT_FAMILY:
        return _SUPPLEMENT_FAMILY[name]
    return _variant_family(name)

#: 2×4 安全区（DESIGN-2x4.md layout_slots.canvas.safeArea.padding12）
SAFE_W = 296.0
SAFE_H = 136.0
#: gap 合法档位（splitRules：12/8/4；rootStructures gap 4/8；ta-S1 actionGap 4）
GAP_OK = {4, 8, 12, 16}


def _declared_gap(node: TNode) -> Optional[float]:
    """间距声明（2026-08-24 五卡真机 dump 实证：A-q18/19/20/62/93 顶层 itemMargin 完全
    生效——q18 声明 4→实测 4.00/4.00；q19/20/93 声明 2→实测 2.00；q93 earbud_panel 8→
    实测 8.00/8.00、run_panel 6→实测 6.00×3，全部吻合）。

    读取顺序：组件顶层 itemMargin → styles.itemMargin，与 layout_2x4._gap 口径一致；
    无声明返回 None（gap 按 0 参与闭合/推演）。
    """
    v = node.comp.get("itemMargin")
    if v is None:
        st = node.comp.get("styles") or {}
        v = st.get("itemMargin") if isinstance(st, dict) else None
    if v is None or isinstance(v, bool):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None
#: title bar 合法高档（titleRow.barHeight：compact 17 / regular 20，±1vp 容差）
TITLE_TIERS = (17.0, 20.0)
#: 等分比对容差（vp），与 layout_2x4._TOL 一致
TOL = 1.0
#: 内容区容器集合（退化等分审计与 layout_2x4 同口径：子块全为容器才判分栏）
_CONTAINER_COMPONENTS = {"Row", "Column", "Stack", "Grid", "List"}


# ---------------------------------------------------------------------------
# 组件树分析（复用 layout_2x4 归一层 TNode；以下只读，不落规则）
# ---------------------------------------------------------------------------

def _fmt_main(v: Optional[float]) -> str:
    return f"{round(v):d}" if v is not None else "?"


def _bg(comp: Dict[str, Any]) -> bool:
    st = comp.get("styles")
    return bool(isinstance(st, dict) and st.get("backgroundColor"))


def is_button_like(node: TNode) -> bool:
    """按钮子块判定：onClick 或 Button 组件。

    口径说明（2026-08-24 数据实证）：76 张卡全部真按钮均携带 onClick 或为 Button
    组件；仅带 backgroundColor 的容器在本数据里是面板/列表项/电池指示等非按钮
    （如 A-q93 earbud_panel、B-q38 agendaItem），故不把 bg 单独当作按钮证据。
    """
    comp = node.comp
    return "onClick" in comp or comp.get("component") == "Button"


def is_action_block(node: TNode) -> bool:
    """action 块判定：叶按钮（onClick/Button 组件），或子块全为 clickable /
    带背景按钮容器；自可点的小容器（高 ≤ 50vp，如 dnd 整行按钮）也视为按钮行。

    口径（2026-08-24 数据实证）：B 分支根容器带整卡 onClick（如 B-q18 root
    Row 160×320），不能因此把 content_root 当 action 行豁免等分审计——大容器
    必须子块全为按钮才算 action。
    """
    comp = node.comp
    if node.kind == "box":
        return "onClick" in comp or comp.get("component") == "Button"
    if node.children and all(is_button_like(k) for k in node.children):
        return True
    if "onClick" in comp or comp.get("component") == "Button":
        return node.h is None or node.h <= 50
    return False


def detect_title(src: TNode) -> Optional[TNode]:
    """title 块判定（任务口径）：content_root 首块为 Row 且含 Text。"""
    if not src.children:
        return None
    first = src.children[0]
    if first.kind != "row":
        return None
    if not any(c.kind == "box" and c.comp.get("component") == "Text" for c in first.children):
        return None
    return first


def title_tier(title: Optional[TNode]) -> Tuple[str, Optional[int]]:
    """title 高档位：(档位串, 声明高)。档位 = 17 / 20 / 24 / h<其他高> / none。"""
    if title is None or title.h is None:
        return ("none", None)
    h = int(round(title.h))
    if h in (17, 20, 24):
        return (str(h), h)
    return (f"h{h}", h)


def _content_area(content: Optional[TNode], tree: Optional[TNode]) -> Optional[TNode]:
    """内容区节点：content_root；root 直接承载内容（B 分支形态）时以 root 自身为内容区。"""
    if content is not None:
        return content
    return tree


def content_depth(node: TNode) -> int:
    """内容区层数：内容区节点到最深层叶子的层数（内容区自身计 0）。"""
    if not node.children:
        return 0
    return 1 + max(content_depth(c) for c in node.children)


def _main_dim(node: TNode, axis: str) -> Optional[float]:
    return node.h if axis == "V" else node.w


def block_key(node: TNode, axis: str) -> tuple:
    """机器签名中的形态层块键（不含更深嵌套，聚类用）：
    (kind, 子块数, 主轴声明尺寸, 是否 action)。主轴 = V 语境取高 / H 语境取宽。

    口径（任务签名清单「各层方向与子块数」+ 结构式示例 V[title24, panel58,
    action32×2]）：签名取形态层 = content_root 直接子块（方向 + 子块数 + 主轴尺寸 +
    action 标记）；更深层（面板内部）属内容层，不进签名（在代表卡树摘要与
    逐卡审计中呈现），避免内容层细节把同形态卡拆散。
    """
    dim = round(_main_dim(node, axis)) if _main_dim(node, axis) is not None else None
    return ("R" if node.kind == "row" else ("C" if node.kind == "col" else "B"),
            len(node.children), dim, is_action_block(node))


def make_signature(src: TNode, title: Optional[TNode]) -> tuple:
    """机器签名（归一化元组，用于聚类）：根方向 / title 档 / 内容区层数 /
    形态层各块（方向·子块数·主轴尺寸·action）/ 末块是否按钮行。"""
    root_dir = "H" if src.kind == "row" else ("V" if src.kind == "col" else "X")
    tier, _ = title_tier(title)
    blocks = tuple(block_key(c, root_dir) for c in src.children
                   if c is not title)
    last = src.children[-1] if src.children else None
    last_is_action = last is not None and last is not title and is_action_block(last)
    return (root_dir, tier, content_depth(src), blocks, last_is_action)


def _fmt_main(v: Optional[float]) -> str:
    return f"{round(v):d}" if v is not None else "?"


def fmt_block(node: TNode, axis: str, is_title: bool = False) -> str:
    """单块人类可读标签：title{h} / action{h}×n / panel{h}|col{w} / text|img|box{h}。"""
    dim = _fmt_main(_main_dim(node, axis))
    if is_title:
        return f"title{dim}"
    if is_action_block(node):
        n = len(node.children)
        return f"action{dim}×{n}" if n else f"action{dim}"
    if node.kind in ("row", "col"):
        return f"panel{dim}" if axis == "V" else f"col{dim}"
    comp = node.comp.get("component")
    tag = {"Text": "text", "Image": "img"}.get(comp, "box")
    return f"{tag}{dim}"


def nested_note(blocks: List[TNode], axis: str) -> str:
    """各块首层嵌套注（区分同名结构式的不同形态）："panel58→R3·C2" 形态。"""
    parts = []
    for b in blocks:
        label = fmt_block(b, axis)
        if b.kind in ("row", "col") and b.children:
            kids = ", ".join(
                ("R" if k.kind == "row" else "C") + str(len(k.children))
                for k in b.children if k.kind in ("row", "col"))
            if kids:
                parts.append(f"{label}→[{kids}]")
    return " · ".join(parts)


def tree_lines(node: TNode, axis: str, max_depth: int = 5, depth: int = 0) -> List[str]:
    """代表卡组件树摘要行（缩进 + id/组件/尺寸/gap/标志）。"""
    st = node.comp.get("styles") or {}
    dims = []
    if node.w is not None:
        dims.append(f"w={node.w:g}")
    if node.h is not None:
        dims.append(f"h={node.h:g}")
    flags = []
    if "onClick" in node.comp:
        flags.append("onClick")
    if node.comp.get("component") == "Button":
        flags.append("Button")
    if _bg(node.comp):
        flags.append("bg")
    meta = " ".join(dims + flags)
    head = f"{node.comp.get('id')}: {node.comp.get('component')}"
    if meta:
        head += f" ({meta})"
    if node.gap is not None:
        head += f" gap={node.gap:g}"
    lines = ["  " * depth + head]
    if depth < max_depth:
        for c in node.children:
            lines.extend(tree_lines(c, axis, max_depth, depth + 1))
    elif node.children:
        lines.append("  " * (depth + 1) + f"…（{len(node.children)} 子节点，深度截断）")
    return lines


# ---------------------------------------------------------------------------
# 原子审计初判（机器建议，不作为结论）
# ---------------------------------------------------------------------------

#: 硬伤类别（用于簇级聚合展示）
HARD_KINDS = ("gap", "title", "split", "vclose", "hclose")


@dataclass
class Audit:
    """单卡原子审计：gap 档位 / 等分 / 垂直闭合 / 横向闭合 / title 高档。"""
    gap_lines: List[str] = field(default_factory=list)
    split_lines: List[str] = field(default_factory=list)
    v_lines: List[str] = field(default_factory=list)
    h_lines: List[str] = field(default_factory=list)
    title_line: str = ""
    hard: List[str] = field(default_factory=list)   # 硬伤类别（HARD_KINDS 子集）
    ok: bool = True


def _exp_split(content_dim: float, gap: Optional[float], n: int) -> float:
    g = gap or 0.0
    return (content_dim - g * (n - 1)) / n


def _node_content_dim(node: TNode, axis: str) -> Optional[float]:
    dim = _main_dim(node, axis)
    if dim is None:
        return None
    return dim - 2 * (node.padding or 0.0)


def audit_card(src: TNode, title: Optional[TNode], axis: str) -> Audit:
    """逐层原子审计（声明层原则：未声明不臆造，交 L2）。

    gap 口径与 layout_2x4._gap 一致（顶层 itemMargin → styles.itemMargin，
    2026-08-24 五卡 dump 实证渲染生效）；未声明按 0 参与闭合验算。
    """
    audit = Audit()
    root_label = "content_root"
    if src.comp.get("id") not in ("content_root", "root"):
        root_label = f"{src.comp.get('id')}"

    def hd(kind: str, msg: str) -> None:
        audit.hard.append(msg)
        audit.ok = False

    # -- title 档位 --
    if title is not None:
        h = title.h
        if h is None:
            audit.title_line = f"{root_label} 首块为 title 行但高未声明"
        else:
            legal = any(abs(h - t) <= 1 for t in TITLE_TIERS)
            tier = "17" if abs(h - 17) <= 1 else ("20" if abs(h - 20) <= 1 else f"{h:g}")
            audit.title_line = f"title 高 {h:g} → 档 {tier}"
            if not legal:
                audit.title_line += "（非 17/20 档）"
                hd("title", f"title 高 {h:g} 非 {{17,20}} 档")
    else:
        audit.title_line = "无 title 块"

    # -- 逐层遍历：gap 档位 + 等分 + 层内闭合 --
    # 硬伤口径（影响「建议入库」判定）：只取形态级——title 档 / content_root 自身
    # gap 档位（depth 0）/ H 分栏等分（depth ≤ 1，content_root 及其直接子 Row）/
    # content_root 横纵闭合。更深层（内容层）的 gap/等分偏差照常量化展示
    # （审计行 + 详情），但不翻转形态级建议（内容层问题由组件级规则另行处理，
    # 避免白名单被内容噪声堵死）。
    def walk(node: TNode, axis: str, label: str, depth: int) -> None:
        if depth > 4:
            return
        if node.kind in ("row", "col"):
            dg = _declared_gap(node)
            # gap 档位（只对生效声明 styles.itemMargin 判定；顶层 itemMargin 视为未声明）
            if dg is not None:
                g = int(round(dg))
                if g not in GAP_OK:
                    audit.gap_lines.append(f"{label} gap={dg:g} ∉ {{4,8,12,16}}")
                    if depth == 0:
                        hd("gap", f"{label} gap {dg:g} 非档位")
            elif depth == 0:
                audit.gap_lines.append(f"{label} gap 未声明（声明层跳过，交 L2）")
            # 等分（与 layout_2x4 退化审计同口径：仅 Row 分栏、子块全为容器才判；
            # action 行特例豁免；Column 纵向堆叠是内容编排（title+行+按钮），非分栏）
            kids = node.children
            if (node.kind == "row" and len(kids) >= 2 and not is_action_block(node)):
                child_dims = [_main_dim(k, axis) for k in kids]
                all_containers = all(
                    k.kind in ("row", "col") or k.comp.get("component") in _CONTAINER_COMPONENTS
                    for k in kids)
                if all_containers and all(d is not None for d in child_dims):
                    content_dim = _node_content_dim(node, axis)
                    if content_dim is None and node is src and axis == "H":
                        content_dim = SAFE_W  # content_root 无声明宽时以安全区 296 为基准
                    if content_dim is not None:
                        exp = _exp_split(content_dim, dg, len(kids))
                        worst = max(abs(d - exp) for d in child_dims)
                        if worst > TOL:
                            dims_txt = ", ".join(f"{d:g}" for d in child_dims)
                            audit.split_lines.append(
                                f"{label} 子块 {dims_txt} 非等分（公式 {exp:g}，基准 {content_dim:g}，gap {dg or 0:g}）")
                            if depth <= 1:
                                hd("split", f"{label} 等分不符（{dims_txt} vs {exp:g}）")
            # 层内闭合（信息级：Σ子主轴 + gap + 2×pad vs 声明父主轴，超/缺量化）
            if node is src:
                if axis == "V":
                    hs = [k.h for k in node.children]
                    if all(h is not None for h in hs):
                        sum_h = sum(hs)
                        gap_total = (dg or 0.0) * (len(hs) - 1)
                        deficit = SAFE_H - sum_h
                        gap_txt = f" + gap {gap_total:g}" if dg else "（gap 未声明按 0）"
                        audit.v_lines.append(
                            f"垂直 Σ子和 {sum_h:g}{gap_txt} vs 安全区 {SAFE_H:g}"
                            f" → {'缺口' if deficit >= 0 else '超出'} {abs(deficit):g}vp")
                        if dg:
                            with_gap = sum_h + gap_total
                            rem = SAFE_H - with_gap
                            audit.v_lines.append(
                                f"  （含 gap 合计 {with_gap:g}，"
                                f"{'闭合 ✓' if abs(rem) <= TOL else ('余 ' + f'{rem:g}' + 'vp' if rem >= 0 else '超 ' + f'{-rem:g}' + 'vp')}）")
                        if abs(SAFE_H - (sum_h + gap_total)) > TOL:
                            if deficit >= 0:
                                hd("vclose", f"垂直缺口 {deficit:g}vp（Σ子和 {sum_h:g} vs {SAFE_H:g}）")
                            else:
                                hd("vclose", f"垂直超出 {-deficit:g}vp（Σ子和 {sum_h:g} vs {SAFE_H:g}）")
                else:
                    for k in node.children:
                        if k.h is not None and SAFE_H - k.h > TOL:
                            audit.v_lines.append(
                                f"{k.comp.get('id')} 高 {k.h:g} vs 安全区 {SAFE_H:g} → 缺口 {SAFE_H - k.h:g}vp")
                            hd("vclose", f"垂直缺口 {SAFE_H - k.h:g}vp（{k.comp.get('id')} {k.h:g} vs {SAFE_H:g}）")
                        elif k.h is not None:
                            audit.v_lines.append(f"{k.comp.get('id')} 高 {k.h:g} ✓（安全区 {SAFE_H:g}）")
                if axis == "H":
                    ws = [k.w for k in node.children]
                    if all(w is not None for w in ws):
                        sum_w = sum(ws)
                        gap_total = (dg or 0.0) * (len(ws) - 1)
                        deficit = SAFE_W - sum_w
                        gap_txt = f" + gap {gap_total:g}" if dg else "（gap 未声明按 0）"
                        audit.h_lines.append(
                            f"横向 Σ子和 {sum_w:g}{gap_txt} vs 安全区 {SAFE_W:g}"
                            f" → {'缺口' if deficit >= 0 else '超出'} {abs(deficit):g}vp")
                        if dg:
                            with_gap = sum_w + gap_total
                            rem = SAFE_W - with_gap
                            audit.h_lines.append(
                                f"  （含 gap 合计 {with_gap:g}，"
                                f"{'闭合 ✓' if abs(rem) <= TOL else ('余 ' + f'{rem:g}' + 'vp' if rem >= 0 else '超 ' + f'{-rem:g}' + 'vp')}）")
                        if abs(SAFE_W - (sum_w + gap_total)) > TOL:
                            if deficit >= 0:
                                hd("hclose", f"横向缺口 {deficit:g}vp（Σ子和 {sum_w:g} vs {SAFE_W:g}）")
                            else:
                                hd("hclose", f"横向超出 {-deficit:g}vp（Σ子和 {sum_w:g} vs {SAFE_W:g}）")
                else:
                    # V 语境：全宽行（title/panel）逐行 vs 296；action 块按胶囊特例豁免
                    for k in node.children:
                        if k is title or is_action_block(k):
                            continue
                        if k.w is not None and SAFE_W - k.w > TOL:
                            audit.h_lines.append(
                                f"{k.comp.get('id')} 宽 {k.w:g} vs 安全区 {SAFE_W:g} → 缺口 {SAFE_W - k.w:g}vp")
                            hd("hclose", f"横向缺口 {SAFE_W - k.w:g}vp（{k.comp.get('id')} {k.w:g} vs {SAFE_W:g}）")
                        elif k.w is not None:
                            audit.h_lines.append(f"{k.comp.get('id')} 宽 {k.w:g} ✓（安全区 {SAFE_W:g}）")
        for i, k in enumerate(node.children):
            walk(k, "H" if k.kind == "row" else "V",
                 f"{label}→{k.comp.get('id')}", depth + 1)

    walk(src, axis, root_label, 0)
    return audit


# ---------------------------------------------------------------------------
# 官方变体匹配（只读调用 layout_2x4 现有匹配逻辑）
# ---------------------------------------------------------------------------

def match_official(card: GenuiCard, content: Optional[TNode], tree: Optional[TNode]) -> Tuple[Optional[str], Optional[str], str]:
    """记录每卡是否命中 18 官方变体 + 最接近变体名（只读调用，不改行为）。

    返回 (命中变体名, 最接近变体名, 状态说明)。content 为 None（root 直接承载内容，
    B 分支形态）时规则层门禁跳过——如实记录，不臆造命中。
    """
    if content is None:
        return (None, None, "root 直接承载内容（非 Stack+content_root），规则门禁跳过")
    sk = _content_sk(content)
    matched = _find_variant(sk)
    best_name: Optional[str] = None
    best_score = float("inf")
    for name, tpl in _VARIANT_TEMPLATES.items():
        _, score = _match_sk(sk, tpl)
        if score < best_score:
            best_name, best_score = name, score
    if matched is not None:
        return (matched[0], matched[0], "命中官方变体")
    return (None, best_name, f"未命中（最接近 {best_name}，差异评分 {best_score:g}）")


def structural_closest(src: TNode) -> Optional[str]:
    """结构等价最接近变体（注释用，非官方判定）：把 root 直接承载内容形态按 content_root
    口径归约后找最接近变体，供 owner 评估「剥 root 壳后是否近官方」。
    """
    sk = _content_sk(src)
    best_name: Optional[str] = None
    best_score = float("inf")
    for name, tpl in _VARIANT_TEMPLATES.items():
        _, score = _match_sk(sk, tpl)
        if score < best_score:
            best_name, best_score = name, score
    return best_name


# ---------------------------------------------------------------------------
# 卡片记录与聚类
# ---------------------------------------------------------------------------

@dataclass
class CardRec:
    branch: str
    qid: str
    card: GenuiCard
    tree: Optional[TNode]
    src: Optional[TNode]            # 内容区节点（content_root 或 root 自身）
    root_is_content: bool
    content: Optional[TNode]
    title: Optional[TNode]
    sig: tuple
    formula: str
    nested: str
    axis: str
    matched: Optional[str]          # 官方命中变体名（None=未命中/门禁跳过）
    matched_note: str
    closest: Optional[str]          # 官方口径最接近变体
    structural_closest: Optional[str]  # 结构等价最接近变体（注释）
    audit: Audit
    error: str = ""


def analyze_card(branch: str, qid: str, card: GenuiCard) -> CardRec:
    tree = build_tree(card)
    if tree is None:
        return CardRec(branch, qid, card, None, None, False, None, None, (),
                       "?", "", "V", None, "缺根（build_tree=None）", None, None, Audit(), "缺根")
    content = _content_node(tree)
    root_is_content = content is None
    src = _content_area(content, tree)
    if src is None:
        return CardRec(branch, qid, card, tree, None, root_is_content, content, None,
                       (), "?", "", "V", None, "内容区缺失", None, None, Audit(), "内容区缺失")
    axis = "H" if src.kind == "row" else ("V" if src.kind == "col" else "X")
    title = detect_title(src)
    sig = make_signature(src, title)
    blocks = [c for c in src.children if c is not title]
    formula = f"{axis}[{', '.join(fmt_block(c, axis, c is title) for c in src.children)}]"
    nested = nested_note(blocks, axis)
    matched, closest, note = match_official(card, content, tree)
    struct = structural_closest(src) if content is None else None
    audit = audit_card(src, title, axis)
    return CardRec(branch, qid, card, tree, src, root_is_content, content, title,
                   sig, formula, nested, axis, matched, note, closest, struct, audit)


@dataclass
class Cluster:
    key: tuple
    cards: List[CardRec] = field(default_factory=list)
    covered: bool = False
    cover: Optional[str] = None   # 覆盖模板名（官方或补充 63:xx）；None = 未覆盖

    @property
    def rep(self) -> CardRec:
        return self.cards[0]

    @property
    def formula(self) -> str:
        return self.rep.formula


def build_clusters(recs: List[CardRec]) -> List[Cluster]:
    groups: Dict[tuple, List[CardRec]] = defaultdict(list)
    for r in recs:
        if r.error:
            continue
        groups[r.sig].append(r)
    clusters = []
    for key, cards in groups.items():
        cards.sort(key=lambda r: (r.branch, r.qid))
        cover = covered_morph(cards[0])
        covered = cover is not None and all(covered_morph(c) is not None for c in cards)
        clusters.append(Cluster(key=key, cards=cards, covered=covered, cover=cover))
    clusters.sort(key=lambda c: (c.covered, -len(c.cards), c.formula))
    return clusters


def cluster_suggestion(cluster: Cluster) -> Tuple[str, str]:
    """簇级机器建议：全卡原子全合法 → 建议入库；否则不建议 + 硬伤类别汇总。"""
    n = len(cluster.cards)
    ok = all(c.audit.ok for c in cluster.cards)
    if ok:
        return ("ok", "建议入库")
    counts: Counter = Counter()
    samples: Dict[str, str] = {}
    for c in cluster.cards:
        for h in c.audit.hard:
            if " gap " in h:
                k = "gap"
            elif h.startswith("title"):
                k = "title"
            elif "等分" in h:
                k = "split"
            elif h.startswith("垂直"):
                k = "vclose"
            elif h.startswith("横向"):
                k = "hclose"
            else:
                k = "other"
            counts[k] += 1
            samples.setdefault(k, h)
    label = {
        "gap": "gap 非档位", "title": "title 高非 17/20 档", "split": "等分不符",
        "vclose": "垂直缺口", "hclose": "横向缺口",
    }
    parts = []
    for k in HARD_KINDS:
        if counts[k]:
            if k in ("vclose", "hclose"):
                parts.append(f"{label[k]}（{samples[k]}）")
            else:
                parts.append(f"{label[k]}×{counts[k]}/{n}")
    return ("bad", "不建议：" + "；".join(parts))


#: 簇级审计聚合（行内初判列用；逐卡精确数值见详情）
@dataclass
class ClusterAudit:
    gap_vals: List[int] = field(default_factory=list)       # content_root 声明 gap 集合
    gap_lines: List[str] = field(default_factory=list)
    title_hs: List[int] = field(default_factory=list)
    title_line: str = ""
    v_lines: List[str] = field(default_factory=list)
    h_lines: List[str] = field(default_factory=list)
    split_count: int = 0
    split_sample: str = ""
    dim_variance: List[str] = field(default_factory=list)   # 各块位主轴尺寸分布


def _range_txt(pairs: List[Tuple[int, Optional[int]]]) -> str:
    """[(子和口径缺口, 含gap口径缺口|None)] → 文本；None = gap 未声明按 0（不再列含 gap 口径）。"""
    if not pairs:
        return ""
    no_gap = [p[0] for p in pairs]
    lo, hi = min(no_gap), max(no_gap)
    rng = f"{lo}" if lo == hi else f"{lo}~{hi}"
    word = "缺口" if hi >= 0 else "超出"
    wg = [p[1] for p in pairs if p[1] is not None]
    if not wg:
        return f"{word} {rng}vp（子和口径；gap 未声明按 0）"
    wlo, whi = min(wg), max(wg)
    if whi <= TOL:
        return f"{word} {rng}vp（子和口径；含 gap 闭合 ✓）"
    wlo, whi = max(wlo, 1), whi
    if wlo == whi:
        wrng = f"{wlo}"
    elif wlo <= 0 < whi:
        wrng = f"超{-wlo}~余{whi}"
    else:
        wrng = f"{wlo}~{whi}"
    return f"{word} {rng}vp（子和口径；含 gap 计 {wrng}vp）"


def cluster_audit(cluster: Cluster) -> ClusterAudit:
    """簇级原子审计聚合（量化范围 + 档位合法性；机器初判，不作为结论）。"""
    ca = ClusterAudit()
    cards = cluster.cards
    axis = cards[0].axis
    src0 = cards[0].src
    # gap（content_root 声明值集合；口径同 layout_2x4._gap：顶层 itemMargin → styles）
    gaps = []
    for c in cards:
        dg = _declared_gap(c.src)
        if dg is not None:
            gaps.append(int(round(dg)))
    gaps = sorted(set(gaps))
    ca.gap_vals = gaps
    if not gaps:
        ca.gap_lines.append("gap 未声明（声明层跳过，交 L2）")
    else:
        bad = [g for g in gaps if g not in GAP_OK]
        if bad:
            ca.gap_lines.append(f"gap 声明值 {gaps}，其中 {bad} ∉ {{4,8,12,16}}")
        else:
            ca.gap_lines.append(f"gap 声明值 {gaps} ✓（档位 {{4,8,12,16}}）")
    # title
    hs = sorted({round(c.title.h) for c in cards if c.title and c.title.h is not None})
    ca.title_hs = hs
    if not hs:
        ca.title_line = "无 title 块"
    else:
        bad = [h for h in hs if not any(abs(h - t) <= 1 for t in TITLE_TIERS)]
        if bad:
            ca.title_line = f"title 高 {hs}，其中 {bad} 非 17/20 档"
        else:
            ca.title_line = f"title 高 {hs} ✓（17/20 档）"
    # 垂直 / 横向闭合（content_root 层；gap 未声明按 0，含 gap 口径只对生效声明成立）
    vpairs: List[Tuple[int, Optional[int]]] = []
    hpairs: List[Tuple[int, Optional[int]]] = []
    for c in cards:
        src = c.src
        dg = _declared_gap(src)
        if axis == "V":
            hsv = [k.h for k in src.children]
            if all(h is not None for h in hsv):
                sum_h = sum(hsv)
                gt = (dg or 0.0) * (len(hsv) - 1)
                vpairs.append((round(SAFE_H - sum_h),
                               None if dg is None else round(SAFE_H - sum_h - gt)))
        else:
            for k in src.children:
                if k.h is not None and SAFE_H - k.h > TOL:
                    vpairs.append((round(SAFE_H - k.h),
                                   None if dg is None else round(SAFE_H - k.h)))
        if axis == "H":
            wsv = [k.w for k in src.children]
            if all(w is not None for w in wsv):
                sum_w = sum(wsv)
                gt = (dg or 0.0) * (len(wsv) - 1)
                hpairs.append((round(SAFE_W - sum_w),
                               None if dg is None else round(SAFE_W - sum_w - gt)))
        else:
            for k in src.children:
                if k is c.title or is_action_block(k):
                    continue
                if k.w is not None and SAFE_W - k.w > TOL:
                    hpairs.append((round(SAFE_W - k.w),
                                   None if dg is None else round(SAFE_W - k.w)))
    if vpairs:
        ca.v_lines.append("垂直：" + _range_txt(vpairs))
    else:
        ca.v_lines.append("垂直：声明齐全卡均闭合 ✓" if axis == "V" else "垂直：块高均达 136 ✓")
    if hpairs:
        ca.h_lines.append("横向：" + _range_txt(hpairs))
    else:
        ca.h_lines.append("横向：全宽行均达 296 ✓")
    # 等分（形态级硬伤口径：与建议判定一致，只计 depth ≤ 1 的 H 分栏不符）
    split_cards = [c for c in cards if any("等分" in h for h in c.audit.hard)]
    ca.split_count = len(split_cards)
    if split_cards:
        ca.split_sample = next(h for h in split_cards[0].audit.hard if "等分" in h)
    # 主轴尺寸分布（结构式同形、数值有差的块位，供 owner 看数值层差异）
    n_blocks = len(src0.children) - (1 if cards[0].title is not None else 0)
    labels = [fmt_block(b, axis) for b in src0.children
              if b is not cards[0].title]
    dims_by_pos: List[List[int]] = [[] for _ in range(n_blocks)]
    for c in cards:
        kids = [k for k in c.src.children if k is not c.title]
        for i, k in enumerate(kids):
            d = _main_dim(k, axis)
            if d is not None:
                dims_by_pos[i].append(round(d))
    pos_dims = []
    for i, dims in enumerate(dims_by_pos):
        if not dims:
            continue
        uniq = sorted(set(dims))
        if len(uniq) > 1:
            pos_dims.append(f"{labels[i].rstrip('0123456789×')}{'/'.join(str(u) for u in uniq)}")
    ca.dim_variance = pos_dims
    return ca


# ---------------------------------------------------------------------------
# 声明层布局推演引擎（简化 flex；视觉示意图用，非规则真值，不落规则）
# ---------------------------------------------------------------------------

#: 画布与安全区常量（DESIGN-2x4.md layout_slots.canvas：root 320×160、padding 12、安全区 296×136）
CANVAS_W = 320.0
CANVAS_H = 160.0
SAFE_X = 12.0
SAFE_Y = 12.0
#: 推演最大深度（从内容容器起计；更深层块跳过并在图注标注，避免图面噪音）
MAX_DEPTH = 6
#: 嵌套子块渲染内缩（px，相对父块）
NEST_INSET = 2.0


@dataclass
class Placed:
    """推演布局块：绝对坐标 (x, y, w, h) + 推演标记。

    undeclared_w/h：该方向 DSL 未声明、由引擎弹性均分/拉伸推得（示意图标注 *）；
    skipped 非空 = 异常降级（负尺寸/剩余空间为负/超深度），跳过该块渲染并在图注标注。
    """
    node: TNode
    x: float
    y: float
    w: float
    h: float
    depth: int = 0
    undeclared_w: bool = False
    undeclared_h: bool = False
    children: List["Placed"] = field(default_factory=list)
    skipped: str = ""


def _raw_dim(node: TNode, key: str) -> Any:
    """styles.width/height 原始声明值（保留 matchParent / 百分比字符串）。"""
    st = node.comp.get("styles") or {}
    return st.get(key) if isinstance(st, dict) else None


def _resolve_dim(raw: Any, avail: float) -> Optional[float]:
    """声明尺寸 → 数值：数字直取；matchParent / 百分比继承父容器对应方向尺寸；
    未声明 / 不可解析 → None（由父层弹性均分或拉伸）。"""
    if raw is None or isinstance(raw, bool):
        return None
    if isinstance(raw, (int, float)):
        return float(raw)
    s = str(raw).strip()
    if not s:
        return None
    if s.lower() == "matchparent":
        return avail
    if s.endswith("%"):
        try:
            return avail * float(s[:-1]) / 100.0
        except ValueError:
            return None
    try:
        return float(s)
    except ValueError:
        return None


def _parse_padding(comp: Dict[str, Any]) -> Tuple[float, float, float, float]:
    """padding 归一：(left, right, top, bottom)。支持单值数值与四值 dict 形态
    （{'left':12,'right':12,'top':8,'bottom':8}，数据实证 71 处均为四键形态）。"""
    st = comp.get("styles") or {}
    pad = st.get("padding")
    if isinstance(pad, dict):
        return (float(pad.get("left") or 0.0), float(pad.get("right") or 0.0),
                float(pad.get("top") or 0.0), float(pad.get("bottom") or 0.0))
    if isinstance(pad, (int, float)) and not isinstance(pad, bool):
        return (float(pad),) * 4
    return (0.0, 0.0, 0.0, 0.0)


def _overflow(p: Placed) -> bool:
    """块越出安全区（x+w>308 或 y+h>148，规范口径）。"""
    return (p.x + p.w > SAFE_X + SAFE_W + 0.05
            or p.y + p.h > SAFE_Y + SAFE_H + 0.05)


def infer_layout(src: TNode) -> Placed:
    """内容区（content_root 或 root 自身，B 分支形态）简化 flex 推演。

    口径（WP-LAYOUT-FORMS-RENDER 任务书）：
    - root 固定 0,0,320,160；内容容器从 padding 起算（content_root 声明尺寸不影响
      画布口径——规范固定 padding 12 → 内容区 12,12,296,136）；
    - Row 子块从左到右 x 累加 子宽+gap（gap 取生效声明 styles.itemMargin，未声明按 0）；
      Column 同理纵向；
    - matchParent / 百分比继承父容器对应方向尺寸；
    - 子块未声明宽/高：弹性均分剩余空间（该方向剩余空间 / 未声明块数），打 undeclared
      标记；剩余空间为负 → 相关块降级跳过（图注标注）；
    - 交叉轴未声明：拉伸到容器内容区（「容器高 = max(子高)」在容器交叉轴未声明且子块
      声明齐全时由拉伸目标等价覆盖；Row/Column 声明了交叉尺寸用声明值）；
    - box（Stack 等）兜底按自上而下堆叠；异常（负尺寸/非正尺寸）跳过该块渲染。
    """
    root = Placed(node=src, x=0.0, y=0.0, w=CANVAS_W, h=CANVAS_H, depth=0)
    pl, pr, pt, pb = _parse_padding(src.comp)
    _place_children(src, root, pl, pt, CANVAS_W - pl - pr, CANVAS_H - pt - pb)
    return root


def _place_children(node: TNode, parent: Placed, cx: float, cy: float,
                    cw: float, ch: float) -> None:
    """在内容盒 (cx, cy, cw, ch)（绝对坐标）内布置 node 的直接子块并递归。"""
    kids = node.children
    if not kids:
        return
    gap = _declared_gap(node) or 0.0
    n = len(kids)
    depth = parent.depth + 1
    if depth > MAX_DEPTH:
        parent.skipped = f"深度>{MAX_DEPTH}，{len(kids)} 个下级块未推演"
        return
    if node.kind == "row":
        # 主轴（宽）：声明直取；未声明弹性均分剩余
        wvals: List[Optional[float]] = []
        n_und = 0
        for k in kids:
            v = _resolve_dim(_raw_dim(k, "width"), parent.w)
            wvals.append(v)
            if v is None:
                n_und += 1
        skip_share = False
        if n_und:
            declared = sum(v for v in wvals if v is not None)
            remaining = cw - declared - gap * (n - 1)
            if remaining < -TOL:
                skip_share = True  # 剩余空间为负：未声明块降级跳过
                share = 0.0
            else:
                share = max(0.0, remaining) / n_und
            wvals = [v if v is not None else share for v in wvals]
        # 交叉轴（高）：未声明拉伸到容器内容高
        hvals = []
        for k in kids:
            v = _resolve_dim(_raw_dim(k, "height"), parent.h)
            hvals.append(ch if v is None else v)
        x = cx
        for k, wv, hv in zip(kids, wvals, hvals):
            _place_child(k, parent, x, cy, wv, hv,
                         skip_share and _raw_dim(k, "width") is None)
            x += wv + gap
    else:  # column（含 box 兜底：自上而下堆叠）
        hvals = []
        n_und = 0
        for k in kids:
            v = _resolve_dim(_raw_dim(k, "height"), parent.h)
            hvals.append(v)
            if v is None:
                n_und += 1
        skip_share = False
        if n_und:
            declared = sum(v for v in hvals if v is not None)
            remaining = ch - declared - gap * (n - 1)
            if remaining < -TOL:
                skip_share = True
                share = 0.0
            else:
                share = max(0.0, remaining) / n_und
            hvals = [v if v is not None else share for v in hvals]
        wvals = []
        for k in kids:
            v = _resolve_dim(_raw_dim(k, "width"), parent.w)
            wvals.append(cw if v is None else v)
        y = cy
        for k, hv, wv in zip(kids, hvals, wvals):
            _place_child(k, parent, cx, y, wv, hv,
                         skip_share and _raw_dim(k, "height") is None)
            y += hv + gap


def _place_child(k: TNode, parent: Placed, x: float, y: float, w: float,
                 h: float, skipped_share: bool) -> None:
    """单个子块落位：非正尺寸/负剩余 → 跳过标记；否则递归推演其内部。"""
    placed = Placed(node=k, x=x, y=y, w=w, h=h, depth=parent.depth + 1,
                    undeclared_w=_raw_dim(k, "width") is None,
                    undeclared_h=_raw_dim(k, "height") is None)
    if skipped_share:
        placed.skipped = "剩余空间为负，未声明尺寸块降级跳过"
    elif w <= 0 or h <= 0:
        placed.skipped = "非正尺寸，跳过"
    parent.children.append(placed)
    if placed.skipped == "" and k.children:
        pl, pr, pt, pb = _parse_padding(k.comp)
        _place_children(k, placed, x + pl, y + pt, w - pl - pr, h - pt - pb)


def _walk_placed(root: Placed):
    """深度优先遍历推演树（含根）。"""
    stack = [root]
    while stack:
        p = stack.pop()
        yield p
        stack.extend(p.children)


def _layout_counts(placed: Placed) -> Tuple[int, int, int, int, int]:
    """(渲染块数, 未声明尺寸块数, 越出安全区块数, 异常跳过块数, matchParent 继承块数)；
    根（内容容器）不计。"""
    n = u = o = s = m = 0
    for p in _walk_placed(placed):
        if p is placed:
            continue
        n += 1
        if p.undeclared_w or p.undeclared_h:
            u += 1
        if _overflow(p):
            o += 1
        if p.skipped:
            s += 1
        if any(isinstance(_raw_dim(p.node, key), str) for key in ("width", "height")):
            m += 1
    return n, u, o, s, m


def _skip_notes(placed: Placed) -> str:
    """图注用的异常跳过说明（去重）。"""
    msgs = []
    for p in _walk_placed(placed):
        if p.skipped and p.skipped not in msgs:
            msgs.append(p.skipped)
    return "；".join(msgs)


def compact_closure(rec: CardRec) -> str:
    """紧凑闭合注（主数值 = 含 gap 口径，与示意图一致；子和口径作参考）。
    示例：Q3 → 垂直余6vp（子和口径缺口22vp）；B-q38 → 垂直闭合✓（子和口径缺口8vp）。"""
    src, axis = rec.src, rec.axis
    kids = src.children
    dg = _declared_gap(src)
    if axis == "V":
        hs = [k.h for k in kids]
        if all(h is not None for h in hs):
            s = sum(hs)
            gt = (dg or 0.0) * (len(hs) - 1)
            rem = SAFE_H - s - gt        # 含 gap 余量（主数值）
            defi = SAFE_H - s            # 子和口径（参考）
            if dg is None:
                word = "缺口" if defi >= -TOL else "超出"
                return f"垂直{word}{abs(defi):.0f}vp（子和口径；gap未声明按0）"
            if abs(rem) <= TOL:
                return f"垂直闭合✓（子和口径{('缺口' if defi >= -TOL else '超出')}{abs(defi):.0f}vp）"
            word = "余" if rem > 0 else "超"
            ref = f"子和口径{('缺口' if defi >= -TOL else '超出')}{abs(defi):.0f}vp"
            return f"垂直{word}{abs(rem):.0f}vp（{ref}）"
        return "垂直：子块高未声明齐全"
    if axis == "H":
        ws = [k.w for k in kids]
        if all(w is not None for w in ws):
            s = sum(ws)
            gt = (dg or 0.0) * (len(ws) - 1)
            rem = SAFE_W - s - gt
            defi = SAFE_W - s
            if dg is None:
                word = "缺口" if defi >= -TOL else "超出"
                return f"横向{word}{abs(defi):.0f}vp（子和口径；gap未声明按0）"
            if abs(rem) <= TOL:
                return f"横向闭合✓（子和口径{('缺口' if defi >= -TOL else '超出')}{abs(defi):.0f}vp）"
            word = "余" if rem > 0 else "超"
            ref = f"子和口径{('缺口' if defi >= -TOL else '超出')}{abs(defi):.0f}vp"
            return f"横向{word}{abs(rem):.0f}vp（{ref}）"
        return "横向：子块宽未声明齐全"
    return ""


def svg_caption(rec: CardRec) -> str:
    """示意图下方一行小字：`A-q3 · V[title24, panel58, action32×2] · 垂直缺口22vp…`。"""
    parts = [f"{rec.branch}-{rec.qid}", f"{rec.formula}"]
    cc = compact_closure(rec)
    if cc:
        parts.append(cc)
    placed = infer_layout(rec.src)
    _, und, ovf, skip, _ = _layout_counts(placed)
    if ovf:
        parts.append(f"⚠{ovf}块越出安全区")
    if und:
        parts.append(f"推演值*×{und}")
    if skip:
        notes = _skip_notes(placed)
        if notes:
            parts.append(f"跳过:{notes}")
    return " · ".join(parts)


# ---------------------------------------------------------------------------
# SVG 布局示意图渲染器（viewBox 320×160，显示 640×320；纯字符串拼接，无新依赖）
# ---------------------------------------------------------------------------

#: 语义配色：(填充, 描边, 虚线样式) —— title 蓝 / panel 灰 / action 绿 / Text 灰虚线 / Image 黄
STYLE_TITLE = ("#e8f0fe", "#0a59f7", "")
STYLE_PANEL = ("#f2f4f7", "#889", "")
STYLE_ACTION = ("#e8f7ee", "#0c7a43", "")
STYLE_TEXT = ("none", "#999", "6 4")
STYLE_IMAGE = ("#fff8e6", "#b3912e", "")
STYLE_BOX = ("#f2f4f7", "#889", "")


def _block_semantics(p: Placed, title: Optional[TNode]) -> Tuple[str, str, str]:
    """块语义配色：title 蓝 / action 绿 / Image 黄 / Text 虚线灰 / 其余容器灰。"""
    node = p.node
    if node is title:
        return STYLE_TITLE
    if is_action_block(node):
        return STYLE_ACTION
    comp = node.comp.get("component")
    if comp == "Image":
        return STYLE_IMAGE
    if comp == "Text":
        return STYLE_TEXT
    return STYLE_PANEL


def _num_fmt(v: float) -> str:
    return f"{v:g}"


def _svg_rect(x: float, y: float, w: float, h: float, rx: float,
              fill: str, stroke: str, sw: float, dash: str) -> str:
    out = [f'<rect x="{_num_fmt(x)}" y="{_num_fmt(y)}" width="{_num_fmt(w)}"'
           f' height="{_num_fmt(h)}" rx="{_num_fmt(rx)}"']
    out.append(' fill="none"' if fill == "none" else f' fill="{fill}"')
    out.append(f' stroke="{stroke}" stroke-width="{_num_fmt(sw)}"')
    if dash:
        out.append(f' stroke-dasharray="{dash}"')
    out.append("/>")
    return "".join(out)


def _trunc(s: str, max_chars: float) -> str:
    """按像素宽截断等宽 id（10px 等宽 ≈ 6px/字符；8.5px ≈ 5.2px/字符）。"""
    n = int(max_chars)
    if n <= 0:
        return ""
    return s if len(s) <= n else s[: max(1, n - 1)] + "…"


def _size_label(p: Placed) -> str:
    w = f"{round(p.w):d}{'*' if p.undeclared_w else ''}"
    h = f"{round(p.h):d}{'*' if p.undeclared_h else ''}"
    return f"{w}×{h}"


def _svg_block(p: Placed, title: Optional[TNode], out: List[str]) -> None:
    """单块圆角矩形 + 标注；嵌套子块相对父块内缩 2px；越界描边改红。"""
    if p.skipped:
        return
    inset = min(NEST_INSET, p.w / 4.0, p.h / 4.0)
    x, y, w, h = p.x + inset, p.y + inset, p.w - 2 * inset, p.h - 2 * inset
    fill, stroke, dash = _block_semantics(p, title)
    overflow = _overflow(p)
    if overflow:
        stroke = "#d33"
    rx = min(4.0, w / 2.0, h / 2.0)
    out.append(_svg_rect(x, y, w, h, rx, fill, stroke, 1.2 if overflow else 1.0, dash))
    cid = str(p.node.comp.get("id") or "")
    if w >= 16 and h >= 10:
        if w >= 34 and h >= 26:
            out.append(f'<text x="{_num_fmt(x + 4)}" y="{_num_fmt(y + 12)}"'
                       f' font-size="10" fill="#333">{esc(_trunc(cid, (w - 8) / 6.0))}</text>')
            out.append(f'<text x="{_num_fmt(x + 4)}" y="{_num_fmt(y + 23)}"'
                       f' font-size="9" fill="#888">{esc(_size_label(p))}</text>')
        else:
            out.append(f'<text x="{_num_fmt(x + 3)}" y="{_num_fmt(y + 11)}"'
                       f' font-size="8.5" fill="#555">{esc(_trunc(cid, (w - 6) / 5.2))}</text>')
    for c in p.children:
        _svg_block(c, title, out)


def svg_for_rec(rec: CardRec, width: int = 640, height: int = 320) -> str:
    """代表卡整张 SVG：卡底 + 安全区参考线（四角 12vp）+ 全部推演块。

    width/height = 显示尺寸（候选行产物小图用 384×192，~60%）。"""
    root = infer_layout(rec.src)
    out = [f'<svg viewBox="0 0 320 160" width="{width}" height="{height}"'
           ' xmlns="http://www.w3.org/2000/svg"'
           ' font-family="ui-monospace,SFMono-Regular,Menlo,Consolas,monospace"'
           ' style="max-width:100%;height:auto">']
    # 卡底：白底 + 1.5px 深灰外框 + 20 圆角
    out.append('<rect x="0.5" y="0.5" width="319" height="159" rx="20"'
               ' fill="#ffffff" stroke="#555" stroke-width="1.5"/>')
    # 安全区参考线：296×136 红色虚线框 + 四角 12vp 标注
    out.append('<rect x="12" y="12" width="296" height="136" fill="none"'
               ' stroke="#d33" stroke-width="1" stroke-dasharray="4 3"/>')
    out.append('<text x="15" y="20" font-size="7" fill="#d33">12</text>')
    out.append('<text x="305" y="20" font-size="7" fill="#d33" text-anchor="end">12</text>')
    out.append('<text x="15" y="147" font-size="7" fill="#d33">12</text>')
    out.append('<text x="305" y="147" font-size="7" fill="#d33" text-anchor="end">12</text>')
    for c in root.children:
        _svg_block(c, rec.title, out)
    out.append("</svg>")
    return "".join(out)


def svg_strip_html(cards: List[CardRec]) -> str:
    """簇代表卡（前 3 张）示意图条：首图直接内联，其余 2 张放 details 折叠。"""
    shown = [c for c in cards if not c.error and c.src is not None][:3]
    if not shown:
        return ""
    items = []
    for rec in shown:
        items.append(f'<div class="svgitem">{svg_for_rec(rec)}'
                     f'<div class="svgcap">{esc(svg_caption(rec))}</div></div>')
    first = items[0]
    rest = "".join(items[1:])
    extra = ""
    if rest:
        extra = (f'<details class="svgextra"><summary>其余代表卡示意图（{len(shown) - 1} 张）'
                 f'</summary><div class="svgstrip">{rest}</div></details>')
    return f'<div class="svgstrip">{first}{extra}</div>'


# ---------------------------------------------------------------------------
# 现网实拍图（2026-08-24 WP-LAYOUT-FORMS-RENDER 追加：人审看真实产物渲染）
# 源：第一次评测/A(…)/images/qN.png 与 B(现网分支)/images/qN.png（只读）；
# 复制到 review/vis-assets/<分支>-qN.png（派生产物，已存在跳过），清单用相对路径引用
# ---------------------------------------------------------------------------

def _live_shot_src(branch: str, qid: str) -> Optional[Path]:
    """实拍源路径（评测数据只读引用）。"""
    root = eval_root()
    if branch == "A":
        d = root / "A(晓峰单独分支——一步走)" / "images"
    elif branch == "B":
        d = root / "B(现网分支)" / "images"
    else:
        return None
    p = d / f"{qid}.png"
    return p if p.is_file() else None


def ensure_live_shot(branch: str, qid: str) -> Optional[Path]:
    """复制实拍到 review/vis-assets/<分支>-qN.png（已存在则跳过）；源缺失返回 None。"""
    src = _live_shot_src(branch, qid)
    if src is None:
        return None
    dst = review_dir() / "vis-assets" / f"{branch}-{qid}.png"
    if not dst.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    return dst


def shot_img_html(branch: str, qid: str) -> str:
    """现网实拍 <img>（相对 vis-assets，1px 边框，384×192 等比 320×160）；
    实拍缺失显示占位框。"""
    if ensure_live_shot(branch, qid) is None:
        return f'<div class="shot-miss">实拍缺失 · {branch}-{qid}</div>'
    return (f'<img src="../vis-assets/{branch}-{qid}.png" width="384" height="192"'
            f' alt="现网实拍 {branch}-{qid}"'
            f' style="border:1px solid #b8bec7;border-radius:8px;display:block;max-width:100%;height:auto">'
            f'<div class="shotcap">现网实拍 {branch}-{qid}</div>')


# ---------------------------------------------------------------------------
# 官方 18 变体标准骨架渲染器（金标准参照系）
# 几何从 layout_2x4._VARIANT_TEMPLATES 结构推导槽位矩形（与检测同源，不复制数值；
# 对应 docs/pixso-layout-abstraction.md：bare 136 全高 / tc 17+4+115 / tr 20+8+108 /
# ta 20+4+72+4+capsule36，胶囊 140×36 全圆角、距卡底 12vp）
# ---------------------------------------------------------------------------

#: 四种根结构家族布局：(title 高 | None, title 后 gap, 内容区 (x, y, w, h))
_FAMILY_LAYOUT = {
    "bare": (None, 0.0, (SAFE_X, SAFE_Y, SAFE_W, SAFE_H)),
    "tc": (17.0, 4.0, (SAFE_X, 33.0, SAFE_W, 115.0)),
    "tr": (20.0, 8.0, (SAFE_X, 40.0, SAFE_W, 108.0)),
    "ta": (20.0, 4.0, (SAFE_X, 36.0, SAFE_W, 108.0)),
}


def _variant_family(name: str) -> str:
    """变体名 → 根结构家族 bare/tc/tr/ta。"""
    for fam in ("bare", "tc", "tr", "ta"):
        if name.startswith(fam + "-"):
            return fam
    return "bare"


def _slot_num(v: float) -> str:
    return f"{round(v, 1):g}"


def _slot_label(w: float, h: float) -> str:
    return f"{_slot_num(w)}×{_slot_num(h)}"


def _family_closure_text(fam: str) -> str:
    return {
        "bare": "content 136 全高",
        "tc": "title 17 + gap 4 + content 115",
        "tr": "title 20 + gap 8 + content 108",
        "ta": "title 20 + gap 4 + content 72 + gap 4 + capsule 36",
    }[fam]


def _tpl_top_slots(tpl: tuple, fam: str) -> List[Tuple[float, float]]:
    """模板首层槽位 (w, h)：box 单槽；row 各子槽（容器均分剩余宽）；col 各子槽（容器均分剩余高）。"""
    kind = tpl[0]
    _, _, (_, _, cw, ch) = _FAMILY_LAYOUT[fam]
    if kind == "box":
        return [(float(tpl[1]), float(tpl[2]))]
    if kind == "vseq":
        out: List[Tuple[float, float]] = []
        for k in tpl[1]:
            if k[0] == "box":
                out.append((float(k[1]), float(k[2])))
            else:
                # 容器槽位（63:27 双按钮行 / 63:37 二分 content）：宽 = Σ子宽+gap，高 = 子 box 高
                sub_w = sum(float(kk[1]) for kk in k[2] if kk[0] == "box") + k[1] * (len(k[2]) - 1)
                sub_h = max(float(kk[2]) for kk in k[2] if kk[0] == "box")
                out.append((sub_w, sub_h))
        return out
    gap = tpl[1]
    kids = tpl[2]
    if kind == "row":
        declared = sum(float(k[1]) for k in kids if k[0] == "box")
        n_cont = sum(1 for k in kids if k[0] != "box")
        rem = cw - declared - gap * (len(kids) - 1)
        cont_w = rem / n_cont if n_cont else 0.0
        return [(float(k[1]) if k[0] == "box" else cont_w, ch) for k in kids]
    declared = sum(float(k[2]) for k in kids if k[0] == "box")
    n_cont = sum(1 for k in kids if k[0] != "box")
    rem = ch - declared - gap * (len(kids) - 1)
    cont_h = rem / n_cont if n_cont else 0.0
    return [(cw, float(k[2]) if k[0] == "box" else cont_h) for k in kids]


def _layout_tpl(tpl: tuple, cx: float, cy: float, cw: float, ch: float,
                fam: str, rects: List[tuple]) -> None:
    """模板结构 → 槽位矩形（绝对坐标；容器子块均分剩余主轴空间）。"""
    kind = tpl[0]
    if kind == "box":
        w, h = float(tpl[1]), float(tpl[2])
        rects.append((cx, cy, w, h, h == 36.0, _slot_label(w, h)))  # 高 36 = 按钮槽位（全圆角）
    elif kind == "row":
        gap = tpl[1]
        kids = tpl[2]
        declared = sum(float(k[1]) for k in kids if k[0] == "box")
        n_cont = sum(1 for k in kids if k[0] != "box")
        rem = cw - declared - gap * (len(kids) - 1)
        cont_w = rem / n_cont if n_cont else 0.0
        x = cx
        for kid in kids:
            if kid[0] == "box":
                w, h = float(kid[1]), float(kid[2])
                rects.append((x, cy, w, h, h == 36.0, _slot_label(w, h)))
                x += w + gap
            else:
                _layout_tpl(kid, x, cy, cont_w, ch, fam, rects)
                x += cont_w + gap
    elif kind == "col":
        gap = tpl[1]
        kids = tpl[2]
        declared = sum(float(k[2]) for k in kids if k[0] == "box")
        n_cont = sum(1 for k in kids if k[0] != "box")
        rem = ch - declared - gap * (len(kids) - 1)
        cont_h = rem / n_cont if n_cont else 0.0
        y = cy
        for kid in kids:
            if kid[0] == "box":
                w, h = float(kid[1]), float(kid[2])
                rects.append((cx, y, w, h, h == 36.0, _slot_label(w, h)))
                y += h + gap
            else:
                _layout_tpl(kid, cx, y, cw, cont_h, fam, rects)
                y += cont_h + gap


def skeleton_rects(name: str) -> Tuple[Optional[tuple], List[tuple], List[tuple]]:
    """官方/补充变体 → (title 槽位 (x,y,w,h)|None, 槽位矩形 [(x,y,w,h,is_capsule,label)],
    首层槽位 [(w,h)])。几何全部从模板结构推导（官方 _VARIANT_TEMPLATES + 补充 _SUPPLEMENT_TEMPLATES）。"""
    tpl = _VARIANT_TEMPLATES.get(name)
    if tpl is None:
        tpl = _SUPPLEMENT_TEMPLATES.get(name)
    if tpl is None:
        return (None, [], [])
    fam = _tpl_family(name)
    title_h, _, (cx, cy, cw, ch) = _FAMILY_LAYOUT[fam]
    title_rect = (SAFE_X, SAFE_Y, SAFE_W, title_h) if title_h else None
    rects: List[tuple] = []
    if fam == "ta":
        # vseq：content + gap 4 + 按钮块（box 单钮 / row 多钮容器，如 63:27/63:37）
        y = cy
        for kid in tpl[1]:
            if kid[0] == "box":
                w, h = float(kid[1]), float(kid[2])
                rects.append((cx, y, w, h, h == 36.0, _slot_label(w, h)))
                y += h + 4.0
            else:
                sub_h = max(float(k[2]) for k in kid[2])
                _layout_tpl(kid, cx, y, cw, sub_h, fam, rects)
                y += sub_h + 4.0
    else:
        _layout_tpl(tpl, cx, cy, cw, ch, fam, rects)
    return (title_rect, rects, _tpl_top_slots(tpl, fam))


def _svg_slot_text(x: float, y: float, w: float, h: float, label: str) -> str:
    fs = 9.0 if w >= 60 else 7.5
    return (f'<text x="{_num_fmt(x + w / 2)}" y="{_num_fmt(y + h / 2 + fs * 0.36)}"'
            f' font-size="{fs:g}" fill="#4a5560" text-anchor="middle">{esc(label)}</text>')


def _svg_skeleton_common(name: str, fam: str, title_rect: Optional[tuple],
                         rects: List[tuple]) -> str:
    """骨架 SVG：卡框 + 安全区 + 中性浅灰虚线槽位（与产物语义着色区分）。"""
    out = ['<svg viewBox="0 0 320 160" width="640" height="320"'
           ' xmlns="http://www.w3.org/2000/svg"'
           ' font-family="ui-monospace,SFMono-Regular,Menlo,Consolas,monospace"'
           ' style="max-width:100%;height:auto">']
    out.append('<rect x="0.5" y="0.5" width="319" height="159" rx="20"'
               ' fill="#ffffff" stroke="#555" stroke-width="1.5"/>')
    out.append('<rect x="12" y="12" width="296" height="136" fill="none"'
               ' stroke="#d33" stroke-width="1" stroke-dasharray="4 3"/>')
    out.append('<text x="15" y="20" font-size="7" fill="#d33">12</text>')
    out.append('<text x="305" y="20" font-size="7" fill="#d33" text-anchor="end">12</text>')
    out.append('<text x="15" y="147" font-size="7" fill="#d33">12</text>')
    out.append('<text x="305" y="147" font-size="7" fill="#d33" text-anchor="end">12</text>')
    if title_rect is not None:
        x, y, w, h = title_rect
        out.append(_svg_rect(x, y, w, h, min(8.0, h / 2.0), "#e3e6ec", "#5a6472", 1.2, "4 3"))
        out.append(_svg_slot_text(x, y, w, h, f"title {_slot_label(w, h)}"))
    for x, y, w, h, cap, label in rects:
        rx = min(h / 2.0, w / 2.0) if cap else min(16.0 if fam == "bare" else 8.0, h / 2.0, w / 2.0)
        out.append(_svg_rect(x, y, w, h, rx, "#eceef1", "#5a6472", 1.2, "4 3"))
        out.append(_svg_slot_text(x, y, w, h, label))
    out.append("</svg>")
    return "".join(out)


def svg_skeleton(variant: str) -> str:
    """官方 18 / 补充 7 变体骨架 SVG（几何与检测同源，从模板结构推导）。"""
    title_rect, rects, _ = skeleton_rects(variant)
    return _svg_skeleton_common(variant, _tpl_family(variant), title_rect, rects)


# ---------------------------------------------------------------------------
# 覆盖判定（官方 18 + 补充 7 共同参与拓扑覆盖；2026-08-24 补充骨架接入）
# 口径：拓扑同构（V/H 层级、title 有无、action 有无与按钮数）+ 关键几何
# （title 档就近 {17,20}、闭合结构）；按钮宽 144/140 等价档不参与判定
# ---------------------------------------------------------------------------

def _rec_morph_sig(rec: CardRec) -> Optional[tuple]:
    """产物形态签名：(axis, title 档|None, 形态层块签名元组)。
    块签名：(kind, n_children, is_action, n_btns)。"""
    if rec.src is None:
        return None
    src = rec.src
    kids = [k for k in src.children if k is not rec.title]
    tier: Optional[int] = None
    if rec.title is not None and rec.title.h is not None:
        th = round(rec.title.h)
        if abs(th - 17) <= 1:
            tier = 17
        elif abs(th - 20) <= 1:
            tier = 20
        else:
            tier = 20 if abs(th - 20) <= abs(th - 17) else 17
    blocks = tuple(_rec_block_sig(k) for k in kids)
    return (rec.axis, tier, blocks)


def _rec_block_sig(node: TNode) -> tuple:
    if is_action_block(node):
        n = len(node.children)
        return ("action", n, True, n if n >= 1 else 1)  # 无子块的 action 容器 = 单按钮自身
    if node.kind in ("row", "col"):
        return (node.kind, len(node.children), False, 0)
    return ("box", 0, False, 0)


def _tpl_block_sig(kid: tuple) -> tuple:
    """模板子结构 → 块签名；高 36 的 box = 按钮槽位；全 36 高子块的 row/col = 按钮行
    （63:27 双按钮行）。"""
    k = kid[0]
    if k == "box":
        w, h = kid[1], kid[2]
        if h == 36.0:
            return ("action", 1, True, 1)
        return ("box", 0, False, 0)
    if k in ("row", "col"):
        sub = kid[2]
        if sub and all(kk[0] == "box" and kk[2] == 36.0 for kk in sub):
            return ("action", len(sub), True, len(sub))
    return (k, len(kid[2]), False, 0)


def _tpl_morph_sig(name: str) -> Optional[tuple]:
    """模板 → 形态签名（与产物同口径）。"""
    tpl = _VARIANT_TEMPLATES.get(name)
    if tpl is None:
        tpl = _SUPPLEMENT_TEMPLATES.get(name)
    if tpl is None:
        return None
    fam = _tpl_family(name)
    tier = {"bare": None, "tc": 17, "tr": 20, "ta": 20}[fam]
    kind = tpl[0]
    if kind == "box":
        return ("V", tier, (("box", 0, False, 0),))
    if kind == "vseq":
        return ("V", tier, tuple(_tpl_block_sig(k) for k in tpl[1]))
    if kind == "row":
        return ("H", tier, tuple(_tpl_block_sig(k) for k in tpl[2]))
    return ("V", tier, tuple(_tpl_block_sig(k) for k in tpl[2]))


def _sig_match(rec_sig: Optional[tuple], tpl_sig: Optional[tuple]) -> bool:
    """覆盖匹配：轴/方向 + title 档 + 块序列逐块（按钮只比数量，宽 144/140 等价档）。"""
    if rec_sig is None or tpl_sig is None:
        return False
    if rec_sig[0] != tpl_sig[0] or rec_sig[1] != tpl_sig[1]:
        return False
    rblk, tblk = rec_sig[2], tpl_sig[2]
    if len(rblk) != len(tblk):
        return False
    for rb, tb in zip(rblk, tblk):
        if tb[0] == "action":
            # 按钮槽位：产物需 action 且按钮数一致（rb[3]/tb[3]；宽 144/140 等价档不参与）
            if rb[0] != "action" or rb[3] != tb[3]:
                return False
        elif tb[0] in ("row", "col"):
            if rb[0] != tb[0] or rb[1] != tb[1]:
                return False
        else:
            # box 槽位（content）：产物需非 action 块（action 只能被按钮槽位匹配）
            if rb[0] == "action":
                return False
    return True


def covered_morph(rec: CardRec) -> Optional[str]:
    """官方 18 + 补充 7 拓扑覆盖判定：返回覆盖模板名（如 'ta-S1' / '63:27'）或 None。"""
    rsig = _rec_morph_sig(rec)
    for name in list(_VARIANT_TEMPLATES) + list(_SUPPLEMENT_TEMPLATES):
        if _sig_match(rsig, _tpl_morph_sig(name)):
            return name
    return None


def _missing_skeleton_name(rec: CardRec) -> str:
    """未覆盖簇的骨架缺口描述：缺什么型（如 tr-S1 / tr-list3 / ta-b3）。"""
    sig = _rec_morph_sig(rec)
    if sig is None:
        return "结构不可判定"
    _, tier, blocks = sig
    fam = {"bare": "bare", 17: "tc", 20: "tr"}[tier if tier is not None else "bare"]
    if any(b[0] == "action" for b in blocks):
        n_btns = max(b[3] for b in blocks if b[0] == "action")
        if tier == 20:
            return f"ta-b{n_btns}（title20 + action {n_btns} 按钮）"
        return f"ta-b{n_btns}-t{tier}"
    if sig[0] == "H":
        n = len(blocks)
        return f"bare-H{n}" if tier is None else f"{fam}-H{n}"
    n = len(blocks)
    if n == 1:
        return f"{fam}-S1（title{tier or '无'} 单内容）"
    return f"{fam}-list{n}（title{tier or '无'} + {n} 块内容）"


def _nearest(v: float, choices: Tuple[int, ...]) -> int:
    return min(choices, key=lambda c: abs(v - c))


@dataclass
class CandidateBlock:
    """候选骨架槽位（规范化几何）。"""
    x: float
    y: float
    w: float
    h: float
    label: str
    cap: bool = False       # 胶囊全圆角
    role: str = "content"   # title/content/action/col


@dataclass
class CandidateSkeleton:
    """未覆盖簇候选骨架：保持产物拓扑 + 几何归一金标准语言 + 决策点记录。"""
    formula: str            # 规范几何描述（供入库/一键复制）：V[title20, content72, capsule140×36×2]
    closure: str            # 闭合式：20+4+72+4+36=136
    family: str             # bare/tc/tr/ta（对应金标准根结构）
    topo: str = ""          # 产物拓扑：V[title, panel, action×2]（保持拓扑的证据）
    title_rect: Optional[tuple] = None
    blocks: List[CandidateBlock] = field(default_factory=list)
    decisions: List[str] = field(default_factory=list)  # 归一决策点：产物值 → 候选值（待裁标注）


def _rec_topo(rec: CardRec) -> str:
    """产物形态层拓扑（保持拓扑的输入证据）：V[title, panel, action×2]。"""
    parts = []
    if rec.title is not None:
        parts.append("title")
    for k in rec.src.children:
        if k is rec.title:
            continue
        if is_action_block(k) and k.children and len(k.children) >= 2:
            parts.append(f"action×{len(k.children)}")
        elif is_action_block(k):
            parts.append("action")
        elif k.kind in ("row", "col"):
            parts.append("panel")
        else:
            parts.append("block")
    return f"{rec.axis}[{', '.join(parts)}]"


def candidate_skeleton(rec: CardRec) -> CandidateSkeleton:
    """未覆盖簇代表卡 → 候选骨架（核心新增：人审对象）。

    保持拓扑（方向/层级/块数不变），几何归一金标准语言：
    - title 高 → 档位 {17,20} 就近（产物 24 → 候选 20，待裁标注）；
    - 根结构家族：无 title → bare；title17 → tc；title20 无 action → tr；有 action → ta；
    - bare：content 136 全高，分栏等分 (296-gap×(n-1))/n，gap 就近档位 {4,8,12,16}；
    - tc/tr：content 115/108 全宽（多块等分），gap 按根结构 4/8；
    - ta：title20 + gap4 + content72 + gap4 + capsule 36（单钮 140×36；双钮 140×36×2 gap8；
      多钮等分 tile），闭合 20+4+72+4+36=136；
    - 每处归一记「产物值 → 候选值（说明；无法机器决定者标待裁）」。
    """
    src, axis = rec.src, rec.axis
    title = rec.title
    kids = [k for k in src.children if k is not title]
    decisions: List[str] = []
    topo = _rec_topo(rec)

    # -- title 档位（产物值 → 档位 {17,20}）--
    if title is not None and title.h is not None:
        th = round(title.h)
        if abs(th - 17) <= 1:
            tier = 17
        elif abs(th - 20) <= 1:
            tier = 20
        else:
            tier = 20 if abs(th - 20) <= abs(th - 17) else 17
            decisions.append(f"title 高 {th}→{tier}（就近档位 {{17,20}}；待裁：认可 {th} 档需拍板）")
    else:
        tier = None

    # -- 根结构家族 --
    has_action = any(is_action_block(k) for k in kids)
    if tier is None:
        family = "bare"
    elif has_action:
        family = "ta"
    elif tier == 17:
        family = "tc"
    else:
        family = "tr"

    # -- gap 档位（bare：产物就近；tc/tr/ta：金标准根结构固定 4/8/4）--
    g0 = _declared_gap(src)
    if family == "bare":
        gap = _nearest(g0, (4, 8, 12, 16)) if g0 is not None else 12
        if g0 is not None and abs(g0 - gap) > TOL:
            decisions.append(f"gap {round(g0)}→{gap}（就近档位 {{4,8,12,16}}）")
    else:
        gap = {"tc": 4, "tr": 8, "ta": 4}[family]
        if g0 is not None and abs(g0 - gap) > TOL:
            decisions.append(f"gap {round(g0)}→{gap}（按 {family} 根结构标准）")

    blocks: List[CandidateBlock] = []
    title_rect = None
    if axis == "V":
        if title is not None:
            title_rect = (SAFE_X, SAFE_Y, SAFE_W, float(tier))
        if family == "ta":
            # ta：title20 + gap4 + content72 + gap4 + capsule 36 = 136
            content_kids = [k for k in kids if not is_action_block(k)]
            action_kids = [k for k in kids if is_action_block(k)]
            cy = SAFE_Y + tier + gap              # 36
            c_h = 72.0
            n_c = len(content_kids)
            if n_c == 1:
                blocks.append(CandidateBlock(SAFE_X, cy, SAFE_W, c_h, f"296×{c_h:g}", role="content"))
                h0 = content_kids[0].h
                if h0 is not None and abs(round(h0) - c_h) > TOL:
                    decisions.append(f"panel 高 {round(h0)}→{c_h:g}（闭合 136 补齐："
                                     f"136-{tier}-{gap}-36-{gap}）")
            elif n_c > 1:
                hh = (c_h - gap * (n_c - 1)) / n_c
                y = cy
                for _ in range(n_c):
                    blocks.append(CandidateBlock(SAFE_X, y, SAFE_W, hh, f"296×{_slot_num(hh)}",
                                                 role="content"))
                    y += hh + gap
                hs0 = "/".join(str(round(k.h)) if k.h is not None else "?" for k in content_kids)
                decisions.append(f"内容块高 {hs0} → 等分 {_slot_num(hh)}×{n_c}（content 区 {c_h:g} 内）")
            # action 区：y=112，高 36；按钮宽 144 等分（=(296-8)/2，2026-08-24 补充骨架实证；
            # 单/双统一 144×36，双按钮 gap 8 闭合 296；官方 capsule 140 为等价档差 4vp）
            ay = cy + c_h + gap                   # 112
            n_btn = 1
            if action_kids:
                act = action_kids[0]
                src_h = round(act.h) if act.h is not None else None
                if src_h is not None and src_h != 36:
                    decisions.append(f"action 高 {src_h}→36（金标准按钮高）")
                btns = act.children if act.children else []
                n_btn = len(btns) if len(btns) >= 2 else 1
                w0 = round(btns[0].w) if btns and btns[0].w is not None else None
                if len(btns) == 1:
                    decisions.append("action 单按钮 → capsule 144×36（金标准单按钮等分宽 "
                                     "(296-8)/2=144）")
                if len(btns) >= 2:
                    agap = _nearest((_declared_gap(act) or 8.0), (4, 8, 12, 16))
                    bw = 144.0
                    x = SAFE_X
                    for _ in range(n_btn):
                        blocks.append(CandidateBlock(x, ay, bw, 36.0, "144×36", cap=True, role="action"))
                        x += bw + agap
                    decisions.append(
                        f"按钮 {n_btn} 个（产物 {w0}×{src_h}）→ capsule 144×36×{n_btn}"
                        f"（等分宽 (296-gap {agap:g}×{n_btn - 1})/{n_btn}；"
                        + (f"产物按钮宽 {w0} 与 144 差 {abs(w0 - 144)}vp，待裁" if w0 is not None
                           and abs(w0 - 144) > 4 else "与 144 等价档"))
            else:
                blocks.append(CandidateBlock(SAFE_X, ay, 144.0, 36.0, "144×36", cap=True, role="action"))
                decisions.append("action 无子块 → capsule 144×36（单按钮表达）")
            closure = f"{tier}+{gap}+{c_h:g}+{gap}+36=136"
            formula = f"V[title{tier}, content{c_h:g}, capsule144×36×{n_btn}]"
        elif family in ("tc", "tr"):
            c_h = 115.0 if family == "tc" else 108.0
            cy = SAFE_Y + tier + gap
            content_kids = [k for k in kids if not is_action_block(k)]
            n_c = len(content_kids)
            if n_c == 1:
                blocks.append(CandidateBlock(SAFE_X, cy, SAFE_W, c_h, f"296×{c_h:g}", role="content"))
                h0 = content_kids[0].h
                if h0 is not None and abs(round(h0) - c_h) > TOL:
                    decisions.append(f"panel 高 {round(h0)}→{c_h:g}（{family} 根结构闭合 136 补齐）")
            elif n_c > 1:
                hh = (c_h - gap * (n_c - 1)) / n_c
                y = cy
                for _ in range(n_c):
                    blocks.append(CandidateBlock(SAFE_X, y, SAFE_W, hh, f"296×{_slot_num(hh)}",
                                                 role="content"))
                    y += hh + gap
                hs0 = "/".join(str(round(k.h)) if k.h is not None else "?" for k in content_kids)
                decisions.append(f"内容块高 {hs0} → 等分 {_slot_num(hh)}×{n_c}（content 区 {c_h:g} 内）")
            closure = f"{tier}+{gap}+{c_h:g}=136"
            formula = (f"V[title{tier}, content{c_h:g}]" if n_c == 1
                       else f"V[title{tier}, content×{n_c}]")
        else:
            # V 轴 bare 兜底（无 title）：内容等分 136
            n_c = len(kids)
            if n_c == 0:
                blocks.append(CandidateBlock(SAFE_X, SAFE_Y, SAFE_W, SAFE_H, "296×136", role="content"))
                closure = "136"
                formula = "V[content136]"
            else:
                hh = (SAFE_H - gap * (n_c - 1)) / n_c
                y = SAFE_Y
                for _ in range(n_c):
                    blocks.append(CandidateBlock(SAFE_X, y, SAFE_W, hh, f"296×{_slot_num(hh)}",
                                                 role="content"))
                    y += hh + gap
                closure = f"{_slot_num(hh)}×{n_c} + gap {gap}×{n_c - 1} = 136"
                formula = f"V[content×{n_c}]"
    else:
        # H 轴：bare（无 title 横向分栏），等分公式 (296-gap×(n-1))/n
        n = len(kids)
        if n == 0:
            blocks.append(CandidateBlock(SAFE_X, SAFE_Y, SAFE_W, SAFE_H, "296×136", role="col"))
            closure = "296"
            formula = "H[296×136]"
        else:
            w = (SAFE_W - gap * (n - 1)) / n
            x = SAFE_X
            for _ in range(n):
                blocks.append(CandidateBlock(x, SAFE_Y, w, SAFE_H, f"{_slot_num(w)}×136", role="col"))
                x += w + gap
            ws0 = [k.w for k in kids]
            if all(w0 is not None for w0 in ws0):
                hs0 = "/".join(str(round(w0)) for w0 in ws0)
                decisions.append(f"栏宽 {hs0} → 等分 {_slot_num(w)}×{n}"
                                 f"（公式 (296-gap {gap}×{n - 1})/{n}）")
            closure = f"{_slot_num(w)}×{n} + gap {gap}×{n - 1} = 296"
            formula = f"H[{_slot_num(w)}×136×{n}]"
    return CandidateSkeleton(formula=formula, closure=closure, family=family, topo=topo,
                             title_rect=title_rect, blocks=blocks, decisions=decisions)


def svg_candidate(cand: CandidateSkeleton) -> str:
    """候选骨架 SVG：Pixso 布局抽象卡风格（浅灰槽位 + 深描边 + 尺寸标注 + 安全区参考线）。"""
    rects = [(b.x, b.y, b.w, b.h, b.cap, b.label) for b in cand.blocks]
    return _svg_skeleton_common("candidate", cand.family, cand.title_rect, rects)


def candidate_row_html(cluster: Cluster) -> str:
    """未覆盖簇行三图布局：候选骨架图（主）+ DSL 推演图（推导来源）+ 现网实拍图（真实产物），
    同排展示；下方归一决策点列表；其余代表卡（前 3）折叠。"""
    rep = cluster.rep
    cand = candidate_skeleton(rep)
    decisions = "".join(f'<div>· {esc(d)}</div>' for d in cand.decisions) if cand.decisions \
        else '<div>· 无归一差异（产物已符合金标准语言）</div>'
    rest = [r for r in cluster.cards[:3] if r is not rep]
    extra = ""
    if rest:
        items = "".join(
            f'<div class="svgitem">{svg_for_rec(r)}'
            f'<div class="svgcap">{esc(svg_caption(r))}</div></div>' for r in rest)
        extra = (f'<details class="svgextra"><summary>其余代表卡示意图（{len(rest)} 张）'
                 f'</summary><div class="svgstrip">{items}</div></details>')
    return (f'<div class="svgstrip"><div class="cand">'
            f'<div class="cand-main"><div class="cmplabel">候选骨架（拟纳入金标准扩展变体表）</div>'
            f'{svg_candidate(cand)}'
            f'<div class="svgcap">{esc(cand.formula)} · 闭合 {esc(cand.closure)}'
            f' · 拓扑 {esc(cand.topo)}</div></div>'
            f'<div class="cand-src"><div class="cmplabel">推导来源 · {rep.branch}-{rep.qid}'
            f'（DSL 推演）</div>'
            f'{svg_for_rec(rep, 384, 192)}<div class="svgcap">{esc(svg_caption(rep))}</div></div>'
            f'<div class="cand-shot"><div class="cmplabel">现网实拍 · {rep.branch}-{rep.qid}</div>'
            f'{shot_img_html(rep.branch, rep.qid)}</div>'
            f'</div>'
            f'<div class="cmpdev"><b>归一决策点（勾选 = 同意候选骨架纳入金标准扩展变体表）</b>'
            f'{decisions}</div>'
            f'{extra}</div>')


def covered_row_html(cluster: Cluster) -> str:
    """已覆盖簇行：代表卡 DSL 推演小图 + 现网实拍图并排（人审已覆盖形态时看真实效果）；
    其余代表卡（前 3）折叠。"""
    rep = cluster.rep
    pair = (f'<div class="cand-src"><div class="cmplabel">DSL 推演 · {rep.branch}-{rep.qid}</div>'
            f'{svg_for_rec(rep, 384, 192)}<div class="svgcap">{esc(svg_caption(rep))}</div></div>'
            f'<div class="cand-shot"><div class="cmplabel">现网实拍 · {rep.branch}-{rep.qid}</div>'
            f'{shot_img_html(rep.branch, rep.qid)}</div>')
    rest = [r for r in cluster.cards[:3] if r is not rep]
    extra = ""
    if rest:
        items = "".join(
            f'<div class="svgitem">{svg_for_rec(r)}'
            f'<div class="svgcap">{esc(svg_caption(r))}</div></div>' for r in rest)
        extra = (f'<details class="svgextra"><summary>其余代表卡示意图（{len(rest)} 张）'
                 f'</summary><div class="svgstrip">{items}</div></details>')
    return f'<div class="svgstrip"><div class="cand">{pair}</div>{extra}</div>'


# ---------------------------------------------------------------------------
# 正例自检（构造 3 张官方变体正例，验证「已覆盖」路径；不触碰评测数据与规则）
# ---------------------------------------------------------------------------

def _mk_card(components: List[Dict[str, Any]]) -> GenuiCard:
    return GenuiCard(
        case_id="selftest",
        update_components={"updateComponents": {
            "surfaceId": "surface_selftest", "root": components[0]["id"],
            "components": components}})


def _box(cid: str, w: float, h: float, comp: str = "Image",
         clickable: bool = False) -> Dict[str, Any]:
    comp_d: Dict[str, Any] = {"id": cid, "component": comp, "children": [],
                              "styles": {"width": w, "height": h}}
    if clickable:
        comp_d["onClick"] = [{"action": "navigate"}]
    return comp_d


def _title_bar(cid: str, h: float) -> Dict[str, Any]:
    return {"id": cid, "component": "Row",
            "children": [{"id": f"{cid}_t", "component": "Text", "children": [],
                          "styles": {"width": 260, "height": h, "fontSize": 12}}],
            "styles": {"width": 296, "height": h}}


def _selftest_cards() -> List[Tuple[str, GenuiCard]]:
    """三张官方变体正例（bare-H2 / tc-S1 / ta-S1），构造口径与 18 变体模板一致。"""
    bare = _mk_card([
        {"id": "root", "component": "Stack", "children": ["content_root"],
         "styles": {"width": 320, "height": 160, "borderRadius": 20, "linearGradient": {}}},
        {"id": "content_root", "component": "Row", "children": ["a", "b"],
         "itemMargin": 12, "styles": {"width": 296, "height": 136, "padding": 12}},
        _box("a", 142, 136), _box("b", 142, 136),
    ])
    tc = _mk_card([
        {"id": "root", "component": "Stack", "children": ["content_root"],
         "styles": {"width": 320, "height": 160, "borderRadius": 20, "linearGradient": {}}},
        {"id": "content_root", "component": "Column", "children": ["title", "body"],
         "itemMargin": 4, "styles": {"width": 296, "height": 136, "padding": 12}},
        _title_bar("title", 17), _box("body", 296, 115),
    ])
    ta = _mk_card([
        {"id": "root", "component": "Stack", "children": ["content_root"],
         "styles": {"width": 320, "height": 160, "borderRadius": 20, "linearGradient": {}}},
        {"id": "content_root", "component": "Column", "children": ["title", "body", "capsule"],
         "itemMargin": 4, "styles": {"width": 296, "height": 136, "padding": 12}},
        _title_bar("title", 20), _box("body", 296, 72), _box("capsule", 140, 36, clickable=True),
    ])
    return [("bare-H2", bare), ("tc-S1", tc), ("ta-S1", ta)]


def selftest() -> List[str]:
    """构造 bare-H2 / tc-S1 / ta-S1 三张正例，断言官方匹配命中且会被标记「已覆盖」。"""
    out = []
    for label, card in _selftest_cards():
        tree = build_tree(card)
        content = _content_node(tree)
        matched, _, note = match_official(card, content, tree)
        rec = analyze_card("SELF", label, card)
        if matched == label and rec.matched == label and rec.audit.ok:
            out.append(f"[PASS] {label}：官方匹配命中 {matched}，已覆盖标记 ✓，原子审计全合法 ✓")
        else:
            out.append(f"[FAIL] {label}：期望命中 {label}，实际 matched={matched}（note={note}）"
                       f" audit.ok={rec.audit.ok} hard={rec.audit.hard}")
    return out


def selftest_render() -> Tuple[List[str], str]:
    """--selftest 渲染几何验证：三张正例推演结果与 18 变体标准形态一致
    （bare-H2 双栏 142×2 填满 296 / tc-S1 17+4+115 / ta-S1 20+4+72+4+36），
    并生成示意图验证页（返回 (断言行, HTML 页)）。"""
    lines: List[str] = []
    html_parts = [
        '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">',
        '<title>EVAL299 layout-forms --selftest 渲染验证</title>',
        '<style>body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",'
        'sans-serif;margin:0;background:#f5f6f8;color:#222}'
        '.wrap{max-width:1280px;margin:0 auto;padding:28px 20px}'
        '.cap{font-size:12px;color:#666;margin:2px 0 22px;font-family:ui-monospace,Menlo,Consolas,monospace}'
        '.flag{background:#eefaf2;border:1px solid #bfe5cd;border-radius:8px;padding:8px 12px;'
        'font-size:12px;color:#0c7a43;margin:0 0 16px;line-height:1.8}</style></head><body><div class="wrap">',
        '<h2 style="font-size:18px">--selftest 正例三卡布局示意图（bare-H2 / tc-S1 / ta-S1）</h2>',
    ]
    for label, card in _selftest_cards():
        rec = analyze_card("SELF", label, card)
        root = infer_layout(rec.src)
        kids = root.children
        if label == "bare-H2":
            ok = (len(kids) == 2
                  and kids[0].w == 142 and kids[1].w == 142
                  and kids[0].x == 12 and kids[1].x == 166
                  and kids[0].h == 136 and kids[1].h == 136
                  and not any(_overflow(k) for k in kids))
            detail = (f"双栏 {kids[0].w:g}×{kids[0].h:g} @({kids[0].x:g},{kids[0].y:g}) + "
                      f"{kids[1].w:g}×{kids[1].h:g} @({kids[1].x:g},{kids[1].y:g})，"
                      f"gap 12 填满 296，无越界")
        elif label == "tc-S1":
            ok = (len(kids) == 2 and kids[0].node is rec.title
                  and kids[0].h == 17 and kids[1].h == 115
                  and kids[1].y == 33 and not any(_overflow(k) for k in kids))
            detail = (f"title 17 @y={kids[0].y:g} + gap 4 + body 115 @y={kids[1].y:g}"
                      f"（闭合 136），无越界")
        else:  # ta-S1
            ok = (len(kids) == 3 and kids[0].h == 20 and kids[1].h == 72
                  and kids[2].h == 36 and kids[2].w == 140 and kids[2].y == 112
                  and not any(_overflow(k) for k in kids))
            detail = (f"title 20 + body 72 + capsule 140×36 @y={kids[2].y:g}"
                      f"（闭合 136），无越界")
        lines.append(f"[{'PASS' if ok else 'FAIL'}] {label} 渲染几何：{detail}"
                     + ("" if ok else f" 实际 children={[(round(k.w), round(k.h)) for k in kids]}"))
        html_parts.append(f'<div>{svg_for_rec(rec)}<div class="cap">{esc(svg_caption(rec))}</div></div>')
    html_parts.append("</div></body></html>")
    return lines, "".join(html_parts)


# ---------------------------------------------------------------------------
# HTML 报告
# ---------------------------------------------------------------------------

CSS = '''
 body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;margin:0;background:#f5f6f8;color:#222}
 .wrap{max-width:1280px;margin:0 auto;padding:28px 20px 60px}
 h1{font-size:22px;margin:0 0 6px;font-weight:700;color:#141b2d}
 h2{font-size:17px;margin:34px 0 10px;border-left:4px solid #0a59f7;padding-left:10px;color:#1a2b4a}
 .meta{color:#555;font-size:13px;line-height:1.9;background:#fff;border:1px solid #e3e5e9;border-radius:10px;padding:12px 16px}
 .note{font-size:12px;color:#888;margin-top:10px;line-height:1.7}
 table{border-collapse:collapse;width:100%;background:#fff;font-size:12.5px;margin-top:12px;border-radius:10px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.08)}
 th{background:#0a59f7;color:#fff;text-align:left;padding:7px 10px;font-size:11.5px;font-weight:600;letter-spacing:.02em;white-space:nowrap}
 td{border-top:1px solid #eef0f3;padding:6px 10px;vertical-align:top;word-break:break-word}
 tr:nth-child(even) td{background:#f7f9fc}
 tr:hover td{background:#eef4ff}
 code{background:#f0f2f5;padding:1px 5px;border-radius:4px;font-size:11.5px;word-break:break-all}
 .pill{display:inline-block;border-radius:999px;padding:2px 8px;font-size:11px;font-weight:600;line-height:1.5;white-space:nowrap}
 .pill-ok{background:#e8f7ee;color:#0c7a43}
 .pill-bad{background:#fff3e6;color:#c2570a}
 .pill-hi{background:#d33;color:#fff}
 .pill-grey{background:#eef0f3;color:#555}
 .pill-blue{background:#e8f0fe;color:#0a59f7}
 .pill-covered{background:#eefaf2;color:#0c7a43}
 .formula{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;font-weight:600;color:#0a2f66}
 .fid{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11px;color:#0a59f7;font-weight:600}
 .nested{font-size:11px;color:#888;margin-top:2px}
 .audit-line{font-size:11.5px;line-height:1.7;color:#333}
 .audit-bad{color:#c2570a;font-weight:600}
 .audit-ok{color:#0c7a43}
 details{margin-top:2px}
 summary{cursor:pointer;font-size:11.5px;color:#0a59f7;user-select:none}
 pre.tree{background:#f8fafc;border:1px solid #e3e5e9;border-radius:8px;padding:8px 10px;font-size:11px;line-height:1.55;overflow-x:auto;color:#334}
 .toolbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:14px 0 4px}
 .btn{background:#0a59f7;color:#fff;border:none;border-radius:8px;padding:8px 14px;font-size:13px;font-weight:600;cursor:pointer}
 .btn:hover{background:#0847c9}
 .btn-ghost{background:#fff;color:#0a59f7;border:1px solid #0a59f7}
 .copybox{width:100%;min-height:60px;margin-top:8px;border:1px solid #0a59f7;border-radius:8px;padding:8px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;display:none;box-sizing:border-box}
 .status{font-size:12.5px;color:#0c7a43;font-weight:600}
 .flag{background:#fff3f0;border:1px solid #f0c8ba;border-radius:8px;padding:8px 12px;font-size:12px;color:#8a3b25;margin-top:8px}
 .flag-green{background:#eefaf2;border:1px solid #bfe5cd;color:#0c7a43}
 input[type=checkbox]{width:16px;height:16px;cursor:pointer}
 .covered-row td{background:#f4faf6}
 .svgstrip{display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap;overflow-x:auto;max-width:100%;min-width:0;padding:2px 0}
 .svgitem{flex:0 0 auto}
 .svgitem svg{display:block;border:1px solid #e3e5e9;border-radius:8px;background:#fff}
 .svgcap{font-size:10.5px;color:#666;margin-top:3px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;max-width:640px;line-height:1.5}
 details.svgextra>summary{cursor:pointer;font-size:11.5px;color:#0a59f7;user-select:none;margin:2px 0}
 .svg-row td{background:#fff;border-top:none;padding:2px 10px 12px}
 .cand{display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap;min-width:max-content}
 .cand-main{flex:0 0 auto}
 .cand-src{flex:0 0 auto}
 .cand-src svg{border:1px dashed #b8bec7}
 .cand-shot{flex:0 0 auto}
 .shotcap{font-size:10.5px;color:#666;margin-top:3px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
 .shot-miss{width:384px;height:192px;border:1px dashed #b8bec7;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#999;font-size:12px;background:#f8fafc}
 .cmplabel{font-size:11.5px;font-weight:700;color:#334;margin-bottom:2px}
 .cmpdev{font-size:11.5px;color:#333;line-height:1.7;background:#f8fafc;border:1px solid #e3e5e9;border-radius:8px;padding:6px 10px;margin-top:8px;min-width:0;max-width:100%}
 .cmpdev b{color:#0a59f7}
 .gal{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px;margin-top:10px}
 .gal-item{background:#fff;border:1px solid #e3e5e9;border-radius:10px;padding:8px;text-align:center}
 .gal-item svg{display:block;margin:0 auto;max-width:100%;height:auto}
 .gal-name{font-size:11px;font-weight:600;color:#0a2f66;margin-top:4px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
 .legend{display:flex;gap:14px;flex-wrap:wrap;align-items:center;font-size:11.5px;color:#444;background:#fff;border:1px solid #e3e5e9;border-radius:10px;padding:8px 14px;margin-top:10px;line-height:2}
 .sw{display:inline-block;width:14px;height:10px;border-radius:3px;margin-right:4px;vertical-align:-1px;border:1px solid #888}
'''


def esc(s) -> str:
    return html.escape(str(s if s is not None else ""))


def audit_html(cluster: Cluster) -> str:
    """簇级原子审计初判（量化数值范围 + ✓/✗；逐卡精确数值见行内详情）。"""
    ca = cluster_audit(cluster)
    lines = []
    for s in ca.gap_lines:
        cls = "audit-bad" if "∉" in s else "audit-ok"
        lines.append(f'<div class="audit-line {cls}">{esc(s)}</div>')
    if ca.split_count:
        lines.append(f'<div class="audit-line audit-bad">等分：{ca.split_count}/{len(cluster.cards)} 卡不符'
                     f'（如 {esc(ca.split_sample)}）</div>')
    else:
        lines.append('<div class="audit-line audit-ok">等分：无分栏容器或全部等分/action 行特例</div>')
    for s in ca.v_lines:
        cls = "audit-bad" if "缺口" in s and "闭合 ✓" not in s else "audit-ok"
        lines.append(f'<div class="audit-line {cls}">{esc(s)}</div>')
    for s in ca.h_lines:
        cls = "audit-bad" if "缺口" in s and "闭合 ✓" not in s else "audit-ok"
        lines.append(f'<div class="audit-line {cls}">{esc(s)}</div>')
    tcls = "audit-bad" if "非 17/20 档" in ca.title_line else "audit-ok"
    lines.append(f'<div class="audit-line {tcls}">{esc(ca.title_line)}</div>')
    if ca.dim_variance:
        lines.append(f'<div class="audit-line" style="color:#888">主轴尺寸分布：{esc("；".join(ca.dim_variance))}</div>')
    return "".join(lines)


def per_card_audit_lines(rec: CardRec) -> List[str]:
    a = rec.audit
    parts = []
    parts.append(f"gap: {'; '.join(a.gap_lines) if a.gap_lines else '✓'}")
    parts.append(f"等分: {'; '.join(a.split_lines) if a.split_lines else '✓'}")
    parts.append(f"垂直: {'; '.join(a.v_lines) if a.v_lines else '—'}")
    parts.append(f"横向: {'; '.join(a.h_lines) if a.h_lines else '—'}")
    parts.append(f"title: {a.title_line}")
    return parts


def details_html(cluster: Cluster) -> str:
    """代表卡组件树摘要（可折叠）+ 逐卡审计初判。"""
    rep = cluster.rep
    head = f'<details><summary>代表卡 {rep.branch}-{rep.qid} 组件树摘要（{len(cluster.cards)} 卡逐卡审计见下）</summary>'
    tree = "\n".join(tree_lines(rep.src, rep.axis))
    head += f'<pre class="tree">{esc(tree)}</pre>'
    head += "<div style='font-size:11.5px;line-height:1.7'>"
    for c in cluster.cards:
        lines = per_card_audit_lines(c)
        tag = '<span class="pill pill-ok">原子全合法</span>' if c.audit.ok \
            else '<span class="pill pill-bad">有硬伤</span>'
        head += (f'<div style="margin-top:6px"><b>{c.branch}-{c.qid}</b> {tag}<br>'
                 + "<br>".join(f"· {esc(x)}" for x in lines) + "</div>")
    head += "</div></details>"
    return head


def render_html(clusters: List[Cluster], recs: List[CardRec], stats: Dict[str, Any],
                selftest_lines: List[str], out_path: Path) -> str:
    uncovered = [c for c in clusters if not c.covered]
    covered = [c for c in clusters if c.covered]
    today = date.today().strftime("%Y%m%d")

    rows = []
    for i, c in enumerate(uncovered, start=1):
        fid = f"F{i:02d}"
        n = len(c.cards)
        card_marks = []
        card_ids = []
        for r in c.cards[:3]:
            mark = '<span class="pill pill-ok" title="原子全合法">✓</span>' if r.audit.ok \
                else '<span class="pill pill-bad" title="有硬伤">✗</span>'
            card_marks.append(f"{mark} {r.branch}-{r.qid}")
            card_ids.append(f"{r.branch}-{r.qid}")
        cell = " ".join(card_marks)
        cards_txt = ", ".join(card_ids)
        if n > 3:
            cell += f" 等（+{n - 3} 卡）"
            cards_txt += f" 等（+{n - 3} 卡）"
        suggestion, sugg_txt = cluster_suggestion(c)
        sugg_pill = ('<span class="pill pill-ok">建议入库</span>'
                     if suggestion == "ok" else
                     f'<span class="pill pill-bad">不建议</span>')
        if suggestion == "ok":
            sugg_html = f'{sugg_pill}<div style="font-size:11.5px;margin-top:3px">原子审计全合法（gap/等分/横纵闭合/title 档均过）；最终入库以 owner 勾选为准</div>'
        else:
            sugg_html = f'{sugg_pill}<div style="font-size:11.5px;margin-top:3px">{esc(sugg_txt)}</div>'
        nested = f'<div class="nested">嵌套：{esc(c.rep.nested)}</div>' if c.rep.nested else ""
        cand = candidate_skeleton(c.rep)
        cands_txt = f"{cand.formula} · 闭合 {cand.closure} · 拓扑 {cand.topo}"
        rows.append(f'''<tr data-form-id="{fid}" data-formula="{esc(c.formula)}"
 data-cards="{esc(cards_txt)}" data-cands="{esc(cands_txt)}">
<td><input type="checkbox" class="pick"></td>
<td><span class="fid">{fid}</span><div class="formula">{esc(c.formula)}</div>{nested}</td>
<td><span class="pill pill-blue">{n} 张</span></td>
<td>{cell}</td>
<td>{details_html(c)}</td>
<td>{audit_html(c)}</td>
<td>{sugg_html}</td>
</tr>
<tr class="svg-row"><td colspan="7">{candidate_row_html(c)}</td></tr>''')

    covered_rows = ""
    if covered:
        for i, c in enumerate(covered, start=1):
            n = len(c.cards)
            src_tag = ("补充 " if c.cover in _SUPPLEMENT_TEMPLATES else "") + (c.cover or "?")
            covered_rows += (f'<tr class="covered-row"><td></td>'
                             f'<td><span class="fid">C{i:02d}</span><div class="formula">{esc(c.formula)}</div>'
                             f'<div class="nested">覆盖模板：{esc(src_tag)}'
                             f'{(" · " + esc(_SUPPLEMENT_NOTE[c.cover])) if c.cover in _SUPPLEMENT_TEMPLATES else ""}'
                             f'</div></td>'
                             f'<td><span class="pill pill-covered">{n} 张</span></td>'
                             f'<td>{esc(", ".join(f"{r.branch}-{r.qid}" for r in c.cards[:3]))}</td>'
                             f'<td>{details_html(c)}</td>'
                             f'<td><span class="pill pill-covered">已覆盖</span></td>'
                             f'<td><span class="pill pill-covered">{esc(src_tag)}</span></td></tr>'
                             f'<tr class="svg-row"><td colspan="7">{covered_row_html(c)}</td></tr>')

    covered_n = sum(len(c.cards) for c in covered)
    selftest_html = ""
    if selftest_lines:
        selftest_html = '<div class="flag flag-green">正例自检（--selftest）：「已覆盖」路径验证<br>' \
                        + "<br>".join(esc(x) for x in selftest_lines) + "</div>"
    n_blk = stats.get("layout_blocks", 0)
    und_pct = (f"{stats['layout_undeclared'] / n_blk * 100:.1f}%" if n_blk else "-")
    legend_html = '''<div class="legend">
<span><i class="sw" style="background:#e8f0fe;border-color:#0a59f7"></i>title 条</span>
<span><i class="sw" style="background:#f2f4f7"></i>panel / 背板</span>
<span><i class="sw" style="background:#e8f7ee;border-color:#0c7a43"></i>action / 按钮</span>
<span><i class="sw" style="background:#fff8e6;border-color:#b3912e"></i>Image</span>
<span><i class="sw" style="background:#fff;border:1px dashed #999"></i>Text（无填充虚线）</span>
<span><i class="sw" style="background:#fff;border:1px solid #d33"></i>红描边 = 越出安全区</span>
<span>尺寸后 <code>*</code> = 推演值（DSL 未声明）</span>
<span>红虚线框 = 安全区 296×136（12vp padding）</span>
<span><i class="sw" style="background:#eceef1;border:1px dashed #5a6472"></i>骨架/候选槽位（标准语言）</span>
</div>'''
    gal_items = "".join(
        f'<div class="gal-item">{svg_skeleton(name)}<div class="gal-name">{esc(name)}</div></div>'
        for name in _VARIANT_TEMPLATES)
    gal_items += "".join(
        f'<div class="gal-item">{svg_skeleton(name)}<div class="gal-name">补充 {esc(name)}</div>'
        f'<div class="nested">{esc(_SUPPLEMENT_NOTE[name])}</div></div>'
        for name in _SUPPLEMENT_TEMPLATES)
    gallery_html = ('<h2>官方 18 变体骨架图鉴 + Pixso 补充 7 张（金标准参照系，'
                    'pixso-layout-abstraction.md / layout_2x4 模板同源；补充：item-id 63:61/63:62 + ta-H2-dual）</h2>'
                    '<div class="gal">' + gal_items + "</div>")

    return f'''<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>EVAL299 2×4 卡形态聚类人审清单 {today}</title>
<style>{CSS}</style></head>
<body><div class="wrap">
<h1>EVAL299 76 张 2×4 卡形态聚类 · 人审清单 + 布局示意图（WP-LAYOUT-FORMS / WP-LAYOUT-FORMS-RENDER）</h1>
<div class="meta">
<b>检测对象</b>：A 分支 40 张（createSurface 320×160）+ B 分支 36 张（root 宽 320）共 <b>{stats['total']}</b> 张（评测集只读引用）<br>
<b>检测层</b>：L1 声明层静态（组件树归约 + 官方 18 变体匹配 + 原子审计初判）+ 声明层推演示意图
（WP-LAYOUT-FORMS-RENDER，简化 flex 求每块 (x,y,w,h) 渲染 SVG；非端侧渲染，无 dump）<br>
<b>结果</b>：簇总数 <b>{stats['clusters']}</b>（未覆盖 <b>{stats['uncovered']}</b> / 已覆盖 <b>{stats['covered']}</b>）；官方变体命中 <b>{covered_n}</b> 张；跳过卡 <b>{stats['skipped']}</b> 张<br>
<b>布局示意图</b>：<b>{stats['render_cards']}</b> 张产物 SVG（每簇代表卡前 3 张：首图内联、其余折叠展开）；
候选骨架 <b>{stats['skeleton_cmp']}</b> 张 + 骨架图鉴 <b>25</b> 张（官方 18 + Pixso 补充 7，几何与检测同源：
从模板结构推导，不复制数值）；推演引擎处理 <b>{n_blk}</b> 块（未声明尺寸 → 推演值*
<b>{stats['layout_undeclared']}</b> 块 / {und_pct}；本批宽高全声明，matchParent 继承
<b>{stats['layout_matchparent']}</b> 块；越出安全区警示 <b>{stats['layout_overflow']}</b> 块；
异常跳过 <b>{stats['layout_skipped']}</b> 块）<br>
<b>报告产物</b>：{esc(str(out_path))}<br>
<b>口径</b>：缺口 = 安全区（296×136）− Σ子和（子和口径，审计参考）；含 gap 口径 = 真机渲染口径
（示意图主数值）。gap 声明先读顶层 itemMargin、无则 styles.itemMargin（与 layout_2x4._gap 一致；
2026-08-24 五卡 dump 实证渲染生效），未声明按 0。声明层原则：未声明尺寸不臆造（交 L2）。
官方变体匹配只读调用 layout_2x4 现有逻辑；root 直接承载内容（B 分支）时规则门禁跳过，如实记录。
机器建议仅初判，最终形态入库与否由 owner 勾选裁定。
</div>
<div class="toolbar">
<button class="btn" onclick="copyChecked()">一键复制已勾选形态</button>
<button class="btn btn-ghost" onclick="toggleAll(true)">全选</button>
<button class="btn btn-ghost" onclick="toggleAll(false)">全不选</button>
<span class="status" id="copystatus"></span>
</div>
<textarea class="copybox" id="copybox" readonly></textarea>
{selftest_html}
{legend_html}
{gallery_html}
<div class="flag">使用说明：每行 = 一个未覆盖形态簇（同结构签名的卡归组）。行下方为该簇的<b>候选骨架</b>——
从产物形态推导、用金标准骨架语言（title 档位 {{17,20}} / 等分公式 / gap 档位 {{4,8,12,16}} /
闭合 136）规范化表达的布局结构（保持产物拓扑），右侧附产物代表卡小图（推导来源），下方列出
逐项归一决策点。勾选 = <b>同意该候选骨架纳入金标准扩展变体表</b>；点「一键复制」输出候选骨架的
规范几何描述（拓扑 + 归一后几何 + 闭合式，供入库直接用）。检查器不擅自扩合规范围，逐条确认后
才可入库。带日期产物按 AGENTS.md 命名规范落 daily_review_dir。</div>
<h2>未覆盖形态簇（人审重点，{len(uncovered)} 簇 · {stats['uncovered_cards']} 张）</h2>
<table>
<colgroup><col style="width:34px"><col style="min-width:200px"><col style="width:56px"><col style="min-width:120px"><col style="min-width:180px"><col style="min-width:240px"><col style="min-width:160px"></colgroup>
<thead><tr><th>勾选</th><th>形态（ID + 结构式）</th><th>张数</th><th>卡号（代表前 3）</th><th>代表卡组件树摘要</th><th>原子审计初判（代表卡，量化）</th><th>机器建议</th></tr></thead>
<tbody>
{''.join(rows)}
<tr class="covered-row"><td colspan="7">
<span class="pill pill-covered">已覆盖簇汇总</span>
本批 {stats['total']} 张卡中命中「官方 18 + Pixso 补充 7」骨架：<b>{covered_n} 张 / {len(covered)} 簇</b>
（拓扑覆盖判定：轴/方向 + title 档就近 {{17,20}} + 块序列（action 按钮数）；按钮宽 144/140 等价档；
补充骨架 63:57/63:20/63:37/63:48/63:27 来自 Pixso item-id 63:61 实读固化）
</td></tr>
{covered_rows}
</tbody></table>
<div class="note">注：结构式格式 V[title24, panel58, action32×2] / H[col132, col152]——V/H = 内容区方向；
title/panel/action/col 为块语义（action = 子块全为 clickable 或带背景按钮容器）；数字为主轴声明尺寸；
×n = 子块数；「嵌套」注给出各块首层容器结构。审计数值以代表卡为准，逐卡数值见行内详情。
示意图为声明层简化 flex 推演（WP-LAYOUT-FORMS-RENDER）：红虚线框 = 安全区 296×136（四角 12vp）；
蓝 = title 条、灰 = panel/背板、绿 = action/按钮、黄 = Image、无填充虚线 = Text、红描边 = 越出安全区；
尺寸后 * = 推演值（DSL 未声明，弹性均分/拉伸）；gap 取声明值（顶层 itemMargin，与 layout_2x4._gap
同口径，2026-08-24 五卡 dump 实证渲染生效），未声明按 0；推演不求像素精确，只求形态可读，不落规则。
候选骨架 = 产物拓扑 + 金标准骨架语言归一（title 档位 / 等分公式 / 闭合 136 / gap 档位），人审
勾选决定是否纳入金标准扩展变体表；机器只列决策点不下结论。图鉴 = 18 官方变体骨架（与候选同风格，
对照「已有 vs 候选」）。</div>
<script>
function collectChecked(){{
  const out = [];
  document.querySelectorAll('tr[data-form-id]').forEach(r => {{
    const cb = r.querySelector('input.pick');
    if (cb && cb.checked) out.push(r.dataset.formId + ' 候选骨架: ' + r.dataset.cands + ' | 卡: ' + r.dataset.cards);
  }});
  return out;
}}
function copyChecked(){{
  const lines = collectChecked();
  const ta = document.getElementById('copybox');
  ta.value = lines.join('\\n');
  ta.style.display = 'block';
  ta.focus(); ta.select();
  try {{ navigator.clipboard.writeText(ta.value); }} catch(e) {{ document.execCommand('copy'); }}
  document.getElementById('copystatus').textContent = '已复制 ' + lines.length + ' 个形态';
}}
function toggleAll(on){{
  document.querySelectorAll('input.pick').forEach(cb => cb.checked = on);
  document.getElementById('copystatus').textContent = '';
}}
</script>
</div></body></html>'''


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def collect_cards() -> Tuple[List[CardRec], List[str]]:
    """选卡：A 分支 createSurface 320×160（40）+ B 分支 root 宽 320（36）。"""
    root = eval_root()
    a_dir = root / "A(晓峰单独分支——一步走)"
    b_dir = root / "B(现网分支)" / "dsl"
    recs: List[CardRec] = []
    errors: List[str] = []
    for branch, scan in (("A", a_dir), ("B", b_dir)):
        if not scan.is_dir():
            errors.append(f"分支目录不存在: {scan}")
            continue
        for p in sorted(scan.glob("*.jsonl")):
            try:
                card = load_genui(p, p.stem)
            except Exception as exc:  # noqa: BLE001  单卡解析失败不阻断整批
                errors.append(f"{branch}/{p.stem}: 解析失败 {exc!r}")
                continue
            if card.card_size != "2x4":
                continue
            recs.append(analyze_card(branch, p.stem, card))
    return recs, errors


def main() -> int:
    ap = argparse.ArgumentParser(description="EVAL299 76 张 2×4 卡形态聚类 + 人审清单（只分析，不改规则）")
    ap.add_argument("--out", default=None, help="报告输出路径（默认 daily_review_dir/EVAL299-layout-forms-YYYYMMDD.html）")
    ap.add_argument("--selftest", action="store_true", help="构造官方变体正例，验证「已覆盖」路径后退出")
    args = ap.parse_args()

    if args.selftest:
        st_lines = selftest()
        r_lines, r_html = selftest_render()
        for line in st_lines + r_lines:
            print(line)
        today = date.today().strftime("%Y%m%d")
        page = daily_review_dir() / f"EVAL299-layout-forms-selftest-{today}.html"
        page.parent.mkdir(parents=True, exist_ok=True)
        page.write_text(r_html, encoding="utf-8")
        print(f"  渲染验证页: {page}")
        ok = all("PASS" in x for x in st_lines) and all("PASS" in x for x in r_lines)
        return 0 if ok else 1

    today = date.today().strftime("%Y%m%d")
    out_path = Path(args.out) if args.out else daily_review_dir() / f"EVAL299-layout-forms-{today}.html"

    recs, errors = collect_cards()
    clusters = build_clusters(recs)
    uncovered = [c for c in clusters if not c.covered]
    covered = [c for c in clusters if c.covered]

    # 推演引擎统计（覆盖全部 76 卡；渲染只取每簇前 3 张）
    n_blk = n_und = n_ovf = n_skip = n_mp = 0
    for r in recs:
        if r.error or r.src is None:
            continue
        b, u, o, s, m = _layout_counts(infer_layout(r.src))
        n_blk += b
        n_und += u
        n_ovf += o
        n_skip += s
        n_mp += m

    stats = {
        "total": len(recs),
        "clusters": len(clusters),
        "uncovered": len(uncovered),
        "covered": len(covered),
        "uncovered_cards": sum(len(c.cards) for c in uncovered),
        "covered_cards": sum(len(c.cards) for c in covered),
        "skipped": len(recs) - sum(len(c.cards) for c in clusters),
        "render_cards": sum(min(3, len(c.cards)) for c in clusters),
        "skeleton_cmp": len(uncovered),
        "shots_copied": 0,
        "shots_existed": 0,
        "shots_missing": 0,
        "layout_blocks": n_blk,
        "layout_undeclared": n_und,
        "layout_overflow": n_ovf,
        "layout_skipped": n_skip,
        "layout_matchparent": n_mp,
    }

    selftest_lines = selftest() if not args.selftest else []
    # 现网实拍复制（每簇代表卡；已存在跳过，源缺失计数）
    for c in clusters:
        r = c.rep
        dst_path = review_dir() / "vis-assets" / f"{r.branch}-{r.qid}.png"
        existed = dst_path.exists()
        if ensure_live_shot(r.branch, r.qid) is None:
            stats["shots_missing"] += 1
        elif existed:
            stats["shots_existed"] += 1
        else:
            stats["shots_copied"] += 1
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(render_html(clusters, recs, stats, selftest_lines, out_path),
                        encoding="utf-8")

    # ---- stdout 汇报摘要 ----
    print(f"EVAL299 2×4 卡形态聚类报告")
    print(f"  总卡数: {stats['total']}（A 40 / B 36 按 card_size 判定筛选）")
    print(f"  簇总数: {stats['clusters']} | 未覆盖: {stats['uncovered']} | 已覆盖: {stats['covered']}")
    n_off = sum(1 for c in covered if c.cover in _SUPPLEMENT_TEMPLATES)
    n_off_cards = sum(len(c.cards) for c in covered if c.cover in _SUPPLEMENT_TEMPLATES)
    print(f"  覆盖判定（官方18 + 补充7）: 已覆盖 {stats['covered_cards']} 张"
          f"（官方 {stats['covered_cards'] - n_off_cards} 张 / 补充 {n_off_cards} 张）")
    if errors:
        print(f"  跳过/出错 {len(errors)} 张:")
        for e in errors:
            print(f"    - {e}")
    print(f"  布局示意图: {stats['render_cards']} 张产物 SVG + 候选骨架 {stats['skeleton_cmp']} 张"
          f" + 骨架图鉴 25 张（官方 18 + 补充 7）")
    print(f"  现网实拍: 代表卡实拍 {stats['shots_copied'] + stats['shots_existed']} 张"
          f"（本次复制 {stats['shots_copied']} / 已存在 {stats['shots_existed']}"
          f" / 缺失 {stats['shots_missing']}），存 review/vis-assets/")
    if n_blk:
        print(f"  推演引擎: 处理块 {n_blk}，未声明尺寸块 {n_und}"
              f"（{n_und / n_blk * 100:.1f}%；本批 76 卡宽高全声明，matchParent 继承 {n_mp} 块），"
              f"越出安全区 {n_ovf}，异常跳过 {n_skip}")
    print(f"  前 5 大未覆盖簇:")
    for c in uncovered[:5]:
        print(f"    {c.formula}  ({len(c.cards)} 张: {', '.join(f'{r.branch}-{r.qid}' for r in c.cards[:3])}{'…' if len(c.cards) > 3 else ''})")
    print(f"  HTML: {out_path}")

    # ---- 验收锚点核对 ----
    q3 = next((c for c in clusters if any(r.branch == "A" and r.qid == "q3" for r in c.cards)), None)
    q2 = next((c for c in clusters if any(r.branch == "A" and r.qid == "q2" for r in c.cards)), None)
    print("  验收锚点核对:")
    if q3 is not None:
        r3 = next(r for r in q3.cards if r.qid == "q3")
        # 覆盖锚点：Q3（V[title24, panel58, action32×2] 双按钮）被补充 63:27 覆盖
        cov3 = covered_morph(r3)
        cov3_ok = q3.covered and cov3 == "63:27"
        print(f"    Q3(A-q3): 簇={q3.formula} 覆盖模板={cov3}（补充 63:27 双按钮 144×36×2）"
              f" → {'PASS' if cov3_ok else 'FAIL'}")
        # 示意图锚点：title 条 / 中间 panel / 底部双按钮并排且未贴安全区底缘
        # （含 gap 口径：24+8+58+8+32=130，距安全区底余 6vp；子和口径缺口 22vp 作参考）
        p3 = infer_layout(r3.src)
        k3 = p3.children
        t3 = next((k for k in k3 if k.node is r3.title), None)
        act3 = next((k for k in k3 if is_action_block(k.node)), None)
        btn3 = act3.children if act3 else []
        gap_bottom = (SAFE_Y + SAFE_H) - (act3.y + act3.h) if act3 else None
        img3_ok = (t3 is not None and any(k.h > 40 for k in k3) and act3 is not None
                   and len(btn3) >= 2 and btn3[0].x != btn3[1].x
                   and gap_bottom is not None and abs(gap_bottom - 6) <= TOL + 1
                   and "垂直余6vp" in svg_caption(r3))
        print(f"    Q3 图: title条={'✓' if t3 else '✗'} 中间panel={'✓' if any(k.h > 40 for k in k3) else '✗'} "
              f"双按钮并排={'✓' if len(btn3) >= 2 and btn3[0].x != btn3[1].x else '✗'} "
              f"距底空隙={gap_bottom:g}vp（含gap渲染口径；子和口径缺口22vp见图注参考） "
              f"→ {'PASS' if img3_ok else 'FAIL'}")
    else:
        print("    Q3(A-q3): 未找到 → FAIL")
    if q2 is not None:
        r2 = next(r for r in q2.cards if r.qid == "q2")
        cov2 = covered_morph(r2)
        cov2_ok = q2.covered and cov2 == "bare-H2"
        print(f"    Q2(A-q2): 簇={q2.formula} 覆盖模板={cov2}（官方 bare-H2 二分等分，"
              f"63:57 同构重申） → {'PASS' if cov2_ok else 'FAIL'}")
        # 示意图锚点：两栏宽明显不等（132 vs 152）
        p2 = infer_layout(r2.src)
        k2 = p2.children
        w2 = [round(k.w) for k in k2]
        img2_ok = len(w2) == 2 and w2[0] == 132 and w2[1] == 152
        print(f"    Q2 图: 两栏宽 {w2 if w2 else '?'}（期望 132 vs 152，不等明显）"
              f" → {'PASS' if img2_ok else 'FAIL'}")
    # ---- 覆盖判定锚点（官方 18 + 补充 7 拓扑覆盖；未覆盖簇保留候选骨架行）----
    print("  覆盖判定与候选骨架锚点:")
    ok_cov_all = all(c.cover is not None for c in covered)
    print(f"    已覆盖簇 {len(covered)} 个全部有覆盖模板={'✓' if ok_cov_all else '✗'}")
    cand_ok = True
    for c in uncovered:
        cand = candidate_skeleton(c.rep)
        if not cand.formula or not cand.blocks:
            cand_ok = False
    print(f"    未覆盖簇 {len(uncovered)} 个均生成候选骨架+决策点={'✓' if cand_ok else '✗'}")
    # ---- 仍无法覆盖的簇清单（本任务核心答案）----
    print(f"  仍无法覆盖的簇（{len(uncovered)} 簇 / {stats['uncovered_cards']} 张）:")
    for c in uncovered:
        hint = _missing_skeleton_name(c.rep)
        print(f"    {c.formula}  ({len(c.cards)} 张: "
              f"{', '.join(f'{r.branch}-{r.qid}' for r in c.cards[:4])}"
              f"{'…' if len(c.cards) > 4 else ''})  缺: {hint}")
    # 图鉴 25 张（官方 18 + 补充 7）全渲染（well-formed）
    try:
        for name in list(_VARIANT_TEMPLATES) + list(_SUPPLEMENT_TEMPLATES):
            import xml.etree.ElementTree as ET
            ET.fromstring(svg_skeleton(name))
        gal_ok = True
    except Exception as exc:  # noqa: BLE001
        gal_ok = False
        print(f"    图鉴渲染异常: {exc!r}")
    print(f"    图鉴 25 张（官方 18 + 补充 7）SVG well-formed={'✓' if gal_ok else '✗'}")
    # ---- 官方 18 变体骨架图鉴几何锚点（pixso-layout-abstraction.md 一致性）----
    print("  图鉴骨架几何锚点（pixso-layout-abstraction.md 抽 3 变体）:")
    t, rects, _ = skeleton_rects("bare-H2")
    ok_b = (t is None and [(round(x), round(y), round(w), round(h))
                           for x, y, w, h, _, _ in rects] == [(12, 12, 142, 136), (166, 12, 142, 136)])
    print(f"    bare-H2: 142×2 + gap12 填满 296 → {'PASS' if ok_b else 'FAIL ' + str(rects)}")
    t, rects, _ = skeleton_rects("tc-S1-list3")
    ok_t = (t == (12.0, 12.0, 296.0, 17.0) and [(round(x), round(y), round(w), round(h))
                                                 for x, y, w, h, _, _ in rects]
            == [(12, 33, 296, 33), (12, 74, 296, 33), (12, 115, 296, 33)])
    print(f"    tc-S1-list3: title17 + 3×33 (gap8×2) → {'PASS' if ok_t else 'FAIL ' + str(rects)}")
    t, rects, _ = skeleton_rects("ta-S1")
    ok_a = (t == (12.0, 12.0, 296.0, 20.0)
            and [(round(x), round(y), round(w), round(h), c) for x, y, w, h, c, _ in rects]
            == [(12, 36, 296, 72, False), (12, 112, 140, 36, True)])
    print(f"    ta-S1: 20+4+72+4+capsule36（胶囊距卡底 12vp）→ "
          f"{'PASS' if ok_a else 'FAIL ' + str(rects)}")
    # 补充骨架几何抽查：63:27 双按钮 144×2+gap8=296 等分闭合
    t, rects, _ = skeleton_rects("63:27")
    ok_s = (t == (12.0, 12.0, 296.0, 20.0)
            and [(round(x), round(y), round(w), round(h), c) for x, y, w, h, c, _ in rects]
            == [(12, 36, 296, 72, False), (12, 112, 144, 36, True), (164, 112, 144, 36, True)])
    print(f"    63:27: 双按钮 144×2+gap8=296 等分闭合 → {'PASS' if ok_s else 'FAIL ' + str(rects)}")
    # ---- 现网实拍锚点（每簇代表卡实拍；未覆盖 15 簇全部应有）----
    print("  现网实拍锚点:")
    shot_q3 = ensure_live_shot("A", "q3") is not None
    shot_b12 = ensure_live_shot("B", "q12") is not None
    miss = [f"{c.rep.branch}-{c.rep.qid}" for c in uncovered
            if ensure_live_shot(c.rep.branch, c.rep.qid) is None]
    print(f"    A-q3 实拍={'✓' if shot_q3 else '✗'}（Q3 簇候选/推演/实拍三图同排）")
    print(f"    B-q12 现网实拍={'✓' if shot_b12 else '✗'}（B 分支源 B(现网分支)/images/q12.png）")
    print(f"    未覆盖 {len(uncovered)} 簇实拍缺失 {len(miss)} 张{('：' + ', '.join(miss)) if miss else ' → 全部有实拍 ✓'}")
    # 清单 HTML 无外链（除相对 ../vis-assets/）
    try:
        html_text = out_path.read_text(encoding="utf-8")
        ext = re.findall(r'(?:src|href)=["\'](?:https?:)?//', html_text)
        ext_ok = not ext
        print(f"    清单 HTML 外链（http(s):// 直连）: {len(ext)} 处"
              f" → {'PASS（无外链，实拍走相对 ../vis-assets/）' if ext_ok else 'FAIL ' + str(ext)}")
    except OSError as exc:  # noqa: BLE001
        print(f"    清单外链检查失败: {exc!r}")
    print(f"    实拍复制统计: 本次复制 {stats['shots_copied']} 张 / 已存在 {stats['shots_existed']} 张"
          f" / 缺失 {stats['shots_missing']} 张")
    # 「建议入库」候选恢复核对（2026-08-24 五卡 dump 实证回滚：顶层 itemMargin 渲染生效，
    # 与 layout_2x4._gap 同口径）——上一轮被误降级的簇应恢复，如实核对
    print("  原「建议入库」候选 8 卡恢复核对（gap 声明先顶层后 styles，同 layout_2x4._gap）:")
    cands = [("A", "q8"), ("B", "q12"), ("B", "q38"), ("B", "q42"),
             ("B", "q44"), ("B", "q45"), ("B", "q62"), ("B", "q65")]
    n_restored = 0
    restored_clusters: set = set()
    for branch, qid in cands:
        r = next((x for x in recs if x.branch == branch and x.qid == qid), None)
        if r is None:
            print(f"    {branch}-{qid}: 未找到 → FAIL")
            continue
        src = r.src
        if r.axis == "V":
            s = sum(k.h for k in src.children)
            gt = (_declared_gap(src) or 0.0) * (len(src.children) - 1)
            defi = SAFE_H - s - gt
        else:
            s = sum(k.w for k in src.children)
            gt = (_declared_gap(src) or 0.0) * (len(src.children) - 1)
            defi = SAFE_W - s - gt
        cl = next(c for c in clusters if any(x is r for x in c.cards))
        sugg = "建议入库" if cluster_suggestion(cl)[0] == "ok" else "不建议"
        if sugg == "建议入库":
            n_restored += 1
            restored_clusters.add(id(cl))
        print(f"    {branch}-{qid} ({r.formula}): 闭合缺口 {defi:+.0f}vp（含 gap 口径）"
              f"簇建议 {sugg}" + ("" if sugg == "建议入库" else "（真实缺口仍存在）"))
    n_restored_cl = len(restored_clusters)
    print(f"    恢复「建议入库」: {n_restored} 卡 / {n_restored_cl} 簇（预期 6 卡 / 5 簇："
          f"A-q8、B-q38+q42、B-q44、B-q62、B-q65；B-q12/q45 所在簇含 B-q39——"
          f"其根无 itemMargin、真实缺口 8vp，仍不建议）"
          f" → {'PASS' if n_restored_cl == 5 else 'FAIL'}")
    print("  已覆盖路径正例自检（--selftest）:")
    for line in selftest_lines:
        print(f"    {line}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
