#!/usr/bin/env python3
"""WP3 标准布局视口层辅助：归位模板解析 + 模板槽位几何 + DSL 推演几何（报告层只读复用）。

职责（报告层「标准模板」叠加视口的数据来源）：
- 归位解析：只读复用 validators/rules/layout_2x4.py 现有匹配函数（build_tree /
  _content_node / _content_sk / _find_variant / _find_topology / _manual_verdict），
  **不改其逻辑**；返回 (template, source)，source = manual（人工指认表）| algorithm；
- 模板槽位：复用 layout_forms_report.skeleton_rects（与检测同源：从官方 18 + 补充 7
  模板结构推导槽位矩形，vp 坐标，卡根原点）；
- DSL 推演：复用 layout_forms_report.infer_layout（简化 flex：Row/Column + padding +
  gap/itemMargin 顶层生效 + matchParent，声明层；无 dump 时的实际布局参照层）。

口径（AGENTS.md 检查器职责边界）：本模块只做几何归位与展示数据准备，不下设计结论；
2×2 / 无归位模板的卡返回空（报告层降级隐藏模板层）。
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from validators.dsl import GenuiCard  # noqa: E402
from validators.rules import layout_2x4  # noqa: E402

try:  # 报告工具依赖（与检测同源几何 + 推演引擎）；导入失败时降级为空几何
    from layout_forms_report import infer_layout, skeleton_rects  # noqa: E402
except Exception:  # noqa: BLE001  报告层增强能力，缺失不阻断
    infer_layout = None
    skeleton_rects = None

#: 模板槽位角色（title / content / action，供视觉着色区分）
_ROLE_ORDER = ("title", "content", "action")


def placement_meta(card: GenuiCard) -> Dict:
    """卡 → 归位模板信息：{"template": str|None, "source": "manual"|"algorithm"|None}。

    解析顺序（与规则侧一致）：人工指认表（_MANUAL_VERDICTS，需 case_id 带分支前缀，
    如 check_case 管线 trio 目录 A-q20）→ 精确匹配 → 拓扑归位；全部不中 → template None。
    非 2×4 卡返回空 dict（报告层不渲染模板层）。
    """
    if card.card_size != "2x4":
        return {}
    try:
        verdict = layout_2x4._manual_verdict(card)
        if verdict is not None:
            return {"template": verdict, "source": "manual"}
        tree = layout_2x4.build_tree(card)
        content = layout_2x4._content_node(tree)
        if content is None and tree is not None and len(tree.children) >= 2:
            content = tree  # root 即 content_root（B 系形态，与规则侧口径一致）
        if content is None:
            return {"template": None, "source": None}
        hit = layout_2x4._find_variant(layout_2x4._content_sk(content))
        if hit is not None:
            return {"template": hit[0], "source": "algorithm"}
        topo = layout_2x4._find_topology(content)
        if topo is not None:
            return {"template": topo[0], "source": "algorithm"}
        return {"template": None, "source": None}
    except Exception:  # noqa: BLE001  meta 为增强信息：异常降级为空
        return {}


def template_slots(name: str) -> Tuple[Optional[tuple], List[Dict]]:
    """模板名 → (title 槽位 (x,y,w,h)|None, 槽位列表 [{x,y,w,h,role,label}]）。

    几何与检测同源（layout_forms_report.skeleton_rects：从模板结构推导，
    不复制数值）；role：title / content / action（capsule 高 36 = action）。
    """
    if skeleton_rects is None:
        return (None, [])
    title_rect, rects, _ = skeleton_rects(name)
    slots = [
        {"x": float(x), "y": float(y), "w": float(w), "h": float(h),
         "role": "action" if cap else "content", "label": label}
        for x, y, w, h, cap, label in rects
    ]
    return (title_rect, slots)


def infer_rects(card: GenuiCard) -> List[Dict]:
    """卡 → DSL 声明推演矩形列表 [{x,y,w,h,id,kind,undeclared}]（无 dump 时实际层参照）。

    复用 layout_forms_report.infer_layout（简化 flex 声明层推演，卡根原点 vp 坐标）。
    """
    if infer_layout is None:
        return []
    try:
        tree = layout_2x4.build_tree(card)
        content = layout_2x4._content_node(tree)
        if content is None and tree is not None and len(tree.children) >= 2:
            content = tree
        if content is None:
            return []
        placed = infer_layout(content)
    except Exception:  # noqa: BLE001  推演为展示增强：异常降级为空
        return []
    out: List[Dict] = []

    def walk(p) -> None:
        for c in p.children:
            nid = str(c.node.comp.get("id") or "")
            if c.w < 1 or c.h < 1:
                continue
            out.append({"x": float(c.x), "y": float(c.y), "w": float(c.w), "h": float(c.h),
                        "id": nid, "kind": c.node.kind,
                        "undeclared": c.undeclared_w or c.undeclared_h})
            walk(c)

    walk(placed)
    return out
