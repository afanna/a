#!/usr/bin/env python3
"""L2b 声明↔真值对账 CLI。"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from validators.config import card_data_dir  # noqa: E402
from validators.dsl import load_case  # noqa: E402
from validators.layout import DumpLayout  # noqa: E402
from validators.reconcile_lib import reconcile  # noqa: E402


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="L2b 声明↔真值对账")
    parser.add_argument("--qdir", default="q010")
    parser.add_argument("--layout", required=True, help="dumpLayout JSON 路径")
    args = parser.parse_args(argv)
    layout_path = Path(args.layout)
    if not layout_path.is_file():
        print(f"错误: 找不到布局文件 {layout_path}", file=sys.stderr)
        return 2
    card = load_case(card_data_dir() / args.qdir)
    layout = DumpLayout.from_file(layout_path)
    findings = reconcile(card, layout)
    print(json.dumps([f.to_dict() for f in findings], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
