#!/usr/bin/env python3
"""回归（M5）：负例集 + 基线 diff，一条命令。

用法：
    python3 scripts/regression.py                    # 负例集 + 汇总当前报告
    python3 scripts/regression.py --baseline         # 生成 baseline
    python3 scripts/regression.py --diff old.json new.json
    python3 scripts/regression.py --all              # batch + 汇总 + 基线 + 负例
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from validators.config import review_dir  # noqa: E402
from validators.design_contract import attach_card_size_contracts, load_design_contract  # noqa: E402
from validators.dsl import load_case, load_genui, load_task_spec  # noqa: E402
from validators.layout import DumpLayout  # noqa: E402
from validators.rules import run_l1, run_l3_heuristics  # noqa: E402
from validators.geometry import run_geometry  # noqa: E402
from validators.reconcile_lib import reconcile  # noqa: E402

HERE = Path(__file__).resolve().parents[1]
NEG = HERE / "tests" / "negatives"


def run_negative_set():
    contract = load_design_contract()
    cases = sorted(p for p in NEG.iterdir() if p.is_dir() and (p / "expected.json").exists())
    failures = []
    checked = 0
    for d in cases:
        exp = json.loads((d / "expected.json").read_text(encoding="utf-8"))
        layout_name = "layout.json" if exp.get("requires_render") else None
        card = load_case(d)
        attach_card_size_contracts(contract, card)  # Idea2-WP-B 注入收口
        findings = run_l1(card, contract, card.query_text)
        findings += run_l3_heuristics(card, contract, card.query_text)
        if layout_name:
            findings += run_geometry(card, DumpLayout.from_file(d / layout_name))
            findings += reconcile(card, DumpLayout.from_file(d / layout_name))
        actual = {(f.rule_id, f.severity, (f.element.dsl_id if f.element else None)) for f in findings}
        for want in exp["expects"]:
            key = (want["rule_id"], want["severity"], want.get("dsl_id"))
            if not any(a[0] == key[0] and a[1] == key[1] and (key[2] is None or key[2] == a[2]) for a in actual):
                failures.append((d.name, want, sorted(actual)))
        checked += 1
    report = {"schema": "design-check/negative-set/v1", "cases_checked": checked,
              "failures": [{"case": f[0], "want": f[1], "actual": f[2]} for f in failures]}
    out = review_dir() / "negative-set-report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"负例集: {checked} cases, 未命中 {len(failures)}")
    for f in failures:
        print("  未命中:", f[0], f[1])
    return 0 if not failures else 1


def load_finding_set(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    out = {}
    for qid, fs in data["cases"].items():
        out[qid] = {(f["layer"], f["rule_id"], f["severity"], (f.get("element") or {}).get("dsl_id")) for f in fs}
    return out


def diff_report(new_path, old_path):
    new = load_finding_set(new_path)
    old = load_finding_set(old_path)
    qids = sorted(set(new) | set(old))
    added, removed = [], []
    for qid in qids:
        n = new.get(qid, set()) - old.get(qid, set())
        r = old.get(qid, set()) - new.get(qid, set())
        for item in n:
            added.append((qid, item))
        for item in r:
            removed.append((qid, item))
    print(f"added: {len(added)}   removed: {len(removed)}")
    for qid, item in sorted(added):
        print("  +", qid, item)
    for qid, item in sorted(removed):
        print("  -", qid, item)
    return 0 if (not added and not removed) else 1


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="回归")
    parser.add_argument("--negatives", action="store_true", help="跑负例集")
    parser.add_argument("--baseline", action="store_true", help="生成 baseline.json（从当前 l1-report）")
    parser.add_argument("--diff", nargs=2, metavar=("NEW", "OLD"), help="diff 两份 unified 报告")
    parser.add_argument("--all", action="store_true", help="batch+summarize+基线+负例 一站式")
    args = parser.parse_args(argv)

    if args.all:
        from scripts import check_batch, summarize
        rc = check_batch.main(["--with-layout"])
        if rc:
            return rc
        rc = summarize.main([])
        if rc:
            return rc
        rc = run_negative_set()
        return rc

    rc = 0
    if args.negatives:
        rc = run_negative_set() or rc
    if args.baseline:
        from scripts import summarize
        rc = summarize.main([]) or rc
    if args.diff:
        rc = diff_report(args.diff[0], args.diff[1]) or rc
    if not (args.negatives or args.baseline or args.diff):
        # 默认 = 负例集 + 基线
        rc = run_negative_set() or rc
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
