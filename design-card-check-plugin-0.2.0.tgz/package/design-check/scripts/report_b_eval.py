#!/usr/bin/env python3
"""评测分支卡双报告生成器（参数化版）：问题清单页 + 可视化报告页。

数据源：check_card.py --dsl/--qdir --layout（L1 + dump 真值 L2a/L2b）。
产物（按 AGENTS.md 报告命名规范 <范围>-<卡号>-<类型>-<YYYYMMDD>.<ext>，日期动态取当日；
2026-08-24 起写入 review/<YYYYMMDD>/ 日目录，文件名规范不变）：
    review/<YYYYMMDD>/<scope>-<tag>-problem-list-<YYYYMMDD>.json（机器友好问题清单）
    review/<YYYYMMDD>/<scope>-<tag>-visual-<YYYYMMDD>.html（人类审阅可视化）
    （tag = 卡号拼接，如 q1q4q7；单卡时两页都含该卡）

用法：
    python3 scripts/report_b_eval.py                    # 零参：保持 B-q1q4q7 既有行为与文件名
    generate_reports(scope, cases, data)                # 参数化入口（check_case.py 管线调用）
        scope: 分支短名（A/B/C/MS/DSL/SET93…）
        cases: [(src, qid), …]，src=报告标签（如 q10），qid=dump 名（如 B-q10）
        data:  {src: {"summary": {...}, "findings": [...]}}
"""
from __future__ import annotations

import html
import hashlib
import json
import subprocess
import sys
from collections import Counter
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_store import load_case_report  # noqa: E402
from validators.config import daily_review_dir, review_dir  # noqa: E402
from validators.layout import DumpLayout  # noqa: E402
from validators.rule_category import category_for  # noqa: E402

try:  # WP3 标准布局视口层：只读复用 layout_2x4 匹配 + layout_forms_report 槽位几何/推演
    from layout_viewport import infer_rects, template_slots  # noqa: E402
except Exception:  # noqa: BLE001  报告层增强能力：缺失时模板层降级隐藏
    infer_rects = template_slots = None

#: 零参 CLI 的默认范围（与历史产物 B-q1q4q7 一致，勿改）
CARDS = [("q1", "b-q1"), ("q4", "b-q4"), ("q7", "b-q7")]
DEFAULT_SCOPE = "B"
BRANCH = "../第一次评测/B(现网分支)/dsl"
#: severity pill 配色（与新类别 pill 同一视觉体系；P0 红 / P1 橙 / P2 灰）
SEV_CLASS = {"P0": "sev-p0", "P1": "sev-p1", "P2": "sev-p2"}
#: 类别 pill 五色（低饱和底 + 同系深字，白底报告上对比清晰；口径见 rule_category）
CAT_CLASS = {"颜色": "cat-color", "布局": "cat-layout", "尺寸": "cat-size",
             "元素": "cat-element", "其他": "cat-other"}
#: review 根：dumps/vis-assets/wireframe 等非日期真值与资产目录维持原位（AGENTS.md 规范）
REVIEW = review_dir()

#: 自包含内嵌 CSS（禁外链 CDN/字体/图标；浅色主题，信息密度优先，不做花哨动效）
CSS = '''
 body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;margin:0;background:#f5f6f8;color:#222}
 .wrap{max-width:1180px;margin:0 auto;padding:28px 20px 60px}
 h1{font-size:22px;margin:0 0 6px;font-weight:700;color:#141b2d}
 h2{font-size:17px;margin:34px 0 10px;border-left:4px solid #0a59f7;padding-left:10px;color:#1a2b4a}
 .meta{color:#555;font-size:13px;line-height:1.9;background:#fff;border:1px solid #e3e5e9;border-radius:10px;padding:12px 16px}
 .card-row{display:flex;gap:14px;flex-wrap:wrap;background:#fff;border:1px solid #e3e5e9;border-radius:12px;padding:14px}
 .panel{flex:1;min-width:280px} .panel .cap{font-size:12px;color:#666;margin:2px 0 6px;text-align:center}
 .panel img{max-width:100%;max-height:330px;border:1px solid #e0e2e6;border-radius:8px;display:block;margin:0 auto}
 table{border-collapse:collapse;width:100%;background:#fff;font-size:12.5px;margin-top:12px;border-radius:10px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.08)}
 th{background:#0a59f7;color:#fff;text-align:left;padding:7px 10px;font-size:11.5px;font-weight:600;letter-spacing:.02em;white-space:nowrap}
 td{border-top:1px solid #eef0f3;padding:6px 10px;vertical-align:top;word-break:break-word}
 tr:nth-child(even) td{background:#f7f9fc}
 tr:hover td{background:#eef4ff}
 code{background:#f0f2f5;padding:1px 5px;border-radius:4px;font-size:11.5px;word-break:break-all}
 .pill{display:inline-block;border-radius:999px;padding:2px 8px;font-size:11px;font-weight:600;line-height:1.5;white-space:nowrap}
 .sev-p0{background:#d33;color:#fff}
 .sev-p1{background:#e77a1f;color:#fff}
 .sev-p2{background:#8a8a8a;color:#fff}
 .cat-color{background:#f3e8fd;color:#6b21a8}
 .cat-layout{background:#e8f0fe;color:#0a59f7}
 .cat-size{background:#fff3e6;color:#c2570a}
 .cat-element{background:#e8f7ee;color:#0c7a43}
 .cat-other{background:#eef0f3;color:#555}
 .tag{display:inline-block;background:#e8f0fe;color:#0a59f7;border-radius:999px;padding:1px 10px;font-size:11px;margin-right:6px}
 .note{font-size:12px;color:#888;margin-top:10px;line-height:1.7}
 a{color:#0a59f7;text-decoration:none}
 .flag{background:#fff3f0;border:1px solid #f0c8ba;border-radius:8px;padding:8px 12px;font-size:12px;color:#8a3b25;margin-top:8px}
 .wf-link{font-size:11.5px;color:#888;text-align:center;margin-top:4px}
 .stage-wrap{background:#fff;border:1px solid #dde3ec;border-radius:12px;padding:12px}
 .vp-row{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px;align-items:start}
 .vp-col{min-width:0}
 .vp-col .cap{font-size:12px;color:#666;margin:2px 0 6px;display:flex;justify-content:space-between;align-items:center;gap:8px}
 .vp-col .cap label{cursor:pointer;white-space:nowrap;color:#0a59f7;font-weight:600}
 .stage{position:relative;width:100%;max-width:640px;margin:0 auto;background:#fff}
 .stage .layer{display:block;width:100%;height:auto;max-height:330px;border:1px solid #dfe2e7;border-radius:8px;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.08)}
 .stage .layer-tpl{position:absolute;inset:0;width:100%;height:100%;border:none;box-shadow:none;background:none}
 .vp-shot img{width:100%;max-width:640px;object-fit:contain;border:1px solid #e0e2e6;border-radius:8px;display:block;margin:0 auto}
 .layer-tpl{display:none} .show-tpl .layer-tpl{display:block}
 .stage .layer-wf rect.delta{stroke:#d33 !important;stroke-width:2}
 .tpl-meta{font-size:11.5px;color:#555;margin-top:6px;line-height:1.7}
'''


def esc(s) -> str:
    return html.escape(str(s if s is not None else ""))


def badge(sev: str) -> str:
    """severity pill：P0 红 / P1 橙 / P2 灰（圆角 pill，与类别徽章同一视觉体系）。"""
    cls = SEV_CLASS.get(sev, "sev-p2")
    return f'<span class="pill {cls}">{esc(sev)}</span>'


def cat_badge(cat: str) -> str:
    """类别 pill：颜色=紫 / 布局=蓝 / 尺寸=橙 / 元素=绿 / 其他=灰。"""
    cls = CAT_CLASS.get(cat, "cat-other")
    return f'<span class="pill {cls}">{esc(cat)}</span>'


def _colgroup(with_fix: bool) -> str:
    """列宽方案：严重度/层/类别窄列固定，规则/位置中列 min-width，问题/修复弹性宽列
    （长规则 ID/路径靠 td/code 的 word-break 断行，不撑破表格）。"""
    cols = ['<col style="width:70px">', '<col style="width:52px">', '<col style="width:78px">',
            '<col style="min-width:150px">', '<col style="min-width:110px">', '<col>']
    if with_fix:
        cols.append('<col>')
    return "<colgroup>" + "".join(cols) + "</colgroup>"


def get_json(dsl: str, layout: str) -> dict:
    out = subprocess.run([sys.executable, "scripts/check_card.py", "--dsl", dsl,
                          "--layout", layout, "--format", "json"],
                         capture_output=True, text=True,
                         cwd=Path(__file__).resolve().parents[1])
    return json.loads(out.stdout)


def wireframe_layer(dump_path: Path, delta_ids: set) -> str:
    """dump 实测 bounds → 线框 SVG 层（vp 坐标，卡根原点）。

    TEMPLATE_DELTA 命中的组件 id → 红框标注（class delta + data-did 供图侧清单联动）。
    """
    lay = DumpLayout.from_file(dump_path)
    root = lay.card_root()
    if root is None:
        return '<div style="color:#999;font-size:12px">dump 未含卡片根</div>'
    rx0, ry0, rx1, ry1 = root.bounds_vp()
    w_all, h_all = rx1 - rx0, ry1 - ry0
    # 字号/线宽按 viewBox 宽归一（基准 320 = 2×4 卡）：2×2 卡（160）减半，
    # 两卡型视觉字号一致（WP3d 2026-08-25）
    sc = w_all / 320.0
    fs_tag, fs_foot = 5.5 * sc, 5.0 * sc
    sw_border, sw_block = 1.5 * sc, 0.6 * sc
    parts = [f'<svg class="layer layer-wf" viewBox="0 0 {w_all:.0f} {h_all:.0f}" '
             f'xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">',
             f'<rect x="0" y="0" width="{w_all}" height="{h_all}" fill="none" stroke="#0a59f7" '
             f'stroke-width="{sw_border:.2f}"/>']

    def draw(node):
        b = node.bounds_vp()
        if b is None or not node.visible or node is root:
            for c in node.children:
                draw(c)
            return
        x0, y0, x1, y1 = b[0] - rx0, b[1] - ry0, b[2] - rx0, b[3] - ry0
        w, h = x1 - x0, y1 - y0
        if w < 4 or h < 4:
            return
        is_text = (node.text or "").strip() != ""
        nid = node.id or ""
        dcls, did = "", ""
        if nid in delta_ids:
            dcls, did = " delta", f' data-did="{esc(nid)}"'
        parts.append(f'<rect class="wf{dcls}"{did} x="{x0:.1f}" y="{y0:.1f}" width="{w:.1f}" '
                     f'height="{h:.1f}" rx="2" '
                     f'fill="{"rgba(10,89,247,0.05)" if is_text else "none"}" '
                     f'stroke="#5a6a7f" stroke-width="{sw_block:.2f}" stroke-opacity="0.85"/>')
        if h >= 14 and w >= 20:
            label = (node.text or "").strip() or (nid[:12] or node.type)
            # 标签按块宽截断（估算字符宽 ≈ 字号×0.62），避免溢出所在块右边界
            n_max = max(1, int((w - 3.0) / (fs_tag * 0.62)))
            label = label[:min(6 if is_text else 12, n_max)]
            parts.append(f'<text class="tag" x="{x0 + 1.5:.1f}" y="{y0 + 7:.1f}" '
                         f'font-size="{fs_tag:.2f}" fill="#333">{esc(label)}</text>')
        for c in node.children:
            draw(c)

    for c in root.children:
        draw(c)
    parts.append(f'<text class="tag" x="{w_all - 4:.1f}" y="{h_all - 3:.1f}" '
                 f'font-size="{fs_foot:.2f}" fill="#999" '
                 f'text-anchor="end">实测 {w_all:.0f}×{h_all:.0f}vp</text>')
    parts.append("</svg>")
    return "".join(parts)


def infer_layer_svg(rects: list, w: float = 320.0, h: float = 160.0) -> str:
    """DSL 声明推演矩形 → SVG 层（无 dump 时实际布局参照；橙系与实测/模板区分）。"""
    sc = w / 320.0  # 字号/线宽按 viewBox 宽归一（基准 320 = 2×4 卡；WP3d）
    fs_tag = 5.5 * sc
    parts = [f'<svg class="layer layer-wf" viewBox="0 0 {w:.0f} {h:.0f}" '
             f'xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">',
             f'<rect x="0" y="0" width="{w:.0f}" height="{h:.0f}" fill="none" stroke="#0a59f7" '
             f'stroke-width="1.5"/>']
    for r in rects:
        star = "*" if r.get("undeclared") else ""
        parts.append(f'<rect class="wf" x="{r["x"]:.1f}" y="{r["y"]:.1f}" width="{r["w"]:.1f}" '
                     f'height="{r["h"]:.1f}" fill="rgba(255,149,0,0.05)" stroke="#e8890c" '
                     f'stroke-width="{0.7 * sc:.2f}"/>')
        if r["h"] >= 14 and r["w"] >= 20:
            label = r.get("id") or r.get("kind") or ""
            n_max = max(1, int((r["w"] - 3.0) / (fs_tag * 0.62)))
            parts.append(f'<text class="tag" x="{r["x"] + 1.5:.1f}" y="{r["y"] + 7:.1f}" '
                         f'font-size="{fs_tag:.2f}" fill="#8a5a0a">{esc(label[:n_max])}{star}</text>')
    parts.append("</svg>")
    return "".join(parts)


def template_layer_svg(name: str, title_rect, slots: list) -> str:
    """标准模板槽位层：蓝/绿虚线 + 半透明填充（与实测线框灰系区分；默认隐藏，
    「标准模板」开关（.show-tpl）勾选后叠加）。

    槽位几何与检测同源（layout_viewport.template_slots → layout_forms_report.skeleton_rects，
    从模板结构推导，不复制数值）；安全区 296×136 蓝虚线框。
    """
    parts = ['<svg class="layer layer-tpl" viewBox="0 0 320 160" '
             'xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">',
             '<rect x="12" y="12" width="296" height="136" fill="none" stroke="#0a59f7" '
             'stroke-width="1" stroke-dasharray="4 3" opacity="0.6"/>']

    def slot_rect(x, y, w, h, role):
        if role == "action":
            stroke, fill, rx = "#0c7a43", "rgba(12,122,67,0.12)", min(h / 2, 8)
        elif role == "title":
            stroke, fill, rx = "#0a59f7", "rgba(10,89,247,0.10)", 3
        else:
            stroke, fill, rx = "#0a59f7", "rgba(10,89,247,0.06)", 3
        return (f'<rect class="tpl" x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" '
                f'rx="{rx:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="1.2" stroke-dasharray="5 3"/>')

    if title_rect is not None:
        x, y, w, h = title_rect
        parts.append(slot_rect(x, y, w, h, "title"))
        parts.append(f'<text class="tag" x="{x + w / 2:.1f}" y="{y + h / 2 + 2:.1f}" font-size="7" '
                     f'fill="#0a59f7" text-anchor="middle">title {w:g}×{h:g}</text>')
    for s in slots:
        parts.append(slot_rect(s["x"], s["y"], s["w"], s["h"], s["role"]))
        parts.append(f'<text class="tag" x="{s["x"] + s["w"] / 2:.1f}" y="{s["y"] + s["h"] / 2 + 2:.1f}" '
                     f'font-size="6.5" fill="#4a5560" text-anchor="middle">{esc(s["label"])}</text>')
    parts.append(f'<text class="tag" x="308" y="150" font-size="5.5" fill="#0a59f7" text-anchor="end">'
                 f'模板 {esc(name)} · 安全区 296×136</text>')
    parts.append("</svg>")
    return "".join(parts)


def _stage_panel(scope: str, src: str, qid: str, d: dict) -> str:
    """双视口舞台（2026-08-25 用户裁决：废除五层叠加，两视口并列）。

    左视口 = 现网真机实拍（独立展示，无叠加；无截图 → 占位框）；
    右视口 = dumpLayout 实测线框（无 dump → DSL 声明推演降级），
    TEMPLATE_DELTA 偏差红框 + 「标准模板」局部开关（默认不勾，勾选后叠加
    模板槽位虚线层）+ 归位标注。
    """
    dump_path = REVIEW / "dumps" / f"{qid}.layout.json"
    has_dump = dump_path.is_file()
    lay = (d.get("meta") or {}).get("layout_2x4") or {}
    tpl_name, tpl_source = lay.get("template"), lay.get("source")
    delta_ids = {((f.get("element") or {}).get("dsl_id") or "") for f in d["findings"]
                 if f["rule_id"] == "LAYOUT2X4.TEMPLATE_DELTA"}
    delta_ids.discard("")
    sid = f"stage-{src}"
    # 左视口：现网真机实拍（独立，无叠加层；vis-assets 缺失 → 显式占位框）
    shot = REVIEW / "vis-assets" / f"{qid}.png"
    if shot.is_file():
        shot_html = (f'<img src="../vis-assets/{qid}.png" alt="{esc(qid)} 现网真机实拍">')
    else:
        shot_html = ('<div style="border:1px dashed #c9ced6;border-radius:8px;padding:34px 10px;'
                     'color:#999;font-size:12px;text-align:center">无现网实拍'
                     f'（{esc(qid)} 截图未复制到 review/vis-assets/）</div>')
    # 右视口标题行：线框说明 + 「标准模板」局部开关（默认不勾 → 模板虚线层隐藏）
    wf_label = "dumpLayout 实测线框" if has_dump else "DSL 声明推演线框"
    cap_right = f'<span>{wf_label}（红框 = TEMPLATE_DELTA 偏差块）</span>'
    if tpl_name and template_slots is not None:
        cap_right += (f'<label><input type="checkbox" '
                      f'onchange="tg(\'{sid}\',\'show-tpl\',this.checked)"> 标准模板</label>')
    # 右视口线框层：dump 实测 bounds 实线；无 dump → DSL 推演（橙系）
    if has_dump:
        wf_svg = wireframe_layer(dump_path, delta_ids)
    else:
        rects = []
        if infer_rects is not None:
            try:
                from validators.dsl import load_genui
                trio = REVIEW / "pipeline" / f"{scope}-{src}" / "card.genui.jsonl"
                if trio.is_file():
                    rects = infer_rects(load_genui(trio, f"{scope}-{src}"))
            except Exception:  # noqa: BLE001  推演缺失降级为空层
                rects = []
        wf_svg = infer_layer_svg(rects)
    tpl_layer = ""
    if tpl_name and template_slots is not None:
        title_rect, slots = template_slots(tpl_name)
        tpl_layer = template_layer_svg(tpl_name, title_rect, slots)
    # 归位标注（人工指认 vs 算法归位；未登记形态显式说明）
    meta_txt = ""
    if tpl_name:
        if tpl_source == "manual":
            meta_txt = (f'归位模板：<b>{esc(tpl_name)}</b>（人工指认 · 2026-08-24 终审，'
                        f'覆写算法归位）')
        else:
            meta_txt = f'归位模板：<b>{esc(tpl_name)}</b>（算法归位）'
        meta_txt += ' · 槽位几何与检测同源（官方 18 + 补充 7）'
    elif lay:
        meta_txt = "归位：未登记形态（VARIANT_MATCH 降 P2，无模板槽位）"
    miss = "" if has_dump else ' · 无 dump：实际层为 <b>DSL 声明推演</b>（声明层简化 flex）'
    return ('<div class="stage-wrap"><div class="vp-row">'
            f'<div class="vp-col"><div class="cap"><span>现网真机实拍</span></div>'
            f'<div class="vp-shot">{shot_html}</div></div>'
            f'<div class="vp-col"><div class="cap">{cap_right}</div>'
            f'<div class="stage" id="{sid}">{wf_svg}{tpl_layer}</div></div>'
            '</div>'
            f'<div class="tpl-meta">{meta_txt}{miss}</div></div>')


def wireframe_svg(dump_path: Path) -> str:
    """dump 实测 bounds → 紧凑线框 SVG（卡根原点，vp 坐标）。"""
    lay = DumpLayout.from_file(dump_path)
    root = lay.card_root()
    if root is None:
        return '<div style="color:#999;font-size:12px">dump 未含卡片根</div>'
    rx0, ry0, rx1, ry1 = root.bounds_vp()
    w_all, h_all = rx1 - rx0, ry1 - ry0
    # 字号/线宽固定基准值（5.5/5.0，2026-08-25 用户终裁对齐 good case B-visual；
    # WP3d 的 viewBox 归一已撤销——dual 线框两卡型统一 5.5，2×2 卡 max-width=320 由下方 w_all*2 决定）
    fs_tag, fs_foot = 5.5, 5.0
    parts = [f'<svg viewBox="0 0 {w_all:.0f} {h_all:.0f}" xmlns="http://www.w3.org/2000/svg" '
             f'style="width:100%;max-width:{max(300, w_all * 2):.0f}px;max-height:330px;display:block;margin:0 auto;'
             f'border:1px solid #dfe2e7;border-radius:8px;background:#fff">',
             f'<rect x="0" y="0" width="{w_all}" height="{h_all}" fill="none" stroke="#0a59f7" '
             f'stroke-width="1.5"/>']

    def draw(node):
        b = node.bounds_vp()
        if b is None or not node.visible or node is root:
            for c in node.children:
                draw(c)
            return
        x0, y0, x1, y1 = b[0] - rx0, b[1] - ry0, b[2] - rx0, b[3] - ry0
        w, h = x1 - x0, y1 - y0
        if w < 4 or h < 4:
            return
        is_text = (node.text or "").strip() != ""
        parts.append(f'<rect x="{x0:.1f}" y="{y0:.1f}" width="{w:.1f}" height="{h:.1f}" rx="2" '
                     f'fill="{"rgba(10,89,247,0.05)" if is_text else "none"}" '
                     f'stroke="#5a6a7f" stroke-width="0.6" stroke-opacity="0.85"/>')
        if h >= 14 and w >= 20:
            label = (node.text or "").strip() or (node.id[:12] or node.type)
            n_max = max(1, int((w - 3.0) / (fs_tag * 0.62)))
            label = label[:min(6 if is_text else 12, n_max)]
            parts.append(f'<text x="{x0 + 1.5:.1f}" y="{y0 + 7:.1f}" font-size="{fs_tag:.2f}" '
                         f'fill="#333">{esc(label)}</text>')
        for c in node.children:
            draw(c)

    for c in root.children:
        draw(c)
    parts.append(f'<text x="{w_all - 4:.1f}" y="{h_all - 3:.1f}" font-size="{fs_foot:.2f}" '
                 f'fill="#999" text-anchor="end">实测 {w_all:.0f}×{h_all:.0f}vp</text>')
    parts.append("</svg>")
    return "".join(parts)


#: 槽位归区规则，报告内以 NEW 徽标提示
AREA_NEW_RULES = ("AREA.TITLE_TEXT_TIER", "GEOMETRY.AREA_TITLE_ALIGN",
                  "GEOMETRY.AREA_CONTENT_TEXT_OVERLAP", "GEOMETRY.AREA_BOTTOM_ANCHOR")


def findings_rows(findings: list, with_fix: bool) -> str:
    order = {"P0": 0, "P1": 1, "P2": 2}
    head = ("<tr><th>严重度</th><th>层</th><th>类别</th><th>规则</th><th>位置</th><th>问题</th>"
            + ("<th>最小修复建议</th>" if with_fix else "") + "</tr>")
    rows = [f"<table>{_colgroup(with_fix)}{head}"]
    for f in sorted(findings, key=lambda x: (order[x["severity"]], x["layer"], x["rule_id"])):
        el = (f.get("element") or {}).get("dsl_id") or (f.get("element") or {}).get("dump_id") or "—"
        fix = f'<td>{esc(f.get("fix_hint") or "")}</td>' if with_fix else ""
        new = (' <span style="background:#e8f7ee;color:#0c7a43;border-radius:4px;'
               'padding:0 5px;font-size:10px">NEW</span>') if f["rule_id"] in AREA_NEW_RULES else ""
        rows.append(f'<tr><td>{badge(f["severity"])}</td><td>{esc(f["layer"])}</td>'
                    f'<td>{cat_badge(category_for(f["rule_id"]))}</td>'
                    f'<td><code>{esc(f["rule_id"])}</code>{new}</td><td><code>{esc(el)}</code></td>'
                    f'<td>{esc(f["message"])}</td>{fix}</tr>')
    rows.append("</table>")
    return "\n".join(rows)


#: 共性问题说明（通用描述，不绑定具体卡；命中卡示例在表格「命中」列动态呈现）
COMMON_NOTES = {
    "TYPE.WEIGHT_MATRIX": ("L1", "字重 600/800 滥用，规范三档仅 400/500/700"),
    "COLOR.TOKEN_UNREGISTERED": ("L1", "未登记色值（手调渐变底/图标填充）"),
    "GRADIENT.UNREGISTERED": ("L1", "渐变 stops 不匹配任何注册预设（须原样使用预设）"),
    "SHAPE.CARD_ROOT_RADIUS": ("L1", "卡根圆角非 20vp；B 分支全量曾 98/98 命中，属管线级偏差，是否豁免待设计师裁定"),
    "SHAPE.BUTTON_RADIUS": ("L1", "按钮圆角非胶囊全圆角（<18vp，2026-08-24 裁决）"),
    "ICON.SIZE_CONTRACT": ("L1", "按钮内图标非场景契约（图文按钮 20vp / 纯图标按钮 16vp）"),
    "VISUAL.CONTRAST": ("L1", "对比度问题（含需端侧确认与全位置不足 3:1 两类）"),
    "GEOMETRY.SLOT_GAP": ("L2a", "槽位边界零间距（0vp ≠ 8vp，实测）"),
    "GEOMETRY.SAFE_AREA_OVERFLOW": ("L2a", "内容右缘越出安全区 12vp（实测）"),
    "GEOMETRY.LABEL_GAP": ("L2a", "环下标签间距与规范档位不符（实测）"),
    "GEOMETRY.CONTENT_ALIGN_ANCHOR": ("L2a", "内容组未锚定底部（P2 建议级；D5 已知表现型居中误判待修）"),
    "RECONCILE.DIMENSION_DRIFT": ("L2b", "声明尺寸 vs 实测不一致——与现网实拍矛盾时标需端侧复核"),
    "AREA.TITLE_TEXT_TIER": ("L1·NEW", "title 区文本档位 12vp（批量命中多为偏高 10–14vp 档位）"),
    "GEOMETRY.AREA_TITLE_ALIGN": ("L2a·NEW", "title 区顶部对齐（批量命中多为 2.0vp 级边缘值，待设计师复核）"),
    "GEOMETRY.AREA_CONTENT_TEXT_OVERLAP": ("L2a·NEW", "content 区文本同心叠放（实证: 数值×状态文本纵向 16vp）"),
    "GEOMETRY.AREA_BOTTOM_ANCHOR": ("L2a·NEW", "bottom 区下探 12vp 安全边距（实证: 按钮下探 8.0vp）"),
}


def report_names(scope: str, cases: list[tuple[str, str]]) -> tuple[str, str]:
    """AGENTS.md 命名规范：<范围>-<卡号>-<类型>-<YYYYMMDD>.<ext>（日期动态取当日）。"""
    today = date.today().strftime("%Y%m%d")
    tag = "".join(src for src, _ in cases)
    return (f"{scope}-{tag}-problem-list-{today}.json", f"{scope}-{tag}-visual-{today}.html")


def q1_flag() -> str:
    return notes_flag_html([Q1_NOTE])


def q4_win_flag() -> str:
    return notes_flag_html([Q4_NOTE])


# ------- F4（Idea4-WP2）：CaseReport 数据驱动层（重出不重跑） -------

#: q1/q4 人工注记正文化（2026-08-26 迁入 review/cases/B-q1.json / B-q4.json notes，
#: 模板不再按卡号硬编码插旗；此处保留正文作为产物缺失时的兜底，仅 keyed 精确 qid）
Q1_NOTE = ("⚠ 需端侧复核：B-q1 的 RECONCILE.DIMENSION_DRIFT 显示本机渲染卡宽 320vp（2x4 形态）"
           "而 DSL 声明 160×160、现网实拍为方形——三者不一致，属本次重渲染环境行为，"
           "未对 B/q1 的尺寸下定论；其 L2 几何结论以现网形态复核为准"
           "（归区器对 >240vp 宽卡自动跳过，AREA 类规则不参与）。")
Q4_NOTE = ("✔ 槽位归区检测首战命中（NEW）：content 区 AREA_CONTENT_TEXT_OVERLAP"
           "（ringValue × ringState 纵向交叠 16vp——两文本在电量环中心同心叠放）"
           "+ bottom 区 AREA_BOTTOM_ANCHOR（saveButton 下探 12vp 安全边距 8.0vp）。"
           "因果链：槽位零间距（SLOT_GAP×2）→ 内容区挤压 → 文本叠放 + 按钮压边距。")
#: 兜底注记按精确 qid 匹配（修复历史 bug：任何分支的 q1/q4 被误插 B 分支注记）。
#: 说明：正片已迁 review/cases/B-q1|B-q4.json notes，case_store 不降级保护也已
#: 扩展到 notes（WP2 补丁）；此处按精确 qid 兜底为最后防线（决策记录：内容不删）。
LEGACY_NOTES = {"b-q1": [Q1_NOTE], "B-q1": [Q1_NOTE], "b-q4": [Q4_NOTE], "B-q4": [Q4_NOTE]}

#: dump 采集方式徽章文案（case_store origin 口径）
DUMP_ORIGIN_ZH = {"fresh": "dump 本机实采", "reused": "dump 复用",
                  "render-evidence": "dump render-evidence"}


def notes_flag_html(notes) -> str:
    """notes 数组 → .flag 注记块（数据驱动：任何卡的 notes 都渲染，内容不删）。"""
    return "".join(f'<div class="flag">{esc(n)}</div>' for n in notes or [])


def _notes_for(qid: str, rep: dict | None) -> list:
    """注记来源优先级：内存 CaseReport → review/cases/<qid>.json → 精确 qid 兜底。

    WP2 补丁：任意一级为空都继续向下查（原实现 rep 非 None 即短路返回，
    导致 merged 路径 CaseReport.notes 被批量写清空时兜底不生效）。
    兜底保留为最后防线：case_store 已扩展 notes 不降级保护（产物即真值），
    但报告层再守一道可抵御任何未来写入方清空 notes（内容不下线是硬要求）。
    """
    notes = (rep.get("notes") if rep is not None else []) or []
    if notes:
        return notes
    try:
        notes = load_case_report(qid).get("notes") or []
    except Exception:  # noqa: BLE001  产物缺失/损坏时兜底，不阻塞报告
        notes = []
    return notes or LEGACY_NOTES.get(qid.lower(), [])


def source_badge_html(rep: dict) -> str:
    """每卡 h2 标题行来源徽章（复用既有 .tag 样式，不改 CSS）：
    输入来源（A/B/C/MS/SET93/DSL）+ dump 采集方式 + 截图有无；
    title 提示挂关键路径（DSL / dump / 截图），悬停可见、不占布局。"""
    src = rep.get("source") or {}
    badges = [f'<span class="tag" title="DSL: {esc(src.get("dsl_path") or "?")}">来源 {esc(src.get("label") or "?")}</span>']
    d = rep.get("dump") or {}
    if d.get("present"):
        badges.append(f'<span class="tag" title="dump: {esc(d.get("path") or "?")}">'
                      f'{esc(DUMP_ORIGIN_ZH.get(d.get("origin"), "dump"))}</span>')
    else:
        badges.append('<span class="tag">无 dump（仅 L1）</span>')
    shot = rep.get("screenshot") or {}
    if shot.get("present"):
        badges.append(f'<span class="tag" title="截图: {esc(shot.get("path") or "?")}">截图 {esc(shot.get("kind"))}</span>')
    else:
        badges.append('<span class="tag">无截图</span>')
    return "".join(badges)


def derive_report_names(reports: list, scope_label: str | None = None) -> tuple[str, str]:
    """F4 命名推导收敛（单一函数）：

    - 单一来源且 ≤8 卡：<范围>-<卡号拼接>-<类型>-<日期>（AGENTS.md 规范，向后兼容）；
    - 混合来源或 >8 卡：<范围段>-<类型>-<日期>，范围段为卡集指纹
      `MIX-<卡数>c-<hash4>`（2026-08-26 裁决；hash4 = 卡集 qid 排序后以 "|" 连接的
      sha256 前 4 位——异卡集不互覆盖、同卡集重跑稳定覆盖）；scope_label 显式
      语义名（如 EVAL299）优先于指纹。
    吸收 build_merged_branch_report 的 (qid,qid) hack、EVAL299 特判、>8 卡省略三处补丁。
    """
    today = date.today().strftime("%Y%m%d")
    labels: list = []
    for r in reports:
        lb = (r.get("source") or {}).get("label") or r["qid"].split("-")[0]
        if lb not in labels:
            labels.append(lb)
    if len(labels) == 1 and len(reports) <= 8:
        tag = "".join(r["qid"].split("-", 1)[1] if "-" in r["qid"] else r["qid"]
                      for r in reports)
        return (f"{labels[0]}-{tag}-problem-list-{today}.json",
                f"{labels[0]}-{tag}-visual-{today}.html")
    if scope_label:
        seg = scope_label
    else:
        digest = hashlib.sha256(
            "|".join(sorted(r["qid"] for r in reports)).encode()).hexdigest()
        seg = f"MIX-{len(reports)}c-{digest[:4]}"
    return (f"{seg}-problem-list-{today}.json", f"{seg}-visual-{today}.html")


def _reports_meta_line(reports: list) -> str:
    """报告头部 meta 的「检测通道/数据源」从 case 集合推导（F4）：
    删写死的 check_card --dsl 注记，改为逐卡产物口径。"""
    n = len(reports)
    labels: list = []
    for r in reports:
        lb = (r.get("source") or {}).get("label") or "?"
        if lb not in labels:
            labels.append(lb)
    origins = Counter((r.get("dump") or {}).get("origin") for r in reports)
    n_dump = sum(v for k, v in origins.items() if k)
    n_shot = sum(1 for r in reports if (r.get("screenshot") or {}).get("present"))
    parts = [f"来源 {'、'.join(labels)}"]
    parts.append("dump：" + (" / ".join(f"{DUMP_ORIGIN_ZH.get(k, k)} {v}" for k, v in origins.items() if k)
                             or "无"))
    parts.append(f"截图 {n_shot} 有 / {n - n_shot} 无")
    return (f"数据源：review/cases/&lt;qid&gt;.json × {n}（{'；'.join(parts)}）· "
            "生成：scripts/report_b_eval.py（重出不重跑，消费逐卡产物，不现场重跑 check_card）")


def _case_label(scope: str, src: str) -> str:
    return f"{scope}-{src}"


def _cards_have(cases: list[tuple[str, str]], src: str) -> bool:
    return any(s == src for s, _ in cases)


def _numeral(n: int) -> str:
    return {1: "单", 2: "两", 3: "三"}.get(n, f"{n}")


PROBLEM_LIST_SCHEMA = "design-check/problem-list/v1"


def _finding_json(f: dict) -> dict:
    """finding → 机器友好 JSON 字段（固定字段集，缺失值为 null，不丢字段名）。

    element 与逐卡产物（Finding.to_dict）同口径透传 dsl_id / json_pointer /
    dump_id 三字段；值为 None/缺失的剔除（空串 json_pointer 保留，与逐卡产物一致）。
    """
    el = f.get("element") or {}
    element = {k: el[k] for k in ("dsl_id", "json_pointer", "dump_id")
               if k in el and el[k] is not None}
    return {"layer": f.get("layer"), "severity": f.get("severity"),
            "evidence_type": f.get("evidence_type"), "rule_id": f.get("rule_id"),
            "element": element,
            "message": f.get("message"), "expected": f.get("expected"),
            "actual": f.get("actual"), "fix_hint": f.get("fix_hint"),
            "evidence_file": f.get("evidence_file")}


def _case_meta_fallback(qid: str) -> dict:
    """旧签名（无 reports）时的逐卡元信息兜底：优先 review/cases/<qid>.json 产物，
    缺失时按文件在场性推导（dump/screenshot）+ qid 前缀推 label。

    裸卡号（如 "q1"，无分支前缀）产物必带前缀（*-q1.json）：glob 唯一命中才
    采用该产物元数据；零命中/多命中落最小推导，且 label 置 None（不臆造分支）。
    """
    rep = None
    if "-" not in qid:  # 裸卡号 → 前缀产物 glob（唯一命中才采信）
        hits = sorted((REVIEW / "cases").glob(f"*-{qid}.json"))
        if len(hits) == 1:
            try:
                rep = load_case_report(hits[0])
            except Exception:  # noqa: BLE001  产物损坏 → 最小推导，不阻塞
                rep = None
    else:
        try:
            rep = load_case_report(qid)
        except Exception:  # noqa: BLE001  产物缺失/损坏 → 最小推导，不阻塞
            rep = None
    if rep is not None:
        return {"source": rep.get("source"), "size": rep.get("size"),
                "dump": rep.get("dump"), "screenshot": rep.get("screenshot")}
    dump_path = REVIEW / "dumps" / f"{qid}.layout.json"
    shot_path = REVIEW / "vis-assets" / f"{qid}.png"
    return {"source": {"kind": "branch",
                       "label": qid.split("-")[0] if "-" in qid else None,
                       "dsl_path": None},
            "size": None,
            "dump": {"present": dump_path.is_file(), "path": str(dump_path), "origin": None},
            "screenshot": {"present": shot_path.is_file(), "path": str(shot_path),
                           "kind": None}}


def _case_json(scope: str, src: str, qid: str, d: dict, rep: dict | None) -> dict:
    meta = ({"source": rep.get("source"), "size": rep.get("size"),
             "dump": rep.get("dump"), "screenshot": rep.get("screenshot")}
            if rep is not None else _case_meta_fallback(qid))
    s = d["summary"]
    return {"qid": qid, "source": meta["source"], "size": meta["size"],
            "dump": meta["dump"], "screenshot": meta["screenshot"],
            "summary": {"total": s.get("total"), "p0": s.get("p0"),
                        "p1": s.get("p1"), "p2": s.get("p2")},
            "notes": _notes_for(qid, rep),
            "findings": [_finding_json(f) for f in d["findings"]]}


def build_problem_list(scope: str, cases: list[tuple[str, str]], data: dict,
                       reports: list | None = None) -> str:
    """问题清单（机器友好 JSON，schema=design-check/problem-list/v1）。

    visual HTML 内已含 findings 表，本产物面向机器消费：summary 与逐卡 summary
    对账、findings 全字段、notes 数据驱动（同 HTML 口径的兜底链）。
    reports（F4 可选）= list[CaseReport]；旧签名 (scope, cases, data) 逐卡元信息
    走 review/cases/<qid>.json 产物兜底，两路径产出同构。
    """
    rep_by_qid = {r["qid"]: r for r in reports} if reports else {}
    case_jsons = [_case_json(scope, src, qid, data[src], rep_by_qid.get(qid))
                  for src, qid in cases]
    summary = {"total": sum(c["summary"]["total"] for c in case_jsons),
               "p0": sum(c["summary"]["p0"] for c in case_jsons),
               "p1": sum(c["summary"]["p1"] for c in case_jsons),
               "p2": sum(c["summary"]["p2"] for c in case_jsons)}
    src_counter = Counter((c["source"] or {}).get("label") or "?" for c in case_jsons)
    sources = "、".join(f"{lb}×{n}" for lb, n in src_counter.items())
    doc = {"schema": PROBLEM_LIST_SCHEMA,
           "generated": date.today().isoformat(),
           "scope": scope, "sources": sources,
           "summary": summary, "cases": case_jsons}
    return json.dumps(doc, ensure_ascii=False, indent=1)


def build_visual(scope: str, cases: list[tuple[str, str]], data: dict,
                 layout: str = "dual", reports: list | None = None) -> str:
    """可视化报告。

    layout="dual"（默认，2026-08-25 用户终裁）: 双视图布局（① 现网实拍 +
    ② dump 实测线框并排，card-row + .panel 结构）——唯一默认形态；
    管线 generate_reports 与多分支合并均走此布局。
    layout="stage": 双视口舞台（现网真机实拍 | dumpLayout 线框 + 标准模板开关，
    WP3 系列实现）——非默认，仅供显式调用；其五层叠加/偏差联动形态已被
    用户三次打回，保留代码待清理。
    reports（F4 可选）= list[CaseReport]：h2 来源徽章 + notes 数据驱动 +
    meta 推导；无 dump 产物卡（L1 批量）以占位框显式标注，不 crash。
    """
    names = report_names(scope, cases)
    tag_zh = " / ".join(src for src, _ in cases)
    today = date.today().strftime("%Y-%m-%d")
    rep_by_qid = {r["qid"]: r for r in reports} if reports else {}
    P = [f'<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
         f'<title>{scope} {tag_zh} 可视化检查报告（真值线框版）</title>'
         f'<style>{CSS}</style></head><body><div class="wrap">']
    P.append(f'<h1>{scope} {tag_zh} 可视化检查报告 '
             '<span style="font-size:13px;color:#0a59f7">· 真值线框版</span></h1>')
    if rep_by_qid:
        meta_line = _reports_meta_line(reports)
    else:
        meta_line = ('检测通道：Python 确定性核心（真值 DESIGN.md / DESIGN-2x4.md）· '
                     '生成：scripts/check_case.py / report_b_eval.py')
    P.append('<div class="meta"><span class="tag">现网实拍</span>'
             f'<span class="tag">dumpLayout 实测线框（{today} 逐卡实采/复用）</span>'
             '<span class="tag">L1 + L2a/L2b + 槽位归区 AREA 检测（NEW）</span><br>'
             f'{meta_line} · '
             f'问题清单：<a href="{names[0]}">{names[0]}</a></div>')
    for src, qid in cases:
        d = data[src]
        s = d["summary"]
        rep = rep_by_qid.get(qid)
        badges = f" {source_badge_html(rep)}" if rep else ""
        P.append(f'<h2>{_case_label(scope, src)} · findings {s["total"]}（P0={s["p0"]} / P1={s["p1"]} / P2={s["p2"]}）{badges}</h2>')
        dump_path = REVIEW / "dumps" / f"{qid}.layout.json"
        if layout == "dual":
            shot = REVIEW / "vis-assets" / f"{qid}.png"
            if shot.is_file():
                shot_html = (f'<div class="cap">① 现网真机实拍</div>'
                             f'<img src="../vis-assets/{qid}.png" alt="{qid} 现网实拍">')
            else:
                shot_html = ('<div class="cap">① 现网真机实拍</div>'
                             '<div style="border:1px dashed #c9ced6;border-radius:8px;padding:34px 10px;'
                             'color:#999;font-size:12px;text-align:center">无现网实拍（'
                             f'{qid} 非评测分支采集或截图未复制到 review/vis-assets/）</div>')
            if dump_path.is_file():
                wf_html = wireframe_svg(dump_path)
                wf_link = (f'<div class="wf-link">完整对照（裁卡实拍 + 声明↔实测表）：'
                           f'<a href="../{qid}_wireframe/index.html">{qid}_wireframe/index.html</a></div>')
            else:
                wf_html = ('<div style="border:1px dashed #c9ced6;border-radius:8px;padding:34px 10px;'
                           'color:#999;font-size:12px;text-align:center">无 dump 实测线框（'
                           f'{qid} 仅 L1 声明检查，dump 未采集——F2 落地后由入口层保证补采）</div>')
                wf_link = ""
            P.append('<div class="card-row">'
                     f'<div class="panel">{shot_html}</div>'
                     '<div class="panel"><div class="cap">② dumpLayout 实测线框（vp，标签为组件 id / 文字前缀）</div>'
                     + wf_html + wf_link + '</div></div>')
        else:
            P.append('<div class="card-row">'
                     f'<div class="panel"><div class="cap">双视口（现网真机实拍 | '
                     f'dumpLayout 线框；标准模板开关默认关）</div>{_stage_panel(scope, src, qid, d)}'
                     + (f'<div class="wf-link">完整对照（裁卡实拍 + 声明↔实测表）：'
                        f'<a href="../{qid}_wireframe/index.html">{qid}_wireframe/index.html</a></div>'
                        if dump_path.is_file() else "") +
                     '</div></div>')
        P.append(notes_flag_html(_notes_for(qid, rep)))
        P.append(findings_rows(d["findings"], with_fix=False))
    if layout != "dual":
        P.append('<script>'
                 'function tg(id,cls,on){var el=document.getElementById(id);if(el)el.classList.toggle(cls,on);}'
                 '</script>')
    P.append('<div class="note">采集：<code>render_eval_dump.py</code>（转换→构建→安装→启动→截图→dumpLayout，逐卡重建）；'
             '线框为本页内联 SVG（实测 bounds，vp 坐标）。STRUCT.TEXT_OVERFLOW 已按 owner 决策移出本轮检出范围。'
             '全部产物可覆盖重生成；最终通过与否由人类设计师确认。</div>')
    P.append("</div></body></html>")
    return "\n".join(P)


def generate_reports(scope: str, cases: list[tuple[str, str]],
                     data: dict, reports: list | None = None) -> tuple[Path, Path]:
    """按 scope + cases 生成双报告，返回 (problem_list_json_path, visual_path)。

    产物名/互链/href 全部由 cases 推导（AGENTS.md 命名规范，日期动态取当日）；
    2026-08-24 起带日期报告写入 review/<YYYYMMDD>/（daily_review_dir），
    同日重生成覆盖，跨日自然成版本；dumps/vis-assets/wireframe 维持 review 根原位。
    reports（F4 可选）= list[CaseReport]：提供时命名走 derive_report_names（单一
    来源 ≤8 卡与旧口径逐一相同）、模板挂徽章/notes/meta 推导。
    """
    if reports:
        # 混合来源不把首卡 scope 当范围段（derive 默认 MIX）；单一来源时
        # labels[0] == scope，命名与旧口径逐一相同
        names = derive_report_names(reports)
        labels = list(dict.fromkeys(
            (r.get("source") or {}).get("label") or r["qid"].split("-")[0] for r in reports))
        if len(labels) > 1:
            # 混合：h2 标签用完整 qid（保留分支前缀），scope 显示 MIX，
            # data 键同步从卡号段重映射到 qid
            scope = "MIX"
            data = {qid: data[src] for src, qid in cases}
            cases = [(qid, qid) for _, qid in cases]
        builders = (build_problem_list, build_visual)
    else:
        names = report_names(scope, cases)
        builders = (build_problem_list, build_visual)
    outputs = tuple(
        (name, builder(scope, cases, data, reports=reports))
        for name, builder in zip(names, builders)
    )
    out_dir = daily_review_dir()
    paths = []
    for name, body in outputs:
        out = out_dir / name
        out.write_text(body, encoding="utf-8")
        if name.endswith(".json"):  # 机器友好产物落盘自检：坏 JSON 立即失败
            json.loads(out.read_text(encoding="utf-8"))
        print("生成:", out, out.stat().st_size, "bytes")
        paths.append(out)
    return (paths[0], paths[1])


def build_from_cases(cases: list, layout: str = "dual",
                     scope_label: str | None = None) -> tuple[str, str]:
    """F4 新入口：list[CaseReport] → (problem_list_json, visual_html)。

    CaseReport = case_store.load_case_report 返回对象（review/cases/<qid>.json 产物）。
    映射到旧三元组 (scope, cases[(src, qid)], data)：src=qid（保留前缀），
    scope=单一来源 label / 混合默认 MIX（scope_label 可覆盖）。
    """
    labels: list = []
    for r in cases:
        lb = (r.get("source") or {}).get("label") or r["qid"].split("-")[0]
        if lb not in labels:
            labels.append(lb)
    scope = scope_label or (labels[0] if len(labels) == 1 else "MIX")
    # 单一来源且 qid 带该前缀 → src 取卡号段（h2 标签 B-q1，与旧口径一致）；
    # 混合来源 → src=qid 保留分支前缀（h2 标签 MIX-A-q42，与 merged 旧口径一致）
    single = len(labels) == 1 and all(r["qid"].startswith(f"{labels[0]}-") for r in cases)
    legacy_cases = [((r["qid"].split("-", 1)[1] if single else r["qid"]), r["qid"])
                    for r in cases]
    data = {src: {"summary": r.get("summary") or {"total": 0, "p0": 0, "p1": 0, "p2": 0},
                  "findings": r.get("findings") or []}
            for (src, _), r in zip(legacy_cases, cases)}
    # 产物名：调用方需要时用 derive_report_names(cases, scope_label)
    names = derive_report_names(cases, scope_label=scope_label)
    p = build_problem_list(scope, legacy_cases, data, reports=cases)
    v = build_visual(scope, legacy_cases, data, layout=layout, reports=cases)
    return p, v


def generate_reports_from_cases(cases: list, layout: str = "dual",
                                scope_label: str | None = None) -> tuple[Path, Path]:
    """F4 新入口（落盘版）：CaseReport 列表 → 双报告写入 review/<YYYYMMDD>/。"""
    scope = scope_label or (lambda lbs: lbs[0] if len(lbs) == 1 else "MIX")(
        [lb for lb in dict.fromkeys(
            (r.get("source") or {}).get("label") or r["qid"].split("-")[0] for r in cases)])
    p_html, v_html = build_from_cases(cases, layout=layout, scope_label=scope_label)
    out_dir = daily_review_dir()
    names = derive_report_names(cases, scope_label=scope_label)
    paths = []
    for name, body in zip(names, (p_html, v_html)):
        out = out_dir / name
        out.write_text(body, encoding="utf-8")
        print("生成:", out, out.stat().st_size, "bytes")
        paths.append(out)
    return (paths[0], paths[1])


def main() -> int:
    """零参 CLI：保持 B-q1q4q7 既有行为与文件名不变（今日日期）。"""
    scope = DEFAULT_SCOPE
    data = {src: get_json(f"{BRANCH}/{src}.jsonl", f"review/dumps/{qid}.layout.json") for src, qid in CARDS}
    generate_reports(scope, CARDS, data)
    # 清理规范前旧名产物（派生输出，可覆盖重生成）
    for legacy in ("b-q1q4q7-problem-list.html", "b-q1q4q7-visual-report.html"):
        old = REVIEW / legacy
        if old.exists():
            old.unlink()
            print("清理旧名:", old)
    for src, _ in CARDS:
        s = data[src]["summary"]
        print(f"  {scope}-{src}: {s['total']} (P0={s['p0']} P1={s['p1']} P2={s['p2']})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
