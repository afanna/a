#!/usr/bin/env python3
"""生成单卡可视化检查报告（自包含 HTML，内嵌卡片 SVG 示意图 + 分级 findings）。

说明：
- 本报告不依赖真机/模拟器/hdc，而是根据 DSL 声明的布局在 SVG 里做一张「示意渲染」，
  用于把卡片结构和检查结论放在一起可视化，方便审阅。
- 若需要「真机截图」级可视化，请走 render_dump.py（需 hdc + 模拟器）→ wireframe.py 的线框页。

用法：
    python3 scripts/report_html.py --dsl <卡片.jsonl> --out <报告.html>
    python3 scripts/report_html.py --qdir q010 --format json --out review/q010_report.html

输出：自包含 HTML（含内联 SVG + findings + 严重度配色）。
"""
from __future__ import annotations

import argparse
import html
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from validators.config import card_data_dir, daily_review_dir, design_spec_path  # noqa: E402
from validators.design_contract import attach_card_size_contracts, load_design_contract  # noqa: E402
from validators.dsl import GenuiCard, load_case, load_genui  # noqa: E402
from validators.rules import run_l1  # noqa: E402

SEV_COLOR = {"P0": "#d33", "P1": "#e77a1f", "P2": "#8a8a8a"}


def load_card(args) -> GenuiCard:
    if args.dir:
        return load_case(Path(args.dir))
    if args.dsl:
        p = Path(args.dsl)
        card = load_genui(p, p.stem)
        card.query_text = ""
        card.task_spec = {}
        return card
    return load_case(card_data_dir() / args.qdir)


# ---------- 简易布局引擎：把 DSL 组件树铺成绝对坐标（用于 SVG 示意） ----------
def escape(v):
    return html.escape(str(v if v is not None else ""))


def _attr_numeric(attrs, key, default):
    v = attrs.get(key)
    if isinstance(v, (int, float)):
        return float(v)
    return default


def _parse_hex(hexstr):
    if not isinstance(hexstr, str):
        return (0, 0, 0, 255)
    h = hexstr.lstrip("#")
    if len(h) == 6:
        h = "FF" + h  # #RRGGBB -> #AARRGGBB
    if len(h) != 8:
        return (0, 0, 0, 255)
    try:
        a, r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4, 6))
    except ValueError:
        return (0, 0, 0, 255)
    return (r, g, b, a)


def _hex_to_rgba_css(hexstr):
    r, g, b, a = _parse_hex(hexstr)
    return f"rgba({r},{g},{b},{a / 255:.2f})"


def _layout(card: GenuiCard):
    """返回 {id: (x, y, w, h)} 及根尺寸，按声明做简单 Column/Row/Stack 铺排。"""
    comps = {c.get("id"): c for c in card.iter_components() if c.get("id")}
    root = comps.get("root")
    if root is None and comps:
        root = next(iter(comps.values()))
    if root is None:
        return {}, (320, 160)

    def get_child_ids(c):
        return [x for x in (c.get("children") or []) if isinstance(x, str)]

    def declare_box(cid, x, y, w, h):
        boxes[cid] = (x, y, w, h)

    boxes: dict = {}

    def place(cid, x, y, avail_w, avail_h, depth=0):
        c = comps.get(cid)
        if c is None:
            return
        st = c.get("styles") or {}
        ctype = c.get("component")
        pad = _attr_numeric(st, "padding", 0)
        margin = _attr_numeric(st, "itemMargin", 0)
        w = _attr_numeric(st, "width", avail_w)
        if w == 0:
            w = avail_w
        h = _attr_numeric(st, "height", 0)
        if h == 0 and ctype not in ("Column", "Row", "Stack"):
            h = _attr_numeric(st, "fontSize", 16) + 4
        if ctype in ("Column", "Row", "Stack") and h == 0:
            h = avail_h
        # matchParent 处理
        if isinstance(st.get("width"), str):
            if st["width"] == "matchParent":
                w = avail_w
        if isinstance(st.get("height"), str):
            if st["height"] == "matchParent":
                h = avail_h
        declare_box(cid, x, y, w, h)
        kids = get_child_ids(c)
        if not kids:
            return
        inner_x = x + pad
        inner_y = y + pad
        inner_w = w - 2 * pad
        inner_h = h - 2 * pad
        if ctype == "Row":
            cx = inner_x
            for k in kids:
                kc = comps.get(k, {})
                kst = kc.get("styles") or {}
                kw = _attr_numeric(kst, "width", 0) or inner_w / max(len(kids), 1)
                kh = _attr_numeric(kst, "height", 0) or inner_h
                place(k, cx, inner_y, kw, kh, depth + 1)
                cx += kw + margin
        elif ctype == "Column":
            cy = inner_y
            for k in kids:
                kc = comps.get(k, {})
                kst = kc.get("styles") or {}
                kw = _attr_numeric(kst, "width", 0) or inner_w
                kh = _attr_numeric(kst, "height", 0) or 0
                if _attr_numeric(kst, "height", 0) == 0 and kc.get("component") in ("Column", "Row", "Stack"):
                    # 具声明 height 的容器子组件除外；无 height 容器按内容，这里给剩余高度
                    kh = inner_h - cy + inner_y
                place(k, inner_x, cy, kw, kh, depth + 1)
                cy += max(kh, 0) + margin
        else:  # Stack → 叠放
            for k in kids:
                kst = (comps.get(k, {}) or {}).get("styles") or {}
                kw = _attr_numeric(kst, "width", 0) or inner_w
                kh = _attr_numeric(kst, "height", 0) or inner_h
                place(k, inner_x + (inner_w - kw) / 2, inner_y + (inner_h - kh) / 2, kw, kh, depth + 1)

    root_st = root.get("styles") or {}
    root_w = _attr_numeric(root_st, "width", 320) or 320
    root_h = _attr_numeric(root_st, "height", 160) or 160
    place(root.get("id"), 0, 0, root_w, root_h)
    return boxes, (root_w, root_h)


def _svg(card: GenuiCard, boxes, root_w, root_h):
    comps = {c.get("id"): c for c in card.iter_components() if c.get("id")}
    root = comps.get("root") or (next(iter(comps.values())) if comps else None)
    root_st = (root.get("styles") if root else {}) or {}
    parts = []
    # 根表现：圆角 + 背景渐变
    radius = _attr_numeric(root_st, "borderRadius", 0)
    bg = root_st.get("backgroundColor")
    grad = root_st.get("linearGradient")
    fill = ""
    if grad and isinstance(grad, dict):
        colors = grad.get("colors") or []
        stops = " ".join(
            f'<stop offset="{p * 100:.0f}%" stop-color="{_hex_to_rgba_css(c)}"/>'
            for c, p in colors if isinstance(c, str) and isinstance(p, (int, float))
        )
        if stops:
            fill = f"<defs><linearGradient id=\"rootgrad\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0\">{stops}</linearGradient></defs>"
    root_fill = "url(#rootgrad)" if (grad and isinstance(grad, dict) and grad.get("colors")) else (_hex_to_rgba_css(bg) if bg else "#ffffff")
    parts.append(fill)
    parts.append(
        f'<rect x="0" y="0" width="{root_w}" height="{root_h}" rx="{radius}" '
        f'fill="{root_fill}" stroke="#bbb" stroke-width="1"/>'
    )
    # 组件盒
    for cid, (x, y, w, h) in boxes.items():
        if cid == (root.get("id") if root else None):
            continue
        c = comps.get(cid, {})
        st = c.get("styles") or {}
        ctype = c.get("component")
        fc = _hex_to_rgba_css(st["fontColor"]) if "fontColor" in st else "#333"
        content = c.get("content", "")
        parts.append(
            f'<rect x="{x}" y="{y}" width="{max(w, 4)}" height="{max(h, 4)}" rx="4" '
            f'fill="none" stroke="#4a90d9" stroke-width="1" stroke-dasharray="3,2"/>'
        )
        # 标签超长组件 id（cardgenerated_<hash>_<语义名>）截尾保留语义段，避免线框内标签叠字
        cid_short = cid if len(cid) <= 18 else "…" + cid[-17:]
        label = f"{cid_short} · {ctype}"
        parts.append(
            f'<text x="{x + 2}" y="{y + 9}" font-size="7" fill="#4a90d9">{escape(label)}</text>'
        )
        if content:
            parts.append(
                f'<text x="{x + 2}" y="{y + h - 4}" font-size="7" fill="{fc}" '
                f'transform="translate(0,0)">{escape(str(content)[:20])}</text>'
            )
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {root_w} {root_h}" width="100%" '
        f'style="max-width:{root_w * 2}px;border:1px solid #eee;border-radius:{radius}px;background:#fff">'
        + "\n".join(parts) + "</svg>"
    )


def _finding_block(f):
    sev = f["severity"]
    layer = f.get("layer")
    rid = f["rule_id"]
    el = (f.get("element") or {}).get("dsl_id")
    loc = f" <code>@{escape(el)}</code>" if el else ""
    fix = f"<div class='fix'>fix: {escape(f.get('fix_hint',''))}</div>" if f.get("fix_hint") else ""
    return (
        f"<div class='finding s{sev}'>"
        f"<b>[{escape(layer)}] {sev} {escape(rid)}</b>{loc}<br>"
        f"<span class='muted'>{escape(f.get('message',''))}</span>{fix}</div>"
    )


def build_html(card, findings, report_summary, dsl_preview) -> str:
    boxes, (rw, rh) = _layout(card)
    svg = _svg(card, boxes, rw, rh)
    sev = report_summary
    fs = [f.to_dict() for f in findings]  # Finding → dict
    finding_html = "\n".join(_finding_block(f) for f in sorted(
        fs, key=lambda f: ({"P0": 0, "P1": 1, "P2": 2}.get(f["severity"], 9), f.get("layer"), f["rule_id"])))
    return """<!doctype html>
<html lang="zh"><head><meta charset="utf-8"><title>Design Check 可视化报告 · {qid}</title>
<style>
body{{font-family:-apple-system,BlinkMacSystemFont,sans-serif;margin:0;background:#f5f6f8;color:#222}}
.wrap{{max-width:960px;margin:0 auto;padding:28px 20px}}
h1{{font-size:20px}} .muted{{color:#666}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-top:16px}}
@media(max-width:760px){{.grid{{grid-template-columns:1fr}}}}
.panel{{background:#fff;border:1px solid #e3e5e8;border-radius:12px;padding:16px}}
.panel h2{{font-size:15px;margin-top:0}}
.badge{{padding:2px 9px;border-radius:10px;color:#fff;font-size:12px;font-weight:600}}
.bP0{{background:#d33}}.bP1{{background:#e77a1f}}.bP2{{background:#8a8a8a}}
.summary{{display:flex;gap:10px;margin:10px 0}}
.summary .cell{{background:#fff;border:1px solid #e3e5e8;border-radius:10px;padding:8px 12px;text-align:center}}
.summary .num{{font-size:22px;font-weight:700}}
.finding{{border-left:4px solid #ccc;padding:6px 10px;margin:8px 0;font-size:13px;border-radius:4px;background:#fafafa}}
.sP0{{border-color:#d33}}.sP1{{border-color:#e77a1f}}.sP2{{border-color:#8a8a8a}}
.fix{{color:#1a7f37;font-size:12px;margin-top:2px}}
pre{{background:#fafafa;border:1px solid #eee;border-radius:8px;padding:10px;font-size:11px;overflow:auto;max-height:220px;white-space:pre-wrap;word-break:break-all}}
.note{{font-size:12px;color:#888;margin-top:8px}}
</style></head><body><div class="wrap">
<h1>🃏 {qid} · Design Check 可视化报告</h1>
<div class="muted">真值：DESIGN.md · 生成：自包含 HTML（内嵌卡片 SVG 示意图，无需真机）。</div>
<div class="summary">
 <div class="cell"><div class="num">{sev_total}</div><div class="muted">问题</div></div>
 <div class="cell"><div class="num" style="color:#d33">{sev_p0}</div><div class="muted">P0</div></div>
 <div class="cell"><div class="num" style="color:#e77a1f">{sev_p1}</div><div class="muted">P1</div></div>
 <div class="cell"><div class="num" style="color:#8a8a8a">{sev_p2}</div><div class="muted">P2</div></div>
</div>
<div class="grid">
  <div class="panel"><h2>卡片渲染（示意）</h2>{svg}
    <div class="note">说明：SVG 为按 DSL 声明的布局示意图，非真机截图；标色/尺寸来自声明值。</div>
  </div>
  <div class="panel"><h2>检查结论（分级）</h2>{finding_html}</div>
</div>
<div class="panel" style="margin-top:24px"><h2>原始 DSL</h2><pre>{dsl_preview}</pre></div>
</div></body></html>""".format(qid=escape(card.case_id),
                                     sev_total=sev["total"], sev_p0=sev["p0"], sev_p1=sev["p1"], sev_p2=sev["p2"],
                                     finding_html=finding_html, svg=svg, dsl_preview=escape(dsl_preview))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="生成单卡可视化检查报告（自包含 HTML）")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--qdir", help="数据集内 case id")
    g.add_argument("--dir", help="三件套目录")
    g.add_argument("--dsl", help="裸 DSL jsonl")
    ap.add_argument("--out", type=Path, default=None, help="输出 html 路径")
    args = ap.parse_args(argv)

    card = load_card(args)
    dsl_preview = ""
    if args.dsl:
        dsl_preview = Path(args.dsl).read_text(encoding="utf-8-sig")
    contract = load_design_contract(design_spec_path())
    attach_card_size_contracts(contract, card)  # Idea2-WP-B 注入收口
    findings = run_l1(card, contract, card.query_text)
    out = {
        "qid": card.case_id,
        "findings": [f.to_dict() for f in findings],
        "summary": {
            "total": len(findings),
            "p0": sum(1 for f in findings if f.severity == "P0"),
            "p1": sum(1 for f in findings if f.severity == "P1"),
            "p2": sum(1 for f in findings if f.severity == "P2"),
        },
    }
    # 默认输出 review/<生成日期YYYYMMDD>/<case_id>_report.html（AGENTS.md 2026-08-24 起
    # 带日期报告落日目录；--out 显式传参时尊重用户路径）
    dest = args.out or (daily_review_dir() / f"{card.case_id}_report.html")
    html_text = build_html(card, findings, out["summary"], dsl_preview)
    dest.write_text(html_text, encoding="utf-8")
    print(f"已生成可视化报告: {dest.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
