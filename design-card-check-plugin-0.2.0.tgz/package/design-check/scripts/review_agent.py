#!/usr/bin/env python3
"""L3 语义评审编排（Phase 4 起步骨架）。

当前为占位实现：无外部依赖、不调用模型。仅做：
- 读取 ``prompts/semantic-review.md`` 模板；
- 汇总给定 case 的 query + task-spec + L1 诊断为待评审上下文；
- 把待评审任务写到 ``review/l3/<qid>.task.json``，供后续接 dsh/Python SDK 或直调多模态 API。

用法：
    python3 scripts/review_agent.py --cases q010 --dry-run
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from validators.config import prompts_dir, review_dir  # noqa: E402
from validators.dataset import load_manifest  # noqa: E402
from validators.dsl import load_case  # noqa: E402


def _load_prompt(name: str) -> str:
    p = prompts_dir() / name
    return p.read_text(encoding="utf-8") if p.exists() else ""


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="L3 语义评审编排（骨架）")
    parser.add_argument("--cases", required=True, help="逗号分隔 case 白名单")
    parser.add_argument("--dry-run", action="store_true", help="只生成任务不执行模型")
    args = parser.parse_args(argv)

    manifest = load_manifest()
    wanted = set(args.cases.split(","))
    missing = sorted(wanted - {e.case_id for e in manifest.entries})
    if missing:
        print(f"错误: 未知 case {', '.join(missing)}", file=sys.stderr)
        return 2

    semantic_prompt = _load_prompt("semantic-review.md")
    visual_prompt = _load_prompt("visual-review.md")
    if not semantic_prompt:
        print("提示: prompts/semantic-review.md 尚未填写正文（当前为占位）", file=sys.stderr)

    out_dir = review_dir() / "l3"
    out_dir.mkdir(parents=True, exist_ok=True)
    for entry in manifest.entries:
        if entry.case_id not in wanted:
            continue
        card = load_case(entry.query_path.parent)
        task = {
            "case_id": entry.case_id,
            "query": card.query_text,
            "size": card.size,
            "task_spec": card.task_spec,
            "dsl": {
                "createSurface": card.create_surface,
                "updateComponents": card.update_components,
                "updateDataModel": card.update_data_model,
            },
            "prompts": {
                "semantic_review": semantic_prompt,
                "visual_review": visual_prompt,
            },
        }
        target = out_dir / f"{entry.case_id}.task.json"
        target.write_text(json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"  生成任务 {target}")
    if args.dry_run:
        print("--dry-run：仅生成任务，未调用模型评审")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
