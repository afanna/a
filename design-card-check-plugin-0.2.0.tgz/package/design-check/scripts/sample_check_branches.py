#!/usr/bin/env python3
"""四分支抽检大报告：每条技术路线随机抽 N 卡 → L1 全规则 → 单文件 problem-list HTML。

用法:
    python3 scripts/sample_check_branches.py [--per-branch 3] [--seed 20260824]

依据: AGENTS.md「第一次评测/ 四分支（A 一步走 / B 现网 / C 模板 / MS 多步走）」；
检测层与 check_batch --eval-dir 模式一致（裸 DSL，L1 全规则含 semantic），
抽样用固定 seed 保证可重复、可比较（先例：2026-08-22 四分支 40 卡抽检 seed=20260822）。
产物命名: EVAL299-problem-list-<YYYYMMDD>.html + EVAL299-visual-<YYYYMMDD>.html
（daily_review_dir 落位，同日覆盖）。
visual 图源 = 评测集现网实拍（复制 review/vis-assets/）+ DSL 声明线框（report_html
_layout/_svg 复用）；本轮无真机渲染，无 dump 实测线框，面板标注声明口径。
"""
from __future__ import annotations

import argparse
import random
import shutil
import sys
from collections import Counter, defaultdict
from datetime import datetime
from html import escape
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_DIR))

from validators.config import daily_review_dir, eval_root, review_dir  # noqa: E402
from validators.design_contract import attach_card_size_contracts, load_design_contract  # noqa: E402
from validators.dsl import CardParseError  # noqa: E402
from validators.eval_loader import load_eval, load_eval_card  # noqa: E402
from validators.finding import sort_findings  # noqa: E402
from validators.rules import run_l1  # noqa: E402

from report_html import _layout, _svg  # noqa: E402

BRANCH_TITLES = {
    "A": "A · 一步走",
    "B": "B · 现网",
    "C": "C · 模板",
    "MS": "MS · 多步走",
}
SEV_ORDER = ("P0", "P1", "P2")
SEV_BADGE = {"P0": "#e8402a", "P1": "#e67e22", "P2": "#7f8c99"}


def pick_samples(entries, per_branch: int, seed: int) -> dict:
    """按分支分组后固定 seed 随机抽样，返回 {branch: [EvalEntry]}（分支内按 case_id 排序）。"""
    groups = defaultdict(list)
    for e in entries:
        groups[e.branch].append(e)
    rng = random.Random(seed)
    picked = {}
    for branch in sorted(groups):
        pool = sorted(groups[branch], key=lambda e: e.case_id)
        picked[branch] = sorted(rng.sample(pool, min(per_branch, len(pool))),
                                key=lambda e: e.case_id)
    return picked


def run_sample(picked: dict, contract: dict) -> dict:
    """逐卡 L1 检测（含 semantic），返回 {branch: [(entry, [Finding.to_dict()])]}。"""
    results = defaultdict(list)
    for branch, entries in picked.items():
        for entry in entries:
            try:
                card = load_eval_card(entry)
            except CardParseError as exc:
                print(f"  [skip] {entry.case_id}: {exc}", file=sys.stderr)
                results[branch].append((entry, {"error": str(exc), "findings": []}))
                continue
            attach_card_size_contracts(contract, card)  # Idea2-WP-B 注入收口
            findings = sort_findings(run_l1(card, contract, entry.query_text,
                                            include_semantic=True))
            results[branch].append((entry, {"findings": [f.to_dict() for f in findings]}))
    return results


def build_html(results: dict, picked: dict, seed: int, per_branch: int) -> str:
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    date_tag = datetime.now().strftime("%Y%m%d")
    n_cases = sum(len(v) for v in results.values())
    flat = []
    for branch, cards in results.items():
        for entry, r in cards:
            for f in r.get("findings", []):
                flat.append((branch, entry.case_id, f))

    sev_total = Counter(f[2]["severity"] for f in flat)
    rule_branch = defaultdict(lambda: defaultdict(int))  # rule -> branch -> count
    rule_sev = defaultdict(Counter)                     # rule -> severity -> count
    branch_stat = defaultdict(lambda: Counter())        # branch -> severity -> count
    branch_total = Counter()
    for branch, _, f in flat:
        rule_branch[f["rule_id"]][branch] += 1
        rule_sev[f["rule_id"]][f["severity"]] += 1
        branch_stat[branch][f["severity"]] += 1
        branch_total[branch] += 1

    css = """
    body{font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;margin:0;background:#f4f6f9;color:#1c2430}
    .wrap{max-width:1180px;margin:0 auto;padding:26px 20px 70px}
    h1{font-size:21px;margin:0 0 4px} .sub{color:#5a6a7f;font-size:12.5px;margin-bottom:18px}
    .panel{background:#fff;border:1px solid #e0e2e6;border-radius:12px;padding:16px 18px;margin-bottom:18px;box-shadow:0 1px 3px rgba(0,0,0,.05)}
    .cap{font-size:13px;font-weight:600;margin-bottom:10px;color:#243244}
    table{border-collapse:collapse;width:100%;background:#fff;font-size:12.5px;border-radius:8px;overflow:hidden}
    th{background:#f2f5f9;text-align:left;padding:7px 10px;border-bottom:1px solid #e0e4ea;white-space:nowrap}
    td{padding:6px 10px;border-bottom:1px solid #eef1f5;vertical-align:top}
    tr:hover td{background:#f7faff}
    .badge{display:inline-block;min-width:26px;text-align:center;color:#fff;font-size:11px;border-radius:9px;padding:1px 7px}
    .b0{background:#e8402a}.b1{background:#e67e22}.b2{background:#7f8c99}
    .zero{color:#b8c2cf}
    .card-h{font-size:14px;font-weight:700;margin:22px 0 8px;padding-top:10px;border-top:1px dashed #d7dee8}
    .card-h .cnt{font-weight:500;color:#5a6a7f;font-size:12px}
    code{background:#f2f5f9;border-radius:4px;padding:1px 5px;font-size:11.5px}
    .ptr{font-family:ui-monospace,Menlo,monospace;font-size:11px;color:#48586c;word-break:break-all}
    .note{font-size:12px;color:#5a6a7f;margin:8px 0 0}
    """

    def sev_badge(s: str) -> str:
        return f'<span class="badge b{int(s[1])}">{s}</span>'

    rows_total = []
    for branch in sorted(branch_stat) or sorted(results):
        c = branch_stat[branch]
        rows_total.append(
            f"<tr><td><b>{escape(BRANCH_TITLES.get(branch, branch))}</b>（{len(results[branch])} 卡）</td>"
            f"<td>{branch_total[branch]}</td>"
            + "".join(f'<td>{c.get(s, 0) or "<span class=zero>0</span>"}</td>' for s in SEV_ORDER)
            + "</tr>")
    rows_total.append(
        f"<tr style='font-weight:700'><td>合计（{n_cases} 卡）</td><td>{len(flat)}</td>"
        + "".join(f"<td>{sev_total.get(s, 0)}</td>" for s in SEV_ORDER) + "</tr>")

    matrix_rows = []
    for rule in sorted(rule_branch, key=lambda r: (-sum(rule_branch[r].values()), r)):
        cells = "".join(
            f'<td>{rule_branch[rule].get(b, 0) or "<span class=zero>·</span>"}</td>'
            for b in sorted(results))
        sevs = "".join(f'<span class="badge b{int(s[1])}">{n}</span> '
                       for s, n in sorted(rule_sev[rule].items()))
        matrix_rows.append(f"<tr><td><code>{escape(rule)}</code></td>{cells}<td>{sevs}</td></tr>")
    matrix_head = "".join(f"<th>{escape(BRANCH_TITLES.get(b, b))}</th>" for b in sorted(results))

    detail = []
    for branch in sorted(results):
        for entry, r in results[branch]:
            fs = r.get("findings", [])
            if r.get("error"):
                detail.append(f'<div class="card-h">{escape(entry.case_id)} '
                              f'<span class="cnt">解析失败：{escape(r["error"])}</span></div>')
                continue
            detail.append(
                f'<div class="card-h">{escape(entry.case_id)} '
                f'<span class="cnt">{len(fs)} 条'
                f'（P0={sum(1 for f in fs if f["severity"] == "P0")}'
                f' / P1={sum(1 for f in fs if f["severity"] == "P1")}'
                f' / P2={sum(1 for f in fs if f["severity"] == "P2")}）</span></div>')
            if not fs:
                detail.append('<table><tr><td class="zero">无 findings</td></tr></table>')
                continue
            body_rows = []
            for f in fs:
                ptr = (f.get("element") or {}).get("json_pointer") or ""
                body_rows.append(
                    f"<tr><td>{sev_badge(f['severity'])}</td>"
                    f"<td><code>{escape(f['rule_id'])}</code><br>"
                    f"<span style='color:#7f8c99;font-size:11px'>{escape(f['layer'])} · {escape(f['evidence_type'])}</span></td>"
                    f"<td>{escape(f.get('message') or '')}"
                    + (f"<br><span class='ptr'>{escape(ptr)}</span>" if ptr else "")
                    + (f"<br><span style='color:#9aa5b1;font-size:11px'>建议：{escape(f.get('fix_hint') or '')}</span>"
                       if f.get("fix_hint") else "") + "</td></tr>")
            detail.append("<table><tr><th>等级</th><th>规则</th><th>问题与证据（json_pointer）</th></tr>"
                          + "".join(body_rows) + "</table>")

    sample_note = "；".join(
        f"{escape(BRANCH_TITLES.get(b, b))}：{'、'.join(e.case_id for e in picked[b])}"
        for b in sorted(picked)) if picked else ""

    return f"""<!doctype html>
<html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EVAL299 四分支抽检问题清单 {date_tag}</title><style>{css}</style></head>
<body><div class="wrap">
<h1>EVAL299 四分支抽检问题清单</h1>
<div class="sub">生成 {today} · 检测层 L1（DSL 声明 + semantic，裸 DSL 无 task-spec） ·
机器检测+定位+建议，最终通过与否由人类设计师确认</div>

<div class="panel"><div class="cap">抽样口径</div>
每条技术路线随机抽 {per_branch} 卡，固定 seed={seed}（可复现：random.Random({seed}).sample，分支内按 case_id 排序后抽样）。<br>
{sample_note}
<div class="note">复现命令：python3 scripts/sample_check_branches.py --per-branch {per_branch} --seed {seed}</div></div>

<div class="panel"><div class="cap">总览（分支 × 等级）</div>
<table><tr><th>分支</th><th>findings</th><th>P0</th><th>P1</th><th>P2</th></tr>{''.join(rows_total)}</table></div>

<div class="panel"><div class="cap">规则 × 分支分布矩阵</div>
<table><tr><th>规则</th>{matrix_head}<th>等级构成</th></tr>{''.join(matrix_rows)}</table></div>

<div class="panel"><div class="cap">逐卡问题明细（{n_cases} 卡）</div>{''.join(detail)}</div>

</div></body></html>"""


def copy_shots(picked: dict) -> dict:
    """评测集现网实拍 images/<stem>.{png,jpg,jpeg} → review/vis-assets/<case_id>.<ext>。

    返回 {case_id: 相对报告的 src 路径}（无实拍的卡不在结果里，报告显式标注）。
    """
    assets_dir = review_dir() / "vis-assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    srcs = {}
    for branch, entries in picked.items():
        for entry in entries:
            stem = entry.dsl_path.stem
            images = eval_root() / Path(entry.branch_dir).name / "images"
            for ext in ("png", "jpg", "jpeg"):
                cand = images / f"{stem}.{ext}"
                if cand.is_file():
                    dst = assets_dir / f"{entry.case_id}.{ext}"
                    shutil.copy2(cand, dst)
                    srcs[entry.case_id] = f"../vis-assets/{dst.name}"
                    break
    return srcs


def build_visual_html(results: dict, picked: dict, srcs: dict,
                      seed: int, per_branch: int) -> str:
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    date_tag = datetime.now().strftime("%Y%m%d")
    n_cases = sum(len(v) for v in results.values())

    css = """
    body{font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;margin:0;background:#f4f6f9;color:#1c2430}
    .wrap{max-width:1180px;margin:0 auto;padding:26px 20px 70px}
    h1{font-size:21px;margin:0 0 4px} .sub{color:#5a6a7f;font-size:12.5px;margin-bottom:18px}
    .card-row{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:14px}
    .panel{background:#fff;border:1px solid #e0e2e6;border-radius:12px;padding:14px 16px;box-shadow:0 1px 3px rgba(0,0,0,.05)}
    .cap{font-size:12.5px;font-weight:600;color:#243244;margin-bottom:8px}
    .panel img{max-width:100%;max-height:330px;border:1px solid #e0e2e6;border-radius:8px;display:block;margin:0 auto}
    .panel svg{width:100%;max-width:640px;display:block;margin:0 auto;border:1px solid #dfe2e7;border-radius:8px;background:#fff}
    .card-h{font-size:15px;font-weight:700;margin:26px 0 10px;padding-top:12px;border-top:1px dashed #d7dee8}
    .badge{display:inline-block;min-width:26px;text-align:center;color:#fff;font-size:11px;border-radius:9px;padding:1px 7px;margin-right:6px}
    .b0{background:#e8402a}.b1{background:#e67e22}.b2{background:#7f8c99}
    .brul{font-size:11.5px;color:#5a6a7f;margin-top:8px;line-height:1.7}
    .missing{font-size:12px;color:#b8c2cf;text-align:center;padding:40px 0}
    .note{font-size:12px;color:#5a6a7f;margin:8px 0 0}
    """

    sections = []
    for branch in sorted(results):
        for entry, r in results[branch]:
            fs = r.get("findings", [])
            sev = Counter(f["severity"] for f in fs)
            badges = "".join(f'<span class="badge b{int(s[1])}">{s}={sev.get(s, 0)}</span>'
                             for s in SEV_ORDER if sev.get(s))
            rules = Counter(f["rule_id"] for f in fs)
            rule_line = "、".join(f"<code>{escape(k)}</code>×{n}"
                                 for k, n in rules.most_common(6)) or "无 findings"
            shot = srcs.get(entry.case_id)
            shot_html = (f'<img src="{shot}" alt="{escape(entry.case_id)} 现网实拍">'
                         if shot else '<div class="missing">该卡无评测集现网实拍</div>')
            try:
                card = load_eval_card(entry)
                boxes, (rw, rh) = _layout(card)
                svg = _svg(card, boxes, rw, rh)
                svg_html = svg if isinstance(svg, str) else svg.getvalue()
            except Exception as exc:  # 线框失败不阻断整卡展示
                svg_html = f'<div class="missing">声明线框生成失败：{escape(repr(exc)[:120])}</div>'
            sections.append(
                f'<div class="card-h">{escape(entry.case_id)} {badges}</div>'
                f'<div class="card-row">'
                f'<div class="panel"><div class="cap">① 评测集现网实拍（images/）</div>{shot_html}'
                f'<div class="brul">规则 Top：{rule_line}</div></div>'
                f'<div class="panel"><div class="cap">② DSL 声明线框（本轮无 dump，声明口径非实测）</div>{svg_html}</div>'
                f'</div>')

    sample_note = "；".join(
        f"{escape(BRANCH_TITLES.get(b, b))}：{'、'.join(e.case_id for e in picked[b])}"
        for b in sorted(picked)) if picked else ""
    return f"""<!doctype html>
<html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EVAL299 四分支抽检可视化 {date_tag}</title><style>{css}</style></head>
<body><div class="wrap">
<h1>EVAL299 四分支抽检可视化报告</h1>
<div class="sub">生成 {today} · 与 EVAL299-problem-list-{date_tag}.html 同抽样口径 ·
机器检测+定位+建议，最终通过与否由人类设计师确认</div>

<div class="panel"><div class="cap">抽样口径与说明</div>
每条技术路线随机抽 {per_branch} 卡，固定 seed={seed}。{sample_note}<br>
① 实拍来自评测集 images/（拍摄时点为评测当时，非本轮渲染）；② 线框为 DSL 声明推演
（report_html 声明铺排），本轮 L1 抽检未做真机渲染，无 dump 实测线框对照。
<div class="note">复现命令：python3 scripts/sample_check_branches.py --per-branch {per_branch} --seed {seed}</div></div>

{''.join(sections)}
</div></body></html>"""


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="四分支抽检大报告（每分支随机 N 卡，L1 全规则）")
    parser.add_argument("--per-branch", type=int, default=3, help="每分支抽样卡数（默认 3）")
    parser.add_argument("--seed", type=int, default=20260824, help="抽样随机种子（默认 20260824）")
    args = parser.parse_args(argv)

    entries = load_eval(eval_root())
    picked = pick_samples(entries, args.per_branch, args.seed)
    for branch, es in sorted(picked.items()):
        print(f"[sample] {branch}: {'、'.join(e.case_id for e in es)}")

    contract = load_design_contract()
    results = run_sample(picked, contract)

    html = build_html(results, picked, args.seed, args.per_branch)
    out = daily_review_dir() / f"EVAL299-problem-list-{datetime.now().strftime('%Y%m%d')}.html"
    out.write_text(html, encoding="utf-8")
    print(f"生成: {out} {out.stat().st_size} bytes")

    srcs = copy_shots(picked)
    print(f"[visual] 实拍资产: {len(srcs)}/{sum(len(v) for v in picked.values())} 卡命中评测集 images/")
    vhtml = build_visual_html(results, picked, srcs, args.seed, args.per_branch)
    vout = daily_review_dir() / f"EVAL299-visual-{datetime.now().strftime('%Y%m%d')}.html"
    vout.write_text(vhtml, encoding="utf-8")
    print(f"生成: {vout} {vout.stat().st_size} bytes")

    total = sum(len(r.get("findings", [])) for cards in results.values() for _, r in cards)
    sev = Counter(f["severity"] for cards in results.values() for _, r in cards
                  for f in r.get("findings", []))
    print(f"findings 总数: {total}（P0={sev.get('P0', 0)} / P1={sev.get('P1', 0)} / P2={sev.get('P2', 0)}）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
