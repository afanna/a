#!/usr/bin/env python3
"""汇总器（M5）：把 unified findings 报告变为
- review/summary.md   Markdown 汇总
- review/index.html   三层画廊（可搜索/过滤）
- review/baseline.json 回归基线（供 diff）

用法：
    python3 scripts/check_batch.py --with-layout
    python3 scripts/summarize.py [--in review/l1-report.json]
"""
from __future__ import annotations

import argparse
import html
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from validators.config import review_dir  # noqa: E402


def _sev_order(sev):
    return {"P0": 0, "P1": 1, "P2": 2}.get(sev, 9)


def load_report(path: Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_markdown(report) -> str:
    s = report["summary"]
    mode = "L1+L2a+L2b" if report.get("flags", {}).get("with_layout") else "L1"
    lines = [
        "# Design Check 汇总",
        "",
        f"- 生成时间: {report.get('generated_at')}",
        f"- 模式: {mode}",
        f"- case 数: {s['cases']}  问题总数: {s['total']}  (P0={s['p0']} P1={s['p1']} P2={s['p2']})",
        "",
        "## 按规则",
        "| rule | P0 | P1 | P2 | cases |",
        "|---|---|---|---|---|",
    ]
    by_rule = {}
    for qid, fs in report["cases"].items():
        for f in fs:
            by_rule.setdefault(f["rule_id"], {"P0": 0, "P1": 0, "P2": 0, "cases": set()})
            by_rule[f["rule_id"]][f["severity"]] += 1
            by_rule[f["rule_id"]]["cases"].add(qid)
    for rid in sorted(by_rule):
        r = by_rule[rid]
        lines.append(f"| {rid} | {r['P0']} | {r['P1']} | {r['P2']} | {len(r['cases'])} |")
    lines.append("")
    lines.append("## 存在问题 case")
    lines.append("| qid | P0 | P1 | P2 | rules |")
    lines.append("|---|---|---|---|---|")
    for qid in sorted(report["cases"]):
        fs = report["cases"][qid]
        if not fs:
            continue
        p0 = sum(1 for f in fs if f["severity"] == "P0")
        p1 = sum(1 for f in fs if f["severity"] == "P1")
        p2 = sum(1 for f in fs if f["severity"] == "P2")
        rules = "; ".join(sorted({f["rule_id"] for f in fs}))
        lines.append(f"| {qid} | {p0} | {p1} | {p2} | {rules} |")
    return "\n".join(lines) + "\n"


def _finding_html(f):
    layer = f.get("layer")
    sev = f["severity"]
    rid = f["rule_id"]
    el = f.get("element") or {}
    loc = ""
    if el.get("dsl_id"):
        loc = " <code>@" + html.escape(str(el["dsl_id"])) + "</code>"
    parts = ["<div class=\"finding s" + sev + "\">",
             "<b>[" + html.escape(str(layer)) + "] " + html.escape(sev) + " " + html.escape(rid) + "</b>" + loc + "<br>",
             "<span class=\"muted\">" + html.escape(f.get("message", "")) + "</span>"]
    if f.get("fix_hint"):
        parts.append("<div class=\"fix\">fix: " + html.escape(f["fix_hint"]) + "</div>")
    parts.append("</div>")
    return "\n".join(parts)


def build_gallery(report) -> str:
    rows = []
    all_rules = sorted({f["rule_id"] for fs in report["cases"].values() for f in fs})
    for qid in sorted(report["cases"]):
        fs = report["cases"][qid]
        if any(f["severity"] == "P0" for f in fs):
            badge = "<span class=\"tag p0\">P0</span>"
        elif any(f["severity"] == "P1" for f in fs):
            badge = "<span class=\"tag p1\">P1</span>"
        else:
            badge = "<span class=\"tag p2\">P2</span>"
        fhtml = "\n".join(_finding_html(f) for f in sorted(fs, key=lambda x: (_sev_order(x["severity"]), x.get("layer"), x["rule_id"])))
        rows.append(
            "<div class=\"card\" data-qid=\"" + html.escape(qid) + "\" data-text=\"" + html.escape(qid).lower() + "\">"
            "<h3>" + badge + " " + html.escape(qid) + "</h3>"
            "<div class=\"findings\">" + fhtml + "</div></div>"
        )
    rule_opts = "".join("<option>" + html.escape(r) + "</option>" for r in all_rules)
    return """<!doctype html>
<html lang="zh"><head><meta charset="utf-8"><title>Design Check 画廊</title>
<style>
body{font-family:-apple-system,sans-serif;margin:24px;color:#222}
input{width:280px;padding:8px;font-size:14px}
.filters{margin:12px 0;display:flex;gap:8px;align-items:center}
select{padding:6px}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:14px;margin-top:16px}
.card{border:1px solid #ddd;border-radius:10px;padding:12px}
.card h3{margin:0 0 8px}
.tag{padding:2px 7px;border-radius:10px;font-size:12px;color:#fff}
.p0{background:#d33} .p1{background:#e77a1f} .p2{background:#888}
.finding{border-left:4px solid #ccc;padding:4px 8px;margin:6px 0;font-size:13px;border-radius:3px}
.sP0{border-color:#d33} .sP1{border-color:#e77a1f} .sP2{border-color:#888}
.fix{color:#1a7f37;font-size:12px} .muted{color:#666}
.hide{display:none}
</style></head><body>
<h1>Design Check 画廊 <small>L1/L2a/L2b 结论并排，可搜索/过滤</small></h1>
<div class="filters">
  <input id="q" placeholder="搜索 qid …">
  <select id="sev"><option value="">全部严重度</option><option value="P0">P0</option><option value="P1">P1</option><option value="P2">P2</option></select>
  <select id="layer"><option value="">全部层</option><option value="L1">L1 声明</option><option value="L2a">L2a 几何</option><option value="L2b">L2b 对账</option><option value="L3">L3 语义</option></select>
  <select id="rule"><option value="">全部规则</option>""" + rule_opts + """</select>
</div>
<div class="cards" id="cards">""" + "\n".join(rows) + """</div>
<script>
const cards=[...document.querySelectorAll('.card')];
function apply(){
  const q=document.getElementById('q').value.toLowerCase();
  const sev=document.getElementById('sev').value;
  const layer=document.getElementById('layer').value;
  const rule=document.getElementById('rule').value;
  for(const c of cards){
    const text=[...c.querySelectorAll('.finding')];
    let ok=(!q||c.dataset.text.includes(q));
    if(sev){ ok=ok&&text.some(t=>t.classList.contains('s'+sev)); }
    if(layer){ ok=ok&&text.some(t=>t.textContent.includes('['+layer+']')); }
    if(rule){ ok=ok&&text.some(t=>t.textContent.includes(rule)); }
    c.classList.toggle('hide',!ok);
  }
}
['q','sev','layer','rule'].forEach(id=>document.getElementById(id).addEventListener('input',apply));
apply();
</script>
</body></html>
"""


def build_baseline(report) -> dict:
    out = {}
    for qid, fs in report["cases"].items():
        out[qid] = sorted(
            [f.get("layer"), f["rule_id"], f["severity"], (f.get("element") or {}).get("dsl_id")] for f in fs
        )
    return {"schema": "design-check/baseline/v1", "generated_at": report.get("generated_at"), "findings": out}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="汇总：summary.md + index.html + baseline.json")
    parser.add_argument("--in", dest="src", default=None, help="unified 报告 JSON（默认 review/l1-report.json）")
    args = parser.parse_args(argv)
    src = Path(args.src) if args.src else review_dir() / "l1-report.json"
    if not src.is_file():
        print(f"错误: 找不到报告 {src}，请先运行 check_batch.py", file=sys.stderr)
        return 2
    report = load_report(src)
    (review_dir() / "summary.md").write_text(build_markdown(report), encoding="utf-8")
    (review_dir() / "index.html").write_text(build_gallery(report), encoding="utf-8")
    (review_dir() / "baseline.json").write_text(
        json.dumps(build_baseline(report), ensure_ascii=False, indent=2), encoding="utf-8")
    print("已生成:")
    for n in ("summary.md", "index.html", "baseline.json"):
        print("  ", review_dir() / n)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
