#!/usr/bin/env python3
"""dumpLayout 线框比对页生成器（通用版）。

用法：
    python3 wireframe.py --qid q008 \
        --dump /tmp/q008_layout.json --screen /tmp/q008_screen.jpeg \
        --dsl "<卡片数据>/q008/card.genui.jsonl" \
        --out ../../design-check/review/q008_wireframe

做三件事：
1. 从 dump 找卡片根（clickable Column），按其 bounds 从全屏截图裁卡（不依赖 card_crop.json）；
2. 用绝对定位 div 画出卡片内每个节点的 bounds 线框（px→显示像素缩放，vp 换算 3.5px/vp）；
3. 声明值对照表：从 DSL 提取每个组件 id 的 width/height 作为“声明”列与实测对照。
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from PIL import Image

BOUNDS_RE = re.compile(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]")


def parse_bounds(s):
    m = BOUNDS_RE.match(s or "")
    if not m:
        return None
    return tuple(map(int, m.groups()))


def find_bundle(n, name):
    a = n.get("attributes") or {}
    if a.get("bundleName") == name:
        return n
    for c in n.get("children") or []:
        found = find_bundle(c, name)
        if found is not None:
            return found
    return None


def load_declared(dsl_path: Path) -> dict[str, dict]:
    """DSL 三行 JSONL -> {component_id: {width,height,margin,fontSize,type,text}}"""
    declared: dict[str, dict] = {}
    for line in dsl_path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if "updateComponents" not in rec:
            continue
        for c in rec["updateComponents"]["components"]:
            st = c.get("styles") or {}
            declared[c.get("id", "")] = {
                "type": c.get("component", ""),
                "text": (c.get("content") or c.get("src") or "").split("/")[-1][:24],
                "width": st.get("width"),
                "height": st.get("height"),
                "margin": st.get("margin"),
                "fontSize": st.get("fontSize"),
            }
    return declared


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--qid", required=True)
    ap.add_argument("--dump", type=Path, required=True)
    ap.add_argument("--screen", type=Path, required=True)
    ap.add_argument("--dsl", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--px-per-vp", type=float, default=3.5)
    ap.add_argument("--scale", type=float, default=2.0)
    args = ap.parse_args()

    data = json.loads(args.dump.read_text())
    app = find_bundle(data, "com.example.myapplication")
    if app is None:
        raise SystemExit("dump 中未找到渲染应用（应用可能已退后台；先 aa start 再 dump）")

    nodes = []

    def walk(n, depth):
        a = n.get("attributes") or {}
        b = parse_bounds(a.get("bounds"))
        if b:
            nodes.append({
                "id": a.get("id") or "",
                "type": a.get("type") or "",
                "text": a.get("text") or "",
                "clickable": a.get("clickable") == "true",
                "visible": a.get("visible"),
                "depth": depth,
                "bounds": b,
            })
        for c in n.get("children") or []:
            walk(c, depth + 1)

    walk(app, 0)

    card = next((n for n in nodes if n["clickable"] and n["type"] == "Column"), None)
    if card is None:
        # 回退：卡片根无 onClick 时（如 A 系 few-shot 卡），按 DSL 根组件 id 定位
        card = next((n for n in nodes if n["id"] == "root"), None)
    if card is None:
        # 回退 2：生成式根 id（MS 多步走 cardgenerated_*_root，不可点击）；
        # 与 validators/layout.py card_root / protocol.py 同一约定：候选唯一才用
        cand = [n for n in nodes if n["id"].endswith("_root")]
        card = cand[0] if len(cand) == 1 else None
    if card is None:
        raise SystemExit("未找到卡片根节点（clickable Column 或 id=root/*_root 唯一）")
    cl, ct, cr, cb = card["bounds"]
    cw, ch = cr - cl, cb - ct

    args.out.mkdir(parents=True, exist_ok=True)
    img = Image.open(args.screen)
    img.crop((cl, ct, cr, cb)).save(args.out / "card.png")
    img.save(args.out / "screen_full.jpeg", quality=85)

    declared = load_declared(args.dsl)
    palette = ["#ff3b30", "#ff9500", "#34c759", "#007aff", "#af52de", "#ff2d55", "#5ac8fa", "#ffd60a"]

    boxes, box_html, rows_html = [], [], []
    for n in nodes:
        l, t, r, b = n["bounds"]
        if l < cl - 1 or t < ct - 1 or r > cr + 1 or b > cb + 1:
            continue
        d = declared.get(n["id"], {})
        vp = f"{(r - l) / args.px_per_vp:.1f}×{(b - t) / args.px_per_vp:.1f}"
        dw, dh = d.get("width"), d.get("height")
        decl_txt = f"{dw}×{dh}" if isinstance(dw, (int, float)) and isinstance(dh, (int, float)) else (f"{dw} / {dh}" if dw or dh else "—")
        match = ""
        if isinstance(dw, (int, float)) and isinstance(dh, (int, float)):
            ok = abs(r - l - dw * args.px_per_vp) <= 2 and abs(b - t - dh * args.px_per_vp) <= 2
            match = "✓" if ok else f"✗ 差{abs(r - l - dw * args.px_per_vp) / args.px_per_vp:.1f}×{abs(b - t - dh * args.px_per_vp) / args.px_per_vp:.1f}vp"
        color = palette[n["depth"] % len(palette)]
        idx = len(boxes)
        x, y = (l - cl) * args.scale, (t - ct) * args.scale
        w, h = (r - l) * args.scale, (b - t) * args.scale
        dash = "border-style:dashed;" if n["clickable"] else ""
        box_html.append(
            f'<div class="wf" data-idx="{idx}" style="left:{x:.1f}px;top:{y:.1f}px;width:{w:.1f}px;height:{h:.1f}px;'
            f'border-color:{color};{dash}"><span class="tag" style="background:{color}">{n["id"] or n["type"]}</span></div>'
        )
        note = d.get("type", "")
        if d.get("text"):
            note += f" · {d['text']}"
        if d.get("fontSize"):
            note += f" · fs{d['fontSize']}"
        rows_html.append(
            f'<tr data-idx="{idx}"><td>{n["id"] or "—"}</td><td>{n["type"]}</td><td>{n["text"] or "—"}</td>'
            f'<td>{r - l}×{b - t}</td><td>{vp}</td><td>{decl_txt}</td><td>{match}</td><td>{note}</td></tr>'
        )
        boxes.append(n)

    disp_w, disp_h = int(cw * args.scale), int(ch * args.scale)
    script_js = """
<script>
function hi(el){document.querySelectorAll('.wf,#tbl tr').forEach(e=>e.classList.remove('hi'));el.classList.add('hi');
 const idx=el.dataset.idx;const peer=document.querySelector((el.tagName==='TR'?'.wf':'tr')+'[data-idx="'+idx+'"]');if(peer)peer.classList.add('hi');}
document.querySelectorAll('.wf').forEach(e=>e.addEventListener('click',()=>hi(e)));
document.querySelectorAll('#tbl tr[data-idx]').forEach(e=>e.addEventListener('click',()=>hi(e)));
</script>"""

    html = f"""<!doctype html><html lang="zh"><head><meta charset="utf-8">
<title>{args.qid} dump 线框 vs 实拍</title>
<style>
 body{{margin:0;font:13px/1.5 -apple-system,"PingFang SC",sans-serif;background:#f2f4f7;color:#1c2430}}
 header{{padding:14px 20px;background:#fff;border-bottom:1px solid #dde3ec;position:sticky;top:0;z-index:9}}
 h1{{margin:0 0 4px;font-size:17px}} .meta{{color:#68758a;font-size:12px}}
 .controls{{margin-top:8px;display:flex;gap:16px;align-items:center;flex-wrap:wrap}} label{{cursor:pointer}}
 main{{display:flex;gap:16px;padding:16px;align-items:flex-start;flex-wrap:wrap}}
 .stage-wrap{{background:#fff;border:1px solid #dde3ec;border-radius:12px;padding:14px;overflow:auto;max-width:1180px}}
 .stage{{position:relative;width:{disp_w}px;height:{disp_h}px;background:#fff;box-shadow:0 4px 18px rgba(0,0,0,.12)}}
 .shot{{position:absolute;inset:0;width:100%;height:100%}}
 .grid{{position:absolute;inset:0;pointer-events:none;opacity:.35;
   background-image:linear-gradient(to right,#7aa1ff33 1px,transparent 1px),linear-gradient(to bottom,#7aa1ff33 1px,transparent 1px);
   background-size:{8 * args.px_per_vp * args.scale:.0f}px {8 * args.px_per_vp * args.scale:.0f}px}}
 .wf{{position:absolute;border:2px solid;box-sizing:border-box;cursor:pointer}}
 .wf:hover{{background:#ffffff22}} .wf.hi{{background:#ffffff44}}
 .tag{{position:absolute;top:-20px;left:-2px;font:11px/1.4 ui-monospace,monospace;color:#fff;padding:1px 6px;border-radius:4px;white-space:nowrap}}
 .hide-shot .shot{{display:none}} .stage.hide-shot{{background:#0d1117}}
 .hide-wf .wf{{display:none}} .hide-grid .grid{{display:none}} .hide-tag .tag{{display:none}}
 table{{border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;font-size:12px}}
 th,td{{padding:6px 10px;border-bottom:1px solid #e8edf4;text-align:left;white-space:nowrap}}
 th{{background:#f7f9fc;position:sticky;top:0}} tr:hover{{background:#eef4ff;cursor:pointer}}
 .note{{color:#68758a;font-size:12px;padding:10px 4px}}
</style></head><body>
<header>
 <h1>{args.qid} — dumpLayout 线框 vs 模拟器实拍</h1>
 <div class="meta">卡片区域 px=({cl},{ct})–({cr},{cb})，{cw}×{ch}px = {cw / args.px_per_vp:.0f}×{ch / args.px_per_vp:.0f}vp（density 560，3.5px/vp）· 显示 ×{args.scale:.0f} · 虚线=可点击 · “对照”列 = DSL 声明尺寸 vs 实测（±2px 判定）</div>
 <div class="controls">
   <label><input type="checkbox" checked onchange="document.body.classList.toggle('hide-shot',!this.checked)"> 截图</label>
   <label><input type="checkbox" checked onchange="stage.classList.toggle('hide-wf',!this.checked)"> 线框</label>
   <label><input type="checkbox" onchange="stage.classList.toggle('hide-grid',this.checked)"> 8vp 网格</label>
   <label><input type="checkbox" checked onchange="stage.classList.toggle('hide-tag',!this.checked)"> 标签</label>
   <span class="meta">点击表格行 ↔ 线框互相高亮；关「截图」看纯线框</span>
 </div>
</header>
<main>
 <div class="stage-wrap">
  <div class="stage" id="stage">
    <img class="shot" src="card.png"><div class="grid"></div>{''.join(box_html)}
  </div>
  <div class="note">卡片截图按 dump 坐标从全屏裁出（未用 card_crop.json）。共 {len(boxes)} 个节点入图。</div>
 </div>
 <table id="tbl"><tr><th>id</th><th>type</th><th>text</th><th>实测px</th><th>实测vp</th><th>声明</th><th>对照</th><th>备注</th></tr>{''.join(rows_html)}</table>
</main>
{script_js}
</body></html>"""
    out_html = args.out / "index.html"
    out_html.write_text(html, encoding="utf-8")
    print(f"card px=({cl},{ct})-({cr},{cb}) {cw}x{ch}px -> {cw / args.px_per_vp:.0f}x{ch / args.px_per_vp:.0f}vp; nodes={len(boxes)}")
    print(f"written: {out_html}")


if __name__ == "__main__":
    main()
