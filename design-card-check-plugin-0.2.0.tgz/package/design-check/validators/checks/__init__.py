"""L1 检查入口（适配层）。

把 ``validators.rules`` 的规则统一导出为 ``run_checks(card, contract, query)``，
返回开发计划 §3.1 的 Finding 列表。

用法：
    from validators.checks import run_checks
    from validators.design_contract import load_design_contract
    findings = run_checks(card, load_design_contract())
"""
from __future__ import annotations

from typing import Dict, List

from ..dsl import GenuiCard
from ..finding import Finding
from ..rules import run_l1


def run_checks(card: GenuiCard, contract: Dict, query: str = "") -> List[Finding]:
    return run_l1(card, contract, query)

