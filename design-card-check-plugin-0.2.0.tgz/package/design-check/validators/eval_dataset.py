"""第一次评测数据集 loader（四分支 DSL 产物，只读引用）。

目录形态（docs/goal-detection-plugin-target.md §1）：
- ``A(晓峰单独分支——一步走)/qN.jsonl``      98 条，顶层平铺
- ``B(现网分支)/dsl/qN.jsonl``               98 条，在 dsl/ 子目录
- ``C(冰心_水峰分支——模板)/QNNN.jsonl``      41 条，大写 Q 跳号
- ``晓峰——多步走/qN.jsonl``                  62 条，仅 2 条 message（缺 updateDataModel）

分支短名 A/B/C/M（多步走）用于报告聚合；缺 message 属分支形态，不报错、
在 entry.notes 标注供下游降级。
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from .config import eval_root

#: 分支目录名前缀 -> 短名
BRANCH_KEYS = (
    ("A(", "A"),
    ("B(", "B"),
    ("C(", "C"),
    ("晓峰——多步走", "M"),
)

GENUI_OPS = ("createSurface", "updateComponents", "updateDataModel")


@dataclass
class EvalEntry:
    branch: str          # 短名 A/B/C/M
    branch_dir: str      # 原始目录名
    case_id: str         # 文件 stem（q44 / Q004）
    path: Path
    size: str = ""       # createSurface 宽高推断（2x2 / 2x4 / ""）
    messages: int = 0
    notes: List[str] = field(default_factory=list)

    @property
    def qid(self) -> str:
        return f"{self.branch}/{self.case_id}"


def _branch_short(dir_name: str) -> str:
    for prefix, short in BRANCH_KEYS:
        if dir_name.startswith(prefix):
            return short
    return dir_name


def _probe(entry: EvalEntry) -> None:
    """轻探测：message 数、尺寸（不整卡解析，避免双读）。"""
    try:
        data = json.loads(entry.path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        entry.notes.append(f"解析失败: {exc!r}")
        return
    if not isinstance(data, list):
        entry.notes.append(f"非 JSON 数组形态: {type(data).__name__}")
        return
    ops = []
    surface = None
    for record in data:
        if not isinstance(record, dict):
            continue
        for op in GENUI_OPS:
            if op in record:
                ops.append(op)
                if op == "createSurface":
                    surface = record[op]
                break
    entry.messages = len(ops)
    if "updateDataModel" not in ops:
        entry.notes.append("缺 updateDataModel（分支形态，绑定类检查降级）")
    if surface and isinstance(surface.get("width"), (int, float)):
        w, h = surface.get("width"), surface.get("height")
        if (w, h) == (160, 160):
            entry.size = "2x2"
        elif (w, h) == (320, 160):
            entry.size = "2x4"
        else:
            entry.size = f"{w}x{h}"


def load_eval_manifest(root: Path | None = None) -> List[EvalEntry]:
    root = Path(root) if root else eval_root()
    if not root.is_dir():
        raise FileNotFoundError(f"评测数据目录不存在: {root}")
    entries: List[EvalEntry] = []
    for branch_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        short = _branch_short(branch_dir.name)
        # B 分支 DSL 在 dsl/ 子目录；其余分支顶层平铺
        scan_dir = branch_dir / "dsl" if (branch_dir / "dsl").is_dir() else branch_dir
        for f in sorted(scan_dir.glob("*.jsonl")):
            entry = EvalEntry(branch=short, branch_dir=branch_dir.name,
                              case_id=f.stem, path=f)
            _probe(entry)
            entries.append(entry)
    return entries
