"""第一次评测四分支 DSL 加载器（WP1：评测集 loader + 协议完整性降级）。

数据形态（``../第一次评测/README.md`` 数据清单，只读引用）：
- ``A(晓峰单独分支——一步走)/qN.jsonl``    98 条，顶层平铺，三条 genui 消息齐全
- ``B(现网分支)/dsl/qN.jsonl``            98 条，DSL 在 ``dsl/`` 子目录
- ``C(冰心_水峰分支——模板)/QNNN.jsonl``   41 条，大写 Q 跳号（Q004–Q097）
- ``晓峰——多步走/qN.jsonl``               62 条，仅 createSurface+updateComponents
                                           两条消息（缺 updateDataModel，分支形态）

统一 entry：
- ``case_id`` 全局唯一且可追溯分支，格式 ``{分支短名}-{stem}``，stem 数字部分
  补零到 3 位：A-q001 / B-q098 / C-Q004 / MS-q003（MS = 多步走）。
- ``query.txt`` 与 DSL 同目录存在则读取（strip），否则空串。
- ``task_spec`` 一律 None：评测集无 task-spec，依赖 dataModelSchema 的检查整体降级。

错误策略：路径缺失 / 空文件 / JSON 非法一律显式报错（聚合列出完整路径），
不静默跳过任何文件。
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from .config import eval_root
from .dsl import CardParseError, GenuiCard, load_genui, parse_dsl_records

#: 分支目录名前缀 -> 报告短名（MS = 晓峰——多步走）
BRANCH_PREFIX_KEYS = (
    ("A(", "A"),
    ("B(", "B"),
    ("C(", "C"),
    ("晓峰——多步走", "MS"),
)

GENUI_OPS = ("createSurface", "updateComponents", "updateDataModel")

#: qN / QNNN 类 stem（A/B/MS 小写 q，C 大写 Q）
_STEM_RE = re.compile(r"^([qQ])(\d+)$")


@dataclass
class EvalEntry:
    branch: str          # 短名 A / B / C / MS
    branch_dir: str      # 原始分支目录名
    case_id: str         # 全局唯一：A-q001 / B-q098 / C-Q004 / MS-q003
    dsl_path: Path       # 实际 jsonl 完整路径
    query_text: str = ""          # query.txt 内容（存在时），否则空串
    task_spec: Optional[Dict] = None   # 评测集一律 None（无 task-spec）
    messages: int = 0              # 探测到的 genui 消息数
    notes: List[str] = field(default_factory=list)

    @property
    def qid(self) -> str:
        return self.case_id


def branch_short(dir_name: str) -> str:
    """分支目录名 -> 短名；未知目录保留原名（不静默吞掉）。"""
    for prefix, short in BRANCH_PREFIX_KEYS:
        if dir_name.startswith(prefix):
            return short
    return dir_name


def make_case_id(branch: str, stem: str) -> str:
    """唯一 case_id：数字部分补零到 3 位，保留大小写（C 分支 Q004）。"""
    m = _STEM_RE.match(stem)
    if m:
        letter = "Q" if m.group(1) == "Q" else "q"
        return f"{branch}-{letter}{int(m.group(2)):03d}"
    return f"{branch}-{stem}"


def _probe(entry: EvalEntry) -> None:
    """轻探测：消息数 + 分支形态标注（不在此解析整卡，校验由 load_eval 完成）。"""
    try:
        data = json.loads(entry.dsl_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return  # 非法文件由 load_eval 显式报错
    ops: List[str] = []
    if isinstance(data, list):
        for record in data:
            if not isinstance(record, dict):
                continue
            for op in GENUI_OPS:
                if op in record:
                    ops.append(op)
                    break
    entry.messages = len(ops)
    if ops and "updateDataModel" not in ops:
        entry.notes.append("缺 updateDataModel（多步走分支形态，绑定类检查降级）")


def load_eval(root: Optional[Path] = None) -> List[EvalEntry]:
    """枚举评测根全部 DSL，校验每个文件，产出统一 entry 列表。

    任一文件缺失 / 为空 / JSON 非法 → 聚合所有错误后抛 ``CardParseError``
    （每条含完整路径），绝不静默跳过。
    """
    root = Path(root) if root else eval_root()
    if not root.is_dir():
        raise CardParseError(f"评测数据目录不存在: {root}")

    entries: List[EvalEntry] = []
    errors: List[str] = []
    for branch_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        short = branch_short(branch_dir.name)
        # B 分支 DSL 在 dsl/ 子目录；其余分支顶层平铺
        scan_dir = branch_dir / "dsl" if (branch_dir / "dsl").is_dir() else branch_dir
        files = sorted(scan_dir.glob("*.jsonl"))
        if not files:
            errors.append(f"{branch_dir}: 未找到任何 *.jsonl DSL 文件")
            continue
        for f in files:
            if f.stat().st_size == 0:
                errors.append(f"空文件: {f}")
                continue
            try:
                parse_dsl_records(f.read_text(encoding="utf-8-sig"))
            except CardParseError as exc:
                errors.append(f"JSON 非法/解析失败: {f} -> {exc}")
                continue
            entry = EvalEntry(
                branch=short,
                branch_dir=branch_dir.name,
                case_id=make_case_id(short, f.stem),
                dsl_path=f,
            )
            query_path = scan_dir / "query.txt"
            if not query_path.is_file():
                query_path = branch_dir / "query.txt"
            if query_path.is_file():
                entry.query_text = query_path.read_text(encoding="utf-8").strip()
            _probe(entry)
            entries.append(entry)

    if errors:
        raise CardParseError(
            "评测集加载失败（不静默跳过，共 %d 处问题）:\n%s"
            % (len(errors), "\n".join(errors))
        )
    return entries


def load_eval_card(entry: EvalEntry) -> GenuiCard:
    """按 entry 加载裸 DSL（load_genui，不要求 query/task-spec 三件套）。"""
    return load_genui(entry.dsl_path, entry.case_id)
