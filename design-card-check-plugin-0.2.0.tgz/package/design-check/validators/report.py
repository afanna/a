"""L1 检查报告（JSON / 文本摘要）。"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping

from .checks import Issue
from .dsl import GenuiCard
from .dataset import DatasetManifest


def build_case_report(card: GenuiCard, issues: List[Issue]) -> Dict[str, Any]:
    return {
        "case_id": card.case_id,
        "size": card.size,
        "issues": [i.to_dict() for i in issues],
        "issue_count": len(issues),
        "has_p0": any(i.severity == "P0" for i in issues),
        "passed": not any(i.severity in ("P0", "P1") for i in issues),
    }


def build_report(manifest: DatasetManifest, case_reports: List[Dict[str, Any]],
                 meta: Mapping[str, Any]) -> Dict[str, Any]:
    total = len(case_reports)
    all_issues = [i for r in case_reports for i in r["issues"]]
    return {
        "schema": "design-check/l1-report/v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "meta": dict(meta),
        "manifest": manifest.to_dict(),
        "summary": {
            "cases": total,
            "with_p0": sum(1 for r in case_reports if r["has_p0"]),
            "issue_count": len(all_issues),
            "p0": sum(1 for i in all_issues if i["severity"] == "P0"),
            "p1": sum(1 for i in all_issues if i["severity"] == "P1"),
            "p2": sum(1 for i in all_issues if i["severity"] == "P2"),
        },
        "cases": case_reports,
    }


def write_json(data: Dict[str, Any], target: Path) -> Path:
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def text_summary(report: Dict[str, Any]) -> str:
    s = report["summary"]
    lines = [
        "L1 Design Check Report",
        f"  cases       : {s['cases']}",
        f"  with_p0     : {s['with_p0']}",
        f"  issues      : {s['issue_count']}  (P0={s['p0']}, P1={s['p1']}, P2={s['p2']})",
    ]
    return "\n".join(lines)
