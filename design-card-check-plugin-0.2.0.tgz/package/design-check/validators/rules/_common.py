"""L1 规则公共小工具。"""
from __future__ import annotations

from typing import Optional

from ..dsl import GenuiCard
from ..finding import Element, Finding, PROGRAM, P1
from ..colors import hex_rrggbbaa, normalize_rgba_to_rrggbbaa


def pointer(card: GenuiCard, dsl_id: str) -> str:
    # 说明：JSON Pointer 只精确到组件 id（组件索引可在打印证据时补齐）。
    return f"/updateComponents/components/{dsl_id}"


def el(card: GenuiCard, dsl_id: Optional[str] = None) -> Element:
    return Element(dsl_id=dsl_id, json_pointer=pointer(card, dsl_id) if dsl_id else "")


def make(
    card: GenuiCard,
    rule_id: str,
    message: str,
    dsl_id: Optional[str] = None,
    *,
    severity: str = P1,
    evidence_type: str = PROGRAM,
    expected: str = "",
    actual: str = "",
    fix_hint: str = "",
    layer: str = "L1",
) -> Finding:
    return Finding(
        qid=card.case_id,
        layer=layer,
        rule_id=rule_id,
        severity=severity,
        evidence_type=evidence_type,
        element=el(card, dsl_id),
        expected=expected,
        actual=actual,
        fix_hint=fix_hint,
        message=message,
    )


def color_value_rgba(value) -> Optional[str]:
    """把 DSL 颜色按 UX 规范 ``#RRGGBBAA`` 归一到小写规范形式。

    旧版这里优先调用 ``normalize_aarrggbb``，会把规范色 ``#0A59F7FF``
    错读成 ``#59F7FF0A``，造成大量 ``COLOR.TOKEN_UNREGISTERED`` 噪音。
    ``normalize_aarrggbb`` 仍保留给明确声明旧 ARGB 输入的渲染兼容路径；
    设计检查的 DSL 统一采用 UX 规范字节序。
    """
    if not isinstance(value, str):
        return None
    return normalize_rgba_to_rrggbbaa(value) or hex_rrggbbaa(value)


def alpha_of_rgba(rrggbbaa: str) -> Optional[int]:
    """从 #rrggbbaa 取 alpha 通道（0-255）。"""
    try:
        return int(rrggbbaa[7:9], 16)
    except Exception:
        return None


def count_components(card: GenuiCard, component: str) -> int:
    return sum(1 for c in card.iter_components() if c.get("component") == component)
