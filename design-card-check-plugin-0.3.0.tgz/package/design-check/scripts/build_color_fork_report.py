#!/usr/bin/env python3
"""色系分叉比对报告：第一次评测四分支全部颜色 × DESIGN.md 金标准。

口径：
- 分支侧：四分支（A 一步走 / B 现网 / C 模板 / MS 多步走）全部卡片、全部组件的
  颜色样式键（fontColor / fillColor / backgroundColor / borderColor / color /
  linearGradient.colors）取值，按分支去重计数。书写格式统一按 UX/DSL 的 #RRGGBBAA 解析。
- 金标准侧：DESIGN.md 正文中出现的全部 hex 色值（#RRGGBBAA，alpha 在后）去重。
- 比对：归一化为 (RGB, alpha) 后三档判定——✓ 完全命中 / △ RGB 命中但 alpha 分叉 /
  ✗ 未登记（附最近金标准 RGB 与欧氏距离）。
- 色系：HSV 饱和度 <5% 归灰阶（白/浅灰/中灰/深灰/黑），其余按色相 8 桶
  （红/橙/黄/绿/青/蓝/紫/品红）。

产物：review/<YYYYMMDD>/EVAL299-visual-<YYYYMMDD>.html（静态自包含，无外部依赖）。
"""
import colorsys
import html
import json
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from validators.config import daily_review_dir, design_spec_path, eval_root  # noqa: E402

BRANCHES = [
    ("A", "A(晓峰单独分支——一步走)"),
    ("B", "B(现网分支)/dsl"),
    ("C", "C(冰心_水峰分支——模板)"),
    ("MS", "晓峰——多步走"),
]
# 分支标注（2026-08-24 用户要求）：不只写字母，带路线名；晓峰系标注晓峰
BRANCH_SHORT = {"A": "A 单步走", "B": "B 现网", "C": "C 模板", "MS": "MS 多步走"}
BRANCH_LABELS = {
    "A": "A · 晓峰 单步走",
    "B": "B · 现网",
    "C": "C · 冰心_水峰 模板",
    "MS": "MS · 晓峰 多步走",
}
COLOR_KEYS = {"fontColor", "fillColor", "backgroundColor", "borderColor", "color"}
HEX_RE = re.compile(r"^#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$")

HUE_FAMILIES = [
    ((345, 15), "红"), ((15, 45), "橙"), ((45, 70), "黄"), ((70, 160), "绿"),
    ((160, 195), "青"), ((195, 255), "蓝"), ((255, 290), "紫"), ((290, 345), "品红"),
]
FAMILY_ORDER = ["红", "橙", "黄", "绿", "青", "蓝", "紫", "品红",
                "白", "浅灰", "中灰", "深灰", "黑"]


def parse_branch_hex(v: str):
    """分支侧 UX/DSL #RRGGBBAA（或 6 位）→ (rgb6, alpha2)。"""
    if not isinstance(v, str):
        return None
    v = v.strip()
    if not HEX_RE.match(v):
        return None
    v = v[1:].upper()
    if len(v) == 6:
        return v, "FF"
    return v[:6], v[6:]


def parse_gold_hex(v: str):
    """金标准侧 #RRGGBBAA（或 6 位）→ (rgb6, alpha2)。"""
    v = v[1:].upper()
    if len(v) == 6:
        return v, "FF"
    return v[:6], v[6:]


def family_of(rgb6: str) -> str:
    r, g, b = (int(rgb6[i:i + 2], 16) / 255 for i in (0, 2, 4))
    mx, mn = max(r, g, b), min(r, g, b)
    if mx == 0:
        return "黑"
    s_hsv = (mx - mn) / mx
    v = mx
    if s_hsv < 0.05:  # 灰阶按明度分桶
        if v >= 0.92:
            return "白"
        if v >= 0.70:
            return "浅灰"
        if v >= 0.35:
            return "中灰"
        if v >= 0.10:
            return "深灰"
        return "黑"
    h, _, _ = colorsys.rgb_to_hsv(r, g, b)
    deg = h * 360
    for (lo, hi), name in HUE_FAMILIES:
        if lo < hi and lo <= deg < hi:
            return name
        if lo > hi and (deg >= lo or deg < hi):  # 红跨 345–15
            return name
    return "红"


def rgb_dist(a: str, b: str) -> int:
    return sum((int(a[i:i + 2], 16) - int(b[i:i + 2], 16)) ** 2 for i in (0, 2, 4))


def collect_branch_colors():
    """返回 {分支: Counter{原始写法: 次数}} 与 {分支: Counter{非hex写法: 次数}}。"""
    out, nonhex = {}, {}
    for tag, sub in BRANCHES:
        cnt, bad = Counter(), Counter()
        for fp in sorted((eval_root() / sub).glob("*.jsonl")):
            txt = fp.read_text(encoding="utf-8")
            recs = json.loads(txt) if txt.lstrip().startswith("[") else [
                json.loads(l) for l in txt.splitlines() if l.strip()]
            for rec in recs:
                for comp in rec.get("updateComponents", {}).get("components", []):
                    st = comp.get("styles", {}) or {}
                    for k in COLOR_KEYS:
                        v = st.get(k)
                        if v is None:
                            continue
                        (cnt if HEX_RE.match(str(v).strip()) else bad)[str(v)] += 1
                    for c, _ in (st.get("linearGradient", {}) or {}).get("colors", []):
                        (cnt if HEX_RE.match(str(c).strip()) else bad)[str(c)] += 1
        out[tag], nonhex[tag] = cnt, bad
    return out, nonhex


def collect_golden():
    """DESIGN.md 全部 hex（含出现次数 + 行内 token 标签）。"""
    text = design_spec_path().read_text(encoding="utf-8")
    golden = {}
    for line in text.splitlines():
        for m in re.finditer(r"#[0-9A-Fa-f]{8}\b|#[0-9A-Fa-f]{6}\b", line):
            rgb6, alpha = parse_gold_hex(m.group(0))
            key = (rgb6, alpha)
            ent = golden.setdefault(key, {"as_written": m.group(0).upper(), "n": 0,
                                          "label": ""})
            ent["n"] += 1
            if not ent["label"]:
                # 优先取 front-matter 的 token 键名（如 scene_weather_start: "#317AF7FF"），
                # 否则退回行内首个反引号 token（正文规则行）。
                km = re.match(r"\s*([a-zA-Z_]\w*):\s*\"" + re.escape(m.group(0)), line)
                tok = re.search(r"`([a-zA-Z][\w-]{3,})`", line)
                ent["label"] = km.group(1) if km else (tok.group(1) if tok else "")
    return golden


def gold_as_aa(rgb6: str, alpha2: str) -> str:
    """金标准以 UX/DSL 统一形式 #RRGGBBAA 展示。"""
    return f"#{rgb6}{alpha2}"


def parse_gradient_registry():
    """解析 DESIGN.md front-matter 的 background_gradients 注册表（小型缩进解析，无外部依赖）。

    返回按文件出现顺序的 preset 列表：name / scene / type / 方向 / stops / 烘焙 stops。
    """
    lines = design_spec_path().read_text(encoding="utf-8").splitlines()
    try:
        start = next(i for i, l in enumerate(lines) if l.startswith("background_gradients:")) + 1
    except StopIteration:
        raise FileNotFoundError("DESIGN.md 缺少 background_gradients 注册表")
    presets, cur, mode = [], None, None
    for l in lines[start:]:
        if l and not l[0].isspace():
            break  # 回到顶层键，注册表结束
        if not l.strip():
            continue
        ind = len(l) - len(l.lstrip())
        s = l.strip()
        if s.startswith("- {") and mode in ("stops", "opq"):
            mo = re.search(r"offset:\s*([\d.]+)%.*?color:\s*\"?(#[0-9A-Fa-f]{6,8})", s)
            if mo:
                cur["stops" if mode == "stops" else "opq"].append(
                    (float(mo.group(1)), mo.group(2).upper()))
            continue
        m = re.match(r"([\w-]+):\s*(.*)$", s)
        if ind == 2 and m and not m.group(2):  # preset 名
            cur = {"name": m.group(1), "meta": {}, "stops": [], "opq": []}
            presets.append(cur)
            mode = None
        elif cur is None or not m:
            continue
        k, v = m.group(1), m.group(2).strip()
        if ind == 4:
            if k in ("scene", "type", "direction", "angle", "center", "radius"):
                cur["meta"][k] = v.strip('"')
                mode = None
            elif k == "stops":
                mode = "stops"
            elif k == "opaqueEquivalent":
                mode = "opq-wait"
            else:  # buttonColorContext 等单行映射
                mode = None
        elif ind == 6 and k == "stops" and mode == "opq-wait":
            mode = "opq"
    if not presets:
        raise ValueError("background_gradients 注册表解析结果为空")
    return presets


def collect_root_backgrounds():
    """四分支卡片 root 背景实际写法：{(bg|None, 方向key, ((color,offset),...))} → {分支: Counter}。"""
    out = {}
    for tag, sub in BRANCHES:
        cnt = Counter()
        for fp in sorted((eval_root() / sub).glob("*.jsonl")):
            txt = fp.read_text(encoding="utf-8")
            recs = json.loads(txt) if txt.lstrip().startswith("[") else [
                json.loads(l) for l in txt.splitlines() if l.strip()]
            for rec in recs:
                uc = rec.get("updateComponents")
                if not uc:
                    continue
                comps = uc.get("components", [])
                byid = {c.get("id"): c for c in comps}
                root = byid.get(uc.get("root")) or next(
                    (c for c in comps if str(c.get("id", "")).endswith("_root")), None)
                if root is None:
                    continue
                st = root.get("styles", {}) or {}
                lg, bg = st.get("linearGradient"), st.get("backgroundColor")
                if lg:
                    d = f"angle={lg['angle']}" if "angle" in lg else f"dir={lg.get('direction', '?')}"
                    cnt[(bg, d, tuple((str(c), float(o)) for c, o in lg.get("colors", [])))] += 1
                elif bg:
                    cnt[(bg, "solid", ())] += 1
        out[tag] = cnt
    return out


def collect_all_gradients():
    """全部组件的 linearGradient 写法（root 含其叠加底色，非 root 无底色）。

    返回 {(bg|None, 方向key, ((color,offset),...))} → {分支: Counter}——
    色系楼层按整组渐变实渲的依据：DSL 里它们本来就是成对的色值。
    """
    out = {}
    for tag, sub in BRANCHES:
        cnt = Counter()
        for fp in sorted((eval_root() / sub).glob("*.jsonl")):
            txt = fp.read_text(encoding="utf-8")
            recs = json.loads(txt) if txt.lstrip().startswith("[") else [
                json.loads(l) for l in txt.splitlines() if l.strip()]
            for rec in recs:
                uc = rec.get("updateComponents")
                if not uc:
                    continue
                comps = uc.get("components", [])
                root_id = uc.get("root") or next(
                    (c.get("id") for c in comps if str(c.get("id", "")).endswith("_root")), None)
                for comp in comps:
                    st = comp.get("styles", {}) or {}
                    lg = st.get("linearGradient")
                    if not lg:
                        continue
                    d = f"angle={lg['angle']}" if "angle" in lg else f"dir={lg.get('direction', '?')}"
                    bg = st.get("backgroundColor") if comp.get("id") == root_id else None
                    cnt[(bg, d, tuple((str(c), float(o)) for c, o in lg.get("colors", [])))] += 1
        out[tag] = cnt
    return out


WEIGHT_NAMES = {400: "Regular", 500: "Medium", 700: "Bold"}


def collect_typography():
    """四分支 fontSize / fontWeight 写法计数：{分支: {"fontSize": Counter, "fontWeight": Counter}}。"""
    out = {}
    for tag, sub in BRANCHES:
        fs, fw = Counter(), Counter()
        for fp in sorted((eval_root() / sub).glob("*.jsonl")):
            txt = fp.read_text(encoding="utf-8")
            recs = json.loads(txt) if txt.lstrip().startswith("[") else [
                json.loads(l) for l in txt.splitlines() if l.strip()]
            for rec in recs:
                for comp in rec.get("updateComponents", {}).get("components", []):
                    st = comp.get("styles", {}) or {}
                    if "fontSize" in st:
                        fs[st["fontSize"]] += 1
                    if "fontWeight" in st:
                        fw[st["fontWeight"]] += 1
        out[tag] = {"fontSize": fs, "fontWeight": fw}
    return out


def parse_typography_tokens():
    """DESIGN.md 排版 token 注册表：[(token名, 字号, 字重)]，如 (display-l-regular, 56, 400)。"""
    text = design_spec_path().read_text(encoding="utf-8")
    toks = re.findall(
        r"^\s*([\w-]+):\s*\{[^}]*?fontSize:\s*(\d+)vp[^}]*?fontWeight:\s*(\d+)",
        text, re.M)
    if not toks:
        raise ValueError("DESIGN.md 排版 token 解析结果为空")
    return [(n, int(s), int(w)) for n, s, w in toks]


def typo_role(token: str) -> str:
    """token 名去掉字重后缀 = 语义角色（display-l-regular → display-l；metric-primary 原样）。"""
    parts = token.split("-")
    return "-".join(parts[:-1]) if parts[-1] in ("regular", "medium", "bold") else token


def build_typography_section(typo, toks):
    """排版比对：单列表格（类别/路线/实渲/值/金标准/用量），实渲为内联文字样例。"""
    font = "'HarmonyOS Sans SC','PingFang Sans SC','PingFang SC','Microsoft YaHei',sans-serif"
    g_sizes, g_weight_n = {}, Counter()
    for name, s, w in toks:
        g_sizes.setdefault(s, set()).add(typo_role(name))
        g_weight_n[w] += 1

    def sample_span(kind, v):
        css = (f"font-size:{v}px" if kind == "fontSize"
               else f"font-weight:{v};font-size:22px")
        txt = str(v) if kind == "fontSize" else "Aa"
        return f'<span class="tsample" style="font-family:{font};{css}">{txt}</span>'

    def kind_rows(kind, gmap, gcount):
        lab = "字号" if kind == "fontSize" else "字重"
        unit = "vp" if kind == "fontSize" else ""
        out = []
        for v, name in sorted(gmap.items()):
            out.append(
                f'<tr class="grow"><td>{lab}</td><td>金标准</td><td>{sample_span(kind, v)}</td>'
                f'<td class="mono">{v}{unit}</td><td><em class="ok">✓ 登记</em> · {name}</td>'
                f'<td>token ×{gcount[v]}</td></tr>')
        for tag, _ in BRANCHES:
            rs = sorted(typo[tag][kind].items(), key=lambda x: (-x[1], x[0]))
            for v, n in rs:
                if v in gmap:
                    stat = f'<em class="ok">✓ 登记</em>'
                elif kind == "fontWeight":
                    stat = ('<em class="bad">✗ 档外</em>·原生六档无此值，端侧回落')
                else:
                    stat = '<em class="bad">✗ 档外</em>·金标准无此档'
                reg = "grow" if v in gmap else ""
                out.append(
                    f'<tr class="{reg}"><td>{lab}</td><td>{BRANCH_SHORT[tag]}</td>'
                    f'<td>{sample_span(kind, v)}</td><td class="mono">{v}{unit}</td>'
                    f'<td>{stat}</td><td>×{n}</td></tr>')
        return "".join(out)

    gmap_s = {s: " / ".join(sorted(rs)) for s, rs in g_sizes.items()}
    gmap_w = {w: WEIGHT_NAMES.get(w, "") for w in g_weight_n}
    gcount_s = Counter(s for _, s, _ in toks)
    union_fs = set().union(*[set(typo[t]["fontSize"]) for t, _ in BRANCHES])
    union_fw = set().union(*[set(typo[t]["fontWeight"]) for t, _ in BRANCHES])
    off_fs, off_fw = union_fs - set(g_sizes), union_fw - set(g_weight_n)
    head = ("<thead><tr><th>类别</th><th>路线</th><th>实渲</th><th>值</th>"
            "<th>金标准</th><th>用量 / 登记</th></tr></thead>")
    table = (f'<table class="flist">{head}'
             f'<tbody>{kind_rows("fontSize", gmap_s, gcount_s)}</tbody>'
             f'<tbody>{kind_rows("fontWeight", gmap_w, g_weight_n)}</tbody></table>'
             '<p class="cap">实渲染列为浏览器字体近似（HarmonyOS Sans SC 缺失时回退），端侧以真机为准；'
             '值列单位 vp 隐含（DSL 全部为 JSON 数值写法）；'
             '字重 600/800 不在原生六档 {100,300,400,500,700,900}，端侧实渲回落到最近可用档。</p>')
    return (f'<section><h2>排版 · 字号 × 字重<small>金标准 {len(g_sizes)} 档字号 + {len(g_weight_n)} 档字重 · '
            f'四分支合并 {len(union_fs)}/{len(union_fw)} 写法 · 档外 {len(off_fs)}（'
            f'{", ".join(str(v) for v in sorted(off_fs))}）+ {len(off_fw)}（'
            f'{", ".join(str(v) for v in sorted(off_fw))}）</small></h2>{table}</section>')


# 方向 → 规范语义（ArkUI angle 180 ≡ direction Bottom ≡ 自上而下；金标准 angle: 180deg 同义）
DIR_CANON = {"Bottom": "to bottom", "Top": "to top", "Left": "to left", "Right": "to right",
             "LeftTop": "to top left", "RightTop": "to top right",
             "LeftBottom": "to bottom left", "RightBottom": "to bottom right"}
DIR_ZH = {"to bottom": "自上而下", "to top": "自下而上", "to bottom right": "左上→右下",
          "to top left": "右下→左上", "radial": "径向（顶部中心）"}


def branch_dir_canon(dkey: str) -> str:
    if dkey.startswith("angle="):
        deg = dkey.split("=")[1].replace("deg", "")
        return {0: "to top", 90: "to right", 180: "to bottom", 270: "to left"}.get(int(deg), f"{deg}deg")
    return DIR_CANON.get(dkey.split("=", 1)[-1], dkey)


def preset_dir_canon(p) -> str:
    if p["meta"].get("type") == "radial":
        return "radial"
    deg = p["meta"].get("angle", "").replace("deg", "")
    return {180: "to bottom", 0: "to top", 90: "to right", 270: "to left"}.get(int(deg or 180), deg)


def css_rgba(rgb6: str, alpha2: str) -> str:
    r, g, b = (int(rgb6[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r},{g},{b},{int(alpha2, 16) / 255:.3f})"


def css_gradient(canon: str, stops) -> str:
    """stops: [(css色, offset)]（offset 已归一为百分比）；canon 为 CSS 方向或 radial。"""
    body = ", ".join(f"{c} {off_pct(o):g}%" for c, o in stops)
    if canon == "radial":
        return f"radial-gradient(circle farthest-corner at 50% 0%, {body})"
    return f"linear-gradient({canon}, {body})"


def off_pct(o: float) -> float:
    """DSL 渐变 offset 为 0–1 浮点，注册表为 0–100 百分比，统一到百分比。"""
    return o * 100 if o <= 1 else o


def sat_of(rgb6: str) -> float:
    r, g, b = (int(rgb6[i:i + 2], 16) / 255 for i in (0, 2, 4))
    mx, mn = max(r, g, b), min(r, g, b)
    return 0.0 if mx == 0 else (mx - mn) / mx


def stops_family(stop_hexes, parser) -> str:
    """渐变整组的色系 = 最高饱和度 stop 的色系（并列取靠前 stop）——渐变的身份色相。"""
    seq = [(sat_of(parser(c)[0]), -i, parser(c)[0]) for i, c in enumerate(stop_hexes)]
    return family_of(max(seq)[2])


def match_preset(bg, dkey, stops, presets, golden_set):
    """分支 root 背景写法 ↔ 注册表：hit / near(差异列表) / miss(最近预设) / solid。"""
    canon = branch_dir_canon(dkey)
    if dkey == "solid":
        parsed = parse_branch_hex(bg) if bg else None
        ok = parsed in golden_set if parsed else False
        return ("solid", "✓ 纯色已登记" if ok else "✗ 纯色未登记", [])
    bstop = tuple(parse_branch_hex(c) for c, _ in stops)
    best = None
    for p in presets:
        pdir = preset_dir_canon(p)
        pstop = tuple(parse_gold_hex(c) for _, c in p["stops"])
        rgb_eq = (tuple(x[0] for x in bstop) == tuple(x[0] for x in pstop)
                  and len(bstop) == len(pstop))
        alpha_diff = rgb_eq and tuple(x[1] for x in bstop) != tuple(x[1] for x in pstop)
        dist = sum(rgb_dist(b[0], g[0]) ** .5 for b, g in zip(bstop, pstop)) + abs(len(bstop) - len(pstop)) * 12
        cand = (0 if (rgb_eq and pdir == canon and not alpha_diff) else 1 if rgb_eq else 2,
                dist, p)
        if best is None or cand[:2] < best[:2]:
            best = cand
    tier, _, p = best
    if tier == 0:
        names = [q["name"] for q in presets
                 if tuple(parse_gold_hex(c) for _, c in q["stops"]) == bstop
                 and preset_dir_canon(q) == canon]
        return ("hit", f"✓ 命中 {' / '.join(names)}", [])
    if tier == 1:
        diffs = []
        pdir = preset_dir_canon(p)
        if canon != pdir:
            diffs.append(f"方向 {DIR_ZH.get(canon, canon)}≠{DIR_ZH.get(pdir, pdir)}")
        pstop = tuple(parse_gold_hex(c) for _, c in p["stops"])
        if tuple(x[1] for x in bstop) != tuple(x[1] for x in pstop):
            diffs.append("alpha 档 " + "→".join(x[1] for x in bstop)
                         + "≠" + "→".join(x[1] for x in pstop))
        return ("near", f"△ 近似 {p['name']}（{'；'.join(diffs)}）", diffs)
    return ("miss", f"✗ 未登记（最近 {p['name']}）", [])


def build_gradient_section(presets, root_bgs, golden_set):
    """金标准登记预设 × 四分支 root 实际写法：圆角卡片实渲预览（参考 20260824 版式）。"""
    # ── 左：金标准（浅色遮罩类在前，按注册表文件顺序） ──────────────
    gitems = []
    for p in presets:
        canon = preset_dir_canon(p)
        css_stops = [(css_rgba(*parse_gold_hex(c)), o) for o, c in p["stops"]]
        grad = css_gradient(canon, css_stops)
        mask = bool(p["opq"])
        if mask:  # 烘焙：直接展示注册表 opaqueEquivalent（纯白宿主 flatten）
            bake = " → ".join(gold_as_aa(*parse_gold_hex(c)) for _, c in p["opq"])
            bake_line = f'烘焙 <b class="bake">{bake}</b>'
        else:
            bake_line = '烘焙 <b class="bake">—（stops 已不透明）</b>'
        gitems.append(
            f'<div class="gcard"><div class="gprev" style="background:{grad}, #FFFFFF"></div>'
            f'<div class="gmeta"><b>{p["name"]}</b><i>{p["meta"].get("scene", "")}</i>'
            f'<span>渐变 <b>{ " → ".join(gold_as_aa(*parse_gold_hex(c)) for _, c in p["stops"]) }</b>'
            f'<br>方向 {DIR_ZH.get(canon, canon)}（{p["meta"].get("angle", p["meta"].get("center", ""))}）'
            f'<br>{bake_line}</span></div></div>')
    # ── 右：四分支写法（全分支合并去重，按总用量降序） ──────────────
    combo = {}
    for tag, cnt in root_bgs.items():
        for k, n in cnt.items():
            combo.setdefault(k, {})[tag] = n
    bitems = []
    for (bg, dkey, stops), tags in sorted(combo.items(), key=lambda kv: -sum(kv[1].values())):
        canon = branch_dir_canon(dkey)
        if dkey == "solid":
            rgb, a = parse_branch_hex(bg)
            grad, stops_txt = css_rgba(rgb, a), f"纯色 {bg}"
        else:
            css_stops = [(css_rgba(*parse_branch_hex(c)), off_pct(o)) for c, o in stops]
            base = css_rgba(*parse_branch_hex(bg)) if bg else "#FFFFFF"
            grad = f"{css_gradient(canon, css_stops)}, {base}"
            stops_txt = " → ".join(c for c, _ in stops) + f"　{dkey}"
            if bg:
                stops_txt = f"底 {bg} + " + stops_txt
        tier, label, _ = match_preset(bg, dkey, stops, presets, golden_set)
        chips = " ".join(f'<span class="chip">{BRANCH_SHORT[t]}×{n}</span>' for t, n in sorted(tags.items()))
        cls = {"hit": "ok", "near": "warn", "miss": "bad", "solid": "warn"}.get(tier, "")
        bitems.append(
            f'<div class="gcard"><div class="gprev" style="background:{grad}"></div>'
            f'<div class="gmeta"><b>{chips}</b><span>{html.escape(stops_txt)}'
            f'<br><em class="{cls}">{label}</em></span></div></div>')
    note = ("预览说明：金标准浅色遮罩按「白基底 + 渐变叠加」实渲（composition: base-color-then-gradient-overlay）；"
            "烘焙列取注册表 opaqueEquivalent（纯白宿主 flatten 等效）；方向映射 angle=180/Bottom=自上而下、"
            "RightBottom=左上→右下、LeftTop=右下→左上，weather 为径向；分支预览按其原文写法渲染（含叠加底色）。")
    return (
        f'<section><h2>卡片背景渐变 · 金标准登记 × 四分支实写（圆角卡片实渲）</h2>{note}'
        f'<div class="gcols"><div class="gpanel"><h3>金标准登记预设'
        f'<small>DESIGN.md background_gradients · {len(presets)} 组</small></h3>'
        f'<div class="gwrap">{"".join(gitems)}</div></div>'
        f'<div class="gpanel"><h3>四分支 root 实际写法'
        f'<small>{len(combo)} 种去重组合 · 按用量降序</small></h3>'
        f'<div class="gwrap">{"".join(bitems)}</div></div></div></section>')


def classify(values, golden):
    """[(rgb6, alpha2, count, 原始写法)] → 每项附 (命中档, 最近金标准, 距离, 色系)。"""
    rows = []
    gold_by_rgb = {}
    for (rgb6, alpha) in golden:
        gold_by_rgb.setdefault(rgb6, set()).add(alpha)
    for rgb6, alpha, n, raw in values:
        fam = family_of(rgb6)
        if alpha in gold_by_rgb.get(rgb6, set()):
            tier, near, d = "hit", "", 0
        elif rgb6 in gold_by_rgb:
            tier, near, d = "alpha", "", 0
        else:
            cands = [g for (g, a) in golden if family_of(g) == fam] or [g for g, _ in golden]
            near = min(cands, key=lambda g: rgb_dist(rgb6, g))
            d = rgb_dist(rgb6, near) ** 0.5
            tier = "miss"
        rows.append(dict(rgb=rgb6, alpha=alpha, n=n, raw=raw, fam=fam,
                         tier=tier, near=near, dist=round(d, 1)))
    return rows


def swatch(rgb6, alpha2, title="", size=34):
    a = int(alpha2, 16) / 255
    r, g, b = (int(rgb6[i:i + 2], 16) for i in (0, 2, 4))
    bg = f"rgba({r},{g},{b},{a})"
    light = "sw-light" if (0.299 * r + 0.587 * g + 0.114 * b) > 186 else ""
    return (f'<div class="sw {light}" title="{html.escape(title)}" '
            f'style="background:{bg}"></div>')


def build_html(golden, branch_rows, nonhex, stats, grad_section="", presets=(), all_grads=None,
               typo_section=""):
    all_grads = all_grads or {}
    today = datetime.now().strftime("%Y%m%d")
    fams = [f for f in FAMILY_ORDER
            if any(r["fam"] == f for rs in branch_rows.values() for r in rs)
            or any(family_of(g) == f for g, _ in golden)
            or any(stops_family([c for c, _ in k[2]], parse_branch_hex) == f
                   for cnt in all_grads.values() for k in cnt)
            or any(stops_family([c for _, c in p["stops"]], parse_gold_hex) == f for p in presets)]

    # ── 总矩阵：行=色系，列=金标准/A/B/C/MS ─────────────────────────
    matrix = ["<table class='matrix'><thead><tr><th>色系</th><th>金标准登记</th>"
              + "".join(f"<th>{BRANCH_SHORT[t]}</th>" for t, _ in BRANCHES)
              + "<th>四分支合计去重</th></tr></thead><tbody>"]
    tot = {"gold": 0, "union": 0}
    for fam in fams:
        g_vals = sorted(f"{g}{a}" for g, a in golden if family_of(g) == fam)
        cells = [f"<td class='g'>{len(g_vals)}</td>"]
        seen_union = set()
        for tag, _ in BRANCHES:
            rs = [r for r in branch_rows[tag] if r["fam"] == fam]
            hit = sum(1 for r in rs if r["tier"] == "hit")
            alp = sum(1 for r in rs if r["tier"] == "alpha")
            miss = sum(1 for r in rs if r["tier"] == "miss")
            cls = "bad" if miss else ("warn" if alp else "ok")
            cells.append(
                f"<td class='{cls}'>{'—' if not rs else len(rs)}"
                + (f"<br><small>✓{hit} △{alp} ✗{miss}</small>" if rs else "") + "</td>")
            seen_union |= {r["rgb"] + r["alpha"] for r in rs}
        tot["gold"] += len(g_vals)
        tot["union"] += len(seen_union)
        matrix.append(
            f"<tr><th>{fam}</th>{''.join(cells)}<td>{len(seen_union) or '—'}</td></tr>")
    matrix.append(f"<tr class='sum'><th>合计</th><td>{tot['gold']}</td>"
                  + "<td></td>" * 4 + f"<td>{tot['union']}</td></tr>")
    matrix.append("</tbody></table>")

    # ── 分色系楼层：DSL 渐变色值对整组实渲 + 纯色，按色系归类 ──────
    detail = []
    tier_badge = {"hit": ("✓ 命中", "ok"), "alpha": ("△ alpha分叉", "warn"),
                  "miss": ("✗ 未登记", "bad")}
    g_tier_cls = {"hit": "ok", "near": "warn", "miss": "bad"}

    def color_prev(rgb6: str, alpha2: str) -> str:
        """纯色圆角卡片预览：主体 = 该色在白卡底上的合成观感；alpha<FF 时底部棋盘条展示原始透明度。"""
        a = int(alpha2, 16) / 255
        r, g, b = (int(rgb6[i:i + 2], 16) for i in (0, 2, 4))
        eff = "#%02X%02X%02X" % (round(r * a + 255 * (1 - a)),
                                 round(g * a + 255 * (1 - a)),
                                 round(b * a + 255 * (1 - a)))
        strip = ("" if alpha2 == "FF" else
                 f'<i class="astrip checker"><b style="background:'
                 f'rgba({r},{g},{b},{a:.3f})"></b></i>')
        return f'<div class="cprev" style="background:{eff}">{strip}</div>'

    def grad_prev(bg, dkey, stops) -> str:
        """DSL 渐变色值对整组实渲（含叠加底色），正方形圆角卡片（贴近 2×2 卡形态）。"""
        canon = branch_dir_canon(dkey)
        css_stops = [(css_rgba(*parse_branch_hex(c)), off_pct(o)) for c, o in stops]
        base = css_rgba(*parse_branch_hex(bg)) if bg else "#FFFFFF"
        return (f'<div class="cprev sq" style="background:'
                f'{css_gradient(canon, css_stops)}, {base}"></div>')

    def alpha_pct(alpha2: str) -> str:
        """alpha 十六进制 → 百分比（如 FF→100%、1A→10.2%、19→9.8%）。"""
        p = round(int(alpha2, 16) / 255 * 100, 1)
        return f"{p:g}%"

    def floor_list(fam, branch_rows, golden):
        """楼层明细表：第一栏路线，第二栏色值（alpha% #RRGGBB），金标准状态 + 用量。"""
        gold_keys = set(golden.keys())
        gold_rgb = {g for g, _ in gold_keys}
        head = ("<thead><tr><th>路线</th><th>色值</th><th>金标准</th><th>用量 / 登记</th>"
                "</tr></thead>")

        def val_cell(rgb, alpha):
            return f'<td class="mono">{alpha_pct(alpha)} #{rgb}</td>'

        tbodys = []
        # 金标准组：该色系全部登记值（含未被分支使用的）
        grows = []
        for (g, a), e in sorted(((k, v) for k, v in golden.items() if family_of(k[0]) == fam),
                                key=lambda kv: -kv[1]["n"]):
            lab = e.get("label", "")
            grows.append(
                f'<tr class="grow"><td>金标准</td>{val_cell(g, a)}'
                f'<td><em class="ok">✓ 登记</em>' + (f' · {html.escape(lab)}' if lab else '')
                + f'</td><td>文档 ×{e["n"]}</td></tr>')
        if grows:
            tbodys.append("<tbody>" + "".join(grows) + "</tbody>")
        # 分支组：每条路线自己的写法，按用量降序
        for tag, _ in BRANCHES:
            rs = sorted([r for r in branch_rows[tag] if r["fam"] == fam],
                        key=lambda r: (-r["n"], r["raw"]))
            if not rs:
                continue
            brows = []
            for r in rs:
                if (r["rgb"], r["alpha"]) in gold_keys:
                    lab = golden[(r["rgb"], r["alpha"])].get("label", "")
                    status = '<em class="ok">✓ 登记</em>' + (f' · {html.escape(lab)}' if lab else '')
                elif r["rgb"] in gold_rgb:
                    status = '<em class="warn">△ RGB 命中·alpha 分叉</em>'
                else:
                    status = '<em class="bad">✗ 未登记</em>'
                reg = "grow" if (r["rgb"], r["alpha"]) in gold_keys else ""
                brows.append(
                    f'<tr class="{reg}"><td>{BRANCH_SHORT[tag]}</td>{val_cell(r["rgb"], r["alpha"])}'
                    f'<td>{status}</td><td>×{r["n"]}</td></tr>')
            tbodys.append("<tbody>" + "".join(brows) + "</tbody>")
        return (f'<table class="flist">{head}{"".join(tbodys)}</table>'
                '<p class="cap">色值列 = 透明度百分比 + #RRGGBB；黄底行 = 金标准登记值；'
                '金标准组列出该色系全部登记值（含未被使用的，用量为 DESIGN.md 文档出现次数）。</p>')

    for fam in fams:
        # 金标准面板：该色系登记渐变预设（整组实渲 + 烘焙）+ 登记纯色值
        g_presets = [p for p in presets
                     if stops_family([c for _, c in p["stops"]], parse_gold_hex) == fam]
        g_rows = sorted(((g, a, e) for (g, a), e in golden.items()
                         if family_of(g) == fam),
                        key=lambda x: -x[2]["n"])
        gcards = ""
        for p in g_presets:
            canon = preset_dir_canon(p)
            css_stops = [(css_rgba(*parse_gold_hex(c)), off_pct(o)) for o, c in p["stops"]]
            bake = (" → ".join(gold_as_aa(*parse_gold_hex(c)) for _, c in p["opq"])
                    if p["opq"] else "—（已不透明）")
            meta = (f'<b>{p["name"]}</b><i>{p["meta"].get("scene", "")}</i>'
                    f'<span>渐变 {" → ".join(gold_as_aa(*parse_gold_hex(c)) for _, c in p["stops"])}'
                    f'<br>烘焙 <b class="bake">{bake}</b></span>')
            gcards += (f'<div class="ccard"><div class="cprev sq" style="background:'
                       f'{css_gradient(canon, css_stops)}, #FFFFFF"></div>'
                       f'<div class="gmeta">{meta}</div></div>')
        for g, a, e in g_rows:
            meta = (f'<b>{gold_as_aa(g, a)}</b>'
                    f'<i>原文 {e["as_written"]}'
                    + (f' · {html.escape(e["label"])}' if e["label"] else "")
                    + '</i>'
                    f'<span>登记 ×{e["n"]}</span>')
            gcards += (f'<div class="ccard">{color_prev(g, a)}'
                       f'<div class="gmeta">{meta}</div></div>')
        ghead = f'金标准 DESIGN.md<small>{len(g_presets)} 组渐变 + {len(g_rows)} 纯色</small>'
        if g_presets or g_rows:
            gpanel = f'<div class="gpanel goldp"><h3>{ghead}</h3><div class="gwrap">{gcards}</div></div>'
        else:
            gpanel = (f'<div class="gpanel goldp"><h3>{ghead}</h3><div class="gwrap">'
                      '<span class="none-lab">该色系无登记值——分支在此色系的全部写法都是注册表外颜色</span></div></div>')
        panels = [gpanel]
        for tag, _ in BRANCHES:
            gentries = sorted([(k, n) for k, n in (all_grads.get(tag) or {}).items()
                               if stops_family([c for c, _ in k[2]], parse_branch_hex) == fam],
                              key=lambda kv: -kv[1])
            rs = sorted([r for r in branch_rows[tag] if r["fam"] == fam],
                        key=lambda r: (-r["n"], r["raw"]))
            if not gentries and not rs:
                continue
            hit = sum(1 for r in rs if r["tier"] == "hit")
            alp = sum(1 for r in rs if r["tier"] == "alpha")
            mis = sum(1 for r in rs if r["tier"] == "miss")
            gt = [match_preset(bg, dkey, stops, presets, set(golden))[0]
                  for (bg, dkey, stops), _ in gentries]
            cards = ""
            for (bg, dkey, stops), n in gentries:
                tier, label, _ = match_preset(bg, dkey, stops, presets, set(golden))
                stops_txt = " → ".join(c for c, _ in stops)
                meta = (f'<b>{html.escape(stops_txt)}</b>'
                        f'<span>{("底 " + bg + " ＋ ") if bg else ""}{dkey}<br>'
                        f'<em class="{g_tier_cls[tier]}">{label}</em><br>用量 ×{n}</span>')
                cards += (f'<div class="ccard">{grad_prev(bg, dkey, stops)}'
                          f'<div class="gmeta">{meta}</div></div>')
            for r in rs:
                badge, cls = tier_badge[r["tier"]]
                extra = (f' ≈#{r["near"]} Δ{r["dist"]}' if r["tier"] == "miss" else
                         (" alpha≠金标准档" if r["tier"] == "alpha" else ""))
                token = ""
                if r["tier"] == "hit":
                    lab = golden.get((r["rgb"], r["alpha"]), {}).get("label", "")
                    token = f'<i>命中 token {html.escape(lab)}</i>' if lab else ""
                meta = (f'<b>{r["raw"]}</b>'
                        f'<span><em class="{cls}">{badge}{extra}</em><br>用量 ×{r["n"]}</span>'
                        + token)
                cards += (f'<div class="ccard">{color_prev(r["rgb"], r["alpha"])}'
                          f'<div class="gmeta">{meta}</div></div>')
            head = (f'{BRANCH_LABELS[tag]}<small>{len(gentries)} 组渐变（✓{gt.count("hit")} '
                    f'△{gt.count("near")} ✗{gt.count("miss")}）'
                    f'+ {len(rs)} 纯色（✓{hit} △{alp} ✗{mis}）</small>')
            panels.append(f'<div class="gpanel"><h3>{head}</h3>'
                          f'<div class="gwrap">{cards}</div></div>')
        detail.append(f'<section><h2>{fam}<small>金标准 {len(g_presets)} 组渐变 + {len(g_rows)} 纯色 · '
                      f'渐变按 DSL 色值对整组实渲，按最高饱和度 stop 归类色系</small></h2>'
                      f'<div class="gcols">{"".join(panels)}</div>'
                      f'{floor_list(fam, branch_rows, golden)}</section>')

    cards = "".join(
        f"<div class='card'><b>{v}</b><span>{k}</span></div>" for k, v in stats.items())

    nonhex_html = ""
    nz = {t: dict(c) for t, c in nonhex.items() if c}
    if nz:
        rows = "".join(
            f"<tr><th>{t}</th><td>{html.escape(', '.join(f'{k}×{v}' for k, v in c.items()))}</td></tr>"
            for t, c in nz.items())
        nonhex_html = f"<section><h2>非 hex 颜色写法（未纳入色系比对）</h2><table class='matrix'>{rows}</table></section>"

    css = """
    body{font:14px/1.6 -apple-system,'PingFang SC','HarmonyOS Sans SC',sans-serif;
      margin:0;background:#F6F7F9;color:#1a1a1a}
    header{background:#202224;color:#fff;padding:18px 28px}
    header h1{margin:0 0 4px;font-size:20px}
    header p{margin:2px 0;color:#bbb;font-size:12.5px}
    main{padding:20px 28px;max-width:1280px;margin:0 auto}
    .cards{display:flex;gap:12px;flex-wrap:wrap;margin:14px 0 20px}
    .card{background:#fff;border-radius:10px;padding:10px 16px;box-shadow:0 1px 3px rgba(0,0,0,.08)}
    .card b{font-size:22px;display:block}
    .card span{font-size:12px;color:#666}
    table.matrix{border-collapse:collapse;background:#fff;border-radius:10px;
      overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.08);width:100%}
    .matrix th,.matrix td{padding:7px 12px;border-bottom:1px solid #eee;text-align:center;font-size:13px}
    .matrix thead th{background:#202224;color:#fff}
    .matrix tbody th{background:#f0f1f3;text-align:left;white-space:nowrap}
    .matrix td.ok{color:#1a7f37}.matrix td.warn{color:#b58105}.matrix td.bad{color:#c62828;font-weight:600}
    .matrix td.g{font-weight:600}
    .matrix tr.sum td,.matrix tr.sum th{background:#f0f1f3;font-weight:700}
    .matrix small{color:#888;font-weight:400}
    section{margin:26px 0}
    section h2{font-size:16px;border-left:4px solid #317AF7;padding-left:10px}
    .row{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-start;margin:10px 0;padding:10px 12px;
      background:#fff;border-radius:10px;box-shadow:0 1px 3px rgba(0,0,0,.06)}
    .row.gold{background:#FFFBEA;border:1px solid #F0E2B6}
    .row.none .lab{color:#a8071a}
    .tag{flex:0 0 62px;font-weight:700;color:#555;padding-top:6px}
    .row.gold .tag{color:#8a6d00}
    .sw{width:38px;height:30px;border-radius:6px;border:1px solid #d0d3d9;flex:none}
    .sw-light{box-shadow:inset 0 0 0 1px #e8e8e8}
    .lab{font-size:11.5px;line-height:1.45;color:#444;max-width:118px}
    .lab b{color:#111}
    .lab i{color:#8a6d00;font-style:normal}
    em.ok{color:#1a7f37;font-style:normal}em.warn{color:#b58105;font-style:normal}
    em.bad{color:#c62828;font-style:normal;font-weight:600}
    .gcols{display:flex;flex-direction:column;gap:16px}
    .gpanel{background:#fff;border-radius:12px;padding:14px 16px;
      box-shadow:0 1px 3px rgba(0,0,0,.08)}
    .gpanel h3{margin:2px 0 4px;font-size:14.5px}
    .gpanel h3 small{color:#888;font-weight:400;margin-left:8px}
    .gwrap{display:flex;flex-wrap:wrap;gap:14px;margin-top:8px}
    .gcard{width:184px}
    .gmeta{font-size:11.5px;line-height:1.55;margin-top:6px}
    .gmeta b{display:block;font-size:12.5px;margin-bottom:2px}
    .gmeta i{display:block;color:#888;font-style:normal;font-size:11px}
    .gmeta span{color:#444;word-break:break-all}
    .gmeta .bake{color:#8a6d00}
    .chip{display:inline-block;background:#eceff3;border-radius:10px;padding:0 8px;
      margin-right:6px;font-weight:700;color:#333}
    .gpanel.goldp{background:#FFFBEA;border:1px solid #F0E2B6}
    .ccard{width:150px}
    .cprev{height:64px;border-radius:14px;border:1px solid #d8dbe0;position:relative;
      overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.10)}
    .cprev.sq{height:auto;aspect-ratio:1/1}
    .gprev{aspect-ratio:1/1;border-radius:18px;border:1px solid #d8dbe0;
      box-shadow:0 2px 7px rgba(0,0,0,.10);overflow:hidden}
    .tsample{display:inline-block;min-width:64px;text-align:center;line-height:1.15;vertical-align:middle}
    .flist{border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;
      box-shadow:0 1px 3px rgba(0,0,0,.08);width:100%;margin-top:14px;font-size:12.5px}
    .flist th,.flist td{padding:5px 10px;border-bottom:1px solid #eee;text-align:center}
    .flist thead th{background:#202224;color:#fff;font-weight:600;white-space:nowrap}
    .flist td.mono{font-family:ui-monospace,Menlo,Consolas,monospace;text-align:left;white-space:nowrap}
    .flist tr.grow td{background:#FFFBEA}
    .cap{color:#888;font-size:12px;margin:6px 2px 0}
    .astrip{position:absolute;left:0;right:0;bottom:0;height:14px}
    .astrip b{position:absolute;inset:0}
    .checker{background-image:linear-gradient(45deg,#d9dce1 25%,transparent 25%,transparent 75%,#d9dce1 75%),
      linear-gradient(45deg,#d9dce1 25%,#fbfbfc 25%,#fbfbfc 75%,#d9dce1 75%);
      background-size:8px 8px;background-position:0 0,4px 4px}
    .none-lab{color:#a8071a;font-size:12px}
    section h2 small{font-size:12px;color:#888;font-weight:400;margin-left:10px}
    footer{padding:16px 28px;color:#888;font-size:12px}
    code{background:#eceff3;padding:1px 6px;border-radius:4px}
    """
    return f"""<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<title>色系分叉比对 · EVAL299 × DESIGN.md</title><style>{css}</style></head><body>
<header><h1>色系分叉比对：第一次评测四分支 × DESIGN.md 金标准</h1>
<p>生成 {datetime.now().strftime('%Y-%m-%d %H:%M')} · 检测层 L1（确定性静态）· 范围 EVAL299（A 98 / B 98 / C 41 / MS 62 卡）</p>
<p>口径：分支侧取全部组件颜色键（fontColor / fillColor / backgroundColor / borderColor / color / 渐变 stops），
按 UX/DSL 统一的 <code>#RRGGBBAA</code> 解析并展示；金标准取 DESIGN.md 全文 hex，
同样按 <code>#RRGGBBAA</code> 解析。比对在 (RGB, alpha) 归一化后进行，三档判定：
✓ 完全命中 / △ RGB 命中但 alpha 分叉 / ✗ 未登记（附最近金标准色与欧氏距离 Δ）。
色系：HSV 饱和度&lt;5% 归灰阶，其余按色相分 8 桶。DESIGN-2x4.md 未纳入本报告。</p>
<p>分支标注：A = 晓峰 单步走（一步生成）· B = 现网分支 · C = 冰心_水峰 模板分支 · MS = 晓峰 多步走。
色系楼层回到 DSL 原生写法：<b>渐变按色值对整组实渲</b>（含叠加底色与原始方向），按渐变中最高饱和度 stop 的色系归类；
纯色按值归类。纯色卡主体为白卡底合成观感，底部棋盘条表示原始透明度。</p></header>
<main><div class="cards">{cards}</div>
<h2>总分叉矩阵</h2>{''.join(matrix)}
{grad_section}
{typo_section}
{''.join(detail)}{nonhex_html}</main>
<footer>复现：<code>python3 design-check/scripts/build_color_fork_report.py</code>
（产物落 <code>design-check/review/{today}/</code>，同日重生成覆盖）· 机器只做检测+定位+建议，最终结论由人类设计师确认</footer>
</body></html>"""


def main():
    golden = collect_golden()
    branch_raw, nonhex = collect_branch_colors()
    branch_rows = {}
    stats = {"金标准去重色值": len(golden)}
    all_pairs = set()
    for tag, _ in BRANCHES:
        vals = [(rgb, a, n, raw)
                for raw, n in branch_raw[tag].items()
                for rgb, a in [parse_branch_hex(raw)]]
        rows = classify(vals, golden)
        branch_rows[tag] = rows
        hit = sum(1 for r in rows if r["tier"] == "hit")
        alp = sum(1 for r in rows if r["tier"] == "alpha")
        miss = sum(1 for r in rows if r["tier"] == "miss")
        stats[f"{BRANCH_SHORT[tag]} 去重/✓/△/✗"] = f"{len(rows)} / {hit} / {alp} / {miss}"
        all_pairs |= {(r["rgb"], r["alpha"]) for r in rows}
    stats["四分支合并去重"] = len(all_pairs)
    presets = parse_gradient_registry()
    root_bgs = collect_root_backgrounds()
    all_grads = collect_all_gradients()
    grad_section = build_gradient_section(presets, root_bgs, set(golden.keys()))
    typo = collect_typography()
    toks = parse_typography_tokens()
    typo_section = build_typography_section(typo, toks)
    g_sizes = {s for _, s, _ in toks}
    g_weights = {w for _, _, w in toks}
    union_fs = set().union(*[set(typo[t]["fontSize"]) for t, _ in BRANCHES])
    union_fw = set().union(*[set(typo[t]["fontWeight"]) for t, _ in BRANCHES])
    stats["字号 合并/金标准/档外"] = f"{len(union_fs)} / {len(g_sizes)} / {len(union_fs - g_sizes)}"
    stats["字重 合并/金标准/档外"] = f"{len(union_fw)} / {len(g_weights)} / {len(union_fw - g_weights)}"
    out = daily_review_dir() / f"EVAL299-visual-{datetime.now().strftime('%Y%m%d')}.html"
    out.write_text(build_html(golden, branch_rows, nonhex, stats, grad_section, presets, all_grads,
                              typo_section),
                   encoding="utf-8")

    print(f"产物: {out}")
    print(f"金标准 {len(golden)} 值 | " + " | ".join(
        f"{BRANCH_SHORT[t]}: {stats[BRANCH_SHORT[t] + ' 去重/✓/△/✗']}" for t, _ in BRANCHES)
        + f" | 合并去重 {len(all_pairs)}")


if __name__ == "__main__":
    main()
