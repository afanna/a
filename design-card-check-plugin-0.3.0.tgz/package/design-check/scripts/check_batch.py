#!/usr/bin/env python3
"""批量设计检查——93 条三件套数据集 + 第一次评测四分支裸 DSL（--eval-dir）。

用法：
    python3 scripts/check_batch.py                    # L1 全量（93 条，三件套）
    python3 scripts/check_batch.py --with-layout      # L1 + L2a/L2b（用数据集 dump 真值）
    python3 scripts/check_batch.py --cases q001,q002
    python3 scripts/check_batch.py --out review/l1-report.json
    python3 scripts/check_batch.py --eval-dir ../第一次评测 \
        --out review/eval-l1-report.json              # 评测集 299 条裸 DSL（L1 含 semantic）

--eval-dir 模式（WP1）：
- 用 validators/eval_loader.py 枚举四分支（A 98 / B 98 / C 41 / MS 62）全部 DSL；
- 无 task-spec，task_spec 一律 None → 汇总 meta 声明「无 task-spec：依赖
  dataModelSchema 的检查整体降级」；
- 输出 per-branch × rule × severity 计数汇总（控制台 + --out JSON）。
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.case_store import build_case_report, dump_absent, screenshot_absent, write_case_report  # noqa: E402
from validators.config import design_spec_path, review_dir  # noqa: E402
from validators.dataset import load_manifest  # noqa: E402
from validators.design_contract import attach_card_size_contracts, load_design_contract  # noqa: E402
from validators.dsl import CardParseError, load_case  # noqa: E402
from validators.layout import DumpLayout  # noqa: E402
from validators.rules import run_l1  # noqa: E402
from validators.finding import sort_findings  # noqa: E402
from packages.pkg_elements.color import aggregate_color_findings  # noqa: E402

#: 评测模式汇总 meta：无 task-spec 的整体降级声明
EVAL_DEGRADATION_NOTE = "无 task-spec：依赖 dataModelSchema 的检查整体降级"


def _run_93_set(args, contract) -> int:
    """原有 93 条三件套路径（行为不变）。"""
    try:
        manifest = load_manifest()
    except (CardParseError, FileNotFoundError) as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2

    wanted = set(args.cases.split(",")) if args.cases else None
    if wanted:
        missing = sorted(wanted - {e.case_id for e in manifest.entries})
        if missing:
            print(f"错误: 未知 case {', '.join(missing)}", file=sys.stderr)
            return 2

    l1_dir = review_dir() / "l1"
    l1_dir.mkdir(parents=True, exist_ok=True)
    all_findings = {}
    for entry in manifest.entries:
        if wanted and entry.case_id not in wanted:
            continue
        try:
            card = load_case(entry.query_path.parent)
        except CardParseError as exc:
            print(f"  [skip] {entry.case_id}: {exc}", file=sys.stderr)
            continue
        attach_card_size_contracts(contract, card)  # Idea2-WP-B 注入收口
        findings = run_l1(card, contract, card.query_text)
        if args.with_layout:
            from validators.dataset import render_evidence_layout_path
            from validators.geometry import run_geometry
            from validators.reconcile_lib import reconcile

            lp = render_evidence_layout_path(entry.case_id)
            if lp.is_file():
                layout = DumpLayout.from_file(lp)
                findings += run_geometry(card, layout)
                findings += reconcile(card, layout)
            # L2 对账追加后重新按 DSL 颜色类别聚合，避免同一底色/透明度
            # 漂移在多个组件上重复计数。
            findings = aggregate_color_findings(card, findings)
        findings = sort_findings(findings)
        all_findings[entry.case_id] = findings
        data = {"qid": entry.case_id, "findings": [f.to_dict() for f in findings]}
        (l1_dir / f"{entry.case_id}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        # F3 逐卡统一落盘（93 集 L1 口径：dump/screenshot absent）
        write_case_report(build_case_report(
            qid=f"SET93-{entry.case_id}", source_kind="qdir", source_label="SET93",
            dsl_path=entry.dsl_path, size=card.size,
            dump=dump_absent(), screenshot=screenshot_absent(),
            findings=[f.to_dict() for f in findings], notes=[]))
        n = len(findings)
        p0 = sum(1 for f in findings if f.severity == "P0")
        print(f"  {entry.case_id} findings={n} (P0={p0})")

    report = {
        "schema": "design-check/unified-findings/v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "flags": {"with_layout": args.with_layout},
        "cases": {qid: [f.to_dict() for f in fs] for qid, fs in all_findings.items()},
        "summary": {
            "cases": len(all_findings),
            "total": sum(len(v) for v in all_findings.values()),
            "p0": sum(1 for v in all_findings.values() for f in v if f.severity == "P0"),
            "p1": sum(1 for v in all_findings.values() for f in v if f.severity == "P1"),
            "p2": sum(1 for v in all_findings.values() for f in v if f.severity == "P2"),
        },
    }
    target = Path(args.out) if args.out else review_dir() / "l1-report.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n汇总写入: {target}")
    return 0


def _run_eval(args, contract) -> int:
    """第一次评测四分支裸 DSL 检查（L1 全规则含 semantic，无 task-spec）。"""
    from validators.eval_loader import load_eval, load_eval_card

    try:
        entries = load_eval(args.eval_dir)
    except CardParseError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2

    out_dir = review_dir() / "eval-l1"
    out_dir.mkdir(parents=True, exist_ok=True)
    all_findings = {}
    branch_stat: dict = defaultdict(lambda: {"cases": 0, "total": 0, "p0": 0, "p1": 0, "p2": 0})
    #: (branch, rule_id, severity) -> count
    branch_rule_sev: Counter = Counter()
    #: (rule_id, severity) -> count（跨分支）
    rule_sev: Counter = Counter()
    degraded_ids: list = []  # 缺 updateDataModel（多步走形态）的 case

    for entry in entries:
        try:
            card = load_eval_card(entry)
        except CardParseError as exc:
            print(f"  [skip] {entry.case_id}: {exc}", file=sys.stderr)
            continue
        attach_card_size_contracts(contract, card)  # Idea2-WP-B 注入收口
        findings = run_l1(card, contract, entry.query_text, include_semantic=True)
        findings = sort_findings(findings)
        all_findings[entry.case_id] = findings
        data = {
            "qid": entry.case_id, "branch": entry.branch, "messages": entry.messages,
            "notes": entry.notes, "findings": [f.to_dict() for f in findings],
        }
        case_dir = out_dir / entry.branch
        case_dir.mkdir(parents=True, exist_ok=True)
        (case_dir / f"{entry.case_id}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        # F3 逐卡统一落盘（评测集 L1 口径：qid 以 DSL 文件 stem 为准 = 补零归一
        # 到 stem 口径，如 A-q001 → A-q1；C 分支 Q004 本身即 stem，保持不变）
        write_case_report(build_case_report(
            qid=f"{entry.branch}-{entry.dsl_path.stem}", source_kind="branch",
            source_label=entry.branch, dsl_path=entry.dsl_path,
            size=card.card_size or "", dump=dump_absent(), screenshot=screenshot_absent(),
            findings=[f.to_dict() for f in findings], notes=[]))

        stat = branch_stat[entry.branch]
        stat["cases"] += 1
        if entry.notes and any("缺 updateDataModel" in n for n in entry.notes):
            degraded_ids.append(entry.case_id)
        for f in findings:
            stat["total"] += 1
            stat[f.severity.lower()] += 1
            branch_rule_sev[(entry.branch, f.rule_id, f.severity)] += 1
            rule_sev[(f.rule_id, f.severity)] += 1

    # per-branch × rule × severity 嵌套结构
    branch_rule_sev_nested: dict = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    for (branch, rule_id, sev), n in branch_rule_sev.items():
        branch_rule_sev_nested[branch][rule_id][sev] = n

    report = {
        "schema": "design-check/eval-l1/v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "scope": {
            "mode": "eval-dir",
            "root": str(Path(args.eval_dir).resolve()),
            "no_task_spec": True,
            "degradation": EVAL_DEGRADATION_NOTE,
        },
        "cases": {qid: [f.to_dict() for f in fs] for qid, fs in all_findings.items()},
        "degraded_no_data_model": sorted(degraded_ids),
        "summary": {
            "cases": sum(s["cases"] for s in branch_stat.values()),
            "branches": {b: dict(s) for b, s in sorted(branch_stat.items())},
            "branch_rule_severity": {
                b: {r: dict(sevs) for r, sevs in sorted(rules.items())}
                for b, rules in sorted(branch_rule_sev_nested.items())
            },
            "by_rule_severity": {f"{r} [{sev}]": n for (r, sev), n in rule_sev.most_common()},
        },
    }
    target = Path(args.out) if args.out else out_dir / "l1-report.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    # 控制台：per-branch 统计 + per-branch×rule×severity 计数汇总
    print("\n分支统计: " + " · ".join(
        f"{b}={s['cases']}卡/{s['total']}条(P0={s['p0']},P1={s['p1']},P2={s['p2']})"
        for b, s in sorted(branch_stat.items())))
    print("\nper-branch × rule × severity:")
    for b, rules in sorted(branch_rule_sev_nested.items()):
        print(f"  [{b}] " + " · ".join(
            f"{r} {sev}={n}" for r, sevs in sorted(rules.items()) for sev, n in sorted(sevs.items())))
    if degraded_ids:
        print(f"\n降级标注（缺 updateDataModel，多步走分支形态）: {len(degraded_ids)} 条")
    print(f"降级声明: {EVAL_DEGRADATION_NOTE}")
    print(f"汇总写入: {target}")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="批量设计检查 + 汇总")
    parser.add_argument("--cases", default=None, help="逗号分隔 case 白名单，默认全部")
    parser.add_argument("--out", default=None, help="汇总 JSON 输出路径")
    parser.add_argument("--with-layout", action="store_true", help="同时跑 L2a/L2b（用 dump 真值）")
    parser.add_argument("--eval-dir", default=None,
                        help="第一次评测根目录；指定后以裸 DSL 模式跑四分支（无 task-spec，L1 含 semantic）")
    args = parser.parse_args(argv)

    try:
        contract = load_design_contract(design_spec_path())
    except (CardParseError, FileNotFoundError) as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2

    if args.eval_dir:
        return _run_eval(args, contract)
    return _run_93_set(args, contract)


if __name__ == "__main__":
    raise SystemExit(main())
