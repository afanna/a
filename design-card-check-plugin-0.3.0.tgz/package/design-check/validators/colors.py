"""颜色字节序适配。

当前 UX 规范与 DSL 统一使用 ``#RRGGBBAA``。旧 ``#AARRGGBB`` 仅通过显式兼容函数解析。
"""
from __future__ import annotations

import re
from typing import Optional

from .design_contract import ALPHA_STEPS as ALPHA_13_STEPS

HEX_RE = re.compile(r"^#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$")


def _hex_component(value: str, start: int, length: int = 2) -> str:
    return value[start : start + length]


def normalize_aarrggbb(value: str) -> Optional[str]:
    """把旧 DSL 颜色 ``#AARRGGBB``（或 6 位 ``#RRGGBB``）转成规范 ``#RRGGBBAA``。"""
    value = value.strip()
    m = HEX_RE.match(value)
    if not m:
        return None
    h = m.group(1)
    if len(h) == 6:
        return f"#{h}FF"
    alpha = h[0:2]
    rgb = h[2:8]
    return f"#{rgb}{alpha}"


def normalize_rgba_to_rrggbbaa(value: str) -> Optional[str]:
    """任何规范的 8 位/6 位 hex 都归一到 ``#RRGGBBAA``（非 8 位补 FF 不透明）。"""
    value = value.strip()
    m = HEX_RE.match(value)
    if not m:
        return None
    h = m.group(1)
    if len(h) == 6:
        return f"#{h}FF"
    return f"#{h}"


def hex_rrggbbaa(value: str) -> Optional[str]:
    """按 UX/DSL #RRGGBBAA 归一；仅为旧输入保留显式兼容回退。"""
    return normalize_rgba_to_rrggbbaa(value) or normalize_aarrggbb(value)


def alpha_channel(rrggbbaa: str) -> Optional[int]:
    """返回 alpha 通道（0-255）；非法输入返回 None。"""
    normalized = normalize_rgba_to_rrggbbaa(rrggbbaa)
    if normalized is None:
        return None
    return int(normalized[7:9], 16)


def parse_ar_color(value: str) -> Optional[tuple]:
    """按旧 ARGB 字节序解析为 (r,g,b,a) 0..1（仅兼容渲染工具）。

    - 6 位 ``#RRGGBB``：不透明（alpha=1.0）；
    - 8 位 ``#AARRGGBB``：旧输入字节序；正式 UX/DSL 判定使用 ``#RRGGBBAA``。
    """
    m = HEX_RE.match(value.strip())
    if not m:
        return None
    h = m.group(1)
    if len(h) == 6:
        a = "FF"
        rgb = h
    else:
        a, rgb = h[0:2], h[2:8]
    try:
        r = int(rgb[0:2], 16) / 255.0
        g = int(rgb[2:4], 16) / 255.0
        b = int(rgb[4:6], 16) / 255.0
        alpha = int(a, 16) / 255.0
    except ValueError:
        return None
    return r, g, b, alpha


#: 13 档 alpha 单一来源（DESIGN.md《Hex 与透明度规则》；goal Phase 0 统一：
#: 历史本地字面量含 0x40/0x59/0x73/0x80 错误档位，已删除，统一导入 design_contract.ALPHA_STEPS）。
#: 兼容别名
alpha_13_steps = ALPHA_13_STEPS
alpha_value = alpha_channel


def alpha_class(alpha: int) -> Optional[int]:
    """把 alpha 映到最近的 13 档；越界返回 None。"""
    if not 0 <= alpha <= 255:
        return None
    return min(ALPHA_13_STEPS, key=lambda step: abs(step - alpha))
