# 模板误触发测试集

本目录由 `build_perturbation_dataset.mjs` 生成，只保留目标模板在 Search 阶段必须被排除的确定负样本，用于统计误触发率。完整基线、缺可选数据、无动作和 Icon 扰动均可能合法命中模板，未纳入本集。

所有用例只使用 `app-11.7.5.205_rom-6.0` 中 `enabled !== false` 的数据、动作和资源能力，且 `deviceInfo.prdVer` 固定为 `11.8.8.342`。

当前服务会按 `prdVer + romVersion` 选择运行时注册表。为使这一选择确定，所有用例的 `deviceInfo.romVersion` 固定为 `7.0`；按现有区间配置会选择 7.0 注册表。已核对本数据集使用的 6.0 启用数据能力、动作模板和素材 ID 与该运行时注册表兼容。

`perturbation_expected.json` 是唯一的预期映照表。每条均要求 `expectedSearchEligibility: ineligible` 与 `expectedPlannerOrRender: not-applicable`。
