# Phase 1 模板测试集审查结果

审查目录：`taskspec/template`。本次把每条入参按微服务实际的 `CapabilityRegistry → TaskSpecBuilder → CardPlanRegistry → retrieve_template_variants` 流程重放，检查 2x2 模板候选；只修改测试数据和旁车记录，不修改 Skill、微服务实现或 TaskSpec 协议。

## 本轮修订

- **Q051**：删除 `/targetDateText`。该字段只由 Activity 宽版模板提供，2x2 的 `ActivityOverviewFull@1` 不覆盖它；query 同步为步数、热量和距离。
- **Q053**：补充“点一下查看运动健康”及 `event.open.health.sport`，让心率更新时间场景进入 `HeartRateOverview` 的更新时间 Hero 候选。
- **Q062**：将天气字段 `/current/temperatureC` 替换为普通 2x2 天气模板支持的 `/current/temperatureText`，保留天气情况字段；不再误触发需要双天气绑定的 `WeatherOverviewDualCityFull@1`。
- 其余 Q001–Q084 未改动。仍保持 6 个能力各 14 条，全部单能力、2x2；没有加入 `relationship`、6.0 不提供的能力或素材。

## 真实代码重放结果

- 重放范围：Q001–Q084，共 84 条。
- 结果：**84/84 条进入模板候选**。
- Q051 实际候选：`ActivityOverviewFull@1`。
- Q053 实际候选集合包含 `HeartRateOverviewUpdatedHero@1`、`HeartRateOverviewUpdatedIconHero@1`。
- Q062 实际候选：`WeatherOverviewFull@1`。
- 本地默认配置缺少可选键 `ai_widget_data_huashan_enable`，重放脚本仅在进程内将其按关闭处理，未改配置文件或服务代码。

## 分布

| 维度 | 结果 |
| --- | --- |
| 数据条数 | 84 |
| 能力出现次数 | {'ViewWeather': 14, 'GetCalendarEvents': 14, 'GetCountdownDays': 14, 'GetEarphoneInfo': 14, 'GetPhoneBatteryInfo': 14, 'GetHealthAndSportSummary': 14} |
| 单能力/双能力行 | 84 / 0 |
| 请求字段数 | {1: 19, 2: 21, 3: 19, 4: 20, 5: 5} |
| 每行事件数 | {0: 35, 1: 40, 2: 9} |
| 每行素材数 | {1: 16, 2: 52, 3: 16} |
| 尺寸 | 全部 2x2 |

每个能力各 14 条，能力维度均匀。动作数量按语义分布，不强求完全相等；`event.open.health.sport` 本轮增加 1 条用于覆盖更新时间心率模板。字段数和素材数没有出现单一数量压倒其他数量的情况。

## 校验

- 84 个 JSON 全部解析成功，编号 Q001–Q084 连续。
- 所有 `candidateOutputFields` 均存在于对应 6.0 outputSchema。
- 所有能力参数满足 6.0 inputSchema；电池能力统一使用 `/data/phoneBattery`。
- 所有事件 ID 和 action 内容与 6.0 `event_capabilities.json` 一致。
- 所有素材 ID 均存在于 6.0 `asset_capabilities.json`。
- `template_expected.json` 是旁车预期，不参与 TaskSpec 发送；其中 Q051、Q053、Q062 已记录真实重放结论。

## 测试边界

主集用于验证单业务 2x2 模板命中。双业务另建专项集，并严格使用已知可组成 HeroTitle/HeroContent 的业务对；2x4、应用使用时长、系统内存、清理内存和存储空间等当前不可提供项另建专项或预检异常集，避免与主集的命中率混在一起。

动作计数（供观察，不要求相等）：{'event.open.weather': 6, 'event.open.clock.alarm': 9, 'event.viewCalendarEvent': 7, 'event.enter.meeting': 1, 'event.open.settings.bluetooth': 10, 'event.open.music.daily': 2, 'event.open.music.favorite': 2, 'event.open.settings.battery': 5, 'event.open.settings.batteryHealth': 5, 'event.setPowerSavingMode': 2, 'event.open.health.sport': 6, 'event.open.health.sleep': 2, 'event.open.settings.dnd': 1}
