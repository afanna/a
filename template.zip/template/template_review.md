# Phase 1 模板测试集审查结果

审查目录：`taskspec/template`。所有入参按微服务实际的 `CapabilityRegistry → TaskSpecBuilder → CardPlanRegistry → retrieve_template_variants` 流程重放；只修改测试数据和旁车记录，不修改 Skill、微服务实现或 TaskSpec 协议。

## 数据集组成

- Q001–Q084：正向模板覆盖集，预期进入模板候选，实际 **84/84** 命中。
- Q085–Q096：合法负向边界集，预期不进入模板候选，实际 **12/12** 未命中。
- 负向用例已并入同一目录和同一编号序列，映照表通过 `inputClass=negative-boundary` 标记，不再单独维护目录。

## 本轮正向修订

- **Q051**：删除 `/targetDateText`。该字段只由 Activity 宽版模板提供，2x2 的 `ActivityOverviewFull@1` 不覆盖它；query 同步为步数、热量和距离。
- **Q053**：补充“点一下查看运动健康”及 `event.open.health.sport`，让心率更新时间场景进入更新时间 Hero 候选。
- **Q062**：将天气字段 `/current/temperatureC` 替换为普通 2x2 天气模板支持的 `/current/temperatureText`，避免误触发需要双天气绑定的 `WeatherOverviewDualCityFull@1`。

## 负向边界说明（Q085–Q096）

这些用例的能力、字段、参数和素材均来自 6.0，但按实际模板检索规则应当失败：

- 字段合法但没有任何提供方模板覆盖：Q086–Q088、Q091–Q093、Q095。
- 字段合法但 2x2 Full 无法覆盖：Q085、Q094、Q096。
- 尺寸不支持：Q089（2x4）。
- 多业务没有合法 Action：Q090。

## 合并后分布

| 维度 | 结果 |
| --- | --- |
| 数据条数 | 96（正向 84，负向 12） |
| 能力出现次数 | {'ViewWeather': 17, 'GetCalendarEvents': 16, 'GetCountdownDays': 16, 'GetEarphoneInfo': 16, 'GetPhoneBatteryInfo': 16, 'GetHealthAndSportSummary': 16} |
| 单能力/双能力行 | 95 / 1（Q090 为双能力负向） |
| 请求字段数 | {1: 29, 2: 24, 3: 19, 4: 20, 5: 5} |
| 每行事件数 | {0: 47, 1: 40, 2: 9} |
| 每行素材数 | {1: 23, 2: 57, 3: 16} |
| 尺寸 | 2x2：95；2x4：1 |

正向集仍按每个能力 14 条均匀分布。合并统计中 Q090 同时包含天气和倒计时两个绑定，因此能力总次数分别为天气 17、其他能力 16；这是为了保留“多业务无 Action”负向边界，不改变正向集均匀度。

## 校验

- Q001–Q096 共 96 个 JSON 全部解析成功，编号连续。
- 所有正向和负向 `candidateOutputFields` 均存在于对应 6.0 outputSchema。
- 所有能力参数、事件和素材均通过 6.0 注册表校验；电池路径统一为 `/data/phoneBattery`。
- 正向实际重放结果为 84/84 命中；负向实际重放结果为 12/12 未命中。
- [template_expected.json](template_expected.json) 是统一旁车映照表：正向为 `inputClass=normal/boundary`，负向 Q085–Q096 为 `inputClass=negative-boundary`，且 `expectedRoute=template-miss-fallback`。

本地默认配置缺少可选键 `ai_widget_data_huashan_enable`；重放时仅在进程内按关闭处理，未修改配置文件或服务代码。
