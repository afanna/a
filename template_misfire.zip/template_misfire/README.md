# template_misfire — 模板误触发测试集（两轴合一）

本目录是模板误触发的唯一数据出口，含两根轴。两轴都必须跑，只跑任一根都会高估覆盖。

| 子目录 | 轴 | 条数 | 编号 | 变量 | 判分 |
| --- | --- | --- | --- | --- | --- |
| `field_axis/` | 字段消融 | 240 | Q082–Q321 | 抽掉 primary / secondary，或追加模板不覆盖却被显式要求的字段 | 目标 `templateId` 未出现在 Search 候选 |
| `semantic_axis/` | 语义错配 | 54 | Q322–Q375 | 字段、尺寸、动作、图标全不动，只改 `userQuery` 业务语义 | 分三层，见下 |

母本正向集是 `../template`（68 条，Q001–Q068；2026-09-22 删掉 13 条不触发模板的用例后重编号），两轴都从它克隆，本目录不写回母本。

## 为什么必须分两轴

`field_axis` 的 240 条里字段是残缺的，Search 的两道确定性硬门就能排除，与语义无关；它证明不了"字段齐但业务不对"时会不会乱套模板。`semantic_axis` 刻意保持字段完备，把唯一的判断权交给语义。

## 分层断言（读代码后的结论，已用门回放验证）

`template_retrieval.py` 的 `query_tokens` 由 **TaskSpec 的 `candidateOutputFields`** 构造（`_task_spec_field_token`，第 1032 行 subset 判定），不解析 `userQuery` 文本；且按 `dataRoot`/binding 分组求字段。所以语义轴不能沿用"目标模板不得进 Search 候选"的口径——照它判会得到误检率≈100% 的假结果。`semantic_axis` 每条带 `misfireAssertedAt`：

| 层 | 条数 | 判据 |
| --- | --- | --- |
| `final-template` | 47 | 最终 CardSpec 采用的 templateId 不得落在 `forbiddenTemplateIds`；采用 `expectedTemplateIds` 内兄弟模板不算误检 |
| `search-gate` | 1 | Q367（编辑加字段超出模板覆盖）确实由字段门排除，按 Search 层判 |
| `preflight` | 6 | 只判是否在生成前终止，出现任何产物即失败，不进误检率分母 |

门回放实测：36 条假阳性探针有 ≥1 个母本族模板能过两道硬门，确实走到 planner；11 条 hit/amb 的期望模板可达。

## 误检率分母

`semantic_axis` 禁止槽位合计 618，按族极不均：WeatherOverview 198、Calendar(Schedule)Overview 176、Battery 91、Bluetooth 75、Countdown 24、HeartRate/Activity/Sleep 各 18 —— 天气+日程占约 60%。因此：

1. 按族分别报，不要合成一个总数；
2. 写明是"每探针一票"还是"每 templateId 一票"；
3. 分母只含假阳性探针（43 条，其中 1 条判在 search-gate、6 条 preflight 剔出），`hit` 9 条算漏触发率，`amb` 2 条只记录选择。

## 族名映射

母本集族标签与注册表 templateId 前缀不一致：母本写 `CalendarOverview`，注册表实际是 `ScheduleOverview@1` 系列 22 个。映射集中在 `paths.mjs` 与 `build_semantic_perturbation.mjs` 的 `FAMILY_PREFIX`，并写进两轴 manifest，避免按标签静默匹配到 0 个模板。

## 跑一遍

```powershell
cd C:\Users\afan\Desktop\卡片\query\CreateMyCard230\taskspec\template_misfire
node build_semantic_perturbation.mjs        # 重新生成语义轴（写 semantic_axis/）
node check_semantic_perturbation.mjs        # 单变量纪律、族与 templateId 互斥、分层一致、编号不冲突、族配额
node audit_perturbation_gates.mjs --axis field --strict
node audit_perturbation_gates.mjs --axis semantic --strict
node check_perturbation_assets.mjs          # field_axis 的素材使用与 emoji 覆盖统计
node audit_field_vacuity.mjs                # field_axis 空负样本审计（当前 238 real-negative / 2 superset / 0 vacuous）
node verify_renumber.mjs                    # 母本重编号后：编号连续、manifest 与文件一致、语义轴引用无未登记差异
```

`--strict` 会把两类无效探针直接判失败：假阳性的禁止族里没有任何模板能过字段门（空探针，永远不会误触发），以及 hit/amb 的期望模板根本不可达。上一版就有 1 条空探针（Q345 的活动族字段根本凑不齐），已通过换第二母本修掉。

## 数据源与写回

`paths.mjs` 是唯一路径出口。注意 `field_axis` 的能力注册表与 provider 资源原本取自 **CreateMyCard-main** 那套（v1 的生成环境），已在 `paths.mjs` 里显式标注并可用 `MISFIRE_LEGACY_PACKAGE` 环境变量切换；改成 230 需要重跑 `build_perturbation_dataset.mjs` 并逐条比对差异后再切，我没有替你改。`build_perturbation_dataset.mjs` 与 `apply_anti_cover_pass.mjs` 是写 `field_axis/` 的生成器，除非要重跑 v1，否则别执行——`semantic_axis` 不依赖它们。

## 已知缺口

1. 还没有跑链路的判分脚本：需要最终采用的 `templateId` 从哪个输出字段读，以及 Search 候选列表的落盘格式。
2. `WorkoutOverview` 族 0 条语义探针（母本把四个健康族并成一个标签）。
3. `semantic_axis` 有 4 条借用 `Phase_opendomain` 未回填条目的 query（Q349、Q350、Q351、Q353），校验器持续给警告。
4. 族对但字段错绑、空态渲染两类判不出，需要结构级或人工判读。
5. `field_axis` 数据未因合并改动；旧快照存档已随目录改名为 `field_axis_snapshot.zip`；其 `reusedTaskSpecCase` 仍是重编号前的旧号，换算表见 `field_axis/baseline_case_mapping.json`。
