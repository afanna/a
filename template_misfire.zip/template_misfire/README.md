# 模板误触发测试集

**策略**：本集每条用例都必须是**能通过微服务校验的合法输入**。会被 preflight 或参数校验拒绝的载荷（未知能力、非规范出参、非法或重复写入根、缺必填入参、未知事件、事件 call 不一致、未知素材、不支持的尺寸）不属于"误触发"，而是"提交即被拒"，混进来只会污染指标，因此一律不入本集。

三组按测试目的划分（编号连续，2026-09-23 剔除被拒用例、去整条重复后重排）：

| 轴 | 范围 | 条数 | 测什么 | 判定层 |
| --- | --- | --- | --- | --- |
| `field_axis/` | Q082–Q321 | 240 | 缺 primary / 缺 secondary / 超集未覆盖字段 | Search 是否排除目标 `templateId` |
| `semantic_axis/` | Q322–Q361 | 40 | 字段完整但业务语义错配、跨族竞争、开域误套、空态、语言与否定变体 | 最终采用的模板与渲染结果 |
| `boundary_axis/` | Q362–Q401 | 40 | 上述两轴的阶段化扩展（字段边界、语义错配、多能力竞争、空态/编辑/样式） | 按每条 `assertedAt` |

合计 320 条，三条口径下**输入全部唯一**（见下方去重说明）。`manifest.json` 是总索引，各轴清单为 `field_axis/manifest.json`、`semantic_axis/perturbation_expected.json`、`boundary_axis/manifest.json`。

## 判定口径要点

- 字段轴：字段残缺时 Search 硬门本就应排除目标模板，断言"`templateId` 不进候选"。兄弟模板可以进。
- 语义轴：**不能**用"候选为空"判定。Search 的 `query_tokens` 由 `candidateOutputFields` 构造（`template_retrieval.py` 的 `_task_spec_field_token`、第 1032 行 subset 判定），字段完备时模板必然进候选，所以只能查最终采用与渲染。
- 覆盖率统计要按 `duplicateOf` 去重（boundary 有 14 条与 semantic 同题），否则误触发覆盖率虚高。

## 2026-09-23 去整条重复 + 去泄题（357 → 320）

**field_axis 泄题修正（一次性脚本已删，新旧对照留在每条记录的 `sourceLabel`）**：原先 240 条的载荷 `title` 写着 `ActivityOverviewCompact@1 缺主数据`、`description` 写着 `移除 primaryData /dailySteps。`，等于把目标模板 id 和缺陷说明直接喂给模型。现在：

- 载荷 `title` 按该条真正展示的字段取名（今日活动/左右耳机/全天日程…共 44 种），`description` 是字段摘要或业务化说法（211 种），句式对齐 `template/`、`Phase_emoji` 的真实风格。
- 模板 id 与缺陷信息移到清单侧：`templateId`、`defectKind`（missing-primary / missing-secondary / superset-uncovered）、`removedFieldPaths`，原始标签保留在 `sourceLabel` 便于追溯。
- 同一 (userQuery + 候选) 的 41 组 115 条里，除首条外改写 74 条句式；改写**只换说法，不改变提到的字段集合**，单变量纪律不变。改写后同输入重复 0 条。

**boundary_axis 去重（`dedupe_axis.mjs boundary --apply`，已执行）**：第二、三阶段把同一用例生成了两三遍，77 条里有 37 条连输入带判定完全相同。剔除后 40 条，保留条的 `mergedFrom` 记录了被并入的旧号，载荷副本在 `_removed_duplicates/boundary/`（文件名带内容指纹）。按 (变体, 判定层, 能力, mutation 模式) 去重后是 24 个组合，**去重前后完全一致，覆盖面没有减少**。明细见 `deduped_boundary_report.json`。

判定"重复"的口径：输入指纹（归一化 userQuery + title + description + 尺寸 + 能力/参数/写入根/出参 + 事件 + 素材）**且**判定指纹（variant/assertedAt/expectedOutcome/mutation.mode/目标族）都相同才算；同文案不同候选是单变量对照，不算重复、不剔除。

**boundary_axis 全 40 条真实化重写**：这一轴的原始文案不是用户话，而是测试说明——`不要生成普通模板，请生成一张公开排期卡片，业务内容与原始字段语义不完全一致。`、`英文正向表达应正常命中。`、`同时展示手机电量与耳机，但主要只关心其中一个业务；检查多能力竞争时是否误选模板。`；title 形如 `字段边界：必须同时展示城市编码｜boundary-376`（带重编号前的旧号），description 形如 `explicit field boundary /location/cityCode；…`（内部字段路径进模型输入）；18 条还有 `…。；必须同时展示X` 的拼接缝，并且业务与候选完全对不上（"暖气片出水温度"配 `GetPhoneBatteryInfo`），等于一条用例同时改了两个变量。现在：

- 40 条 `userQuery` 全部重写成用户口吻，且按变体口径校正：`field-boundary` 业务与候选同域并自然提出那个额外字段；`semantic-mismatch` 业务与候选异域（首末班车/缴费提醒/手表电量/鱼缸水质…）；`multi-capability` 主次分明；`empty-edit-style` 用"手环没戴"这类真实说法代替"应显示空态"的断言。
- `title`/`description` 换成业务文案；改写前的合成标签整条留在清单侧 `sourceLabel`/`sourceQuery`。
- 只改这三个文本字段，脚本断言候选、尺寸、事件、素材、`session`、`deviceInfo` 逐字节未变。
- 顺带收口 field_axis 5 条"措辞 0.91–0.92 接近 + 候选相同"的用例（Q257/Q291/Q292/Q303/Q308），改写时断言提到的字段组等价。

## 2026-09-23 两次结构调整

**字段统一（`unify_axes.mjs`）**：原 `edge_axis` 更名 `boundary_axis`；`category`/`probeGroup` → `variant`；`misfireAssertedAt`(含 `search-gate`) 与 `assertedAt` 合并为 `assertedAt`，取值 `preflight | search | final-template`；`reusedTaskSpecCase` → `sourceCase`、第二母本 → `sourceCaseB`；缺陷标签从 `sourceCase` 拆到 `defectKind`。

**剔除被拒用例（`prune_rejected_cases.mjs`）**：按运行侧回报的失败清单 + 策略推导，从 semantic 移除 14 条、boundary 移除 29 条（含全部 `variant=preflight`、`expectedPreflight=fail`、编辑意图误放进 create 载荷、2x2 内合并多能力导致超载的用例），随后连续重编号并重挂 `sourceCase`/`sourceCaseB`/`duplicateOf`/`mutation.pair`。被剔载荷没有直接删除，集中在 `_removed_rejected/<轴>/`（`taskspec` 不在版本控制内，删了不可恢复），明细见 `pruned_rejected_report.json`。

`auto/` 的 8 条倒计时（A183–A190）属另一数据集，失败原因是 `GetCountdownDays` 缺必填 `targetDate`，已在 `../auto/` 内修复（3 条按 query 推导、5 条按授权填合法占位并标 `syntheticCountdownDates`）。

## 一次误删与恢复（Q361）

演练"没有可删项就要安全退出"的守卫时，我用了在册编号 `Q322,Q999` 作探针。重编号后 `Q322` 已指向另一条合法用例，于是它被真的删掉了；隔离区又因同名文件已存在（存的是另一条旧用例）跳过副本，原件随之被删——载荷彻底离开磁盘。守卫本身没问题，探针选错才是根因：**演练破坏性迁移只能用确定不在册的编号**。

恢复结果 `Q361`（构造键 M002，母本 `../template/Q004.json`，业务语义错配：运动诉求配天气字段）：

- 判定元数据整条取自 `_prestate_snapshot/semantic_axis__perturbation_expected.json`（原始 54 条记录，未被后续重排污染），未改动任何期望值。
- 候选、`size`、`session` 按语义轴的母本克隆约定照抄 `template/Q004`；`prdVer` 取同轴兄弟值（11.9.9.342）。
- `userQuery/title/description` 三条文本磁盘上已无副本，按 `semanticDelta` 重写，因此这条的记录带 `provenance` 字段说明重建来源。
- 恢复脚本先校验重建签名与快照 `templateSignature` 一致、再校验 `bindingCount/requestedDisplayFieldCount/eventCount/assetCount` 四项与快照一致，不一致就中止；边界轴 77 条与语义轴原 39 条已用内容哈希逐字节比对过备份，确认只有新增、没有串位。

`prune_rejected_cases.mjs` 同时修掉了放大这次损失的缺陷：隔离文件名加入内容指纹（`Q322__<hash8>.json`），并在副本未落盘时拒绝删除原件。

## 复跑与校验

```powershell
cd C:\Users\afan\Desktop\卡片\query\CreateMyCard230\taskspec\template_misfire
node check_axis_integrity.mjs                 # 只读：编号连续、manifest 与文件一致、引用可解析、无被拒声明
node check_duplicates.mjs                        # 只读：三档口径的唯一性与重复数、title 是否还含模板 id
node check_synthetic_text.mjs                 # 只读：拼接缝/测试说明口吻/旧编号/字段路径/模板 id 五类合成痕迹
node dedupe_axis.mjs boundary                 # 只读演练（默认 dry-run），确认没有新的整条重复
node unify_axes.mjs                           # 幂等迁移 + 跨轴断链检查
node ..\find_near_duplicates.mjs 0.9          # 跨全部数据集的文案雷同簇
node ..\audit_capability_legality.mjs --dirs=template_misfire   # 能力/动作/图标合法性 + 策略违规检查
node ..\diagnose_failures.mjs ""              # 全量按 preflight 规则做静态预判
node ..\classify_failures.mjs "<失败id清单>"   # 把运行侧失败按原因分桶
cd ..\..\..\query_agent
python check_dataset_near_duplicates.py       # 流水线同度量，分"真重复"与"同文案异候选"两桶
```

当前结果：320 条编号连续、断链 0、未预期非法 0、"预期被拒"声明 0、三档口径重复 0、五类合成痕迹全 0；按流水线度量**真重复 0 对**，field_axis 余 143 对"同文案异候选"是单变量对照、有意保留。

已知遗留：`../template/Q045` 与 `Q046` 文案相似度 0.900（只差"手机电量"与"电池健康状态"）。该目录由外部替换进来，按约定不改，只在此登记；若纳入本集统计，按"同文案异候选"口径处理或先改写。
