# 模板误触发测试集

**策略**：本集每条用例都必须是**能通过微服务校验的合法输入**。会被 preflight 或参数校验拒绝的载荷（未知能力、非规范出参、非法或重复写入根、缺必填入参、未知事件、事件 call 不一致、未知素材、不支持的尺寸）不属于"误触发"，而是"提交即被拒"，混进来只会污染指标，因此一律不入本集。

三组按测试目的划分（编号连续，2026-09-23 剔除被拒用例、去整条重复后重排）：

| 轴 | 范围 | 条数 | 测什么 | 判定层 |
| --- | --- | --- | --- | --- |
| `field_axis/` | Q082–Q334 | 253 | 缺 primary / 缺 secondary / 超集未覆盖字段 | Search 是否排除目标 `templateId` |
| `semantic_axis/` | Q335–Q374 | 40 | 字段完整但业务语义错配、跨族竞争、开域误套、空态、语言与否定变体 | 最终采用的模板与渲染结果 |
| `boundary_axis/` | Q375–Q414 | 40 | 上述两轴的阶段化扩展（字段边界、语义错配、多能力竞争、空态/编辑/样式） | 按每条 `assertedAt` |

合计 **333 条**，编号全局唯一且连续（Q082–Q414，三轴首尾相接），三条口径下**输入基本唯一**（见下方去重说明）。`manifest.json` 是总索引，各轴清单为 `field_axis/manifest.json`、`semantic_axis/perturbation_expected.json`、`boundary_axis/manifest.json`。`check_axis_integrity.mjs` 会查跨轴编号重复（2026-09-29 修过一次假检查：它原来对 Set 求数组找重复，永远查不出来）。

## 判定口径要点

- **本集任何模板被采用都算误触发**——目标模板算，兄弟模板也算。不给"允许兄弟模板"的白名单；复算出的可进候选只用作捕获 FP 的事实依据，不构成可接受答案。
- 字段轴：字段残缺时 Search 硬门本就应排除目标模板，断言"`templateId` 不进候选"。
- 语义轴：**不能**用"候选为空"判定。Search 的 `query_tokens` 由 `candidateOutputFields` 构造（`template_retrieval.py` 的 `_task_spec_field_token`、第 1032 行 subset 判定），字段完备时模板必然进候选，所以只能查最终采用与渲染。
- 覆盖率统计要按 `duplicateOf` 去重（boundary 有 14 条与 semantic 同题），否则误触发覆盖率虚高。

## 2026-09-29 用生产代码复算模板命中（`replay_preflight_and_search.py`）

复算走的是服务真链路，不是我另写一套规则：`GenerationPreflight(registry).run(request)`（当初拒掉 50 个 ID 的同一道闸门）→ 通过后用它产出的 `TaskSpec`/`CardSpec` 调 `search_template_variants()`（生产 Search 入口，`pipeline.py:189`；`retrieve_template_variants()` 只留给旧测试）。载荷里 `uid`/`device` 属于信封层，按 `provider_gallery._request_from_envelope` 的方式从 `userAuth.user.userId`、`deviceInfo` 补齐；首层 `action` 上限 2 且必须唯一，复算按此裁剪。

结论：

- **316 条全部通过 preflight**，素材引用、9 种能力、事件 call 全部在 rom-7.0 清单声明；不会因素材或能力被拒。
- **字段轴的构造缺陷**（已修）：`TaskSpecBuilder` 在 `candidateOutputFields` 为空或全部无法解析时，会**回退成该能力全部叶子**（`candidate_output_fields_fallback`），而首层的 `requiredOutputFieldsByCapability` 必须来自候选，所以"清空出参模拟缺主数据"的 16 条根本没进字段门，Search 直接报 `required output fields must come from candidates`。另有 3 条（Q084/Q085/Q304）声称缺字段但移掉的是目标模板**不要求**的字段，目标照样进候选。
- **修正规则**：候选出参必须非空、取自**目标模板同族字段域**（不跨族取字段，避免把语义错配混进字段轴）、且至少缺目标模板一个 `required` 字段。15 条已按此重建（`field_axis_probe_fix_report.json` 有 before/after），复算后**目标进候选 0 条**。
- **4 条无法构造**（待你定）：`Q166–Q169` 目标属 `CountdownOverview` 族，4 个模板都只要求 `/countdownDays`，而 `GetCountdownDays` 只有这一个叶子——不存在"非空候选且缺该字段"的构造法。
- 兄弟模板：复算显示 field_axis 34 条、semantic 29 条、boundary 24 条存在可进候选的模板。按上面的判定口径，这些若被采用一律记为误触发，不设置白名单。

复跑：`cd ..\\..\\..` 后 `python replay_preflight_and_search.py --dir=template_misfire`（逐条明细写入 `preflight_search_replay_template_misfire.json`）。


## 2026-09-29 服务级三层复检（请求模型 / 清单解析 / preflight）

`python ..\check_service_rejection.py --dir=auto,template_misfire,Phase_new_assets`：用服务自己的 `GenerateWidgetCardRequest` 做**不过滤字段**的模型校验、按 prdVer+rom 解析清单、再跑 `GenerationPreflight.run()`，逐条报 code。结果 726 条 **0 问题**。

这一层查出并修掉的问题（字段/声明层查不出来，因为字段本身是合法声明的）：

- **24 条用例的事件引用了指不到的数据路径**：`events/i/entityId` 这类索引占位写法（7 处）未归一，以及引用的字段没列进该绑定的 `candidateOutputFields`（24 处补入 `entityId`/`cityCode`）。由 `fix_event_data_refs.mjs` 修正，规则：补进去的字段必须是能力清单声明的叶子，且**不能是探针故意移除的那个字段**（有冲突保护）。
- **`Q353`**：日历绑定写在 `/data/calendar2`，而事件 `event.viewCalendarEvent` 的 actionTemplate 固定引用 `/data/calendar/...`。原先 preflight 判依赖不成立，**静默把事件剔除**（用例实际测的输入少了一个事件候选）；把引用改到 `/data/calendar2` 反而变成硬拒 `EVENT_DATA_PATH_INVALID`。正确做法是让绑定写回事件模板期望的 `/data/calendar` 并补 `entityId` 出参，现已修好。

复检口径：misfire 333 条生产 preflight **333/333 通过**、目标模板进候选 0、空候选 0；数据引用不可解析 0；能力/事件/素材声明核对 0 问题；编号 `Q082–Q414` 全局唯一连续。

## 2026-09-29 按最新模板清单对齐（316 → 333）

模板侧自 09-07 起新增 29 个、下线 9 个、字段归属变更 7 个（`node ..\template_diff_vs_baseline.mjs --base=2026-09-07` 可复查）。据此做了三件事（`align_field_axis.mjs`，报告 `field_axis_aligned_report.json`）：

- **修正 1 条失效探针**：`ScheduleOverviewNextEventLocationFull@1` 的 `dtEnd` 由 secondary 降为 optional，原"缺 dtEnd"不再排除它 → 改为缺 `/events/0/title`。
- **新增 19 条探针**覆盖此前无人引用的新模板：`ScheduleOverviewTimezoneTimeFull/DateLocationFull/ReminderDetailsFull@1`、`BluetoothDeviceOverviewEarbudPairHero@1`、`WeatherOverviewUpdatedAtFull/WindFull@1`。构造规则：候选=该模板自己要渲染的字段（required+optional）去掉**一个** required，其余保留，因此每条输入互不相同、语义就是这张卡的内容。
- **删除 2 条**：`Q289`（目标 `WeatherOverviewHeroTitle@1`）、`Q300`（目标 `WeatherOverviewTravelSupport@1`）——这两个模板 `primaryData`/`secondaryData` 都是空，字段门无法排除，必然可进候选，按"必触发即删"处理。

**登记但无法构造字段探针的模板**（要覆盖得换探针维度，如尺寸/动作/事件）：`CountdownOverview*` 4 个（能力只有 `/countdownDays` 一个叶子且全被要求）、`BatteryOverviewPercentLevelHero@1`（需 planner 兜底开关）、`ResourceUsageOverview*` 3 个（能力 `GetSystemMemInfo` 未在 rom-7.0 声明，模板不可达）。

复算结果：**333 条全部通过生产 preflight**，空候选 0、schema 叶子为 0 的 0、**目标模板进候选 0 条**；能力/素材声明核对 0 问题。过程中还修了复算器自身两个缺陷（`dataModelSchema` 里数组是真实 list，遍历漏掉导致日历族被误判退化；首层 `action` 上限 2 且需唯一）和 `check_axis_integrity` 的跨轴重复假检查。

## 2026-09-23 去整条重复 + 去泄题（357 → 320）

**field_axis 泄题修正（一次性脚本已删，新旧对照留在每条记录的 `sourceLabel`）**：原先 240 条的载荷 `title` 写着 `ActivityOverviewCompact@1 缺主数据`、`description` 写着 `移除 primaryData /dailySteps。`，等于把目标模板 id 和缺陷说明直接喂给模型。现在：

- 载荷 `title` 按该条真正展示的字段取名（今日活动/左右耳机/全天日程…共 44 种），`description` 是字段摘要或业务化说法（211 种），句式对齐 `template/`、`Phase_emoji` 的真实风格。
- 模板 id 与缺陷信息移到清单侧：`templateId`、`defectKind`（missing-primary / missing-secondary / superset-uncovered）、`removedFieldPaths`，原始标签保留在 `sourceLabel` 便于追溯。
- 同一 (userQuery + 候选) 的 41 组 115 条里，除首条外改写 74 条句式；改写**只换说法，不改变提到的字段集合**，单变量纪律不变。改写后同输入重复 0 条。

**boundary_axis 去重（`dedupe_axis.mjs boundary --apply`，已执行）**：第二、三阶段把同一用例生成了两三遍，77 条里有 37 条连输入带判定完全相同。剔除后 40 条，保留条的 `mergedFrom` 记录了被并入的旧号，载荷副本在 `_removed_duplicates/boundary/`（文件名带内容指纹）。按 (变体, 判定层, 能力, mutation 模式) 去重后是 24 个组合，**去重前后完全一致，覆盖面没有减少**。明细见 `deduped_boundary_report.json`。

判定"重复"的口径：输入指纹（归一化 userQuery + title + description + 尺寸 + 能力/参数/写入根/出参 + 事件 + 素材）**且**判定指纹（variant/assertedAt/expectedOutcome/mutation.mode/目标族）都相同才算；同文案不同候选是单变量对照，不算重复、不剔除。

**boundary_axis 全 40 条真实化重写**：这一轴的原始文案不是用户话，而是测试说明——`不要生成普通模板，请生成一张公开排期卡片，业务内容与原始字段语义不完全一致。`、`英文正向表达应正常命中。`、`同时展示手机电量与耳机，但主要只关心其中一个业务；检查多能力竞争时是否误选模板。`；title 形如 `字段边界：必须同时展示城市编码｜boundary-376`（带重编号前的旧号），description 形如 `explicit field boundary /location/cityCode；…`（内部字段路径进模型输入）；18 条还有 `…。；必须同时展示X` 的拼接缝，并且业务与候选完全对不上（"暖气片出水温度"配 `GetPhoneBatteryInfo`），等于一条用例同时改了两个变量。现在：

- 40 条 `userQuery` 全部重写成用户口吻，且按变体口径校正：`field-boundary` 业务与候选同域并自然提出那个额外字段；`semantic-mismatch` 业务与候选异域（首末班车/缴费提醒/手表电量/鱼缸水质…）；`multi-capability` 主次分明；`empty-edit-style` 用"手环没戴"这类真实说法代替"应显示空态"的断言。
- `title`/`description` 换成业务文案；改写前的合成标签整条留在清单侧 `sourceLabel`/`sourceQuery`。
- 只改这三个文本字段，脚本断言候选、尺寸、事件、素材、`session`、`deviceInfo` 逐字节未变。
- 顺带收口 field_axis 5 条"措辞 0.91–0.92 接近 + 候选相同"的用例（Q257/Q291/Q292/Q303/Q308），改写时断言提到的字段组等价。

## 2026-09-23 两次结构调整

**字段统一（`unify_axes.mjs`）**：原 `edge_axis` 更名 `boundary_axis`；`category`/`probeGroup` → `variant`；`misfireAssertedAt`(含 `search-gate`) 与 `assertedAt` 合并为 `assertedAt`，取值 `preflight | search | final-template`；`reusedTaskSpecCase` → `sourceCase`、第二母本 → `sourceCaseB`；缺陷标签从 `sourceCase` 拆到 `defectKind`。

**剔除被拒用例（`prune_rejected_cases.mjs`）**：按运行侧回报的失败清单 + 策略推导，从 semantic 移除 14 条、boundary 移除 29 条（含全部 `variant=preflight`、`expectedPreflight=fail`、编辑意图误放进 create 载荷、2x2 内合并多能力导致超载的用例），随后连续重编号并重挂 `sourceCase`/`sourceCaseB`/`duplicateOf`/`mutation.pair`。被剔载荷没有直接删除，集中在 `_removed_rejected/<轴>/`（`taskspec` 不在版本控制内，删了不可恢复），明细见 `pruned_rejected_report.json`。

`auto/` 的 8 条倒计时（A183–A190）属另一数据集，失败原因是 `GetCountdownDays` 缺必填 `targetDate`，已在 `../auto/` 内修复（3 条按 query 推导、5 条按授权填合法占位并标 `syntheticCountdownDates`）。

## 一次误删与恢复（Q361）

演练"没有可删项就要安全退出"的守卫时，我用了在册编号 `Q322,Q999` 作探针。重编号后 `Q322` 已指向另一条合法用例，于是它被真的删掉了；隔离区又因同名文件已存在（存的是另一条旧用例）跳过副本，原件随之被删——载荷彻底离开磁盘。守卫本身没问题，探针选错才是根因：**演练破坏性迁移只能用确定不在册的编号**。

恢复结果 `Q361`（构造键 M002，母本 `../template/Q004.json`，业务语义错配：运动诉求配天气字段）：

- 判定元数据整条取自 `_prestate_snapshot/semantic_axis__perturbation_expected.json`（原始 54 条记录，未被后续重排污染），未改动任何期望值。
- 候选、`size`、`session` 按语义轴的母本克隆约定照抄 `template/Q004`；`prdVer` 取同轴兄弟值（11.9.9.342）。
- `userQuery/title/description` 三条文本磁盘上已无副本，按 `semanticDelta` 重写，因此这条的记录带 `provenance` 字段说明重建来源。
- 恢复脚本先校验重建签名与快照 `templateSignature` 一致、再校验 `bindingCount/requestedDisplayFieldCount/eventCount/assetCount` 四项与快照一致，不一致就中止；边界轴 77 条与语义轴原 39 条已用内容哈希逐字节比对过备份，确认只有新增、没有串位。

`prune_rejected_cases.mjs` 同时修掉了放大这次损失的缺陷：隔离文件名加入内容指纹（`Q322__<hash8>.json`），并在副本未落盘时拒绝删除原件。

## 复跑与校验

```powershell
cd C:\Users\afan\Desktop\卡片\query\CreateMyCard230\taskspec\template_misfire
node check_axis_integrity.mjs                 # 只读：编号连续、manifest 与文件一致、引用可解析、无被拒声明
node check_duplicates.mjs                        # 只读：三档口径的唯一性与重复数、title 是否还含模板 id
node check_synthetic_text.mjs                 # 只读：拼接缝/测试说明口吻/旧编号/字段路径/模板 id 五类合成痕迹
node dedupe_axis.mjs boundary                 # 只读演练（默认 dry-run），确认没有新的整条重复
node drop_cases.mjs --axis=field --ids=Q999 --reason=...   # 删用例（隔离+重编号+重挂引用），默认 dry-run
node unify_axes.mjs                           # 幂等迁移 + 跨轴断链检查
node ..\verify_declared.mjs template_misfire  # 严格核对能力/出参/入参/事件/素材是否都在清单声明
python ..\replay_preflight_and_search.py --dir=template_misfire   # 生产 preflight + 生产 Search 复算模板命中
node ..\find_near_duplicates.mjs 0.9          # 跨全部数据集的文案雷同簇
node ..\audit_capability_legality.mjs --dirs=template_misfire   # 能力/动作/图标合法性 + 策略违规检查
node ..\diagnose_failures.mjs ""              # 全量按 preflight 规则做静态预判
node ..\classify_failures.mjs "<失败id清单>"   # 把运行侧失败按原因分桶
cd ..\..\..\query_agent
python check_dataset_near_duplicates.py       # 流水线同度量，分"真重复"与"同文案异候选"两桶
```

当前结果：**333 条**编号全局唯一且连续（Q082–Q414）、断链 0、未预期非法 0、"预期被拒"声明 0、五类合成痕迹全 0、口径2/口径3 输入重复 0（口径1 剩 1 对是同输入不同断言）；生产链路复算 preflight **333/333 通过**、空候选出参 0 条、目标模板进候选 0 条；按流水线度量**真重复 0 对**，field_axis 余 143 对"同文案异候选"是单变量对照、有意保留。

已知遗留：`../template/Q045` 与 `Q046` 文案相似度 0.900（只差"手机电量"与"电池健康状态"）。该目录由外部替换进来，按约定不改，只在此登记；若纳入本集统计，按"同文案异候选"口径处理或先改写。
