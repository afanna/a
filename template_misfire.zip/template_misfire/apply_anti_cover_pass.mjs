/**
 * 反覆盖覆写 pass（默认 dry-run，加 --apply 才写盘）。
 *
 * 判据来自 template_retrieval.py：
 *   ① 数据门 required(primary+secondary) ⊆ dataModelSchema —— 确定性；
 *   ② 覆盖门 explicit_fields ⊆ available —— explicit 由第一层从 query 抽取，概率性。
 * 兄弟模板同时过 ①② → 改写为该能力所有模板都失配的反覆盖集 F*（只依赖 ①）；
 * 只过 ① → 保留为模型探针 attribution=model；空投影按 task_spec_builder 全集回退后判定；
 * 无合法 F* 的能力（GetCountdownDays）改用同能力双 binding 命中 binding_count 门禁。
 */
import fs from "node:fs/promises";
import path from "node:path";
import { fieldAxisDir, legacyCapabilityRoot, legacyProviderRoot } from "./paths.mjs";

const APPLY = process.argv.includes("--apply");
const caseRoot = fieldAxisDir;
const capabilityRoot = legacyCapabilityRoot;
const providerRoot = legacyProviderRoot;

const CARD_NAMES = {
  GetPhoneBatteryInfo: "电池卡片", GetCalendarEvents: "日程卡片", GetCountdownDays: "倒计时卡片",
  GetEarphoneInfo: "耳机状态卡片", GetHealthAndSportSummary: "健康运动卡片", ViewWeather: "天气卡片",
};
// query 点名用：按优先级取第一个落在 F* 内的字段。反覆盖用例的判定只依赖数据门，
// 这里仅保证 query 自然、且点名字段确实在供给内（避免走 "required output fields must come from candidates" 异常路径）。
const QUERY_LABELS = {
  GetPhoneBatteryInfo: [["/chargingStatusDesc", "充电状态"], ["/batteryTemperatureText", "电池温度"], ["/healthStatusDesc", "电池健康度"]],
  GetCalendarEvents: [["/events/0/dtEnd", "结束时间"], ["/events/0/eventLocation", "会议地点"], ["/events/0/isAllDay", "是否全天"]],
  GetCountdownDays: [["/countdownDays", "剩余天数"]],
  GetEarphoneInfo: [["/earphoneName", "耳机名称"], ["/rightBatteryLevel", "右耳电量"], ["/updatedAt", "更新时间"]],
  GetHealthAndSportSummary: [["/dailyDistanceText", "运动距离"], ["/dailyTotalCaloriesText", "消耗的热量"], ["/sleepScore", "睡眠得分"]],
  ViewWeather: [["/current/temperatureText", "当前温度"], ["/current/airQuality", "空气质量"], ["/current/humidityPercent", "相对湿度"]],
};
const readJson = async (p) => JSON.parse(await fs.readFile(p, "utf8"));
const unique = (items) => [...new Set(items)];

function pointerLeaves(schema, prefix = "") {
  if (!schema || typeof schema !== "object") return [];
  if (schema.type === "array") return pointerLeaves(schema.items, `${prefix}/0`);
  if (schema.properties) return Object.entries(schema.properties).flatMap(([k, c]) => pointerLeaves(c, `${prefix}/${k}`));
  return prefix ? [prefix] : [];
}
function combinations(items, size) {
  if (size === 0) return [[]];
  const out = [];
  for (let i = 0; i <= items.length - size; i += 1)
    for (const rest of combinations(items.slice(i + 1), size - 1)) out.push([items[i], ...rest]);
  return out;
}
function minimumHittingSet(sets) {
  const universe = unique(sets.flat());
  for (let size = 1; size <= universe.length; size += 1)
    for (const combo of combinations(universe, size)) {
      const picked = new Set(combo);
      if (sets.every((set) => set.some((item) => picked.has(item)))) return combo;
    }
  return null;
}
const requiredOf = (t) => unique([...(t.primaryData ?? []), ...(t.secondaryData ?? [])]);
const availableOf = (t) => unique([...requiredOf(t), ...(t.optionalData ?? [])]);

async function main() {
  const dataCapabilities = await readJson(path.join(capabilityRoot, "data_capabilities.json"));
  const enabled = dataCapabilities.filter((c) => c.enabled !== false);
  const capabilityById = new Map(enabled.map((c) => [c.id, c]));

  const templates = new Map();
  for (const entry of await fs.readdir(providerRoot, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    let bundle;
    try { bundle = await readJson(path.join(providerRoot, entry.name, "provider.json")); } catch { continue; }
    const dataDomain = (bundle.capabilities ?? []).find((c) => capabilityById.has(c.capabilityId))?.dataDomain;
    for (const t of bundle.templates ?? [])
      if (t.capabilityId && capabilityById.has(t.capabilityId)) templates.set(t.templateId, { ...t, dataDomain });
  }

  const leavesByCapability = new Map([...capabilityById].map(([id, cap]) => [
    id, unique([...pointerLeaves(cap.outputSchema), ...[...templates.values()].filter((t) => t.capabilityId === id).flatMap(availableOf)]),
  ]));
  const antiCover = new Map();
  for (const capabilityId of capabilityById.keys()) {
    const sets = [...templates.values()].filter((t) => t.capabilityId === capabilityId).map(requiredOf).filter((s) => s.length);
    if (!sets.length) continue;
    const removed = minimumHittingSet(sets);
    if (!removed) continue;
    const fields = leavesByCapability.get(capabilityId).filter((f) => !new Set(removed).has(f));
    if (fields.length) antiCover.set(capabilityId, { fields, removed });
  }

  const manifest = await readJson(path.join(caseRoot, "perturbation_expected.json"));
  const journal = [];
  const counts = { rewritten: 0, dualBinding: 0, modelProbe: 0, kept: 0 };

  for (const testCase of manifest.cases) {
    const filePath = path.join(caseRoot, testCase.file);
    const taskSpec = await readJson(filePath);
    const { capabilityId } = testCase;
    const target = templates.get(testCase.templateId);
    const bindings = taskSpec.content.candidateDataBindings ?? [];
    const supplied = unique(bindings.flatMap((b) => b.candidateOutputFields ?? []));
    const runtimeFields = supplied.length ? supplied : (leavesByCapability.get(capabilityId) ?? []);
    const siblings = [...templates.entries()].filter(([id, t]) => id !== testCase.templateId && t.capabilityId === capabilityId);
    const passes = (t) => requiredOf(t).every((f) => runtimeFields.includes(f));
    const covered = (t) => runtimeFields.every((f) => availableOf(t).includes(f));
    const hardSibling = siblings.find(([, t]) => passes(t) && covered(t));
    const softSibling = siblings.find(([id, t]) => passes(t) && !covered(t) && id !== hardSibling?.[0]);

    if (!hardSibling) {
      if (softSibling) { testCase.attribution = "model"; testCase.siblingRequiringTrim = softSibling[0]; counts.modelProbe += 1; }
      else { testCase.attribution = "service"; counts.kept += 1; }
      if (APPLY) await fs.writeFile(filePath, `${JSON.stringify(taskSpec, null, 2)}\n`, "utf8");
      continue;
    }

    const before = { fields: supplied, bindingCount: bindings.length, query: taskSpec.content.userQuery, hardSibling: hardSibling[0] };
    const cover = antiCover.get(capabilityId);
    if (cover) {
      taskSpec.content.candidateDataBindings = [{ ...(bindings[0] ?? {}), capabilityId, candidateOutputFields: cover.fields }];
      testCase.bindingCount = 1;
      counts.rewritten += 1;
    } else {
      const root = target?.dataDomain ?? "/data/countdown";
      const field = requiredOf(target)[0] ?? (leavesByCapability.get(capabilityId) ?? [])[0];
      taskSpec.content.candidateDataBindings = [1, 2].map((i) => ({
        capabilityId, arguments: bindings[0]?.arguments ?? {}, writeResultTo: `${root}${i}`, candidateOutputFields: [field],
      }));
      testCase.antiCoverRemovedPaths = [];
      testCase.bindingCount = 2;
      counts.dualBinding += 1;
    }
    const removed = testCase.antiCoverRemovedPaths ?? cover.removed;
    testCase.antiCoverRemovedPaths = removed;
    const witness = requiredOf(target).filter((f) => removed.includes(f));
    testCase.requiredWitness = witness;
    const labelPool = cover ? cover.fields : runtimeFields;
    const labels = (QUERY_LABELS[capabilityId] ?? []).filter(([f]) => labelPool.includes(f)).slice(0, 2).map(([, label]) => label);
    const query = `帮我做个${CARD_NAMES[capabilityId] ?? "信息卡片"}，看${labels.join("、") || "相关信息"}。`;
    Object.assign(taskSpec.content, {
      userQuery: query,
      title: `${testCase.templateId} 反覆盖集`,
      description: `反覆盖集：整能力移除 ${removed.join("、")}；目标模板硬前置命中 ${witness.join("、") || "（由 binding_count 排除）"}。`,
      candidateAssetIds: (taskSpec.content.candidateAssetIds ?? []).slice(0, 2),
    });
    Object.assign(taskSpec, {
      userQuery: taskSpec.content.userQuery, title: taskSpec.content.title, description: taskSpec.content.description,
      candidateDataBindings: taskSpec.content.candidateDataBindings, candidateAssetIds: taskSpec.content.candidateAssetIds,
      size: taskSpec.content.size, candidateEventCandidates: taskSpec.content.candidateEventCandidates,
      utterance: { ...(taskSpec.utterance ?? {}), original: query, type: "text" },
    });
    testCase.variant = cover ? "anti-cover" : "anti-cover-binding-count";
    testCase.variantLabel = "反覆盖集";
    testCase.mutationPaths = removed;
    testCase.attribution = "service";
    testCase.expectedSearchEligibility = "ineligible";
    testCase.expectationReason = cover
      ? "数据门 required ⊄ F*：该能力全部模板（含兄弟模板）的 primary+secondary 至少缺 1 个字段，Search 无任何候选。"
      : "该能力无合法反覆盖集，改用同能力双 binding，binding_count != len(data_roots) 使全部单绑定模板失配。";
    journal.push({ caseId: testCase.caseId, templateId: testCase.templateId, capabilityId, before,
      after: { fields: taskSpec.content.candidateDataBindings.flatMap((b) => b.candidateOutputFields ?? []),
               bindingCount: taskSpec.content.candidateDataBindings.length, removed, witness, query } });
    if (APPLY) await fs.writeFile(filePath, `${JSON.stringify(taskSpec, null, 2)}\n`, "utf8");
  }

  manifest.summary = { ...manifest.summary, mode: APPLY ? "applied" : "dry-run",
    antiCoverRewritten: counts.rewritten, dualBindingRewritten: counts.dualBinding, modelProbes: counts.modelProbe, keptAsIs: counts.kept };
  manifest.scope.antiCoverByCapability = Object.fromEntries([...antiCover].map(([id, v]) => [id, { keptFields: v.fields.length, removedFields: v.removed }]));
  if (APPLY) {
    await fs.writeFile(path.join(caseRoot, "perturbation_expected.json"), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
    await fs.writeFile(path.join(caseRoot, "rewrite_manifest.json"), `${JSON.stringify({ generatedAt: new Date().toISOString(), mode: "applied", counts, cases: journal }, null, 2)}\n`, "utf8");
  }
  const violations = [];
  for (const entry of journal) {
    const groups = [...templates.values()].filter((t) => t.capabilityId === entry.capabilityId);
    if (entry.after.bindingCount > 1) {
      if (groups.some((t) => (t.bindingCount ?? 1) > 1)) violations.push({ caseId: entry.caseId, note: "存在多绑定模板，binding_count 门禁不足以排除全部" });
      continue;
    }
    const leaked = groups.filter((t) => requiredOf(t).length && requiredOf(t).every((f) => entry.after.fields.includes(f)));
    if (leaked.length) violations.push({ caseId: entry.caseId, templateId: entry.templateId, leaked: leaked.map((t) => t.templateId) });
    const unreachableByGate = groups.filter((t) => requiredOf(t).length === 0);
    if (unreachableByGate.length) violations.push({ caseId: entry.caseId, templateId: entry.templateId,
      note: "该能力存在无 required 数据的模板，数据门无法排除", templates: unreachableByGate.map((t) => t.templateId) });
  }
  const witnesses = journal.filter((entry) => entry.after.witness.length === 0 && entry.after.bindingCount === 1);
  console.log(JSON.stringify({ mode: APPLY ? "APPLIED" : "DRY-RUN", counts,
    templates: templates.size, capabilitiesWithoutAntiCover: [...capabilityById.keys()].filter((c) => !antiCover.has(c)),
    antiCoverSelfCheck: { rewrittenCases: journal.length, dataGateViolations: violations, casesWithoutAttributionWitness: witnesses.map((e) => e.caseId) },
    distinctQueries: unique(journal.map((entry) => entry.after.query)),
    probeSamples: manifest.cases.filter((c) => c.attribution === "model").slice(0, 6).map((c) => `${c.caseId} ${c.templateId} ← ${c.siblingRequiringTrim}`) }, null, 2));
}

await main();
