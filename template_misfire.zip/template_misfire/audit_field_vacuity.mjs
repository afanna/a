import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// 检查 field_axis 的负样本是否"空负样本"：
// 把被抽掉的字段补回去（=未扰动基线），若目标模板那时仍过不了两道硬门，
// 说明这条用例的"目标模板被排除"与扰动无关，测不到任何东西。
import { fieldAxisDir, legacyProviderRoot } from "./paths.mjs";

const providerRoot = legacyProviderRoot;
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const bundles = fs.readdirSync(providerRoot, { withFileTypes: true }).filter((e) => e.isDirectory()).flatMap((e) => {
  try { return [readJson(path.join(providerRoot, e.name, "provider.json"))]; } catch { return []; }
});
const templates = new Map();
for (const b of bundles) for (const t of b.templates ?? []) if (t.capabilityId) templates.set(t.templateId, t);

const manifest = readJson(path.join(fieldAxisDir, "perturbation_expected.json"));
const rows = [];
for (const c of manifest.cases) {
  const t = templates.get(c.templateId);
  if (!t) { rows.push({ case: c.caseId, verdict: "template-not-in-provider" }); continue; }
  const spec = readJson(path.join(fieldAxisDir, c.file));
  const fields = new Set((spec.candidateDataBindings ?? []).flatMap((b) => b.candidateOutputFields ?? []));
  const required = [...(t.primaryData ?? []), ...(t.secondaryData ?? [])];
  const available = new Set([...required, ...(t.optionalData ?? [])]);
  if (c.variant === "uncovered-valid-field") {
    rows.push({ case: c.caseId, verdict: "superset-variant-skipped" });
    continue;
  }
  const mutated = required.every((f) => fields.has(f)) && [...fields].every((f) => available.has(f));
  const restored = new Set(fields);
  for (const p of c.mutationPaths ?? []) restored.add(p);
  const wouldMatchAfterRestore = required.every((f) => restored.has(f)) && [...restored].every((f) => available.has(f));
  rows.push({
    case: c.caseId,
    template: c.templateId,
    variant: c.variant,
    baseline: c.reusedTaskSpecCase,
    verdict: mutated ? "already-matching-mutation-ineffective" : wouldMatchAfterRestore ? "real-negative" : "vacuous-restored-still-miss",
    fieldsNow: [...fields].length,
    required: required.length
  });
}
const tally = rows.reduce((a, r) => ((a[r.verdict] = (a[r.verdict] ?? 0) + 1), a), {});
const byBaseline = {};
for (const r of rows) if (r.baseline) (byBaseline[r.baseline] ??= {})[r.verdict] = (byBaseline[r.baseline][r.verdict] ?? 0) + 1;
console.log(JSON.stringify({
  total: rows.length,
  tally,
  vacuousByBaseline: Object.fromEntries(Object.entries(byBaseline).filter(([, v]) => v["vacuous-restored-still-miss"]).map(([k, v]) => [k, v])),
  ineffectiveByBaseline: Object.fromEntries(Object.entries(byBaseline).filter(([, v]) => v["already-matching-mutation-ineffective"]).map(([k, v]) => [k, v])),
  sampleVacuous: rows.filter((r) => r.verdict === "vacuous-restored-still-miss").slice(0, 6)
}, null, 2));
