/**
 * 静态回放 template_retrieval.py 的两条 Search 硬门，验证 perturbation_v1：
 * ① 数据门：required(primary+secondary) ⊆ dataModelSchema 字段；
 * ② 覆盖门：query 显式字段(=用例 candidateOutputFields) ⊆ 模板可覆盖字段(primary+secondary+optional)。
 * 忽略运行时才可见的 size/binding/discriminator 细节，结论按“目标模板必被排除”口径统计。
 */
import fs from "node:fs/promises";
import path from "node:path";
import { fieldAxisDir, semanticAxisDir, legacyProviderRoot } from "./paths.mjs";

const providerRoot = legacyProviderRoot;
// --axis field（默认，v1 字段消融集）| --axis semantic（v2 语义轴，用于验证探针是否真的能通过两条硬门）
const axis = process.argv.includes("--axis") ? process.argv[process.argv.indexOf("--axis") + 1] : "field";
const caseRoot = axis === "field" ? fieldAxisDir : axis === "semantic" ? semanticAxisDir : null;
if (!caseRoot) throw new Error("--axis 只能是 field 或 semantic");
console.log(`audit axis=${axis}`);

const readJson = async (p) => JSON.parse(await fs.readFile(p, "utf8"));

const bundles = [];
for (const entry of await fs.readdir(providerRoot, { withFileTypes: true })) {
  if (!entry.isDirectory()) continue;
  try { bundles.push(await readJson(path.join(providerRoot, entry.name, "provider.json"))); } catch { /* non-template providers */ }
}
const templates = new Map();
for (const bundle of bundles) {
  for (const template of bundle.templates ?? []) {
    if (template.capabilityId) templates.set(template.templateId, template);
  }
}

const manifest = await readJson(path.join(caseRoot, "perturbation_expected.json"));

if (axis === "semantic") {
  // 运行时按 dataRoot/binding 分组求 query_tokens（template_retrieval.py 第 566-590 行），
  // 同能力的两条 binding 是两个独立 dataRoot，必须逐 binding 判门，合并字段会造出假超集。
  const bindingsOf = (taskSpec) =>
    (taskSpec.candidateDataBindings ?? []).map((b) => ({ capabilityId: b.capabilityId, fields: b.candidateOutputFields ?? [], dataRoot: b.writeResultTo }));
  const gateFor = (id, bindings) => {
    const t = templates.get(id);
    if (!t) return null;
    const required = [...(t.primaryData ?? []), ...(t.secondaryData ?? [])];
    const available = new Set([...required, ...(t.optionalData ?? [])]);
    const hit = bindings.some(
      (b) => b.capabilityId === t.capabilityId && required.every((f) => b.fields.includes(f)) && b.fields.every((f) => available.has(f))
    );
    return hit;
  };
  const rows = [];
  for (const testCase of manifest.cases) {
    if (testCase.misfireAssertedAt !== "final-template") continue;
    const taskSpec = await readJson(path.join(caseRoot, testCase.file));
    const groups = bindingsOf(taskSpec);
    const forbiddenEligible = testCase.forbiddenTemplateIds.filter((id) => gateFor(id, groups) === true);
    const forbiddenExcluded = testCase.forbiddenTemplateIds.filter((id) => gateFor(id, groups) === false);
    const expectedEligible = testCase.expectedTemplateIds.filter((id) => gateFor(id, groups) === true);
    const unknown = testCase.forbiddenTemplateIds.filter((id) => !templates.has(id));
    rows.push({
      case: testCase.caseId,
      direction: testCase.probeDirection,
      family: testCase.targetTemplateFamily,
      capabilities: [...new Set(groups.map((b) => b.capabilityId))].join("+"),
      bindingCount: groups.length,
      forbiddenSize: testCase.forbiddenTemplateIds.length,
      forbiddenStillEligibleAtSearch: forbiddenEligible.length,
      forbiddenExcludedAtSearch: forbiddenExcluded.length,
      expectedEligibleAtSearch: expectedEligible.length,
      unknownTemplateIds: unknown.length,
      verdict:
        testCase.probeDirection === "fp"
          ? forbiddenEligible.length
            ? "reaches-planner"
            : "already-excluded-by-field-gate"
          : expectedEligible.length
            ? "reachable"
            : "expected-template-unreachable"
    });
  }
  const byVerdict = rows.reduce((a, r) => ((a[r.verdict] = (a[r.verdict] ?? 0) + 1), a), {});
  const vacuous = rows.filter((r) => r.verdict === "already-excluded-by-field-gate").map((r) => r.case);
  const unreachable = rows.filter((r) => r.verdict === "expected-template-unreachable").map((r) => r.case);
  if (process.argv.includes("--strict") && (vacuous.length || unreachable.length)) {
    console.error(`空探针：fp 禁止族无一模板可过门 ${vacuous.join(",") || "无"}；hit/amb 期望族不可达 ${unreachable.join(",") || "无"}`);
    process.exit(1);
  }
  console.log(JSON.stringify({
    axis: "semantic",
    evaluated: rows.length,
    byVerdict,
    fpProbesActuallyBlockedByFieldGate: rows.filter((r) => r.verdict === "already-excluded-by-field-gate").map((r) => r.case),
    fpProbesReachingPlanner: rows.filter((r) => r.verdict === "reaches-planner").length,
    unreachableExpected: rows.filter((r) => r.verdict === "expected-template-unreachable").map((r) => r.case),
    sample: rows.slice(0, 6)
  }, null, 2));
  process.exit(0);
}

const results = { total: 0, targetStillEligible: [], siblingMatches: 0, noSibling: [], byVariant: {} };

for (const testCase of manifest.cases) {
  const taskSpec = await readJson(path.join(caseRoot, testCase.file));
  const fields = [...new Set((taskSpec.candidateDataBindings ?? []).flatMap((b) => b.candidateOutputFields ?? []))];
  const target = templates.get(testCase.templateId);
  const required = [...(target.primaryData ?? []), ...(target.secondaryData ?? [])];
  const available = new Set([...required, ...(target.optionalData ?? [])]);
  const dataGate = required.every((field) => fields.includes(field));
  const coverageGate = fields.every((field) => available.has(field));
  const targetEligible = dataGate && coverageGate;
  const siblings = [...templates.values()].filter((candidate) => {
    if (candidate === target || candidate.capabilityId !== target.capabilityId) return false;
    const candidateRequired = [...(candidate.primaryData ?? []), ...(candidate.secondaryData ?? [])];
    const candidateAvailable = new Set([...candidateRequired, ...(candidate.optionalData ?? [])]);
    return candidateRequired.every((field) => fields.includes(field)) && fields.every((field) => candidateAvailable.has(field));
  }).map((candidate) => candidate.templateId);
  results.total += 1;
  const variant = testCase.variant;
  results.byVariant[variant] ??= { count: 0, targetEligible: 0, withSibling: 0 };
  results.byVariant[variant].count += 1;
  if (targetEligible) results.targetStillEligible.push({ case: testCase.caseId, template: testCase.templateId, variant, fields });
  else results.byVariant[variant].targetEligible += 1;
  if (siblings.length) { results.siblingMatches += 1; results.byVariant[variant].withSibling += 1; }
  else results.noSibling.push(testCase.caseId);
  if (variant === "uncovered-valid-field" && !taskSpec.userQuery.includes("城市代码")) {
    results.targetStillEligible.push({ case: testCase.caseId, template: testCase.templateId, variant, note: "query 未显式请求追加字段" });
  }
}

console.log(JSON.stringify({
  total: results.total,
  targetExcludedByHardGates: results.total - results.targetStillEligible.length,
  targetStillEligible: results.targetStillEligible,
  casesWithLegitimateSiblingTemplate: results.siblingMatches,
  casesWithNoSiblingAtAll: results.noSibling.length,
  byVariant: results.byVariant,
}, null, 2));
