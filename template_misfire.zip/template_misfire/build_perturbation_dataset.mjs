import fs from "node:fs/promises";
import path from "node:path";
import { fieldAxisDir, legacyCapabilityRoot, legacyProviderRoot } from "./paths.mjs";

// 数据写进合并后的 field_axis；能力与 provider 资源仍按 v1 原始生成环境读取，见 paths.mjs
const outputRoot = fieldAxisDir;
const capabilityRoot = legacyCapabilityRoot;
const providerRoot = legacyProviderRoot;
const prdVer = "11.8.8.342";
const runtimeRomVersion = "7.0";

const readJson = async (filePath) => JSON.parse(await fs.readFile(filePath, "utf8"));
const unique = (items) => [...new Set(items)];

function pointerLeaves(schema, prefix = "") {
  if (!schema || typeof schema !== "object") return [];
  if (schema.type === "array") return pointerLeaves(schema.items, `${prefix}/0`);
  if (schema.properties) {
    return Object.entries(schema.properties).flatMap(([key, child]) => pointerLeaves(child, `${prefix}/${key}`));
  }
  return prefix ? [prefix] : [];
}

function sampleValue(schema) {
  if (Object.hasOwn(schema ?? {}, "default")) return schema.default;
  if (Object.hasOwn(schema ?? {}, "const")) return schema.const;
  if (schema?.enum?.length) return schema.enum[0];
  switch (schema?.type) {
    case "string": return "测试";
    case "integer": return Number.isFinite(schema.minimum) ? schema.minimum : 1;
    case "number": return Number.isFinite(schema.minimum) ? schema.minimum : 1;
    case "boolean": return true;
    case "array": return [sampleValue(schema.items)];
    case "object": return Object.fromEntries(Object.entries(schema.properties ?? {}).map(([key, value]) => [key, sampleValue(value)]));
    default: return null;
  }
}

function defaultArguments(capability) {
  const args = Object.fromEntries((capability.inputSchema?.required ?? []).map((key) => [key, sampleValue(capability.inputSchema.properties?.[key])]));
  if (capability.id === "ViewWeather") return { prefectureName: "上海市", districtName: "浦东新区", forecastDays: 1 };
  if (capability.id === "GetCalendarEvents") return { futureDays: 7 };
  if (capability.id === "GetCountdownDays") return { targetDate: "2026-09-20" };
  if (capability.id === "GetHealthAndSportSummary") return { targetDayOffset: 0 };
  return args;
}

function maxDailyIndex(fields) {
  return Math.max(-1, ...fields.map((field) => {
    const match = field.match(/^\/daily\/(\d+)\//);
    return match ? Number(match[1]) : -1;
  }));
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function buildEvent(event) {
  return { capabilityId: event.id, action: clone(event.actionTemplate) };
}

function templateTitle(template, variant) {
  return `${template.templateId} ${variant}`;
}

const fieldLabels = {
  "/appUsage/appName": "应用名称", "/appUsage/durationText": "使用时长",
  "/availableMemText": "可用内存", "/totalMemText": "总内存", "/usagePercent": "内存使用率",
  "/batteryCapacityLevelDesc": "电池容量状态", "/batteryLevel": "剩余电量",
  "/batterySOC": "电池电量", "/batterySOCText": "电池电量", "/batteryTemperatureText": "电池温度",
  "/chargingStatusDesc": "充电状态", "/healthStatusDesc": "电池健康状态", "/pluggedTypeDesc": "充电器类型",
  "/voltageText": "电池电压", "/updatedAt": "数据更新时间", "/nowCurrentText": "当前时间",
  "/dailySteps": "今天的步数", "/dailyTotalCaloriesText": "消耗的热量", "/dailyDistanceText": "运动距离", "/targetDateText": "统计日期",
  "/exerciseTypeName": "最近一次运动类型", "/exerciseDurationText": "运动时长", "/exerciseCalorieText": "运动消耗热量",
  "/exerciseHeartRateAvg": "平均心率", "/exerciseHeartRateMax": "最高心率", "/exerciseHeartRateMin": "最低心率",
  "/deepSleepDurationText": "深睡时长", "/nightSleepDurationText": "夜间睡眠时长", "/totalNapDurationText": "小睡时长",
  "/sleepScore": "睡眠评分", "/sleepStatus": "睡眠状态", "/sleepTypeDesc": "睡眠类型", "/fallAsleepTimeText": "入睡时间", "/wakeupTimeText": "起床时间",
  "/earphoneName": "耳机名称", "/leftBatteryLevel": "左耳电量", "/rightBatteryLevel": "右耳电量",
  "/leftChargingStatusDesc": "左耳充电状态", "/rightChargingStatusDesc": "右耳充电状态", "/isConnected": "耳机连接状态", "/isBatteryPresentText": "耳机仓状态",
  "/countdownDays": "还有几天", "/eventCount": "日程数量",
  "/location/prefectureName": "城市名称", "/location/districtName": "区县名称", "/location/cityCode": "城市代码",
  "/current/temperatureText": "当前温度", "/current/condition": "天气现象", "/current/coldLevel": "感冒指数",
  "/current/uvIndex": "紫外线指数", "/current/airQuality": "空气质量",
};

// 7.0 资源注册表中已注册 emoji 的业务语义，直接替换同名单色 icon；无对应 emoji 的（天气、电池、左右耳、耳机仓等）保留 icon。
const emojiReplacements = {
  "asset.calendar_fill": "asset.emoji_calendar",
  "asset.icon_meeting": "asset.emoji_calendar2",
  "asset.clock": "asset.emoji_time",
  "asset.clock_fill": "asset.emoji_time",
  "asset.stopwatch_fill": "asset.emoji_time",
  "asset.icon_timing": "asset.emoji_clock",
  "asset.alarm_fill_1": "asset.emoji_clock",
  "asset.icon_earphone": "asset.emoji_earphone",
  "asset.figure_run": "asset.emoji_run",
  "asset.heart_fill": "asset.emoji_health",
  "asset.moon_z_fill_1": "asset.emoji_z",
  "asset.moon_circle_fill": "asset.emoji_z",
  "asset.music_fill": "asset.emoji_music",
  "asset.phone_fill": "asset.emoji_phone1",
  "asset.icon_phone": "asset.emoji_phone1",
};

const cardNames = {
  GetAppUsageDuration: "应用使用卡片", GetPhoneBatteryInfo: "电池卡片", GetCalendarEvents: "日程卡片",
  GetCountdownDays: "倒计时卡片", GetEarphoneInfo: "耳机状态卡片", GetHealthAndSportSummary: "健康运动卡片",
  GetSystemMemInfo: "设备状态卡片", ViewWeather: "天气卡片",
};

const actionPhrases = {
  "event.call.phone": "点一下打开拨号界面",
  "event.clean.memory": "点一下清理手机内存",
  "event.enter.meeting": "点击按钮一键入会",
  "event.open.clock.alarm": "点一下打开闹钟",
  "event.open.health.sleep": "点一下查看睡眠详情",
  "event.open.health.sport": "点一下查看运动详情",
  "event.open.music.daily": "点一下打开每日歌单",
  "event.open.music.favorite": "点一下打开收藏歌单",
  "event.open.settings.battery": "点一下打开电池设置",
  "event.open.settings.batteryHealth": "点一下查看电池健康设置",
  "event.open.settings.bluetooth": "点一下打开蓝牙设置",
  "event.open.settings.dnd": "点一下打开免打扰设置",
  "event.open.settings.parentControl": "点一下打开健康使用设置",
  "event.open.settings.storage": "点一下打开存储空间设置",
  "event.open.weather": "点一下查看天气详情",
  "event.setPowerSavingMode": "点一下开启省电模式",
  "event.startNavigate": "点一下打开导航",
  "event.viewCalendarEvent": "点一下查看日程详情",
};

function labelForField(field) {
  if (fieldLabels[field]) return fieldLabels[field];
  if (/^\/current\/temperature/.test(field)) return "当前温度";
  if (/^\/current\/feelsLikeC/.test(field)) return "体感温度";
  if (/^\/current\/condition/.test(field)) return "当前天气";
  if (/^\/current\/humidityPercent/.test(field)) return "空气湿度";
  if (/^\/current\/airQuality/.test(field)) return "空气质量";
  if (/^\/current\/uvIndex/.test(field)) return "紫外线指数";
  if (/^\/current\/wind/.test(field)) return "风力情况";
  if (/^\/current\/alertLevel/.test(field)) return "天气预警";
  if (/^\/current\/coldLevel/.test(field)) return "感冒指数";
  if (/^\/daily\/\d+\/temperatureRangeText/.test(field)) return "温度范围";
  if (/^\/daily\/\d+\/rainProbabilityPercent/.test(field)) return "下雨概率";
  if (/^\/daily\/\d+\/airQuality/.test(field)) return "空气质量";
  if (/^\/daily\/\d+\/condition/.test(field)) return "天气情况";
  if (/^\/daily\/\d+\/(date|weekday)/.test(field)) return "日期和星期";
  if (/^\/daily\/\d+\/uvIndex/.test(field)) return "紫外线指数";
  if (/^\/events\/\d+\/title/.test(field)) return "日程标题";
  if (/^\/events\/\d+\/dtStart/.test(field)) return "开始时间";
  if (/^\/events\/\d+\/dtEnd/.test(field)) return "结束时间";
  if (/^\/events\/\d+\/eventLocation/.test(field)) return "会议地点";
  if (/^\/events\/\d+\/description/.test(field)) return "日程备注";
  if (/^\/events\/\d+\/timeZone/.test(field)) return "时区";
  if (/^\/events\/\d+\/isAllDay/.test(field)) return "是否全天";
  if (/^\/events\/\d+\/startDate/.test(field)) return "日程日期";
  if (/^\/events\/\d+\/remindTime/.test(field)) return "提醒时间";
  return null;
}

function naturalUserQuery(capabilityId, fields, events, firstArguments) {
  const labels = unique(fields.map(labelForField).filter(Boolean));
  const cardName = cardNames[capabilityId] ?? "信息卡片";
  const weatherPrefix = capabilityId === "ViewWeather" ? `${firstArguments?.prefectureName ?? "当地"}` : "";
  const requested = labels.length ? labels.join("、") : "相关信息";
  const actions = unique(events.map((event) => actionPhrases[event.capabilityId]).filter(Boolean));
  const action = actions.length ? `，${actions.join("，")}` : "";
  return `帮我做个${weatherPrefix}${cardName}，看${requested}${action}。`;
}

async function main() {
  const [dataCapabilities, eventCapabilities, assetCapabilities] = await Promise.all([
    readJson(path.join(capabilityRoot, "data_capabilities.json")),
    readJson(path.join(capabilityRoot, "event_capabilities.json")),
    readJson(path.join(capabilityRoot, "asset_capabilities.json")),
  ]);
  const enabledDataCapabilities = dataCapabilities.filter((item) => item.enabled !== false);
  const enabledEventCapabilities = eventCapabilities.filter((item) => item.enabled !== false);
  const enabledAssetCapabilities = assetCapabilities.filter((item) => item.enabled !== false);
  const allDataCapabilityIds = new Set(dataCapabilities.map((item) => item.id));
  const capabilityById = new Map(enabledDataCapabilities.map((item) => [item.id, item]));
  const eventById = new Map(enabledEventCapabilities.map((item) => [item.id, item]));
  const assetById = new Map(enabledAssetCapabilities.map((item) => [item.id, item]));
  const assetIds = [...assetById.keys()].sort();

  const existingFiles = (await fs.readdir(templateRoot)).filter((name) => /^Q\d+\.json$/.test(name)).sort();
  const existingCases = await Promise.all(existingFiles.map(async (name) => ({
    caseId: path.basename(name, ".json"),
    data: await readJson(path.join(templateRoot, name)),
  })));
  const seedByCapability = new Map();
  for (const existingCase of existingCases) {
    for (const binding of existingCase.data.candidateDataBindings ?? []) {
      if (!seedByCapability.has(binding.capabilityId)) seedByCapability.set(binding.capabilityId, existingCase);
    }
  }

  const providerDirectories = (await fs.readdir(providerRoot, { withFileTypes: true }))
    .filter((entry) => entry.isDirectory())
    .map((entry) => entry.name);
  const bundles = [];
  for (const directory of providerDirectories) {
    const providerPath = path.join(providerRoot, directory, "provider.json");
    try { bundles.push(await readJson(providerPath)); } catch { /* Layout and action providers may not have a provider file. */ }
  }
  const templates = bundles.flatMap((bundle) => (bundle.templates ?? []).map((template) => ({
    ...template,
    providerId: bundle.providerId,
    dataDomain: (bundle.capabilities ?? []).find((capability) => capability.capabilityId === template.capabilityId)?.dataDomain,
  }))).filter((template) => capabilityById.has(template.capabilityId));

  const unusedSystemMemoryTemplates = bundles.flatMap((bundle) => bundle.templates ?? [])
    .filter((template) => template.capabilityId === "GetSystemMemInfo").map((template) => template.templateId);
  const disabledDataCapabilityTemplates = bundles.flatMap((bundle) => bundle.templates ?? [])
    .filter((template) => template.capabilityId && allDataCapabilityIds.has(template.capabilityId) && !capabilityById.has(template.capabilityId))
    .map((template) => template.templateId);
  const unsupportedProviderTemplates = bundles.flatMap((bundle) => bundle.templates ?? [])
    .filter((template) => template.capabilityId && !allDataCapabilityIds.has(template.capabilityId)).map((template) => template.templateId);
  if (templates.length === 0) throw new Error("未发现可由 7.0 数据注册表支持的模板。");

  const manifestCases = [];
  let sequence = 82;

  function createBindings(template, fields) {
    const capability = capabilityById.get(template.capabilityId);
    const maxDaily = maxDailyIndex(fields);
    const count = template.bindingCount ?? 1;
    return Array.from({ length: count }, (_, index) => {
      const argumentsValue = { ...defaultArguments(capability) };
      if (capability.id === "ViewWeather" && maxDaily >= 0) argumentsValue.forecastDays = Math.max(argumentsValue.forecastDays ?? 1, maxDaily + 1);
      if (capability.id === "ViewWeather" && count > 1) {
        Object.assign(argumentsValue, index === 0
          ? { prefectureName: "上海市", districtName: "浦东新区" }
          : { prefectureName: "北京市", districtName: "朝阳区" });
      }
      return {
        capabilityId: capability.id,
        arguments: argumentsValue,
        writeResultTo: count > 1 ? `${template.dataDomain}${index + 1}` : template.dataDomain,
        candidateOutputFields: fields,
      };
    });
  }

  function matchingAssetIds(template, fields, events) {
    const tags = unique(Object.values(template.assetParameterSemanticTags ?? {}).flat());
    const taggedAssets = tags.map((tag) => assetCapabilities.find((asset) => asset.sceneTags?.includes(tag))?.id).filter(Boolean);
    const fieldText = fields.join(" ");
    const eventIds = new Set(events.map((event) => event.capabilityId));
    const inferredAssets = [];
    const add = (...ids) => inferredAssets.push(...ids);

    switch (template.capabilityId) {
      case "GetAppUsageDuration":
        add("asset.icon_phone", "asset.clock_fill");
        break;
      case "GetPhoneBatteryInfo":
        add("asset.battery_leaf_fill");
        if (/charging|plugged/.test(fieldText)) add("asset.bolt_fill");
        if (/Temperature|temperature/.test(fieldText)) add("asset.heat_generation");
        if (/updatedAt/.test(fieldText)) add("asset.clock_fill");
        break;
      case "GetCalendarEvents":
        add("asset.calendar_fill", "asset.icon_meeting");
        if (/dtStart|dtEnd|remindTime/.test(fieldText)) add("asset.clock_fill");
        if (/eventLocation/.test(fieldText)) add("asset.local_fill");
        break;
      case "GetCountdownDays":
        add("asset.icon_timing", "asset.calendar_fill");
        break;
      case "GetEarphoneInfo":
        add("asset.icon_earphone");
        if (/leftBattery|leftCharging/.test(fieldText)) add("asset.icon_left");
        if (/rightBattery|rightCharging/.test(fieldText)) add("asset.icon_right");
        if (/batteryLevel|Charging/.test(fieldText)) add("asset.earphone_case_16644");
        break;
      case "GetHealthAndSportSummary":
        if (/sleep|Sleep|fallAsleep|wakeup/.test(fieldText)) add("asset.moon_z_fill_1");
        if (/heart|Heart/.test(fieldText)) add("asset.heart_fill");
        if (/daily|exercise|workout|Steps|Distance|Calorie/.test(fieldText)) add("asset.figure_run");
        if (/Calorie/.test(fieldText)) add("asset.flame_fill");
        if (!inferredAssets.length) add("asset.figure_run");
        break;
      case "ViewWeather":
        add("asset.sun_max");
        if (/temperature|Temperature|feelsLike/.test(fieldText)) add("asset.icon_weather_thermometer");
        if (/rain|humidity/.test(fieldText)) add("asset.drop_1");
        if (/wind/.test(fieldText)) add("asset.icon_weather_wind");
        if (/alert/.test(fieldText)) add("asset.typhoon_fill", "asset.bell_fill");
        if (/cold|airQuality|uvIndex/.test(fieldText)) add("asset.cold");
        break;
      default:
        break;
    }

    if (eventIds.has("event.open.music.daily") || eventIds.has("event.open.music.favorite")) add("asset.music_fill");
    if (eventIds.has("event.call.phone")) add("asset.phone_fill");
    if (eventIds.has("event.open.settings.bluetooth")) add("asset.icon_earphone");
    if (eventIds.has("event.open.clock.alarm")) add("asset.alarm_fill_1");
    if (eventIds.has("event.open.weather")) add("asset.sun_max");
    if (eventIds.has("event.viewCalendarEvent") || eventIds.has("event.enter.meeting")) add("asset.calendar_fill");

    const replaced = unique([...taggedAssets, ...inferredAssets]).map((assetId) => emojiReplacements[assetId] ?? assetId);
    return unique(replaced).filter((assetId) => assetById.has(assetId));
  }

  function makeTaskSpec(template, variant, fields, events, assetCandidates, sourceCaseId) {
    const seed = seedByCapability.get(template.capabilityId)?.data;
    const source = seed ? clone(seed) : {
      content: {}, deviceInfo: { countryCode: "CN", deviceFormation: "HDSpeaker", deviceType: 0, locale: "zh-CN", phoneType: "SGT-AL10", romVersion: runtimeRomVersion, sysVer: "EmotionUI_9.0.0", time: "20260911090000000" },
      pagination: { limit: 5, start: "" }, session: {}, userAuth: { user: { userId: "" } }, utterance: {}, version: "1.0",
    };
    const caseId = `Q${String(sequence).padStart(3, "0")}`;
    const title = templateTitle(template, variant.titleSuffix);
    const candidateDataBindings = createBindings(template, fields);
    if (variant.argumentOverrides) {
      for (const binding of candidateDataBindings) Object.assign(binding.arguments, variant.argumentOverrides);
    }
    const userQuery = naturalUserQuery(template.capabilityId, fields, events, candidateDataBindings[0]?.arguments);
    const content = {
      ...(source.content ?? {}),
      bundleName: "com.omega_w_0823.hmservice",
      userQuery,
      candidateDataBindings,
      title,
      size: "2x2",
      candidateEventCandidates: events,
      description: variant.description,
      candidateAssetIds: assetCandidates,
    };
    const taskSpec = {
      ...source,
      content,
      deviceInfo: { ...source.deviceInfo, prdVer, romVersion: runtimeRomVersion },
      session: { ...source.session, interactionId: String(sequence).padStart(3, "0"), isNew: true, sessionId: "taskspec-template-7.0-perturbation-v1" },
      utterance: { ...(source.utterance ?? {}), original: userQuery, type: "text" },
      bundleName: content.bundleName,
      userQuery: content.userQuery,
      candidateDataBindings: content.candidateDataBindings,
      title: content.title,
      size: content.size,
      candidateEventCandidates: content.candidateEventCandidates,
      description: content.description,
      candidateAssetIds: content.candidateAssetIds,
    };
    return { caseId, taskSpec, sourceCaseId };
  }

  function addCase(template, variant, fields, events, expectation) {
    const sourceCaseId = seedByCapability.get(template.capabilityId)?.caseId ?? null;
    const { caseId, taskSpec } = makeTaskSpec(template, variant, fields, events, matchingAssetIds(template, fields, events), sourceCaseId);
    manifestCases.push({
      caseId,
      file: `${caseId}.json`,
      templateId: template.templateId,
      providerId: template.providerId,
      capabilityId: template.capabilityId,
      bindingCount: template.bindingCount ?? 1,
      variant: variant.key,
      variantLabel: variant.label,
      mutationPaths: variant.mutationPaths ?? [],
      mutationArguments: variant.argumentOverrides ?? {},
      reusedTaskSpecCase: sourceCaseId,
      expectedSearchEligibility: expectation.searchEligibility,
      expectedPlannerOrRender: expectation.plannerOrRender,
      expectationReason: expectation.reason,
      primaryData: template.primaryData ?? [],
      secondaryData: template.secondaryData ?? [],
      optionalData: template.optionalData ?? [],
      supportedEventIds: template.supportedEventIds ?? [],
      assetSemanticTags: template.assetParameterSemanticTags ?? {},
      prdVer,
    });
    const filePath = path.join(outputRoot, `${caseId}.json`);
    writes.push(fs.writeFile(filePath, `${JSON.stringify(taskSpec, null, 2)}\n`, "utf8"));
    sequence += 1;
  }

  const writes = [];
  await fs.mkdir(outputRoot, { recursive: true });
  for (const template of templates.sort((left, right) => left.templateId.localeCompare(right.templateId))) {
    const primary = template.primaryData ?? [];
    const secondary = template.secondaryData ?? [];
    const optional = template.optionalData ?? [];
    const available = unique([...primary, ...secondary, ...optional]);
    const validEvents = (template.supportedEventIds ?? []).map((id) => eventById.get(id)).filter(Boolean);

    for (const field of primary) {
      addCase(template,
        { key: "missing-primary", label: "缺必要主数据", titleSuffix: "缺主数据", description: `移除 primaryData ${field}。`, mutationPaths: [field] },
        available.filter((candidate) => candidate !== field),
        validEvents.length ? [buildEvent(validEvents[0])] : [],
        { searchEligibility: "ineligible", plannerOrRender: "not-applicable", reason: `primaryData ${field} 属于硬前置，目标模板必须被 Search 排除。` });
    }
    for (const field of secondary) {
      addCase(template,
        { key: "missing-secondary", label: "缺辅助数据", titleSuffix: "缺辅助数据", description: `移除 secondaryData ${field}。`, mutationPaths: [field] },
        available.filter((candidate) => candidate !== field),
        validEvents.length ? [buildEvent(validEvents[0])] : [],
        { searchEligibility: "ineligible", plannerOrRender: "not-applicable", reason: `secondaryData ${field} 与 primaryData 同为硬前置，目标模板必须被 Search 排除。` });
    }
    if (primary.length + secondary.length === 0) {
      const unsupported = pointerLeaves(capabilityById.get(template.capabilityId).outputSchema).find((field) => !available.includes(field));
      if (unsupported) {
        addCase(template,
          { key: "uncovered-valid-field", label: "超集数据+未覆盖请求字段", titleSuffix: "超集未覆盖", description: `保留完整基线字段，追加模板不覆盖的合法字段 ${unsupported}，query 显式请求展示它。`, mutationPaths: [unsupported] },
          [...available, unsupported], validEvents.length ? [buildEvent(validEvents[0])] : [],
          { searchEligibility: "ineligible", plannerOrRender: "not-applicable", reason: `Search 全覆盖硬门（template_retrieval：explicit_fields ⊆ covered_paths）：query 显式请求的 ${unsupported} 不在模板可覆盖字段内，目标模板必被排除；数据多一个字段本身不构成排除理由。` });
      }
    }
  }

  await Promise.all(writes);
  const manifest = {
    version: "1.0",
    purpose: "provider-template-false-trigger-v1",
    generatedAt: new Date().toISOString(),
    capabilityRegistry: "app-11.7.7.300_rom-7.0",
    requiredPrdVer: prdVer,
    runtimeRomVersion,
    sourceTestSet: "../Q001.json–Q081.json",
    scope: {
      templatesSupportedByDataRegistry: templates.length,
      excludedTemplates: unsupportedProviderTemplates,
      excludedReason: "GetSystemMemInfo 不在 7.0 data_capabilities.json 中，或数据能力已在该注册表中停用。",
      excludedSystemMemoryTemplates: unusedSystemMemoryTemplates,
      excludedDisabledDataCapabilityTemplates: disabledDataCapabilityTemplates,
    },
    summary: {
      totalCases: manifestCases.length,
      templatesCoveredByNegativeCases: new Set(manifestCases.map((testCase) => testCase.templateId)).size,
      variants: Object.fromEntries([...new Set(manifestCases.map((testCase) => testCase.variant))].sort().map((variant) => [variant, manifestCases.filter((testCase) => testCase.variant === variant).length])),
      eligible: manifestCases.filter((testCase) => testCase.expectedSearchEligibility === "eligible").length,
      ineligible: manifestCases.filter((testCase) => testCase.expectedSearchEligibility === "ineligible").length,
      possibleSearchEligibility: manifestCases.filter((testCase) => testCase.expectedSearchEligibility === "possible").length,
      possibleTemplateMatch: manifestCases.filter((testCase) => testCase.expectedPlannerOrRender === "possible-template-match").length,
    },
    cases: manifestCases,
  };
  await fs.writeFile(path.join(outputRoot, "perturbation_expected.json"), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
  await fs.writeFile(path.join(outputRoot, "README.md"), `# 模板误触发测试集\n\n本目录由 \`build_perturbation_dataset.mjs\` 生成，只保留目标模板在 Search 阶段必须被排除的确定负样本（不含任何完整命中用例），用于统计误触发率。\n\n## 相似性原则\n每条负样本与完整命中基线只差一个决定性扰动：缺字段类保留基线其余全部数据、动作与图标，query 仍显式列出全部保留字段；超集类（uncovered-valid-field）基线字段一个不少，仅追加一个能力合法但目标模板不覆盖的字段，并在 query 中显式请求展示它。\n\n## Search 硬门（template_retrieval.py，确定性过滤，与 LLM 排序无关）\n① \`_template_required_fields_are_available\`：primary+secondary 必须全部存在于 dataModelSchema 且类型一致，数据超集不拒绝；② \`explicit_fields ⊆ covered_paths\`：query 显式要求的展示字段必须全部落在模板可覆盖字段并集内。因此“数据比要求多”本身不会阻止触发；只有多出的字段同时被 query 显式要求展示、且目标模板覆盖不了时才确定不触发（超集类用例即测这条门）。\n\n## 运行时与注册表\n数据、动作、资源统一使用 \`app-11.7.7.300_rom-7.0\` 注册表中 \`enabled !== false\` 的条目；\`deviceInfo.prdVer=${prdVer}\`、\`deviceInfo.romVersion=${runtimeRomVersion}\` 使运行时按 registry_ranges 稳定命中该 7.0 目录。业务语义有已注册 emoji 的资源候选优先替换为 \`asset.emoji_*\`（日历、会议、时间、闹钟、耳机、跑步、心率、睡眠、音乐、电话），无对应 emoji 的（电池、天气、左右耳、耳机仓、定位等）保留单色 icon。\n\n## 判定口径\n误触发按目标模板逐条统计：\`expectedSearchEligibility: ineligible\` 只要求该 templateId 不出现在 Search 候选中。部分用例存在合法命中的兄弟模板（如 WideFull 缺统计日期时 Full 仍满足全部必需要求），运行器应断言“目标模板未出现”，而不是“完全没有生成卡片”。\n\n\`perturbation_expected.json\` 是唯一的预期映照表。\n`, "utf8");

  const writtenFiles = await fs.readdir(outputRoot);
  const generatedCaseFiles = writtenFiles.filter((name) => /^Q\d+\.json$/.test(name));
  if (generatedCaseFiles.length !== manifestCases.length) throw new Error(`生成文件数 ${generatedCaseFiles.length} 与映照表 ${manifestCases.length} 不一致。`);
  for (const testCase of manifestCases) {
    const taskSpec = await readJson(path.join(outputRoot, testCase.file));
    if (taskSpec.deviceInfo?.prdVer !== prdVer) throw new Error(`${testCase.caseId} prdVer 不正确。`);
    if (taskSpec.deviceInfo?.romVersion !== runtimeRomVersion) throw new Error(`${testCase.caseId} romVersion 不正确。`);
    if (JSON.stringify(taskSpec.content?.candidateDataBindings) !== JSON.stringify(taskSpec.candidateDataBindings)) throw new Error(`${testCase.caseId} content 与顶层数据绑定不一致。`);
    if (JSON.stringify(taskSpec.content?.candidateEventCandidates) !== JSON.stringify(taskSpec.candidateEventCandidates)) throw new Error(`${testCase.caseId} content 与顶层动作不一致。`);
    if (JSON.stringify(taskSpec.content?.candidateAssetIds) !== JSON.stringify(taskSpec.candidateAssetIds)) throw new Error(`${testCase.caseId} content 与顶层 Icon 不一致。`);
    for (const binding of taskSpec.candidateDataBindings) if (!capabilityById.has(binding.capabilityId)) throw new Error(`${testCase.caseId} 使用了非 7.0 数据能力。`);
    for (const event of taskSpec.candidateEventCandidates) if (!eventById.has(event.capabilityId)) throw new Error(`${testCase.caseId} 使用了非 7.0 动作。`);
    for (const assetId of taskSpec.candidateAssetIds) if (!assetById.has(assetId)) throw new Error(`${testCase.caseId} 使用了非 7.0 注册表 Icon。`);
  }
  console.log(JSON.stringify({ outputRoot, templates: templates.length, cases: manifestCases.length, variants: manifest.summary.variants }, null, 2));
}

await main();
