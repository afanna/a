import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// 误触发探针集：克隆 taskspec/template 的正向用例作为母本，保持 candidate* / deviceInfo / 尺寸不变，
// 只改语义层（userQuery/title/description）或按 singleDelta 声明的字段做最小补丁。
// 目的是让"模板是否命中"只由业务语义决定，而不是由字段差异决定——这是误触发唯一可信的测法。

// 语义轴误触发探针：perturbation_v1 对 101 个模板做字段消融（缺 primary/secondary/超集字段），
// 本脚本补另一个轴——字段签名齐全但 query 业务语义不属于该模板族时，模板会不会被误命中。
// 克隆 taskspec/template 的正向用例作母本，除 singleDelta 声明的字段外逐字段一致，
// 因此命中与否只由语义决定。输出到 semantic_axis/，编号从 Q322 起（field_axis 占 Q082–Q321）。

const here = path.dirname(fileURLToPath(import.meta.url));
const taskspecRoot = path.resolve(here, "..");
const parentDir = path.join(taskspecRoot, "template");
const outDir = path.join(here, "semantic_axis");
fs.mkdirSync(outDir, { recursive: true });
const parent = JSON.parse(fs.readFileSync(path.join(parentDir, "template_expected.json"), "utf8"));
const parentIndex = new Map(parent.cases.map((c) => [c.caseId, c]));
const DUP_KEYS = ["bundleName", "userQuery", "candidateDataBindings", "title", "size", "candidateEventCandidates", "description", "candidateAssetIds"];

const cloneCase = (id) => JSON.parse(fs.readFileSync(path.join(parentDir, `${id}.json`), "utf8"));

const syncTop = (p) => {
  for (const k of DUP_KEYS) p[k] = p.content[k];
  return p;
};

const signatureOf = (p) => {
  const c = p.content;
  const caps = (c.candidateDataBindings || [])
    .map((b) => `${b.capabilityId}[${(b.candidateOutputFields || []).join(",")}]`)
    .join("+");
  const actions = (c.candidateEventCandidates || []).map((e) => e.capabilityId).join(",") || "none";
  return `${c.size}|${caps}|actions=${actions}`;
};

const rewrite = (p, { query, title, description }) => {
  if (query !== undefined) p.content.userQuery = query;
  if (title !== undefined) p.content.title = title;
  if (description !== undefined) p.content.description = description;
  return syncTop(p);
};

const setFields = (p, cap, fields) => {
  const b = p.content.candidateDataBindings.find((x) => x.capabilityId === cap) || p.content.candidateDataBindings[0];
  b.candidateOutputFields = fields;
  return syncTop(p);
};

const mergePair = (p, otherId) => {
  const other = cloneCase(otherId);
  p.content.candidateDataBindings = [...p.content.candidateDataBindings, ...other.content.candidateDataBindings.map((b) => ({ ...b, writeResultTo: b.writeResultTo + "2" }))];
  p.content.candidateEventCandidates = [...p.content.candidateEventCandidates, ...other.content.candidateEventCandidates];
  p.content.candidateAssetIds = [...new Set([...p.content.candidateAssetIds, ...other.content.candidateAssetIds])];
  return syncTop(p);
};

const setSize = (p, size) => {
  p.content.size = size;
  return syncTop(p);
};

const setPrdVer = (p, prdVer) => {
  p.deviceInfo.prdVer = prdVer;
  return p;
};

const asSession = (p, interactionId) => {
  p.session.isNew = false;
  p.session.interactionId = interactionId;
  return p;
};

const OD = JSON.parse(fs.readFileSync(path.join(taskspecRoot, "Phase_opendomain", "opendomain_expected.json"), "utf8"));
const odRecord = (id) => [...OD.cases, ...OD.pending].find((c) => c.file === `${id}.json`);
const odSpec = (id) => {
  const main = path.join(taskspecRoot, "Phase_opendomain", `${id}.json`);
  const pend = path.join(taskspecRoot, "Phase_opendomain", "pending", `${id}.json`);
  const status = (odRecord(id) ?? {}).status ?? (fs.existsSync(pend) && !fs.existsSync(main) ? "unverified" : undefined);
  if (!status) throw new Error(`开域条 ${id} 不在 opendomain_expected.json 的 cases/pending 里`);
  const file = fs.existsSync(main) ? main : pend;
  if (fs.existsSync(main) && fs.existsSync(pend)) throw new Error(`开域条 ${id} 同时存在于主集与 pending，需先重跑 Phase_opendomain`);
  return { spec: JSON.parse(fs.readFileSync(file, "utf8")), status };
};

const v1 = JSON.parse(fs.readFileSync(path.join(here, "field_axis", "perturbation_expected.json"), "utf8"));
const TEMPLATE_IDS = [...new Set(v1.cases.map((x) => x.templateId))];
// 母本集 template_expected.json 里的族标签与注册表 templateId 前缀不完全一致：
// 母本写 CalendarOverview，注册表里实际是 ScheduleOverview@1 系列。映射集中放这里，避免静默漏配。
const FAMILY_PREFIX = { CalendarOverview: "ScheduleOverview" };
const FAMILIES = ["ActivityOverview", "BatteryOverview", "BluetoothDeviceOverview", "CalendarOverview", "CountdownOverview", "HeartRateOverview", "SleepOverview", "WeatherOverview"];
for (const f of FAMILIES) {
  const prefix = FAMILY_PREFIX[f] ?? f;
  if (!TEMPLATE_IDS.some((id) => id.startsWith(prefix))) throw new Error(`v1 模板清单里没有 ${f}（前缀 ${prefix}）`);
}
const idsOfFamily = (f) => TEMPLATE_IDS.filter((id) => id.startsWith(FAMILY_PREFIX[f] ?? f)).sort();

const G1 = "business-mismatch";
const G2 = "cross-template-race";
const G3 = "open-domain-mishit";
const G4 = "empty-value";
const G5 = "preflight-reject";
const G6 = "edit-reuse";
const G7 = "negation-and-variant";
const GROUP_LABEL = {
  [G1]: "业务语义错配",
  [G2]: "跨模板竞争",
  [G3]: "开域内容误套端侧模板",
  [G4]: "字段齐但值为空",
  [G5]: "preflight 应拒绝",
  [G6]: "编辑与多轮复用",
  [G7]: "否定语义与语言变体"
};

const CASES = [
  // G1 字段签名齐全但业务不是它：命中母本 family 即为误触发
  { n: "M001", g: G1, pair: "Q001", fam: "WeatherOverview", q: "生成一张静态卡片，展示我刚查到的三亚蜈支洲岛未来三天船班时刻表。", t: "船班时刻", d: "船班时刻表", out: "fusion-only", note: "候选是天气字段，内容是搜来的船班时刻；套天气模板即误触发" },
  { n: "M002", g: G1, pair: "Q004", fam: "WeatherOverview", q: "生成一张静态卡片，展示我记录的本周健身打卡次数和消耗卡路里。", t: "健身打卡", d: "健身打卡记录", out: "fusion-only", note: "运动业务配天气字段" },
  { n: "M003", g: G1, pair: "Q012", fam: "WeatherOverview", q: "生成一张静态卡片，对比我家两个孩子这个月的身高和体重。", t: "身高体重", d: "儿童身高体重", out: "neither", note: "双主体对比，模板 Hero 结构装不下" },
  { n: "M004", g: G1, pair: "Q018", fam: "CalendarOverview", q: "生成一张静态卡片，展示附近五家火锅店的评分和人均消费。", t: "火锅店", d: "火锅店评分", out: "fusion-only", note: "日程字段配餐饮榜单内容" },
  { n: "M005", g: G1, pair: "Q019", fam: "CalendarOverview", q: "生成一张静态卡片，展示上海本月各美术馆的展览排期和闭馆日。", t: "展览排期", d: "展览排期", out: "fusion-only", note: "公开排期信息，不是本机日程" },
  { n: "M006", g: G1, pair: "Q027", fam: "CalendarOverview", q: "生成一张静态卡片，展示我收藏歌单的更新提醒。", t: "歌单更新", d: "歌单更新提醒", out: "fusion-only", note: "音乐业务配日程字段" },
  { n: "M007", g: G1, pair: "Q033", fam: "CountdownOverview", q: "生成一张静态卡片，展示今天步数目标的完成百分比。", t: "步数目标", d: "步数完成度", out: "fusion-only", note: "countdownDays 字段在，但用户要的是完成度" },
  { n: "M008", g: G1, pair: "Q034", fam: "CountdownOverview", q: "生成一张静态卡片，展示高铁G1次列车的发车时刻和停靠站。", t: "G1次列车", d: "列车时刻", out: "fusion-only", note: "公开时刻表内容" },
  { n: "M009", g: G1, pair: "Q036", fam: "BluetoothDeviceOverview", q: "生成一张静态卡片，展示手机剩余电量和是否在充电。", t: "手机充电", d: "手机电量", out: "fusion-only", note: "候选是耳机字段，用户要手机数据；用耳机数据冒充即错绑" },
  { n: "M010", g: G1, pair: "Q039", fam: "BluetoothDeviceOverview", q: "生成一张静态卡片，展示我家智能门锁的设备名和连接状态。", t: "智能门锁", d: "门锁状态", out: "neither", note: "智慧生态设备，非蓝牙耳机" },
  { n: "M011", g: G1, pair: "Q040", fam: "BluetoothDeviceOverview", q: "生成一张静态卡片，展示胎压监测四个轮胎的气压数值。", t: "胎压", d: "四轮气压", out: "neither", note: "左右耳双字段结构相似，易被套用" },
  { n: "M012", g: G1, pair: "Q044", fam: "BatteryOverview", q: "生成一张静态卡片，展示我本月话费余额和已用流量。", t: "话费流量", d: "话费与流量", out: "fusion-only", note: "百分比字段易被误当电量" },
  { n: "M013", g: G1, pair: "Q048", fam: "BatteryOverview", q: "生成一张静态卡片，展示我笔记本电脑的电池健康度和充电状态。", t: "笔记本电池", d: "笔记本电池", out: "neither", note: "端侧能力只覆盖本机手机" },
  { n: "M014", g: G1, pair: "Q052", fam: "BatteryOverview", q: "生成一张静态卡片，展示家里暖气片的出水温度和加热档位。", t: "暖气温度", d: "暖气出水温度", out: "fusion-only", note: "温度+档位字段形似电池温度与充电器类型" },
  { n: "M015", g: G1, pair: "Q056", fam: "HeartRateOverview", q: "生成一张静态卡片，展示我基金今天和昨天的净值涨跌。", t: "基金净值", d: "净值涨跌", out: "fusion-only", note: "最高/最低字段易被当成财务极值" },
  { n: "M016", g: G1, pair: "Q057", fam: "ActivityOverview", q: "生成一张静态卡片，展示仓库今天的出货件数、总重量和体积。", t: "出货统计", d: "出货件数重量体积", out: "neither", note: "三项大盘字段结构相同" },
  { n: "M017", g: G1, pair: "Q059", fam: "SleepOverview", q: "生成一张静态卡片，展示服务器本周的运行时长和重启次数。", t: "服务器时长", d: "运行时长与重启", out: "fusion-only", note: "睡眠时长字段被套到运维指标" },
  { n: "M018", g: G1, pair: "Q066", fam: "SleepOverview", q: "生成一张静态卡片，展示我住的酒店入住评分和当前房态。", t: "酒店评分", d: "酒店评分房态", out: "fusion-only", note: "评分+状态字段同形" },

  // G2 一条 query 同时满足两个 family 的字段签名，语义只指向其一
  { n: "M019", g: G2, pair: "Q020", also: "Q009", fam: "WeatherOverview", req: ["CalendarOverview"], q: "生成一张静态卡片，看下午那场会议几点开始、在哪个会议室。", t: "下午会议", d: "会议时间与地点", out: "template+fusion", note: "天气+日程字段齐全，语义只要日程；命中天气模板即误触发" },
  { n: "M020", g: G2, pair: "Q009", also: "Q020", fam: "CalendarOverview", req: ["WeatherOverview"], q: "生成一张静态卡片，看现在多少度、是不是在下雨。", t: "当前天气", d: "温度与天气", out: "template+fusion", note: "反向：同一份合并候选，语义只要天气" },
  { n: "M021", g: G2, pair: "Q054", also: "Q036", fam: "BluetoothDeviceOverview", req: ["BatteryOverview"], q: "生成一张静态卡片，看手机还剩多少电、在不在充电，顺便进省电模式。", t: "手机电量", d: "手机充电状态", out: "template+fusion", note: "手机与耳机充电字段同时在场" },
  { n: "M022", g: G2, pair: "Q036", also: "Q054", fam: "BatteryOverview", req: ["BluetoothDeviceOverview"], q: "生成一张静态卡片，看耳机仓还有多少电、在不在充电。", t: "耳机仓电量", d: "耳机仓充电", out: "template+fusion", note: "反向：只要耳机" },
  { n: "M023", g: G2, amb: true, pair: "Q033", also: "Q025", fam: "CountdownOverview", req: ["CountdownOverview", "CalendarOverview"], q: "生成一张静态卡片，看离我出差还有几天，当天第一个日程几点开始。", t: "出差倒数与日程", d: "倒数与首个日程", out: "template+fusion", note: "两个都是主诉求，独占任一族都算取舍型误触发，因此 forbidden 留空、只记歧义" },
  { n: "M024", g: G2, pair: "Q066", also: "Q057", fam: "ActivityOverview", req: ["SleepOverview"], q: "生成一张静态卡片，看昨晚睡得怎么样、睡了多久。", t: "昨晚睡眠", d: "睡眠时长与得分", out: "template+fusion", note: "睡眠 binding 与活动 binding 各自字段完备，两族都能过门，才是真竞争；反向要求只要睡眠" },
  { n: "M025", g: G2, amb: true, pair: "Q003", also: "Q010", fam: "WeatherOverview", req: ["WeatherOverview"], q: "生成一张静态卡片，看当前天气，有预警的话一并显示。", t: "天气与预警", d: "当前天气和预警", out: "template+fusion", note: "同为天气族内两个模板（预警版与概览版）竞争，两者都属允许答案，只记录实际选了哪个" },
  { n: "M026", g: G2, pair: "Q058", also: "Q064", fam: "HeartRateOverview", req: ["ActivityOverview"], q: "生成一张静态卡片，看今天走了多少步。", t: "今日步数", d: "步数", out: "template+fusion", note: "心率字段在场但用户只要步数" },

  // G3 开域（搜索）内容误命中端侧能力模板，候选与 userQuery 来自 Phase_opendomain
  { n: "M027", g: G3, pair: "Q020", od: "Q001", fam: "CalendarOverview", q: "", out: "fusion-only", note: "演唱会排期是搜索结果，套本机日程模板即误触发" },
  { n: "M028", g: G3, pair: "Q033", od: "Q005", fam: "CountdownOverview", q: "", out: "fusion-only", note: "动物园开园时间与休园日是公开信息，不该套倒计时模板" },
  { n: "M029", g: G3, pair: "Q031", od: "Q003", fam: "CalendarOverview", q: "", out: "neither", note: "CBA 赛程多条，日程模板只有单条结构" },
  { n: "M030", g: G3, pair: "Q044", od: "Q006", fam: "BatteryOverview", q: "", out: "fusion-only", note: "利率百分比字段与电量百分比字段同形" },
  { n: "M031", g: G3, pair: "Q034", od: "Q010", fam: "CountdownOverview", q: "", out: "neither", note: "地铁首末班是多点列表，模板装不下" },
  { n: "M032", g: G3, pair: "Q041", od: "Q013", fam: "BluetoothDeviceOverview", q: "", out: "neither", note: "三家套餐对比，设备模板会塌成单值" },

  // G4 字段齐但值尚未产生，考模板命中后的空态而不是命中本身
  { n: "M033", g: G4, pair: "Q025", fields: ["/events/0/dtStart", "/events/0/title"], fam: "CalendarOverview", q: "我今天没有任何安排，就想看个卡片确认一下是不是空的。", t: "今日无日程", d: "空日程确认", out: "template+fusion", note: "eventCount=0 时必须给空态，不能显示上一条日程" },
  { n: "M034", g: G4, pair: "Q003", fields: ["/current/alertLevel", "/updatedAt"], fam: "WeatherOverview", q: "今天没有天气预警，帮我看下预警位还留不留着。", t: "无预警", d: "无预警空态", out: "template-only", note: "无预警时预警图标/文案不应保留" },
  { n: "M035", g: G4, pair: "Q056", fields: ["/exerciseHeartRateMax", "/exerciseHeartRateMin"], fam: "HeartRateOverview", q: "今天还没运动，帮我看下心率那两项现在是什么。", t: "未运动心率", d: "心率未测量", out: "template+fusion", note: "空值不能渲染成 0 或上次数据" },
  { n: "M036", g: G4, pair: "Q036", fields: ["/batteryLevel", "/chargingStatusDesc"], fam: "BluetoothDeviceOverview", q: "耳机现在没连接，帮我看个卡片知道没连上就行。", t: "耳机未连接", d: "未连接空态", out: "template+fusion", note: "isConnected=false 时电量不得显示上次值" },
  { n: "M037", g: G4, pair: "Q033", fields: ["/countdownDays"], fam: "CountdownOverview", q: "我还没定目标日期，先做个倒计时卡片占位。", t: "目标未定", d: "倒计时占位", out: "neither", note: "targetDate 未定时应澄清，不该造一个数" },
  { n: "M038", g: G4, pair: "Q059", fields: ["/deepSleepDurationText", "/nightSleepDurationText", "/sleepScore", "/sleepStatus"], fam: "SleepOverview", q: "昨晚没戴手表睡，睡眠数据应该没有，帮我看下卡片长什么样。", t: "无睡眠数据", d: "睡眠空态", out: "template+fusion", note: "缺记录方式时不得沿用前天数据" },

  // G5 preflight 拒绝：能力/字段/权限/协议不合法，模板与融球都不该开始
  { n: "M039", g: G5, pair: "Q009", fields: ["/current/condition", "/current/unknownField"], fam: "WeatherOverview", q: "生成一张静态卡片，看当前天气和一个未定义的扩展字段。", t: "未知字段", d: "字段不存在", preflight: "fail", out: "neither", note: "出参清单里没有的字段" },
  { n: "M040", g: G5, pair: "Q044", cap: "GetWeather", fam: "BatteryOverview", q: "生成一张静态卡片，看电量和电量等级。", t: "能力名错误", d: "能力未注册", preflight: "fail", out: "neither", note: "capabilityId 拼成 GetWeather" },
  { n: "M041", g: G5, pair: "Q020", fam: "CalendarOverview", q: "生成一张静态卡片，看明天上午的会议安排。", t: "无权限", d: "日历未授权", preflight: "fail", out: "neither", note: "用户尚未授予日历权限" },
  { n: "M042", g: G5, pair: "Q033", fam: "CountdownOverview", q: "生成一张静态卡片，看离放假还有几天。", t: "缺必填参数", d: "targetDate 缺失", preflight: "fail", out: "neither", note: "GetCountdownDays 无 targetDate" },
  { n: "M043", g: G5, pair: "Q049", cap: "GetAppUsageDuration", fam: "BatteryOverview", q: "生成一张静态卡片，看最耗电的应用排行。", t: "停用能力", d: "能力不在清单", preflight: "fail", out: "neither", note: "GetAppUsageDuration 在 6.0 清单中停用" },
  { n: "M044", g: G5, pair: "Q057", fam: "ActivityOverview", q: "生成一张静态卡片，看今天的步数、里程和热量。", t: "写入路径冲突", d: "writeResultTo 重复", preflight: "fail", out: "neither", note: "同一能力写两条同路径绑定" },

  // G6 编辑与多轮：previousGenui 来自模板，是否复用模板
  { n: "M045", g: G6, pair: "Q009", fam: "WeatherOverview", q: "把这张天气卡片的标题改成“出门前看一眼”，其它不动。", t: "出门前看一眼", d: "改标题", out: "template+fusion", note: "纯文字修改应沿用模板" },
  { n: "M046", g: G6, gate: "search", pair: "Q009", fields: ["/current/condition", "/current/temperatureText", "/current/humidityPercent", "/current/windLevel"], fam: "WeatherOverview", q: "在这张天气卡片上再加湿度和风力，标题也改一下。", t: "加字段", d: "超出模板签名", out: "fusion-only", note: "加字段后超出模板可承载范围，应降级通用生成。门回放确认这条被 Search 字段门直接排除（见 audit --axis semantic），所以断言在 search 层而非 planner 层。" },
  { n: "M047", g: G6, pair: "Q009", fam: "WeatherOverview", q: "这张天气卡片改成 2x4，多放几天预报。", t: "改尺寸", d: "2x4 多日", size: "2x4", out: "neither", note: "2x4 不在模板支持尺寸内" },
  { n: "M048", g: G6, pair: "Q044", fam: "BatteryOverview", q: "把这张电量卡片的背景改成深色，数字再大一点。", t: "改样式", d: "纯视觉修改", out: "template+fusion", note: "纯视觉修改不得换掉模板" },

  // G7 否定语义、语言变体与显式样式冲突
  { n: "M049", g: G7, pair: "Q010", fam: "WeatherOverview", q: "帮我做个天气卡片，但别用那种一个大数字加图标的模板样式。", t: "天气非模板样式", d: "排斥模板", out: "fusion-only", note: "用户显式排斥模板版式" },
  { n: "M050", g: G7, pair: "Q025", fam: "CalendarOverview", q: "不要日程卡片，把明天那场评审会的地址给我一句话就行。", t: "拒绝卡片", d: "非卡片诉求", out: "neither", note: "不该生成卡片，模板与融球都不该触发" },
  { n: "M051", g: G7, pair: "Q020", fam: "CalendarOverview", q: "Make me a card showing my next meeting time and room.", t: "Next meeting", d: "English query", out: "template+fusion", note: "反向探针：英文表达也应正常命中，测漏触发" },
  { n: "M052", g: G7, pair: "Q049", fam: "BatteryOverview", q: "搞个电片，看看剩多少电，顺便进池设置。", t: "错别字电量", d: "口语与错别字", out: "template+fusion", note: "反向探针：错别字与口语不应导致漏触发" },
  { n: "M053", g: G7, pair: "Q004", fam: "WeatherOverview", q: "做个 2x4 的深色天气卡片，字号要大，预警和空气都要有。", t: "2x4 天气", d: "显式尺寸冲突", size: "2x4", out: "neither", note: "用户指定尺寸优先于模板尺寸" },
  { n: "M054", g: G7, pair: "Q066", fam: "SleepOverview", q: "用 asset.emoji_sleep 当整张卡片的背景，把睡眠得分放上面。", t: "素材冲突", d: "显式素材要求", out: "fusion-only", note: "模板自带图标位与用户指定大图冲突，不应既套模板又铺背景" }
];

const outOf = (c) => c.out;
const usedOf = (c) => (c.out === "template+fusion" || c.out === "template-only");
const fusionOf = (c) => c.out === "template+fusion" || c.out === "fusion-only";
// dir: fp=命中母本族即误触发；hit=必须命中母本族（测空态渲染/编辑复用/语言变体导致的漏触发）；amb=允许多族竞争
const dirOf = (c) => c.dir ?? "fp";
const HIT = new Set(["M033", "M034", "M035", "M036", "M038", "M045", "M048", "M051", "M052"]);

const cases = [];
for (const c of CASES) {
  const parentCase = parentIndex.get(c.pair);
  if (!parentCase) throw new Error(`母本用例不存在: ${c.pair}`);
  let p = cloneCase(c.pair);
  const deltas = ["userQuery", "title", "description"];

  if (c.also) {
    mergePair(p, c.also);
    deltas.push("candidateDataBindings", "candidateEventCandidates", "candidateAssetIds");
  }
  if (c.od) {
    const rec = odRecord(c.od);
    if (!rec) throw new Error(`开域用例不在 manifest: ${c.od}`);
    const { spec, status } = odSpec(c.od);
    c.q = spec.userQuery;
    c.t = spec.title;
    c.d = spec.description;
    c.odStatus = status;
  }
  if (c.fields) {
    setFields(p, parentCase.templateSignature.split("|")[1].split("[")[0], c.fields);
    deltas.push("candidateDataBindings");
  }
  if (c.cap) {
    p.content.candidateDataBindings[0].capabilityId = c.cap;
    deltas.push("candidateDataBindings");
  }
  if (c.size) {
    setSize(p, c.size);
    deltas.push("size");
  }
  if (c.out === "template-only") setPrdVer(p, "11.7.5.205");
  if (c.g === G6) {
    asSession(p, "2");
    deltas.push("session");
  }
  if (c.n === "M041") {
    p.content.candidateDataBindings = [];
    deltas.push("candidateDataBindings");
  }
  if (c.n === "M042") {
    p.content.candidateDataBindings[0].arguments = {};
    deltas.push("candidateDataBindings");
  }
  if (c.n === "M044") {
    const b = p.content.candidateDataBindings[0];
    p.content.candidateDataBindings = [b, { ...b }];
    deltas.push("candidateDataBindings");
  }

  rewrite(p, { query: c.q, title: c.t, description: c.d });

  const sig = signatureOf(p);
  const dir = c.amb ? "amb" : HIT.has(c.n) ? "hit" : dirOf(c);
  const allowed = dir === "fp" ? (c.req ?? []) : dir === "hit" ? [c.fam] : c.req;
  const forbidden = dir === "fp" ? [c.fam] : [];
  if (allowed !== undefined && usedOf(c) && !allowed.length) throw new Error(`${c.n}: outcome 声明会命中模板但允许族为空`);
  const caseId = `Q${321 + Number(c.n.slice(1))}`;
  const preflightFail = c.preflight === "fail";
  fs.writeFileSync(path.join(outDir, `${caseId}.json`), JSON.stringify(p, null, 2) + "\n", "utf8");
  cases.push({
    caseId,
    file: `${caseId}.json`,
    probeKey: c.n,
    variant: c.g,
    variantLabel: GROUP_LABEL[c.g],
    probeDirection: dir,
    reusedTaskSpecCase: c.pair,
    secondBaselineCase: c.also ?? null,
    semanticDelta: [...new Set(deltas)],
    mutationPaths: [],
    mutationArguments: {},
    templateId: null,
    targetTemplateFamily: c.fam,
    forbiddenTemplateFamily: forbidden,
    expectedTemplateFamily: allowed,
    forbiddenTemplateIds: forbidden.flatMap(idsOfFamily),
    expectedTemplateIds: allowed.flatMap(idsOfFamily),
    templateSignature: sig,
    capabilityId: p.content.candidateDataBindings[0]?.capabilityId ?? null,
    providerId: null,
    bindingCount: p.content.candidateDataBindings.length,
    requestedDisplayFieldCount: p.content.candidateDataBindings.reduce((s, b) => s + (b.candidateOutputFields?.length ?? 0), 0),
    eventCount: p.content.candidateEventCandidates.length,
    assetCount: p.content.candidateAssetIds.length,
    prdVer: p.deviceInfo.prdVer,
    expectedPreflight: c.preflight ?? "pass",
    // Search 层两道门只看字段（query_tokens 由 candidateOutputFields 构造，见 template_retrieval.py
    // _task_spec_field_token / 第 1032 行的 subset 判定），本集刻意不改字段，因此母本族模板必然进候选。
    // 语义轴的误检只能判最终采用，不能沿用 v1 的 Search 候选排除口径。
    expectedSearchEligibility: preflightFail ? "not-applicable" : c.gate === "search" ? "ineligible" : "eligible",
    expectedFinalTemplateAdoption: preflightFail || c.gate === "search" || dir === "fp" ? false : true,
    misfireAssertedAt: preflightFail ? "preflight" : c.gate === "search" ? "search-gate" : "final-template",
    expectedPlannerOrRender: preflightFail ? "not-applicable" : dir === "fp" ? "generic-or-other-family" : "template",
    expectationReason: c.note,
    expectedLayout: p.content.size,
    expectedOutcome: outOf(c),
    expectedTemplateUsed: usedOf(c),
    expectedFusionBall: fusionOf(c),
    inputClass: "semantic-misfire-probe",
    complexity: parentCase.complexity,
    coverageIncluded: true,
    coverageClass: `${c.g}:${c.fam}`,
    notes: c.note,
    openDomainCase: c.od ?? null,
    openDomainFactStatus: c.od ? c.odStatus : undefined
  });
}

const familiesTally = cases.reduce((a, x) => ((a[x.targetTemplateFamily] = (a[x.targetTemplateFamily] ?? 0) + 1), a), {});
const groupTally = cases.reduce((a, x) => ((a[x.variant] = (a[x.variant] ?? 0) + 1), a), {});
const eligibilityTally = cases.reduce((a, x) => ((a[x.expectedSearchEligibility] = (a[x.expectedSearchEligibility] ?? 0) + 1), a), {});

const manifest = {
  version: "semantic-perturbation-v2",
  purpose: "provider-template-false-trigger-v2-semantic",
  generatedAt: "2026-09-21",
  capabilityRegistry: v1.capabilityRegistry,
  requiredPrdVer: v1.requiredPrdVer,
  runtimeRomVersion: v1.runtimeRomVersion,
  sourceTestSet: "template",
  axis: "v1（perturbation_v1，240 条）做字段消融：缺 primary、缺 secondary、超集未覆盖字段。v2 补另一根轴：字段签名齐全但 query 业务语义不属于该模板族时会不会误命中。两轴合起来才是完整的模板误触发覆盖，任一单独看都会高估。",
  scope: {
    parentScope: parent.scope,
    familyPrefixMap: FAMILY_PREFIX,
    templateIdsInRegistry: TEMPLATE_IDS.length,
    familiesCovered: Object.keys(familiesTally).sort(),
    numbering: "Q322–Q375，接续 v1 的 Q082–Q321，不改动 v1 任何文件",
    probeCountBasis: "54 = 6 族 × ≥3 条假阳性(18) + 跨族竞争 8 + 开域误套 6 + 空态 6 + preflight 6 + 编辑复用 4 + 否定与变体 6"
  },
  vocabulary: {
    variant: GROUP_LABEL,
    probeDirection: {
      fp: "假阳性探针：命中 targetTemplateFamily 即误触发",
      hit: "假阴性探针：必须命中 targetTemplateFamily，不命中即漏触发",
      amb: "歧义探针：多族都算允许答案，只记录实际选择"
    },
    expectedSearchEligibility: ["eligible", "ineligible", "not-applicable"],
    expectedFinalTemplateAdoption: [true, false],
    misfireAssertedAt: ["final-template", "search-gate", "preflight"],
    expectedPlannerOrRender: ["template", "generic-or-other-family", "not-applicable"],
    expectedOutcome: ["template+fusion", "template-only", "fusion-only", "neither"],
    expectedPreflight: ["pass", "fail"]
  },
  judging: {
    layerWarning: "不要沿用 v1 口径。v1 判“templateId 未出现在 Search 候选即通过”，那是字段消融轴成立的前提。Search 的 query_tokens 由 candidateOutputFields 构造（template_retrieval.py 的 _task_spec_field_token 与第 1032 行 subset 判定），只看字段不看 query 文本，所以本集不改字段 → 母本族必然进候选；照 v1 判会得出误检率 100% 的假结果。",
    misfire: "误检定义在最终采用：expectedFinalTemplateAdoption=false 时，最终 CardSpec 采用的 templateId 不得落在 forbiddenTemplateIds 内；若采用了 expectedTemplateIds 中的兄弟模板则不算误检。",
    miss: "expectedFinalTemplateAdoption=true 而最终未采用该族任何模板 → 判漏触发（对应 hit 探针）。",
    preflight: "misfireAssertedAt=preflight 的 6 条只判是否在生成前终止，出现任何产物即失败，不进误检率分母。",
    denominator: "误检率必须按族分别报。禁止槽位合计 618，其中 WeatherOverview 198、ScheduleOverview 184，两族占约 62%，HeartRate/Activity/Sleep 各 18；混合成一个总数会被大族主导。同时要说明是“每探针一票”还是“每 templateId 一票”，两种口径数字不同。",
    upstreamInterception: "fp 探针若被上游 preflight 先裁掉不相关候选，也会表现为“没采用”，但根因不在模板层。运行器需记录排除实际发生在 preflight、search 还是 cardplan/渲染层。",
    misbind: "族选对但字段错绑（Q330、Q342 这类）无法只靠模板 ID 判出，需比对渲染字段与文案。"
  },
  summary: {
    totalCases: cases.length,
    byVariant: groupTally,
    byProbeDirection: cases.reduce((a, x) => ((a[x.probeDirection] = (a[x.probeDirection] ?? 0) + 1), a), {}),
    byEligibility: eligibilityTally,
    byTargetFamily: familiesTally,
    byOutcome: cases.reduce((a, x) => ((a[x.expectedOutcome] = (a[x.expectedOutcome] ?? 0) + 1), a), {}),
    preflightFailCases: cases.filter((x) => x.expectedPreflight === "fail").length,
    forbiddenTemplateIdsCovered: new Set(cases.flatMap((x) => x.forbiddenTemplateIds)).size,
    openDomainProbes: cases
      .filter((x) => x.openDomainCase)
      .reduce((a, x) => ((a[x.openDomainFactStatus ?? "unknown"] = (a[x.openDomainFactStatus ?? "unknown"] ?? 0) + 1), a), {})
  },
  cases
};
fs.writeFileSync(path.join(outDir, "perturbation_expected.json"), JSON.stringify(manifest, null, 2) + "\n", "utf8");
console.log(JSON.stringify(manifest.summary, null, 2));
