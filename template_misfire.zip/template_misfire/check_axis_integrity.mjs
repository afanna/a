import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// 只读校验：编号连续、manifest 与文件一一对应、跨轴引用可解析、无"预期被拒"声明、无空候选载荷
const here = path.dirname(fileURLToPath(import.meta.url));
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const index = readJson(path.join(here, "manifest.json"));
const axes = {
  semantic: { manifest: "semantic_axis/perturbation_expected.json", dir: "semantic_axis" },
  boundary: { manifest: "boundary_axis/manifest.json", dir: "boundary_axis" },
  field: { manifest: "field_axis/manifest.json", dir: "field_axis" }
};
const problems = [];
const allIds = new Set();
const payloadsByAxis = {};
// 先收集全部三轴的载荷编号，避免按处理顺序误判断链
for (const [key, axis] of Object.entries(axes)) {
  payloadsByAxis[key] = new Set(
    fs.readdirSync(path.join(here, axis.dir)).filter((n) => /^Q\d+\.json$/.test(n)).map((n) => n.replace(/\.json$/, ""))
  );
}
const knownPayload = (id) =>
  Object.values(payloadsByAxis).some((set) => set.has(id)) || fs.existsSync(path.join(here, "..", "template", `${id}.json`));
for (const [key, axis] of Object.entries(axes)) {
  const manifest = readJson(path.join(here, axis.manifest));
  const files = [...payloadsByAxis[key]].sort();
  const ids = (manifest.cases ?? []).map((c) => c.caseId);
  if (ids.length !== new Set(ids).size) problems.push(`${key}: manifest 内 caseId 重复`);
  const missing = ids.filter((id) => !files.includes(id));
  const extra = files.filter((id) => !ids.includes(id));
  if (missing.length) problems.push(`${key}: manifest 有但文件缺 ${missing.slice(0, 5).join(",")}`);
  if (extra.length) problems.push(`${key}: 文件有但 manifest 缺 ${extra.slice(0, 5).join(",")}`);
  const nums = ids.map((id) => Number(id.slice(1))).sort((a, b) => a - b);
  for (let i = 0; i < nums.length; i++) if (nums[i] !== nums[0] + i) { problems.push(`${key}: 编号不连续（${ids[i]} 起）`); break; }
  for (const item of manifest.cases ?? []) {
    if (item.variant === "preflight" || item.assertedAt === "preflight" || item.expectedPreflight === "fail") {
      problems.push(`${key}: ${item.caseId} 声明为"预期被拒"，违反只保留合法输入的策略`);
    }
    if (item.file && !files.includes(item.file.replace(/\.json$/, ""))) problems.push(`${key}: ${item.caseId} 的 file 字段指向缺失文件`);
    for (const id of [item.sourceCase, item.sourceCaseB, item.duplicateOf, ...(item.mutation?.pair ?? [])].filter(Boolean)) {
      if (!knownPayload(id)) problems.push(`${key}: ${item.caseId} 引用断链 ${id}`);
    }
    const payload = readJson(path.join(here, axis.dir, `${item.caseId}.json`)).content ?? {};
    if (!(payload.candidateDataBindings ?? []).length && !(payload.candidateEventCandidates ?? []).length && !(payload.candidateAssetIds ?? []).length) {
      problems.push(`${key}: ${item.caseId} 三类候选全空，等于没有可测输入`);
    }
  }
  for (const id of ids) allIds.add(id);
}
const declared = index.axes;
for (const key of ["field", "semantic", "boundary"]) {
  const ids = [...allIds].filter((id) => {
    const n = Number(id.slice(1));
    const [from, to] = declared[key].range.split("-").map((x) => Number(x.slice(1)));
    return n >= from && n <= to;
  });
  if (ids.length !== declared[key].caseCount) problems.push(`index: ${key} 声明 ${declared[key].caseCount} 实数 ${ids.length}（range ${declared[key].range}）`);
}
// 编号必须全局唯一：同一 id 出现在两个轴就是冲突（原先对 Set 求数组找重复，永远查不出来）
const seenAxis = new Map();
const crossDup = [];
for (const [key, axis] of Object.entries(axes)) {
  for (const id of (readJson(path.join(here, axis.manifest)).cases ?? []).map((c) => c.caseId)) {
    if (seenAxis.has(id)) crossDup.push(`${id}(${seenAxis.get(id)}/${key})`);
    else seenAxis.set(id, key);
  }
}
if (crossDup.length) problems.push(`跨轴编号重复 ${crossDup.slice(0, 5).join(",")}`);
console.log(JSON.stringify({ axes: Object.fromEntries(Object.entries(declared).map(([k, v]) => [k, `${v.range} (${v.caseCount})`])), total: index.totalCaseCount, problems, ok: problems.length === 0 }, null, 2));
if (problems.length) process.exitCode = 1;
