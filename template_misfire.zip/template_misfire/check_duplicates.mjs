import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// 只读：三档口径统计误触发集的重复度
//  口径1 只看模型真正吃到的语义输入：userQuery + 候选(能力/字段/事件/素材) + size
//  口径2 口径1 + title/description（当前 title 里写着模板 id 与缺陷标签）
//  口径3 口径2 + 清单里的判定标注
const here = path.dirname(fileURLToPath(import.meta.url));
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const norm = (s) => String(s ?? "").replace(/[0-9０-９]/g, "").replace(/[\s，。、；：""''"'\(\)（）《》\-—_·!?！？]/g, "").trim();
const sig = (c) => {
  const bindings = (c.candidateDataBindings ?? [])
    .map((b) => `${b.capabilityId}:${(b.candidateOutputFields ?? []).map((f) => (typeof f === "string" ? f : f.path)).sort().join(",")}`)
    .sort().join("|");
  const events = (c.candidateEventCandidates ?? []).map((e) => e.call ?? e.eventId ?? e.capabilityId).filter(Boolean).sort().join(",");
  return `${c.size}#${bindings}#${events}#${[...(c.candidateAssetIds ?? [])].sort().join(",")}`;
};

const AXES = [
  ["field", "field_axis/manifest.json", "field_axis"],
  ["semantic", "semantic_axis/perturbation_expected.json", "semantic_axis"],
  ["boundary", "boundary_axis/manifest.json", "boundary_axis"]
];
const LABELS = ["variant", "expectedOutcome", "assertedAt", "expectedTemplateUsed", "targetTemplateFamily", "forbiddenTemplateFamily", "templateId", "defectKind", "sourceCase"];
const rows = [];
for (const [axis, manPath, dir] of AXES) {
  const manifest = readJson(path.join(here, manPath));
  for (const item of manifest.cases ?? []) {
    const content = readJson(path.join(here, dir, item.file ?? `${item.caseId}.json`)).content ?? {};
    rows.push({
      axis,
      id: item.caseId,
      k1: `${norm(content.userQuery)}||${sig(content)}`,
      k2: `${norm(content.userQuery)}||${sig(content)}||${norm(content.title)}||${norm(content.description)}`,
      k3: `${norm(content.userQuery)}||${sig(content)}||${norm(content.title)}||${LABELS.map((f) => JSON.stringify(item[f] ?? null)).join(",")}`,
      title: String(content.title ?? "")
    });
  }
}
const uniq = (key) => new Set(rows.map((r) => r[key])).size;
const leaky = rows.filter((r) => /Overview@|Compact@|Full@|Hero@|Support@|@[0-9]/.test(r.title)).length;
console.log(`总 ${rows.length} 条`);
for (const [label, key] of [["口径1 userQuery+候选", "k1"], ["口径2 +title/description", "k2"], ["口径3 +判定标注", "k3"]]) {
  const u = uniq(key);
  const dup = rows.length - u;
  console.log(`  ${label}: 唯一 ${u} / 重复 ${dup} 条`);
}
console.log(`  title 里含模板 id 或版本后缀（如 XxxOverviewCompact@1）的条数: ${leaky}`);
for (const axis of ["field", "semantic", "boundary"]) {
  const sub = rows.filter((r) => r.axis === axis);
  const cnt = (key) => sub.length - new Set(sub.map((r) => r[key])).size;
  console.log(`  ${axis} ${sub.length} 条 -> 口径1重复 ${cnt("k1")} | 口径2重复 ${cnt("k2")} | 口径3重复 ${cnt("k3")}`);
}
