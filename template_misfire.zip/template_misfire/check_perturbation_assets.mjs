import fs from "node:fs/promises";
import path from "node:path";
import { fieldAxisDir, legacyCapabilityRoot } from "./paths.mjs";

const caseRoot = fieldAxisDir;
const registry = path.join(legacyCapabilityRoot, "asset_capabilities.json");
const readJson = async (p) => JSON.parse(await fs.readFile(p, "utf8"));

const assets = (await readJson(registry)).filter((item) => item.enabled !== false);
const valid = new Set(assets.map((item) => item.id));
const files = (await fs.readdir(caseRoot)).filter((name) => /^Q\d+\.json$/.test(name)).sort();
const errors = [];
const emojiUsage = new Map();
let filesWithEmoji = 0;
for (const name of files) {
  const spec = await readJson(path.join(caseRoot, name));
  const top = spec.candidateAssetIds ?? [];
  if (!top.length) errors.push(`${name}: empty assets`);
  if (JSON.stringify(top) !== JSON.stringify(spec.content?.candidateAssetIds)) errors.push(`${name}: inner mismatch`);
  for (const id of top) {
    if (!valid.has(id)) errors.push(`${name}: unknown ${id}`);
    if (id.includes("emoji_")) emojiUsage.set(id, (emojiUsage.get(id) ?? 0) + 1);
  }
  if (top.some((id) => id.includes("emoji_"))) filesWithEmoji += 1;
}
const manifest = await readJson(path.join(caseRoot, "perturbation_expected.json"));
const uncovered = manifest.cases.filter((item) => item.variant === "uncovered-valid-field");
const uncoveredDetail = [];
for (const item of uncovered) {
  const spec = await readJson(path.join(caseRoot, item.file));
  uncoveredDetail.push({
    file: item.file,
    template: item.templateId,
    query: spec.userQuery,
    fields: spec.candidateDataBindings.flatMap((binding) => binding.candidateOutputFields),
    assets: spec.candidateAssetIds,
    events: spec.candidateEventCandidates.map((event) => event.capabilityId),
  });
}
console.log(JSON.stringify({
  files: files.length,
  errors: errors.slice(0, 12),
  errorCount: errors.length,
  filesWithEmoji,
  emojiUsage: Object.fromEntries(emojiUsage),
  eligible: manifest.summary.eligible,
  ineligible: manifest.summary.ineligible,
  hasSplitAssetRegistry: "assetRegistry" in manifest,
  uncoveredDetail,
}, null, 2));
