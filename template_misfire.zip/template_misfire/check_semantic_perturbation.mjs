import fs from "node:fs";
import path from "node:path";

// 校验语义轴误触发探针集（semantic_axis）：单变量纪律、族与 templateId 互斥、
// 分层断言一致性、编号不与 field_axis 冲突、族配额与母本覆盖率。
import { fieldAxisDir, parentTemplateDir, semanticAxisDir } from "./paths.mjs";

const outDir = semanticAxisDir;
const fieldDir = fieldAxisDir;
const parent = JSON.parse(fs.readFileSync(path.join(parentTemplateDir, "template_expected.json"), "utf8"));
const parentIndex = new Map(parent.cases.map((c) => [c.caseId, c]));
const manifest = JSON.parse(fs.readFileSync(path.join(outDir, "perturbation_expected.json"), "utf8"));
const v1 = JSON.parse(fs.readFileSync(path.join(fieldDir, "perturbation_expected.json"), "utf8"));
const v1Ids = new Set(v1.cases.map((c) => c.caseId));
const v1TemplateIds = new Set(v1.cases.map((c) => c.templateId));
const DUP_KEYS = ["bundleName", "userQuery", "candidateDataBindings", "title", "size", "candidateEventCandidates", "description", "candidateAssetIds"];
const errors = [];
const warnings = [];
const FAMILIES = ["ActivityOverview", "BatteryOverview", "BluetoothDeviceOverview", "CalendarOverview", "CountdownOverview", "HeartRateOverview", "SleepOverview", "WeatherOverview"];
const FAMILY_PREFIX = { CalendarOverview: "ScheduleOverview" };
const PREFIXES = FAMILIES.map((f) => [FAMILY_PREFIX[f] ?? f, f]);
const familyOfId = (id) => {
  const hit = PREFIXES.filter(([p]) => id.startsWith(p)).sort((a, b) => b[0].length - a[0].length)[0];
  return hit ? hit[1] : "unknown";
};

const files = fs.readdirSync(outDir).filter((n) => /^Q\d{3}\.json$/.test(n)).sort();
if (files.length !== manifest.cases.length) errors.push(`文件数 ${files.length} 与 manifest ${manifest.cases.length} 不符`);
const collide = files.filter((f) => v1Ids.has(f.replace(/\.json$/, "")));
if (collide.length) errors.push(`编号与 v1 冲突: ${collide.join(",")}`);
const tooLow = manifest.cases.filter((c) => Number(c.caseId.slice(1)) <= 321).map((c) => c.caseId);
if (tooLow.length) errors.push(`编号未接续 v1（应 >Q321）: ${tooLow.join(",")}`);

const OUTCOME = {
  "template+fusion": { used: true, fusion: true },
  "template-only": { used: true, fusion: false },
  "fusion-only": { used: false, fusion: true },
  neither: { used: false, fusion: false }
};

const familyTally = new Map();
for (const c of manifest.cases) {
  const spec = JSON.parse(fs.readFileSync(path.join(outDir, `${c.caseId}.json`), "utf8"));
  const p = parentIndex.get(c.reusedTaskSpecCase);
  if (!p) {
    errors.push(`${c.caseId}: 母本 ${c.reusedTaskSpecCase} 不在 template_expected.json`);
    continue;
  }
  const base = JSON.parse(fs.readFileSync(path.join(parentTemplateDir, `${c.reusedTaskSpecCase}.json`), "utf8"));

  for (const k of DUP_KEYS) if (JSON.stringify(spec[k]) !== JSON.stringify(spec.content?.[k])) errors.push(`${c.caseId}: 顶层 ${k} 与 content 不一致`);

  const declared = new Set(c.semanticDelta);
  if (!declared.has("userQuery")) errors.push(`${c.caseId}: 探针必须至少改动 userQuery，否则与母本无差别`);
  for (const k of ["size", "candidateEventCandidates", "candidateAssetIds", "candidateDataBindings"]) {
    if (declared.has(k)) continue;
    if (JSON.stringify(spec.content[k]) !== JSON.stringify(base.content[k])) errors.push(`${c.caseId}: ${k} 改了但未登记进 semanticDelta`);
  }
  if (!declared.has("deviceInfo") && JSON.stringify(spec.deviceInfo) !== JSON.stringify(base.deviceInfo) && c.expectedOutcome !== "template-only") {
    errors.push(`${c.caseId}: deviceInfo 与母本不同（只有 template-only 允许降版本）`);
  }
  if (!declared.has("session") && c.variant !== "edit-reuse" && JSON.stringify(spec.session) !== JSON.stringify(base.session)) {
    errors.push(`${c.caseId}: session 与母本不同但未登记 semanticDelta`);
  }

  const famOverlap = c.expectedTemplateFamily.filter((f) => c.forbiddenTemplateFamily.includes(f));
  if (famOverlap.length) errors.push(`${c.caseId}: 期望族与禁止族重叠 ${famOverlap.join(",")}，探针无意义`);
  const idOverlap = c.expectedTemplateIds.filter((i) => c.forbiddenTemplateIds.includes(i));
  if (idOverlap.length) errors.push(`${c.caseId}: 期望 templateId 与禁止 templateId 重叠 ${idOverlap.slice(0, 2).join(",")}…`);
  for (const i of [...c.forbiddenTemplateIds, ...c.expectedTemplateIds]) if (!v1TemplateIds.has(i)) errors.push(`${c.caseId}: templateId 不在 v1 注册清单 ${i}`);

  if (!["fp", "hit", "amb"].includes(c.probeDirection)) errors.push(`${c.caseId}: probeDirection 非法`);
  const layer = c.misfireAssertedAt;
  if (!["final-template", "search-gate", "preflight"].includes(layer)) errors.push(`${c.caseId}: misfireAssertedAt 非法 ${layer}`);
  const wantEligibility = layer === "preflight" ? "not-applicable" : layer === "search-gate" ? "ineligible" : "eligible";
  if (c.expectedSearchEligibility !== wantEligibility) {
    errors.push(`${c.caseId}: ${layer} 层的 expectedSearchEligibility 应为 ${wantEligibility}`);
  }
  const wantAdoption = layer === "final-template" && c.probeDirection !== "fp";
  if (c.expectedFinalTemplateAdoption !== wantAdoption) errors.push(`${c.caseId}: expectedFinalTemplateAdoption 应为 ${wantAdoption}`);
  if (c.probeDirection === "fp" && !c.forbiddenTemplateIds.length) errors.push(`${c.caseId}: fp 探针没有禁止的 templateId`);
  if (c.probeDirection === "hit") {
    if (c.forbiddenTemplateIds.length) errors.push(`${c.caseId}: hit 探针不应有禁止 templateId`);
    if (!c.expectedTemplateIds.length) errors.push(`${c.caseId}: hit 探针必须给出期望 templateId`);
    if (layer !== "final-template") errors.push(`${c.caseId}: hit 探针必须判最终采用`);
  }
  if (c.probeDirection === "amb") {
    if (c.forbiddenTemplateIds.length) errors.push(`${c.caseId}: amb 探针不应有禁止 templateId`);
    if (!c.expectedTemplateIds.length) errors.push(`${c.caseId}: amb 探针必须给出允许 templateId`);
  }
  if (layer === "preflight" && c.expectedOutcome !== "neither") errors.push(`${c.caseId}: preflight 条目应期望 neither`);
  if (c.expectedPreflight === "fail" && layer !== "preflight") errors.push(`${c.caseId}: preflight=fail 却标了 ${layer}`);

  const rule = OUTCOME[c.expectedOutcome];
  if (!rule) errors.push(`${c.caseId}: expectedOutcome 非法`);
  else {
    if (rule.used !== c.expectedTemplateUsed) errors.push(`${c.caseId}: expectedTemplateUsed 与 outcome 矛盾`);
    if (rule.fusion !== c.expectedFusionBall) errors.push(`${c.caseId}: expectedFusionBall 与 outcome 矛盾`);
  }
  if (c.variant === "edit-reuse" && spec.session?.isNew !== false) errors.push(`${c.caseId}: edit 探针未标记 isNew=false`);
  if (!c.expectationReason) warnings.push(`${c.caseId}: 缺 expectationReason`);
  if (c.openDomainCase && !["real-payload", "verified-web"].includes(c.openDomainFactStatus)) {
    warnings.push(`${c.caseId}: 借用开域条 ${c.openDomainCase}，其事实状态为 ${c.openDomainFactStatus}，query 数值不得当真实数据引用`);
  }
  familyTally.set(c.targetTemplateFamily, (familyTally.get(c.targetTemplateFamily) ?? 0) + 1);
}

for (const [f, n] of familyTally) if (n < 3) errors.push(`族 ${f} 只有 ${n} 条探针，少于 3 条无法判趋势`);

const positives = parent.cases.filter((x) => x.expectedOutcome === "template+fusion" || x.expectedOutcome === "template-only");
const usedParents = new Set(manifest.cases.map((c) => c.reusedTaskSpecCase));
const uncovered = positives.filter((x) => !usedParents.has(x.caseId)).map((x) => x.caseId);

console.log(
  JSON.stringify(
    {
      probes: files.length,
      axis: "v2 语义轴，判最终模板采用；字段轴见 perturbation_v1（240 条，判 Search 候选排除，未改动）",
      layer: "misfireAssertedAt=" + [...new Set(manifest.cases.map((c) => c.misfireAssertedAt))].join(","),
      byAdoption: manifest.cases.reduce((a, c) => ((a[String(c.expectedFinalTemplateAdoption)] = (a[String(c.expectedFinalTemplateAdoption)] ?? 0) + 1), a), {}),
      forbiddenSlotsByFamily: manifest.cases
        .flatMap((c) => c.forbiddenTemplateIds.map(familyOfId))
        .reduce((a, f) => ((a[f] = (a[f] ?? 0) + 1), a), {}),
      numberingRange: `${manifest.cases[0]?.caseId}–${manifest.cases.at(-1)?.caseId}`,
      forbiddenTemplateIdsCovered: new Set(manifest.cases.flatMap((c) => c.forbiddenTemplateIds)).size,
      byEligibility: manifest.summary.byEligibility,
      positiveParentCoverage: `${usedParents.size}/${positives.length} = ${((usedParents.size / positives.length) * 100).toFixed(1)}%`,
      uncoveredParents: uncovered.slice(0, 12),
      errors: errors.slice(0, 25),
      errorCount: errors.length,
      warnings: warnings.slice(0, 6),
      warningCount: warnings.length
    },
    null,
    2
  )
);
if (errors.length) process.exitCode = 1;
