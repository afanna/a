import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// 只读：统计误触发集载荷里残留的"合成痕迹"——拼接缝、旧编号、内部字段路径、模板 id
const here = path.dirname(fileURLToPath(import.meta.url));
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const AXES = [["field", "field_axis/manifest.json", "field_axis"], ["semantic", "semantic_axis/perturbation_expected.json", "semantic_axis"], ["boundary", "boundary_axis/manifest.json", "boundary_axis"]];
const rules = {
  拼接缝: (t) => /。；|；必须/.test(t.userQuery),
  query里出现测试说明口吻: (t) => /(应正常命中|不应导致|检查.{0,12}是否|业务内容与原始字段)/.test(t.userQuery),
  title含旧编号或轴名: (t) => /｜|\bboundary-\d+|field-boundary|语义错配边界：|字段边界：|状态边界：|多能力竞争：/.test(t.title),
  description含字段路径或轴标记: (t) => /\/[a-z]+[A-Za-z]*|boundary-axis|explicit field|[A-Za-z]+Probe\b/.test(t.description),
  title或description含模板id: (t) => /@1\b|Overview[A-Za-z]*@|Compact|Full\b|Hero|Support/.test(`${t.title}${t.description}`)
};
const tally = {};
const samples = {};
let total = 0;
for (const [axis, man, dir] of AXES) {
  for (const item of readJson(path.join(here, man)).cases) {
    const c = readJson(path.join(here, dir, item.file ?? `${item.caseId}.json`)).content ?? {};
    const t = { userQuery: String(c.userQuery ?? ""), title: String(c.title ?? ""), description: String(c.description ?? "") };
    total++;
    for (const [name, fn] of Object.entries(rules)) {
      if (fn(t)) {
        tally[name] = (tally[name] ?? 0) + 1;
        (samples[name] ??= []).push(`${axis}/${item.caseId}`);
      }
    }
  }
}
console.log(`共 ${total} 条载荷`);
for (const name of Object.keys(rules)) console.log(`  ${name}: ${tally[name] ?? 0}` + (tally[name] ? ` （${samples[name].slice(0, 4).join(", ")}${samples[name].length > 4 ? " …" : ""}）` : ""));
