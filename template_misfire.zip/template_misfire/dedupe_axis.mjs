import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

// 剔除整条重复的用例：输入指纹与判定指纹都相同才算重复（同文案不同候选属单变量对照，保留）
// 默认 dry-run，加 --apply 才写盘；被剔载荷进 _removed_duplicates/<轴>/，文件名带内容指纹。
// 写盘采用"全部读进内存 -> 清空 -> 按新号写回"，不用 rename。
const here = path.dirname(fileURLToPath(import.meta.url));
const APPLY = process.argv.includes("--apply");
const AXIS = (process.argv[2] ?? "boundary").replace(/--apply/g, "").trim() || "boundary";
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const writeJson = (p, v) => fs.writeFileSync(p, JSON.stringify(v, null, 2) + "\n", "utf8");

const CONF = {
  boundary: { dir: "boundary_axis", manifest: "boundary_axis/manifest.json", startIndex: 362 },
  semantic: { dir: "semantic_axis", manifest: "semantic_axis/perturbation_expected.json", startIndex: 322 }
};
const conf = CONF[AXIS];
if (!conf) throw new Error(`未知轴 ${AXIS}`);

const norm = (s) => String(s ?? "").replace(/[0-9]/g, "").replace(/[\s，。、；：""''"'（）()]/g, "");
const inputFp = (c) => {
  const bindings = (c.candidateDataBindings ?? [])
    .map((b) => `${b.capabilityId}|${JSON.stringify(b.arguments ?? {})}|${b.writeResultTo ?? b.candidateWriteRoot ?? ""}|${[...(b.candidateOutputFields ?? [])].sort().join(",")}`)
    .sort().join("||");
  const events = (c.candidateEventCandidates ?? []).map((e) => JSON.stringify(e)).sort().join(",");
  return [norm(c.userQuery), norm(c.title), norm(c.description), c.size, bindings, events, [...(c.candidateAssetIds ?? [])].sort().join(",")].join("#");
};
const expectFp = (item) =>
  [item.variant, item.assertedAt, item.expectedOutcome, item.mutation?.mode ?? "", item.templateId ?? "", item.targetTemplateFamily ?? "", item.expectedTemplateUsed ?? ""].join("|");

const manifest = readJson(path.join(here, conf.manifest));
const rows = (manifest.cases ?? []).map((item) => {
  const payload = readJson(path.join(here, conf.dir, item.file ?? `${item.caseId}.json`));
  return { item, payload, fp: `${inputFp(payload.content ?? {})}@@${expectFp(item)}` };
});
const byFp = new Map();
for (const r of rows) (byFp.get(r.fp) ?? byFp.set(r.fp, []).get(r.fp)).push(r);

const richness = (r) => ["sourceCase", "duplicateOf", "candidateOutputFields", "rationale", "mutation"].filter((k) => r.item[k] != null && r.item[k] !== "").length;
const dropped = [];
const keepers = [];
for (const group of byFp.values()) {
  if (group.length === 1) { keepers.push(group[0]); continue; }
  const sorted = [...group].sort((a, b) => richness(b) - richness(a) || a.item.caseId.localeCompare(b.item.caseId));
  const [keeper, ...rest] = sorted;
  for (const r of rest) {
    if (keeper.item.duplicateOf == null && r.item.duplicateOf != null) keeper.item.duplicateOf = r.item.duplicateOf;
    if (keeper.item.sourceCase == null && r.item.sourceCase != null) keeper.item.sourceCase = r.item.sourceCase;
    (keeper.item.mergedFrom ??= []).push(r.item.caseId);
    dropped.push(r);
  }
  keepers.push(keeper);
}
keepers.sort((a, b) => Number(a.item.caseId.slice(1)) - Number(b.item.caseId.slice(1)));

console.log(`轴 ${AXIS}：${rows.length} 条 -> 保留 ${keepers.length} 条，剔除整条重复 ${dropped.length} 条`);
for (const r of dropped.slice(0, 12)) {
  const keeper = keepers.find((k) => (k.item.mergedFrom ?? []).includes(r.item.caseId));
  console.log(`  剔 ${r.item.caseId}（并入 ${keeper.item.caseId}）variant=${r.item.variant} "${(r.payload.content.userQuery ?? "").slice(0, 30)}"`);
}
if (!APPLY) {
  console.log("\ndry-run：未写盘。加 --apply 落盘。");
  process.exit(0);
}

// 隔离被剔载荷（带内容指纹，避免与历史同名文件互相顶掉）
const quarantine = path.join(here, "_removed_duplicates", AXIS);
fs.mkdirSync(quarantine, { recursive: true });
for (const r of dropped) {
  const bytes = JSON.stringify(r.payload, null, 2) + "\n";
  const fp = crypto.createHash("sha256").update(bytes).digest("hex").slice(0, 8);
  const target = path.join(quarantine, `${r.item.caseId}__${fp}.json`);
  if (!fs.existsSync(target)) fs.writeFileSync(target, bytes, "utf8");
  if (!fs.existsSync(target)) throw new Error(`隔离副本未生成，中止：${r.item.caseId}`);
}

// 连续重编号 + 重挂引用（被剔 id 指向其保留代表）
const mergedTo = new Map();
for (const k of keepers) for (const id of k.item.mergedFrom ?? []) mergedTo.set(id, k.item.caseId);
const nextNum = conf.startIndex;
const shift = new Map();
keepers.forEach((r, i) => shift.set(r.item.caseId, `Q${nextNum + i}`));
const resolve = (v) => {
  if (typeof v !== "string" || !v) return v;
  const base = mergedTo.get(v) ?? v;
  return shift.get(base) ?? (rows.some((r) => r.item.caseId === base) ? null : v);
};
for (const r of keepers) {
  const oldId = r.item.caseId;
  r.item.caseId = shift.get(oldId);
  r.item.file = `${r.item.caseId}.json`;
  r.item.probeKey = `${AXIS}-${r.item.caseId.slice(1)}-${r.item.variant}`;
  if (r.item.sourceCase) r.item.sourceCase = resolve(r.item.sourceCase) ?? null;
  if (r.item.duplicateOf) r.item.duplicateOf = resolve(r.item.duplicateOf) ?? null;
  if (Array.isArray(r.item.mutation?.pair)) {
    r.item.mutation.pair = [...new Set(r.item.mutation.pair.map(resolve))].filter(Boolean);
    if (r.item.mutation.pair.length < 2) delete r.item.mutation.pair;
  }
}
// 先清空再写，逐条核对数量
const dirAbs = path.join(here, conf.dir);
for (const f of fs.readdirSync(dirAbs)) if (/^Q\d+\.json$/.test(f)) fs.rmSync(path.join(dirAbs, f));
for (const r of keepers) writeJson(path.join(dirAbs, r.item.file), r.payload);
if (fs.readdirSync(dirAbs).filter((n) => /^Q\d+\.json$/.test(n)).length !== keepers.length) throw new Error("写回数量与保留条数不一致");

manifest.cases = keepers.map((r) => r.item);
manifest.caseCount = keepers.length;
manifest.dedupePolicy = "整条重复（输入指纹+判定指纹均相同）只保留一条，其余记录在 mergedFrom；同文案不同候选属单变量对照，不算重复";
writeJson(path.join(here, conf.manifest), manifest);

const index = readJson(path.join(here, "manifest.json"));
const nums = keepers.map((r) => Number(r.item.caseId.slice(1)));
index.axes[AXIS].range = `Q${Math.min(...nums)}-Q${Math.max(...nums)}`;
index.axes[AXIS].caseCount = keepers.length;
index.totalCaseCount = readJson(path.join(here, "field_axis/manifest.json")).cases.length + readJson(path.join(here, "semantic_axis/perturbation_expected.json")).cases.length + (AXIS === "boundary" ? keepers.length : readJson(path.join(here, "boundary_axis/manifest.json")).cases.length);
writeJson(path.join(here, "manifest.json"), index);
writeJson(path.join(here, `deduped_${AXIS}_report.json`), {
  axis: AXIS,
  before: rows.length,
  after: keepers.length,
  removed: dropped.map((r) => r.item.caseId),
  ranges: { [AXIS]: index.axes[AXIS].range },
  total: index.totalCaseCount
});
console.log(`\n已落盘：${AXIS} ${index.axes[AXIS].range}（${keepers.length} 条），总 ${index.totalCaseCount} 条`);
