// 删除指定用例并保持一致性：隔离原件 -> 该轴连续重编号 -> 重挂跨轴引用 -> 更新总索引。
//
// 与 dedupe_axis.mjs 的区别：这里删的是"人工判定不该留在集内"的用例（例如字段门无法排除、
// 必然触发模板的用例），不是整条重复。默认 dry-run，加 --apply 落盘。
// 载荷一律先读进内存再落盘，不用 rename；隔离文件名带内容指纹，避免重名顶掉。
//
// 用法：node drop_cases.mjs --axis=field --ids=Q166,Q167 --reason=must-trigger-template [--apply]
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const writeJson = (p, v) => fs.writeFileSync(p, JSON.stringify(v, null, 2) + "\n", "utf8");
const arg = (name, dflt = "") => {
  const hit = process.argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.split("=", 2)[1] : dflt;
};

const AXIS = arg("axis");
const IDS = arg("ids").split(",").map((s) => s.trim()).filter(Boolean);
const REASON = arg("reason", "manual-drop");
const APPLY = process.argv.includes("--apply");

const AXES = {
  field: { dir: "field_axis", manifest: "field_axis/manifest.json", start: 82 },
  semantic: { dir: "semantic_axis", manifest: "semantic_axis/perturbation_expected.json", start: 322 },
  boundary: { dir: "boundary_axis", manifest: "boundary_axis/manifest.json", start: 362 }
};
if (!AXES[AXIS]) throw new Error(`--axis 必须是 ${Object.keys(AXES).join("/")}`);
if (!IDS.length) throw new Error("--ids 不能为空");

const manifests = {};
for (const [key, cfg] of Object.entries(AXES)) manifests[key] = readJson(path.join(here, cfg.manifest));
const allIds = new Set(Object.values(manifests).flatMap((m) => (m.cases ?? []).map((c) => c.caseId)));
const unknown = IDS.filter((id) => !allIds.has(id));
if (unknown.length) throw new Error(`这些编号不在任何轴里（不得用在册号试跑）：${unknown.join(",")}`);
const owner = new Map();
for (const [key, cfg] of Object.entries(AXES)) for (const item of manifests[key].cases ?? []) owner.set(item.caseId, key);
const wrongAxis = IDS.filter((id) => owner.get(id) !== AXIS);
if (wrongAxis.length) throw new Error(`这些编号不属于 ${AXIS} 轴：${wrongAxis.map((id) => `${id}(${owner.get(id)})`).join(",")}`);

const dropSet = new Set(IDS);
const target = manifests[AXIS];
const survivors = (target.cases ?? []).filter((c) => !dropSet.has(c.caseId));
const removed = (target.cases ?? []).filter((c) => dropSet.has(c.caseId));
console.log(`${AXIS} 轴 ${(target.cases ?? []).length} 条 -> 保留 ${survivors.length} 条，删除 ${removed.length} 条（原因 ${REASON}）`);
for (const item of removed) console.log(`  删 ${item.caseId} 目标=${item.templateId ?? "-"} defect=${item.defectKind ?? "-"}`);

// 先把该轴全部载荷读进内存（含待删者，用于隔离）
const dirAbs = path.join(here, AXES[AXIS].dir);
const staged = new Map();
for (const file of fs.readdirSync(dirAbs)) {
  if (/^Q\d+\.json$/.test(file)) staged.set(file.replace(".json", ""), readJson(path.join(dirAbs, file)));
}
const missingPayload = [survivors, removed].flat().filter((c) => !staged.has(c.caseId));
if (missingPayload.length) throw new Error(`这些用例没有对应载荷，停止：${missingPayload.map((c) => c.caseId).join(",")}`);

const quarantine = path.join(here, "_removed_dropped", AXIS);
fs.mkdirSync(quarantine, { recursive: true });

// 该轴连续重编号
const remap = new Map();
const pad = (n) => `Q${String(n).padStart(3, "0")}`;
survivors.forEach((item, i) => remap.set(item.caseId, pad(AXES[AXIS].start + i)));
const fallbackByTemplate = new Map();
for (const item of survivors) if (item.templateId && !fallbackByTemplate.has(item.templateId)) fallbackByTemplate.set(item.templateId, item.caseId);
const resolveRef = (value) => {
  if (typeof value !== "string" || !value) return value;
  if (remap.has(value)) return remap.get(value);
  if (dropSet.has(value)) return null;
  return value;
};

const rewritten = [];
for (const [key, cfg] of Object.entries(AXES)) {
  const manifest = manifests[key];
  for (const item of manifest.cases ?? []) {
    if (key === AXIS) {
      if (!remap.has(item.caseId)) continue;  // 待删记录不参与重编号，避免 caseId 被覆写成 undefined
      const oldId = item.caseId;
      item.caseId = remap.get(oldId);
      item.file = `${item.caseId}.json`;
      if (item.probeKey) item.probeKey = `${key}-${item.caseId.slice(1)}-${item.variant ?? item.defectKind ?? "case"}`;
    }
    for (const field of ["sourceCase", "sourceCaseB", "duplicateOf"]) {
      const next = resolveRef(item[field]);
      if (item[field] && next === null) {
        item[field] = (fallbackByTemplate.get(item.templateId) ?? null);
        if (item[field]) (item.retargetedRefs ??= []).push(`${field}->${item[field]}`);
        else (item.droppedRefs ??= []).push(field);
        rewritten.push(`${key}/${item.caseId}: ${field} 原指向已删用例`);
      } else if (next) item[field] = next;
    }
    if (Array.isArray(item.mutation?.pair)) {
      const pair = item.mutation.pair.map(resolveRef).filter(Boolean);
      if (pair.length !== item.mutation.pair.length) rewritten.push(`${key}/${item.caseId}: mutation.pair 缩短`);
      item.mutation.pair = pair;
      if (pair.length < 2) delete item.mutation.pair;
    }
  }
}

if (!APPLY) {
  console.log("dry-run：未写盘。加 --apply 落盘。");
  process.exit(0);
}

// 隔离被删载荷（带内容指纹），再清空目录、按新编号写回
for (const item of removed) {
  const bytes = JSON.stringify(staged.get(item.caseId), null, 2) + "\n";
  const fp = crypto.createHash("sha256").update(bytes).digest("hex").slice(0, 8);
  const target2 = path.join(quarantine, `${item.caseId}__${REASON}__${fp}.json`);
  if (!fs.existsSync(target2)) fs.writeFileSync(target2, bytes, "utf8");
  if (!fs.existsSync(target2)) throw new Error(`隔离副本未生成，拒绝删除 ${item.caseId}`);
}
for (const file of fs.readdirSync(dirAbs)) if (/^Q\d+\.json$/.test(file)) fs.rmSync(path.join(dirAbs, file));
for (const item of survivors) writeJson(path.join(dirAbs, item.file), staged.get(remapReverse(remap, item.caseId)));
function remapReverse(map, newId) {
  for (const [oldId, value] of map) if (value === newId) return oldId;
  throw new Error(`找不到 ${newId} 的原编号`);
}
const written = fs.readdirSync(dirAbs).filter((n) => /^Q\d+\.json$/.test(n)).length;
if (written !== survivors.length) throw new Error(`写回 ${written} 个与保留 ${survivors.length} 条不一致`);

target.cases = survivors;
target.caseCount = survivors.length;
for (const [key, cfg] of Object.entries(AXES)) writeJson(path.join(here, cfg.manifest), manifests[key]);

const index = readJson(path.join(here, "manifest.json"));
const nums = survivors.map((c) => Number(c.caseId.slice(1)));
index.axes[AXIS].range = `${pad(Math.min(...nums))}-${pad(Math.max(...nums))}`;
index.axes[AXIS].caseCount = survivors.length;
index.totalCaseCount = Object.values(manifests).reduce((n, m) => n + (m.cases ?? []).length, 0);
index.dropPolicy = `被删用例记录在 _removed_dropped/<轴>/，原因标签 ${REASON}`;
writeJson(path.join(here, "manifest.json"), index);
writeJson(path.join(here, `dropped_${AXIS}_report.json`), {
  axis: AXIS,
  reason: REASON,
  before: survivors.length + removed.length,
  after: survivors.length,
  dropped: removed.map((c) => ({ caseId: c.caseId, templateId: c.templateId ?? null, defectKind: c.defectKind ?? null })),
  remap: Object.fromEntries(remap),
  refFixes: rewritten,
  total: index.totalCaseCount
});
console.log(`已落盘：${AXIS} ${index.axes[AXIS].range}（${survivors.length} 条），集内合计 ${index.totalCaseCount} 条`);
if (rewritten.length) console.log(`引用重挂 ${rewritten.length} 处：\n  ${rewritten.slice(0, 10).join("\n  ")}`);
