# 边界扩展轴

编号 Q376–Q481，共 106 条，用于把模板误触发测试集从 294 条扩展到 400 条。

本轴按断言层分类：field-boundary 40、semantic-mismatch 30、multi-capability 16、preflight 10、empty-edit-style 10。每条用例在 manifest 中记录来源、变异和判定层；新增用例不能只按 Search 候选为空判定，必须按 manifest 的 `assertedAt` 检查对应阶段。
