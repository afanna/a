# 模板误触发测试集

本目录由 `build_perturbation_dataset.mjs` 生成，只保留目标模板在 Search 阶段必须被排除的确定负样本（不含任何完整命中用例），用于统计误触发率。

## 相似性原则
每条负样本与完整命中基线只差一个决定性扰动：缺字段类保留基线其余全部数据、动作与图标，query 仍显式列出全部保留字段；超集类（uncovered-valid-field）基线字段一个不少，仅追加一个能力合法但目标模板不覆盖的字段，并在 query 中显式请求展示它。

## Search 硬门（template_retrieval.py，确定性过滤，与 LLM 排序无关）
① `_template_required_fields_are_available`：primary+secondary 必须全部存在于 dataModelSchema 且类型一致，数据超集不拒绝；② `explicit_fields ⊆ covered_paths`：query 显式要求的展示字段必须全部落在模板可覆盖字段并集内。因此“数据比要求多”本身不会阻止触发；只有多出的字段同时被 query 显式要求展示、且目标模板覆盖不了时才确定不触发（超集类用例即测这条门）。

## 运行时与注册表
数据、动作、资源统一使用 `app-11.7.7.300_rom-7.0` 注册表中 `enabled !== false` 的条目；`deviceInfo.prdVer=11.8.8.342`、`deviceInfo.romVersion=7.0` 使运行时按 registry_ranges 稳定命中该 7.0 目录。业务语义有已注册 emoji 的资源候选优先替换为 `asset.emoji_*`（日历、会议、时间、闹钟、耳机、跑步、心率、睡眠、音乐、电话），无对应 emoji 的（电池、天气、左右耳、耳机仓、定位等）保留单色 icon。

## 判定口径
误触发按目标模板逐条统计：`expectedSearchEligibility: ineligible` 只要求该 templateId 不出现在 Search 候选中。部分用例存在合法命中的兄弟模板（如 WideFull 缺统计日期时 Full 仍满足全部必需要求），运行器应断言“目标模板未出现”，而不是“完全没有生成卡片”。

`perturbation_expected.json` 是唯一的预期映照表。
