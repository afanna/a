# 字段轴

编号范围：Q082–Q317，共 236 条（2026-09-29 删掉 4 条必触发用例后重排；`Q318–Q321` 是空号，不回收）。

每条用例围绕一个目标模板做字段消融或字段超集测试，断言目标模板在 Search 硬门阶段被排除。**判定口径**：本集是误触发数据集，任何模板被采用都算误触发——目标算，兄弟也算，不设"允许兄弟模板"的白名单。

构造纪律（由生产代码 `TaskSpecBuilder` + `search_template_variants` 复算验证）：

- `candidateOutputFields` 必须**非空**。清空出参不会造成"缺字段"：`TaskSpecBuilder` 在候选为空或全部无法解析时会回退成该能力全部叶子，而首层的 `requiredOutputFieldsByCapability` 必须来自候选，Search 会直接拒绝而不是排除某个模板。
- 候选出参只能取**目标模板同族**（同 `business_id`）能渲染的字段，避免把语义错配混进字段轴。
- 必须**至少缺目标模板一个 `required` 字段**，否则目标照样进候选（复算曾抓到 Q084/Q085/Q304 三条这种情况）。
- 清单侧字段：`templateId`（目标）、`defectKind`（missing-primary / missing-secondary / superset-uncovered / missing-required）、`removedFieldPaths`、`probeConstruction`（字段集构造方式）、`sourceLabel`（改写前的合成标签）。

删除记录：`Q166–Q169`（目标 `CountdownOverviewFull/Hero/Support/TravelSupport@1`）已移出本轴——`GetCountdownDays` 只有 `/countdownDays` 一个叶子，而这 4 个模板都把它列为 required，不存在"非空候选且缺该字段"的构造法，必然触发模板，按"必触发即删"处理。载荷在 `../_removed_dropped/field/`，明细见 `../dropped_field_report.json`。
