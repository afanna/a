// 修正载荷里"事件引用了不存在/未请求的数据路径"的问题：
//  1) 索引写法归一（events/i/... -> events/0/...）
//  2) 引用根不存在时，改指到该能力实际使用的写入根（如 /data/calendar -> /data/calendar2）
//  3) 引用字段不在该绑定的候选出参里时，把它补进去（补进去的字段必须是能力清单声明过的叶子）
// 只动 candidateEventCandidates 的引用与对应绑定的 candidateOutputFields，其余字节不变。
// 用法：node fix_event_data_refs.mjs [--apply]
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const APPLY = process.argv.includes("--apply");
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const writeJson = (p, v) => fs.writeFileSync(p, JSON.stringify(v, null, 2) + "\n", "utf8");

const CAP_DIR = path.join(here, "widget_service", "cloud", "data", "capabilities", "app-11.7.7.300_rom-7.0");
const declared = new Map(readJson(path.join(CAP_DIR, "data_capabilities.json")).map((c) => [c.id, c]));
const leafSet = new Map();
for (const [id, cap] of declared) {
  const set = new Set();
  const walk = (node, pre) => {
    if (!node || typeof node !== "object") return;
    if (node.type === "array") { walk(node.items, `${pre}/0`); return; }
    for (const [k, v] of Object.entries(node.properties ?? {})) {
      const p = `${pre}/${k}`;
      if (v && v.type && !["object", "array"].includes(v.type)) set.add(p);
      else if (v && (v.properties || v.items)) walk(v, p);
    }
    // 数组叶子（如 remindTime: [string]）也算可请求路径
    if (node.type && !["object", "array"].includes(node.type)) set.add(pre);
  };
  walk(cap.outputSchema, "");
  leafSet.set(id, set);
}

const AXES = [
  ["field_axis", "field_axis/manifest.json", "field_axis"],
  ["semantic_axis", "semantic_axis/perturbation_expected.json", "semantic_axis"],
  ["boundary_axis", "boundary_axis/manifest.json", "boundary_axis"]
];
const REF = /\$\{\s*(\/data\/[^}\s]+)\s*\}/g;
const normIndex = (p) => p.replace(/\/events\/(i|idx|\$?\{[^}]*\})\//g, "/events/0/").replace(/\/daily\/(i|idx)\//g, "/daily/0/");

const changes = [];
for (const [, manRel, dirName] of AXES) {
  const dir = path.join(here, "taskspec", "template_misfire", dirName);
  const manifest = readJson(path.join(here, "taskspec", "template_misfire", manRel));
  for (const file of fs.readdirSync(dir).filter((n) => /^Q\d+\.json$/.test(n))) {
    const p = path.join(dir, file);
    const payload = readJson(p);
    const content = payload.content ?? {};
    const bindings = content.candidateDataBindings ?? [];
    let touched = false;
    const addedFields = new Map();
    for (const evt of content.candidateEventCandidates ?? []) {
      const text = JSON.stringify(evt);
      for (const m of text.matchAll(REF)) {
        const original = m[1];
        let ref = normIndex(original);
        if (ref !== original) {
          evt.action = JSON.parse(JSON.stringify(evt.action).replaceAll(original, ref));
          touched = true;
          changes.push({ id: file.replace(".json", ""), kind: "index-normalized", from: original, to: ref });
        }
        let binding = bindings.find((b) => ref.startsWith(String(b.writeResultTo ?? "").replace(/\/$/, "") + "/"));
        if (!binding) {
          // 引用根不存在：改指到"以该根为前缀的实际写入根"（如 /data/calendar -> /data/calendar2），取最长匹配
          const rel = ref.split("/").slice(3).join("/");
          const wanted = original.split("/").slice(0, 3).join("/");
          const candidates = bindings
            .filter((b) => typeof b.writeResultTo === "string" && b.writeResultTo.startsWith(wanted))
            .sort((a, b) => String(b.writeResultTo).length - String(a.writeResultTo).length);
          const newRoot = candidates[0]?.writeResultTo;
          if (!newRoot) { changes.push({ id: file.replace(".json", ""), kind: "UNFIXABLE-root", ref: original }); continue; }
          ref = `${String(newRoot).replace(/\/$/, "")}/${rel}`;
          binding = bindings.find((b) => b.writeResultTo === newRoot);
          evt.action = JSON.parse(JSON.stringify(evt.action).replaceAll(original, ref));
          touched = true;
          changes.push({ id: file.replace(".json", ""), kind: "root-rewired", from: original, to: ref });
        }
        if (!binding) { changes.push({ id: file.replace(".json", ""), kind: "UNFIXABLE-nobinding", ref }); continue; }
        const rel = ref.slice(String(binding.writeResultTo).replace(/\/$/, "").length);
        const fields = (binding.candidateOutputFields ?? []).map(String);
        if (!fields.includes(rel)) {
          const leaves = leafSet.get(binding.capabilityId) ?? new Set();
          const ok = leaves.has(rel) || leaves.has(rel.replace(/\/\d+\//g, "/0/"));
          if (!ok) { changes.push({ id: file.replace(".json", ""), kind: "UNFIXABLE-undeclared-field", ref: rel, capability: binding.capabilityId }); continue; }
          const rec = (manifest.cases ?? []).find((c) => c.caseId === file.replace(".json", ""));
          if ((rec?.removedFieldPaths ?? []).includes(rel)) {
            changes.push({ id: file.replace(".json", ""), kind: "CONFLICT-probe-removes-this-field", ref: rel, target: rec?.templateId });
            continue; // 不能把探针故意移除的字段补回去，否则用例失效
          }
          binding.candidateOutputFields = [...fields, rel];
          addedFields.set(binding.capabilityId, [...(addedFields.get(binding.capabilityId) ?? []), rel]);
          touched = true;
          changes.push({ id: file.replace(".json", ""), kind: "field-added", capability: binding.capabilityId, added: rel });
        }
      }
    }
    if (touched && APPLY) {
      for (const k of ["candidateDataBindings", "candidateEventCandidates"]) if (payload[k] !== undefined) payload[k] = content[k];
      writeJson(p, payload);
      const item = (manifest.cases ?? []).find((c) => c.caseId === file.replace(".json", ""));
      if (item) {
        item.candidateOutputFields = (content.candidateDataBindings ?? []).flatMap((b) => (b.candidateOutputFields ?? []).map(String));
        item.eventDataRefsFixed = changes.filter((c) => c.id === item.caseId).map((c) => c.kind);
      }
      writeJson(path.join(here, "taskspec", "template_misfire", manRel), manifest);
    }
  }
}
const kinds = {};
for (const c of changes) kinds[c.kind] = (kinds[c.kind] ?? 0) + 1;
console.log(`涉及改动 ${new Set(changes.map((c) => c.id)).size} 条用例，动作 ${changes.length} 处`);
console.log("分类:", JSON.stringify(kinds));
for (const c of changes.filter((x) => x.kind.startsWith("UNFIXABLE"))) console.log("  无法自动修:", JSON.stringify(c));
console.log("示例:", JSON.stringify(changes.slice(0, 6)));
if (!APPLY) console.log("\ndry-run：未写盘。加 --apply 落盘。");
