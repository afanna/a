import path from "node:path";
import { fileURLToPath } from "node:url";

// 模板误触发测试集的统一路径出口。两轴数据放同一目录，读哪个包分开声明，避免重跑时悄悄换数据源。
export const misfireRoot = path.dirname(fileURLToPath(import.meta.url));
export const taskspecRoot = path.resolve(misfireRoot, "..");
export const packageRoot = path.resolve(taskspecRoot, ".."); // CreateMyCard230
export const workspaceRoot = path.resolve(packageRoot, "..");

// 母本正向集（taskspec/template 的 Q001–Q081），语义轴探针从它克隆
export const parentTemplateDir = path.join(taskspecRoot, "template");
// 两轴数据目录
export const fieldAxisDir = path.join(misfireRoot, "field_axis");
export const semanticAxisDir = path.join(misfireRoot, "semantic_axis");

// field_axis 的 240 条与 audit 回放原本跑在 CreateMyCard-main 那套注册表与 provider 资源上，
// 沿用原环境以保持可比性；若要改指 230，需重跑 build_perturbation_dataset 并逐条核对差异后再改这里。
const legacyPackage = process.env.MISFIRE_LEGACY_PACKAGE ?? "CreateMyCard-main";
export const legacyWorkspace = path.join(workspaceRoot, legacyPackage);
const legacyService = path.join(legacyWorkspace, "widget_service");
export const legacyCapabilityRoot = path.join(legacyService, "cloud/data/capabilities/app-11.7.7.300_rom-7.0");
export const legacyProviderRoot = path.join(legacyService, "cloud/services/template_generation/resources/source/providers");

// 230 本地资源，语义轴与素材/开域集使用
export const localCapabilityRoot = path.join(
  packageRoot,
  "widget_service/cloud/data/capabilities/app-11.7.7.300_rom-7.0"
);
export const localProviderRoot = path.join(
  packageRoot,
  "widget_service/cloud/services/template_generation/resources/source/providers"
);
