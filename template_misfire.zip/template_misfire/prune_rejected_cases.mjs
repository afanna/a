import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

// 误触发集只保留能通过微服务校验的合法输入：
// 按运行侧回报的失败清单剔除被拒用例，再连续重编号并重挂跨轴引用。
const here = path.dirname(fileURLToPath(import.meta.url));
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const writeJson = (p, v) => fs.writeFileSync(p, JSON.stringify(v, null, 2) + "\n", "utf8");

const REJECTED = (process.argv[2] ?? "").split(",").map((s) => s.trim()).filter(Boolean);
const AXES = {
  semantic: { dir: "semantic_axis", manifest: "semantic_axis/perturbation_expected.json", start: 322 },
  boundary: { dir: "boundary_axis", manifest: "boundary_axis/manifest.json", start: null }
};

const rejectedSet = new Set(REJECTED);
const removed = { semantic: [], boundary: [], outsideAxes: [] };
const manifests = {};
for (const [key, axis] of Object.entries(AXES)) {
  manifests[key] = readJson(path.join(here, axis.manifest));
}
const inAxis = new Map();
for (const [key, axis] of Object.entries(AXES)) {
  for (const item of manifests[key].cases ?? []) inAxis.set(item.caseId, key);
}
for (const id of REJECTED) {
  const axis = inAxis.get(id);
  if (axis) removed[axis].push(id);
  else removed.outsideAxes.push(id);
}

// 故意注入缺陷的 preflight 探针同样属于"会被拒绝"，一并清出
for (const item of manifests.semantic.cases ?? []) {
  if (item.expectedPreflight === "fail" && !removed.semantic.includes(item.caseId)) removed.semantic.push(item.caseId);
}
for (const item of manifests.boundary.cases ?? []) {
  if ((item.variant === "preflight" || item.assertedAt === "preflight") && !removed.boundary.includes(item.caseId)) {
    removed.boundary.push(item.caseId);
  }
}

const totalRemoved = removed.semantic.length + removed.boundary.length;
if (totalRemoved === 0) {
  console.log("没有需要剔除的被拒用例：不改文件、不重写 manifest 与报告");
  process.exit(0);
}

const remap = {};
const survivors = {};
for (const [key, axis] of Object.entries(AXES)) {
  const keep = (manifests[key].cases ?? []).filter((c) => !removed[key].includes(c.caseId));
  survivors[key] = keep;
}
let next = AXES.semantic.start;
for (const item of survivors.semantic) {
  remap[item.caseId] = `Q${next++}`;
  item.__old = item.caseId;
  item.caseId = remap[item.__old];
}
let boundaryStart = next;
for (const item of survivors.boundary) {
  remap[item.caseId] = `Q${next++}`;
  item.__old = item.caseId;
  item.caseId = remap[item.__old];
}
const ref = (value) => {
  if (!value) return value;
  const single = String(value).trim();
  if (remap[single]) return remap[single];
  if (rejectedSet.has(single) || Object.values(removed).flat().includes(single)) return null;
  return single;
};
for (const item of survivors.semantic) {
  item.sourceCaseB = ref(item.sourceCaseB);
  item.probeKey = `semantic-${String(item.__old).slice(1)}-${item.variant}`;
}
for (const item of survivors.boundary) {
  item.sourceCase = ref(item.sourceCase);
  if (item.mutation?.pair) {
    item.mutation.pair = item.mutation.pair.map(ref).filter(Boolean);
    if (item.mutation.pair.length < 2) delete item.mutation.pair;
  }
  item.duplicateOf = ref(item.duplicateOf) ?? item.duplicateOf ?? null;
  if (item.duplicateOf && !survivors.semantic.some((s) => s.caseId === item.duplicateOf)) item.duplicateOf = null;
  item.probeKey = `boundary-${String(item.__old).slice(1)}-${item.variant}`;
}

// 落盘：先把要保留的载荷读进内存，再删旧文件、写新文件
const payloads = new Map();
for (const [key, axis] of Object.entries(AXES)) {
  for (const item of survivors[key]) {
    payloads.set(`${key}/${item.caseId}`, readJson(path.join(here, axis.dir, `${item.__old}.json`)));
  }
}
// 被剔除的载荷不直接删：移入 _removed_rejected/<轴>/ 隔离区（taskspec 不在版本控制内，删了不可恢复）
// 重编号后同名文件指的是不同用例，所以隔离文件名必须带内容指纹；副本没落盘就不许删原件。
const quarantine = path.join(here, "_removed_rejected");
const contentId = (file) => crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex").slice(0, 8);
for (const [key, axis] of Object.entries(AXES)) {
  const backup = path.join(quarantine, key);
  fs.mkdirSync(backup, { recursive: true });
  for (const file of fs.readdirSync(path.join(here, axis.dir))) {
    if (!/^Q\d+\.json$/.test(file)) continue;
    const source = path.join(here, axis.dir, file);
    const target = path.join(backup, `${file.replace(/\.json$/, "")}__${contentId(source)}.json`);
    if (!fs.existsSync(target)) fs.copyFileSync(source, target);
    if (!fs.existsSync(target)) throw new Error(`隔离副本未生成，拒绝删除 ${file}`);
    fs.rmSync(source);
  }
}
for (const [key, axis] of Object.entries(AXES)) {
  for (const item of survivors[key]) {
    const payload = payloads.get(`${key}/${item.caseId}`);
    const filename = `${item.caseId}.json`;
    delete item.__old;
    item.file = filename;
    writeJson(path.join(here, axis.dir, filename), payload);
  }
  manifests[key].cases = survivors[key];
}
manifests.semantic.caseCount = survivors.semantic.length;
manifests.boundary.caseCount = survivors.boundary.length;
manifests.boundary.numbering = {
  from: boundaryStart,
  to: next - 1,
  note: "只保留能通过微服务校验的用例；被拒探针已移出本轴"
};
writeJson(path.join(here, AXES.semantic.manifest), manifests.semantic);
writeJson(path.join(here, AXES.boundary.manifest), manifests.boundary);

const index = readJson(path.join(here, "manifest.json"));
index.axes.semantic.caseCount = survivors.semantic.length;
index.axes.semantic.range = `Q${AXES.semantic.start}-Q${boundaryStart - 1}`;
index.axes.boundary.caseCount = survivors.boundary.length;
index.axes.boundary.range = `Q${boundaryStart}-Q${next - 1}`;
index.totalCaseCount =
  readJson(path.join(here, AXES.semantic.manifest)).cases.length +
  readJson(path.join(here, "field_axis/manifest.json")).cases.length +
  survivors.boundary.length;
index.version = "template-misfire-index-v4-valid-inputs-only";
index.validityPolicy = "本集只允许能通过微服务校验的合法输入；缺参、未知能力/字段/事件/素材、非法写入根、不支持尺寸等被拒用例不得进入本集";
writeJson(path.join(here, "manifest.json"), index);

const report = {
  generatedAt: "2026-09-23",
  运行侧回报失败数: REJECTED.length,
  其中不在两轴内: removed.outsideAxes,
  从semantic移除: removed.semantic.length,
  从boundary移除: removed.boundary.length,
  移除明细: { semantic: removed.semantic, boundary: removed.boundary },
  新语义轴: { count: survivors.semantic.length, range: index.axes.semantic.range },
  新边界轴: { count: survivors.boundary.length, range: index.axes.boundary.range },
  总条数: index.totalCaseCount
};
writeJson(path.join(here, "pruned_rejected_report.json"), report);
console.log(JSON.stringify(report, null, 2));
