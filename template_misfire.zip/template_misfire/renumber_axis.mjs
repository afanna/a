// 重排单轴编号并全量重挂引用（含其他轴指向本轴的引用）。
// 用法：node renumber_axis.mjs --axis=semantic --start=335 [--apply]
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const arg = (n, d = "") => (process.argv.find((a) => a.startsWith(`--${n}=`)) || `--${n}=${d}`).split("=")[1];
const AXIS = arg("axis");
const START = Number(arg("start"));
const APPLY = process.argv.includes("--apply");
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const writeJson = (p, v) => fs.writeFileSync(p, JSON.stringify(v, null, 2) + "\n", "utf8");
const pad = (n) => `Q${String(n).padStart(3, "0")}`;

const AXES = {
  field: { dir: "field_axis", manifest: "field_axis/manifest.json" },
  semantic: { dir: "semantic_axis", manifest: "semantic_axis/perturbation_expected.json" },
  boundary: { dir: "boundary_axis", manifest: "boundary_axis/manifest.json" }
};
if (!AXES[AXIS]) throw new Error("--axis 必须是 field/semantic/boundary");
if (!START) throw new Error("--start 必填");

const manifests = {};
for (const [k, cfg] of Object.entries(AXES)) manifests[k] = readJson(path.join(here, cfg.manifest));
const owner = new Map();
for (const [k, cfg] of Object.entries(AXES)) for (const item of manifests[k].cases ?? []) owner.set(item.caseId, k);

const target = manifests[AXIS];
const records = [...(target.cases ?? [])].sort((a, b) => Number(a.caseId.slice(1)) - Number(b.caseId.slice(1)));
const remap = new Map();
records.forEach((item, i) => remap.set(item.caseId, pad(START + i)));

// 先全部读进内存
const dirAbs = path.join(here, AXES[AXIS].dir);
const staged = new Map();
for (const file of fs.readdirSync(dirAbs)) if (/^Q\d+\.json$/.test(file)) staged.set(file.replace(".json", ""), readJson(path.join(dirAbs, file)));
for (const item of records) if (!staged.has(item.caseId)) throw new Error(`缺载荷 ${item.caseId}`);

// 本轴重编号
for (const item of records) {
  item.__payload = item.caseId;
  item.caseId = remap.get(item.__payload);
  item.file = `${item.caseId}.json`;
  if (item.probeKey) item.probeKey = `${AXIS}-${item.caseId.slice(1)}-${item.variant ?? item.defectKind ?? "case"}`;
}
// 全部三轴中指向本轴旧号的引用统一改写
for (const [, manifest] of Object.entries(manifests)) {
  for (const item of manifest.cases ?? []) {
    for (const f of ["sourceCase", "sourceCaseB", "duplicateOf"]) {
      if (typeof item[f] === "string" && remap.has(item[f])) item[f] = remap.get(item[f]);
    }
    if (Array.isArray(item.mutation?.pair)) item.mutation.pair = item.mutation.pair.map((v) => (remap.has(v) ? remap.get(v) : v));
  }
}
for (const item of records) delete item.__payload;

if (!APPLY) {
  console.log(`${AXIS}: ${records[0].caseId}..${records.at(-1).caseId}（${records.length} 条）将落盘`);
  console.log("dry-run：未写盘。");
  process.exit(0);
}
for (const file of fs.readdirSync(dirAbs)) if (/^Q\d+\.json$/.test(file)) fs.rmSync(path.join(dirAbs, file));
for (const item of records) writeJson(path.join(dirAbs, item.file), staged.get(remapReverse(item.caseId)));
function remapReverse(newId) {
  for (const [oldId, v] of remap) if (v === newId) return oldId;
  throw new Error(`找不到 ${newId} 原号`);
}
target.caseCount = records.length;
target.cases = records;
for (const [k, cfg] of Object.entries(AXES)) writeJson(path.join(here, cfg.manifest), manifests[k]);

const index = readJson(path.join(here, "manifest.json"));
const numsOf = (k) => (manifests[k].cases ?? []).map((c) => Number(c.caseId.slice(1)));
for (const k of Object.keys(AXES)) {
  const nums = numsOf(k);
  index.axes[k].range = `${pad(Math.min(...nums))}-${pad(Math.max(...nums))}`;
  index.axes[k].caseCount = nums.length;
}
index.totalCaseCount = Object.values(manifests).reduce((n, m) => n + (m.cases ?? []).length, 0);
writeJson(path.join(here, "manifest.json"), index);
console.log(`已落盘：${AXIS} ${index.axes[AXIS].range}；field ${index.axes.field.range} / semantic ${index.axes.semantic.range} / boundary ${index.axes.boundary.range}，合计 ${index.totalCaseCount}`);
