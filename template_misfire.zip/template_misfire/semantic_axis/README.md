# semantic_axis — 模板误触发测试集（语义轴）

`field_axis` 测的是**字段轴**：对 101 个模板逐个做消融（缺 primary、缺 secondary、追加模板未覆盖却被 query 显式要求的字段），期望该 `templateId` 被 Search 硬门排除。240 条全是确定负样本。

本目录补**语义轴**：字段签名一个不少、尺寸动作图标都齐，但 `userQuery` 的业务根本不属于这个模板族——这时模板会不会被误命中。v1 测不出这种情况，因为 v1 的母本字段是残缺的，Search 靠字段完备性就能拒绝；语义轴必须让字段完备，只剩语义可依赖。

两轴合看才是完整的误触发覆盖：只看 v1 会高估，因为"字段齐但业务错"这一类完全没进统计。

## 构造法

克隆 `taskspec/template` 的一条正向用例作母本，除 `semanticDelta` 显式登记的字段外，`candidateDataBindings`、`candidateEventCandidates`、`candidateAssetIds`、`size`、`deviceInfo`、`session` 与母本逐字段一致。唯一变量是语义（`userQuery`/`title`/`description`），或按需最小合并第二个母本的候选。

## 判分层：不能用 v1 的口径（重要）

读代码确认：Search 的门②用的 `query_tokens` 是由 **TaskSpec 的 `candidateOutputFields` 构造**的（`template_retrieval.py` 的 `_task_spec_field_token`，以及第 1032 行 `{token.path for token in query_tokens}.issubset(covered_paths)`），**不解析 `userQuery` 文本**。本集刻意不改字段，所以字段完备时母本族模板必然进 Search 候选。

结论：v1 的"目标 templateId 未出现在 Search 候选即通过"在 v2 上不成立——照它判会得到**误检率≈100%**的假结果，那测的是检索机制不看语义，不是模型差。

v2 因此把断言分层写进数据：

| 字段 | 值 | 含义 |
| --- | --- | --- |
| `expectedSearchEligibility` | `eligible` 48 条、`not-applicable` 6 条 | Search 层按字段必然放行，不设"应排除"期望 |
| `expectedFinalTemplateAdoption` | `false` 43 条、`true` 11 条 | 误检判在**最终采用**：false 时最终 CardSpec 采用的 templateId 不得落在 `forbiddenTemplateIds` |
| `misfireAssertedAt` | `final-template` 48 条、`preflight` 6 条 | 6 条 preflight 探针只判是否在生成前终止，不进误检率分母 |

误检定义：fp 探针最终采用了 `forbiddenTemplateIds` 中任一 templateId 即误检；采用 `expectedTemplateIds` 中的兄弟模板不算。

## 误检率分母

禁止槽位合计 618，按族极不均：WeatherOverview 198、Calendar(Schedule)Overview 176、Bluetooth 75、Battery 91、Countdown 24、HeartRate 18、Activity 18、Sleep 18 —— 天气+日程两族占 60%。所以：

1. 必须**按族分别报**，混合成一个总数会被大族主导；
2. 要写明口径是"每探针一票"还是"每 templateId 一票"，两者数字不同；
3. 分母只算 43 条 fp，`preflight` 6 条与 `hit` 9 条各自单列（后者算漏触发率）。


## 规模与编号

54 条，编号 Q322–Q375，接续 v1 的 Q082–Q321，**不改动 v1 与母本集任何文件**。54 由族配额推导：6 族 × ≥3 条假阳性（18）+ 跨族竞争 8 + 开域误套 6 + 空态 6 + preflight 6 + 编辑复用 4 + 否定与变体 6。

| probeDirection | 条数 | 判分 |
| --- | --- | --- |
| `fp` 假阳性 | 43 | 误检率分母：最终不得采用 `forbiddenTemplateIds`（其中 6 条属 preflight 组，只判生成前终止） |
| `hit` 假阴性 | 9 | 漏触发率分母：最终必须采用母本族（空态渲染、编辑复用、纯英文与口语错别字） |
| `amb` 歧义 | 2 | 两族皆允许，只记录实际采用哪个，不进任一比率 |

目标族分布：Weather 12、Calendar 10、Battery 9、Countdown 7、Bluetooth 6、Sleep 4、Activity 3、HeartRate 3；被禁止的 templateId 覆盖 97 个（注册表 101 个）。母本正向覆盖率 28/68。

## 族名映射

母本集 `template_expected.json` 的族标签与注册表 templateId 前缀不一致：母本写 `CalendarOverview`，注册表里是 `ScheduleOverview@1` 系列 22 个。映射集中在 `build_semantic_perturbation.mjs` 的 `FAMILY_PREFIX`，并写进 manifest 的 `scope.familyPrefixMap`，避免按标签找模板时静默漏配。

## 已知限制

1. fp 探针的候选是**故意**与业务错配的。若上游 preflight 先把不相关候选裁掉，最终采用也会"正确"，但根因不在模板层——运行器必须记录采用或拒绝实际发生在 `preflight`、`search` 还是 `cardplan`/渲染层，否则误检率会虚低。
2. 判分还缺两件事：一是最终采用了哪个模板从哪个字段读（CardSpec 里的 templateId？）；二是确认 `explicit_fields` 真的只来自 TaskSpec。若 planner 其实会解析 `userQuery` 抽字段，那部分 fp 探针在 Search 层就该被拒，届时要把 `misfireAssertedAt` 细分成 `search` 与 `final-template` 两级，而不是全压在最终采用上。
3. 族选对但字段错绑（Q330、Q342 这类）单靠 templateId 判不出来，需比对渲染字段与文案。
4. `variant=empty-value` 的 5 条考察命中后的空态渲染（0、沿用上次数据、占位符都算不合格），模板采用判定对它无效。
5. 4 条借用 `Phase_opendomain` 未回填条目（Q349、Q350、Q351、Q353）：探针有效，但 query 里的数值不可当真实数据引用，校验器逐条给警告。
6. `WorkoutOverview` 族 0 条探针——母本集把 Activity/HeartRate/Sleep/Workout 写成一个族标签，我没有单族签名可依据。
7. 判分脚本还没写：需要你们 Search 候选与最终 CardSpec 的实际输出格式。

## 重新生成与校验

```powershell
node .\CreateMyCard230\taskspec\template\build_semantic_perturbation.mjs
node .\CreateMyCard230\taskspec\template\check_semantic_perturbation.mjs
```

校验器强制：与母本的单变量纪律、`expectedTemplateIds` 与 `forbiddenTemplateIds` 不相交且都在 v1 注册清单内、`expectedSearchEligibility`（只允许 `eligible`/`not-applicable`）与 `probeDirection`、`expectedFinalTemplateAdoption`、`misfireAssertedAt`、`expectedOutcome` 五者一致、编号不与 v1 冲突且 >Q321、每族 ≥3 条、edit 探针 `session.isNew=false`。
