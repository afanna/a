import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// 三轴统一：edge_axis 改名 boundary_axis（按断言阶段分层的边界轴），
// 字段归一（variant / assertedAt / sourceCase / sourceCaseB / defectKind），跨轴去重与引用校验。
const here = path.dirname(fileURLToPath(import.meta.url));
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const writeJson = (p, v) => fs.writeFileSync(p, JSON.stringify(v, null, 2) + "\n", "utf8");

const OLD_DIR = path.join(here, "edge_axis");
const NEW_DIR = path.join(here, "boundary_axis");
if (fs.existsSync(OLD_DIR) && !fs.existsSync(NEW_DIR)) fs.renameSync(OLD_DIR, NEW_DIR);

const index = readJson(path.join(here, "manifest.json"));
if (index.axes?.edge) {
  const edge = index.axes.edge;
  delete index.axes.edge;
  index.axes.boundary = {
    directory: "boundary_axis",
    manifest: "boundary_axis/manifest.json",
    caseCount: edge.caseCount,
    range: edge.range
  };
  index.axesOrder = ["field", "semantic", "boundary"];
  index.version = "template-misfire-index-v3-unified";
  index.fieldNotes = {
    assertedAt: "preflight | search | final-template，统一三轴断言阶段字段名与取值",
    sourceCase: "母本用例号；缺陷类探针的标签放 defectKind，不再混写在 sourceCase 里",
    variant: "用例类别，取代原 category / probeGroup 两套命名",
    duplicateOf: "与 semantic 轴同题时指向那条 semantic 用例；统计误触发覆盖率时只算一条"
  };
  writeJson(path.join(here, "manifest.json"), index);
}

// semantic 轴字段归一
const semanticPath = path.join(here, "semantic_axis/perturbation_expected.json");
const semantic = readJson(semanticPath);
const LAYER_MAP = { "final-template": "final-template", preflight: "preflight", "search-gate": "search" };
for (const item of semantic.cases ?? []) {
  item.assertedAt = LAYER_MAP[item.misfireAssertedAt] ?? item.assertedAt ?? "final-template";
  delete item.misfireAssertedAt;
  item.sourceCase = item.reusedTaskSpecCase ?? item.sourceCase;
  delete item.reusedTaskSpecCase;
  if ("secondBaselineCase" in item) {
    item.sourceCaseB = item.secondBaselineCase ?? null;
    delete item.secondBaselineCase;
  }
  if (item.variantLabel === undefined && item.probeGroup) item.variantLabel = item.probeGroup;
}
writeJson(semanticPath, semantic);

// boundary 轴字段归一 + 去重
const boundaryPath = path.join(here, "boundary_axis/manifest.json");
const boundary = readJson(boundaryPath);
const SEMANTIC_VARIANT_BY_CATEGORY = {
  "semantic-mismatch": ["business-mismatch", "cross-template-race"],
  "empty-edit-style": ["empty-value", "edit-reuse"],
  preflight: ["preflight-reject"],
  "multi-capability": ["cross-template-race", "business-mismatch"],
  "field-boundary": []
};
const semanticIndex = new Map((semantic.cases ?? []).map((c) => [c.caseId, c]));
const semanticByParent = new Map();
for (const c of semantic.cases ?? []) {
  const parent = String(c.sourceCase ?? "").replace(/\.json$/, "");
  if (!parent) continue;
  if (!semanticByParent.has(parent)) semanticByParent.set(parent, []);
  semanticByParent.get(parent).push(c);
}

const pool = [];
for (const dir of ["field_axis", "semantic_axis"]) {
  for (const file of fs.readdirSync(path.join(here, dir)).filter((n) => /^Q\d+\.json$/.test(n))) {
    const content = readJson(path.join(here, dir, file)).content ?? {};
    pool.push({
      id: file.replace(/\.json$/, ""),
      capability: content.candidateDataBindings?.[0]?.capabilityId ?? "",
      fields: (content.candidateDataBindings?.[0]?.candidateOutputFields ?? []).join(","),
      size: content.size ?? "",
      assets: (content.candidateAssetIds ?? []).length,
      assetsKey: (content.candidateAssetIds ?? []).join(","),
      textKey: `${content.title ?? ""}|${content.description ?? ""}`
    });
  }
}
// 注入式缺陷探针的 sourceCase 被写成了缺陷标签；按注入维度容差回填真实母本，多母本同分则不猜
const DEFECT_TOLERANCE = {
  "unknown-capability": ["capability"],
  "invalid-output-field": ["fields"],
  "unknown-event": ["events"],
  "invalid-event-call": ["events"],
  "invalid-asset": ["assets"],
  "unsupported-size": ["size"]
};
function recoverSource(defectKind, content) {
  const tolerance = new Set(DEFECT_TOLERANCE[defectKind] ?? []);
  const binding = content.candidateDataBindings?.[0] ?? {};
  const self = {
    capability: binding.capabilityId ?? "",
    fields: (binding.candidateOutputFields ?? []).join(","),
    size: content.size ?? "",
    assetsKey: (content.candidateAssetIds ?? []).join(","),
    textKey: `${content.title ?? ""}|${content.description ?? ""}`
  };
  const scored = [];
  for (const candidate of pool) {
    let score = 0;
    if (!tolerance.has("capability") && candidate.capability === self.capability) score += 2;
    if (!tolerance.has("fields") && candidate.fields === self.fields) score += 3;
    if (!tolerance.has("size") && candidate.size === self.size) score += 1;
    if (!tolerance.has("assets") && candidate.assetsKey === self.assetsKey) score += 2;
    if (candidate.textKey === self.textKey) score += 2;
    if (score >= 6) scored.push({ id: candidate.id, score });
  }
  const top = Math.max(...scored.map((x) => x.score), 0);
  const best = scored.filter((x) => x.score === top);
  if (!best.length) return { error: "无可容差匹配母本" };
  if (best.length > 1) return { error: `多母本同分（${best.map((x) => x.id).join(",")}），不猜` };
  return { id: best[0].id };
}

const dedup = { tagged: 0, byCategory: {}, recovered: 0, unresolvedSource: [] };
for (const item of boundary.cases ?? []) {
  item.variant = item.category ?? item.variant ?? "";
  delete item.category;
  const refs = [item.sourceCase, ...(item.mutation?.pair ?? [])].filter(Boolean);
  const isCaseRef = (v) => /^Q\d{3}$/.test(String(v).trim());
  if (item.sourceCase && !isCaseRef(item.sourceCase)) {
    item.defectKind = item.sourceCase;
    item.sourceCase = refs.find(isCaseRef) ?? null;
    if (!item.sourceCase) {
      dedup.unresolvedSource.push({ caseId: item.caseId, defectKind: item.defectKind });
    }
  }
  if (item.sourceCase) {
    item.sourceCase = String(item.sourceCase).split("+")[0].trim();
    if (!isCaseRef(item.sourceCase)) item.sourceCase = null;
  }
  item.assertedAt = LAYER_MAP[item.assertedAt] ?? item.assertedAt;
  if (!item.sourceCase && item.defectKind) {
    const content = readJson(path.join(here, "boundary_axis", item.file)).content ?? {};
    const recovered = recoverSource(item.defectKind, content);
    if (recovered.id) {
      item.sourceCase = recovered.id;
      item.sourceCaseRecovery = "按注入维度容差唯一匹配回填，非人工指认";
      dedup.recovered++;
    } else if (/^预检边界测试/.test(String(readJson(path.join(here, "boundary_axis", item.file)).content?.userQuery ?? ""))) {
      item.sourceCase = null;
      item.syntheticProbe = true;
      item.sourceCaseReason = "合成 preflight 探针，本就没有母本，不是断链";
    } else {
      dedup.unresolvedSource.push({ caseId: item.caseId, defectKind: item.defectKind, reason: recovered.error });
    }
  }

  // 同一母本（或边界轴直接以某条 semantic 用例为母本）+ 类别可归入同族 + 断言阶段一致 -> 判重复
  const candidates = [...new Set([...(semanticByParent.get(item.sourceCase) ?? []), ...(semanticIndex.has(item.sourceCase) ? [semanticIndex.get(item.sourceCase)] : [])])];
  const allowed = SEMANTIC_VARIANT_BY_CATEGORY[item.variant] ?? [];
  const twin = candidates.find((c) => (allowed.length === 0 || allowed.includes(c.variant)) && (c.assertedAt ?? "") === (item.assertedAt ?? ""));
  if (twin) {
    item.duplicateOf = twin.caseId;
    dedup.tagged++;
    dedup.byCategory[item.variant] = (dedup.byCategory[item.variant] ?? 0) + 1;
  }
}
boundary.version = "boundary-axis-index-v2-unified";
boundary.numbering = { ...boundary.numbering, note: "本轴按断言阶段分层；目录名已从旧称改为本名，历史说明只留在 README" };
writeJson(boundaryPath, boundary);
writeJson(path.join(here, "boundary_axis/dedup_report.json"), {
  generatedAt: "2026-09-23",
  rule: "同一母本、类别可归入 semantic 同一族、且断言阶段相同 -> 记 duplicateOf，统计时只算一条",
  ...dedup
});

// 清除旧的 edge 命名痕迹（含载荷 title 里的 ｜edge-NNN 内部标记）
// 只动数据文件，不动 README —— 文档里要保留 "原 edge_axis" 这类历史说明
function scrubEdgeText(text) {
  return text
    .replace(/edge_axis/g, "boundary_axis")
    .replace(/edge-/g, "boundary-")
    .replace(/\bedge\b/g, "boundary");
}
let scrubbed = 0;
const scrubTargets = [
  ...fs.readdirSync(NEW_DIR).filter((n) => /^Q\d+\.json$/.test(n) || n === "manifest.json").map((n) => path.join(NEW_DIR, n)),
  path.join(here, "manifest.json")
];
for (const target of scrubTargets) {
  if (!fs.existsSync(target) || !String(target).endsWith(".json")) continue;
  const before = fs.readFileSync(target, "utf8");
  const after = scrubEdgeText(before);
  if (after !== before) {
    fs.writeFileSync(target, after, "utf8");
    scrubbed++;
  }
}

// 跨轴引用与编号完整性
const caseFileExists = (id) =>
  fs.existsSync(path.join(here, "boundary_axis", `${id}.json`)) ||
  fs.existsSync(path.join(here, "semantic_axis", `${id}.json`)) ||
  fs.existsSync(path.join(here, "field_axis", `${id}.json`)) ||
  fs.existsSync(path.join(here, "..", "template", `${id}.json`));
const problems = [];
for (const item of boundary.cases ?? []) {
  if (!["preflight", "search", "final-template"].includes(item.assertedAt)) problems.push(`${item.caseId}: assertedAt 非法 ${item.assertedAt}`);
  if (item.sourceCase && !caseFileExists(item.sourceCase)) problems.push(`${item.caseId}: sourceCase 断链 ${item.sourceCase}`);
  for (const pair of item.mutation?.pair ?? []) if (!caseFileExists(pair)) problems.push(`${item.caseId}: mutation.pair 断链 ${pair}`);
}
for (const item of semantic.cases ?? []) {
  if (item.sourceCase && !caseFileExists(item.sourceCase)) problems.push(`${item.caseId}: sourceCase 断链 ${item.sourceCase}`);
  if (item.sourceCaseB && !caseFileExists(item.sourceCaseB)) problems.push(`${item.caseId}: sourceCaseB 断链 ${item.sourceCaseB}`);
}
const allIds = [...(readJson(path.join(here, "field_axis/manifest.json")).cases ?? []), ...(semantic.cases ?? []), ...(boundary.cases ?? [])].map((c) => c.caseId);
const dupIds = allIds.filter((id, i) => allIds.indexOf(id) !== i);
console.log(
  JSON.stringify(
    {
      renamed: fs.existsSync(NEW_DIR),
      scrubbedEdgeFiles: scrubbed,
      syntheticProbesWithoutParent: (boundary.cases ?? []).filter((x) => x.syntheticProbe).length,
      boundaryCases: (boundary.cases ?? []).length,
      semanticCases: (semantic.cases ?? []).length,
      dedupTagged: dedup.tagged,
      dedupByVariant: dedup.byCategory,
      sourceUnresolved: dedup.unresolvedSource.length,
      duplicateCaseIds: dupIds,
      problems: problems.slice(0, 12),
      problemCount: problems.length
    },
    null,
    2
  )
);
if (problems.length || dupIds.length) process.exitCode = 1;
