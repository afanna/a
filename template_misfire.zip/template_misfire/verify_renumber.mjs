import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// 重编号后的引用完整性核对：
// 1) 语义轴每条探针与新母本逐字段比对，差异必须都在 semanticDelta 登记内；
//    其中 session 只允许 interactionId 随母本号走（非 edit 探针）。
// 2) field_axis 快照的 reusedTaskSpecCase 仍是旧编号，报告换算需求。
const here = path.dirname(fileURLToPath(import.meta.url));
const taskspec = path.resolve(here, "..");
const parentDir = path.join(taskspec, "template");
const axisDir = path.join(here, "semantic_axis");
const semantic = JSON.parse(fs.readFileSync(path.join(axisDir, "perturbation_expected.json"), "utf8"));
const renameMap = JSON.parse(fs.readFileSync(path.join(parentDir, "rename_map.json"), "utf8"));
const removed = new Set(renameMap.removed.map((r) => r.oldCaseId));
const errors = [];
let sessionOnly = 0;
let clean = 0;

for (const c of semantic.cases) {
  const probe = JSON.parse(fs.readFileSync(path.join(axisDir, c.file), "utf8"));
  const parent = JSON.parse(fs.readFileSync(path.join(parentDir, `${c.reusedTaskSpecCase}.json`), "utf8"));
  const registered = new Set(c.semanticDelta);
  let probeLevelDiff = false;
  for (const key of Object.keys(parent)) {
    if (["content", "userQuery", "candidateDataBindings", "title", "size", "candidateEventCandidates", "description", "candidateAssetIds", "session", "pagination", "deviceInfo", "bundleName", "userAuth", "utterance", "version"].includes(key) === false) {
      errors.push(`${c.caseId}: 母本多出未知字段 ${key}`);
      continue;
    }
    if (JSON.stringify(probe[key]) === JSON.stringify(parent[key])) continue;
    if (key === "content" || key === "session") continue; // 单独核
    if (!registered.has(key)) errors.push(`${c.caseId}: ${key} 与母本不同但未登记 semanticDelta`);
  }
  // content 内部
  const pc = probe.content ?? {};
  const bc = parent.content ?? {};
  for (const key of Object.keys(bc)) {
    if (JSON.stringify(pc[key]) === JSON.stringify(bc[key])) continue;
    const mapped = { userQuery: "userQuery", title: "title", description: "description", size: "size", candidateDataBindings: "candidateDataBindings", candidateEventCandidates: "candidateEventCandidates", candidateAssetIds: "candidateAssetIds" }[key];
    if (!registered.has(mapped)) errors.push(`${c.caseId}: content.${key} 差异未登记`);
  }
  // session 内部：非 edit 探针只允许 interactionId 变
  const ps = probe.session ?? {};
  const bs = parent.session ?? {};
  const rest = (s) => JSON.stringify({ ...s, interactionId: null });
  if (rest(ps) !== rest(bs)) {
    if (!registered.has("session")) errors.push(`${c.caseId}: session 除 interactionId 外还有差异且未登记`);
  } else if (ps.interactionId !== bs.interactionId) {
    sessionOnly += 1;
  } else {
    clean += 1;
  }
  if (!removed.has(c.reusedTaskSpecCase) && !renameMap.oldToNew[c.reusedTaskSpecCase] && !/^Q\d{3}$/.test(c.reusedTaskSpecCase)) {
    errors.push(`${c.caseId}: reusedTaskSpecCase 形状异常 ${c.reusedTaskSpecCase}`);
  }
}

const field = JSON.parse(fs.readFileSync(path.join(here, "field_axis", "perturbation_expected.json"), "utf8"));
const fieldRefs = [...new Set(field.cases.map((x) => x.reusedTaskSpecCase).filter(Boolean))];
const staleRemoved = fieldRefs.filter((r) => removed.has(r));
const staleKept = fieldRefs.filter((r) => renameMap.oldToNew[r]);

const parentFiles = fs.readdirSync(parentDir).filter((n) => /^Q\d{3}\.json$/.test(n)).sort();
const ids = parentFiles.map((f) => f.replace(".json", ""));
const expected = ids.map((_, i) => `Q${String(i + 1).padStart(3, "0")}`);
const gaps = ids.filter((id, i) => id !== expected[i]);
const pm = JSON.parse(fs.readFileSync(path.join(parentDir, "template_expected.json"), "utf8"));
const manifestIds = pm.cases.map((c) => c.caseId);
const fileSet = new Set(ids);

console.log(
  JSON.stringify(
    {
      parentCount: parentFiles.length,
      parentNumberingContiguous: gaps.length === 0,
      parentNumberingGaps: gaps.slice(0, 5),
      manifestMatchesFiles: manifestIds.length === ids.length && manifestIds.every((id) => fileSet.has(id)),
      removedFilesPreserved: fs.readdirSync(path.join(parentDir, "_removed_non_triggering")).filter((n) => n.endsWith(".json")).length,
      semanticProbeFieldDiffsOnlyInteractionId: sessionOnly,
      semanticProbeFullyIdenticalSession: clean,
      semanticErrors: errors.slice(0, 10),
      semanticErrorCount: errors.length,
      fieldAxisStaleRefs: {
        note: "field_axis 是 v1 快照，reusedTaskSpecCase 仍用重编号前的母本号，未自动改写",
        distinctRefs: fieldRefs.length,
        pointingAtRemovedCases: staleRemoved,
        needRemapViaRenameMap: staleKept.length
      }
    },
    null,
    2
  )
);
if (errors.length || gaps.length || !pm || manifestIds.length !== ids.length) process.exitCode = 1;
