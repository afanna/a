"""把渲染对照表导出成 Excel：明细列与 md 同源，结果列填 F/P/V/D/U 后汇总页自动算分。

数据源：指令与元数据取自 visual_axis/chain_axis 的 manifest，判据取自 render_checklist.CHECK。
用法：python export_checklist_xlsx.py
"""
from __future__ import annotations

import json
from pathlib import Path

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

import render_checklist as rc

HERE = Path(__file__).resolve().parent
OUT = HERE / "渲染对照表.xlsx"
INDEX = HERE / "manifest.json"

HEAD = ["用例", "用例文件", "测什么", "指令原文（userQuery）", "尺寸", "期望结论", "判定强度",
        "冲突对象", "走模板链路", "候选模板数", "看哪里", "✓ 通过判据", "✗ 违规判据",
        "口径/对照备注", "结果", "截图或证据", "复核说明"]
WIDTH = [8, 12, 26, 54, 7, 13, 9, 15, 11, 10, 28, 44, 44, 30, 8, 18, 24]
CENTER = (1, 2, 5, 7, 9, 10, 15)
EDIT_COLS = (15, 16, 17)
COL = {name: idx + 1 for idx, name in enumerate(HEAD)}
HEADER_FILL = "4F6228"
EDIT_FILL = "FFF7E6"

OUTCOME = {
    "follow": "照做",
    "follow-with-notify": "照做并告知",
    "proper-degradation": "合理降级",
    "refuse-and-notify": "拒绝并告知",
    "no-target-template": "不走模板",
    "target-eligible": "应命中模板",
}
CONFLICT = {
    "default-palette": "默认色板",
    "template-default": "模板默认",
    "component-whitelist": "组件白名单",
    "action-budget": "动作预算",
    "action-policy": "动作策略",
    "content-budget": "内容预算",
    "asset-budget": "素材预算",
    "asset-palette": "素材配色",
    "asset": "素材",
    "contrast-ux": "对比度风险",
    "readability": "可读性",
    "mock-data": "端侧 mock 数据",
    "type-scale": "字阶",
    "surface-rule": "背板规则",
    "display-unit": "展示单位",
    "touch-target": "触控下限",
    "protected-text": "受保护文本",
    "input-noise": "输入噪音",
    "none": "无",
    "": "无",
}
STATES = [
    ("F", "FOLLOWED 遵从：该条判据 ✓ 全中"),
    ("P", "PARTIAL 部分：多对象题只中一部分，或色差落在 ΔE00 3-8"),
    ("V", "VIOLATED 违规：回落默认、越界改写、出现禁止项或静默忽略用户要求"),
    ("D", "PROPER_DEGRADATION 合理降级：按优先级取舍且回复已告知"),
    ("U", "UNVERIFIABLE 判不了：静态图与截图都判不到，在复核说明写缺什么证据"),
]
FAMILIES = ["颜色", "字号", "边框", "透明度", "布局", "对齐", "一致性", "组件",
            "按钮", "负向", "内容预算", "综合冲突", "鲁棒", "链路"]


def conflict_label(value: str) -> str:
    parts = [CONFLICT.get(one, one) for one in value.split("+") if one]
    return "+".join(parts) if parts else "无"


def case_row(item: dict) -> list:
    proof = item["complianceProof"]
    check = rc.CHECK[proof["sourceId"]]
    chain = proof["chainEvidence"]
    notes = "；".join(one for one in (proof.get("dataValueCaveat") or check.get("note", ""),
                                      proof.get("controlCase", "")) if one)
    return [
        item["caseId"],
        item["file"],
        item["dimension"],
        item["userQuery"],
        item["size"],
        OUTCOME.get(item["expectedOutcome"], item["expectedOutcome"]),
        "硬" if proof["strength"] == "hard" else "软",
        conflict_label(proof["conflictWith"]), 
        "是" if chain["templatePathAvailable"] else "否",
        chain["eligibleCount"],
        check["look"],
        "；".join(check["pass"]),
        "；".join(check["fail"]),
        notes,
        "",
        "",
        "",
    ]


def style_sheet(ws, rows: list) -> None:
    ws.append(HEAD)
    head_fill = PatternFill("solid", fgColor=HEADER_FILL)
    edit_fill = PatternFill("solid", fgColor=EDIT_FILL)
    for idx in range(1, len(HEAD) + 1):
        cell = ws.cell(row=1, column=idx)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = head_fill
        cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(idx)].width = WIDTH[idx - 1]
    for row in rows:
        ws.append(row)
    for r in range(2, ws.max_row + 1):
        for c in range(1, len(HEAD) + 1):
            cell = ws.cell(row=r, column=c)
            cell.alignment = Alignment(wrap_text=True, vertical="top",
                                       horizontal="center" if c in CENTER else "left")
            if c in EDIT_COLS:
                cell.fill = edit_fill
        ws.cell(row=r, column=1).font = Font(bold=True)
    ws.freeze_panes = "D2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(HEAD))}{ws.max_row}"

    letter = get_column_letter(COL["结果"])
    rng = f"{letter}2:{letter}{ws.max_row}"
    dv = DataValidation(type="list", formula1='"F,P,V,D,U"', allow_blank=True, showDropDown=False,
                        errorTitle="结果列只收单字母",
                        error="填 F / P / V / D / U 之一；判不了填 U 并在复核说明写缺什么证据。",
                        promptTitle="结果", prompt="F 遵从 / P 部分 / V 违规 / D 合理降级 / U 判不了")
    ws.add_data_validation(dv)
    dv.add(rng)
    palette = {"F": ("C6EFCE", "006100"), "P": ("FFEB9C", "9C6500"), "V": ("FFC7CE", "9C0006"),
               "D": ("DDEBF7", "1F4E79"), "U": ("EDEDED", "7F7F7F")}
    for state, (bg, fg) in palette.items():
        ws.conditional_formatting.add(rng, CellIsRule(
            operator="equal", formula=[f'"{state}"'], fill=PatternFill("solid", fgColor=bg),
            font=Font(color=fg, bold=True)))


def span(sheet: str, header: str, last_row: int, col: str = None) -> str:
    letter = col or get_column_letter(COL[header])
    return f"'{sheet}'!${letter}$2:${letter}${last_row}"



def add_sumifs(pairs: list, sheets: list, countif: bool = True) -> str:
    out = []
    for name, last in sheets:
        args = [f"{span(name, header, last)}, \"{value}\"" for header, value in pairs]
        fn = "COUNTIFS" if len(args) > 1 else "COUNTIF"
        out.append(f"{fn}({', '.join(args)})")
    return "+".join(out)


def write_summary(wb: Workbook, sheets: list, total: int) -> None:
    ws = wb.create_sheet("汇总")
    for letter, width in zip("ABCD", (26, 12, 12, 78)):
        ws.column_dimensions[letter].width = width
    head_font = Font(bold=True, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor=HEADER_FILL)
    row = 1

    def block_title(text: str) -> None:
        nonlocal row
        ws.cell(row=row, column=1, value=text).font = Font(bold=True, size=12)
        row += 1

    def header(labels: list) -> None:
        nonlocal row
        for idx, label in enumerate(labels, start=1):
            cell = ws.cell(row=row, column=idx, value=label)
            cell.font = head_font
            cell.fill = head_fill
            cell.alignment = Alignment(vertical="center", wrap_text=True)
        row += 1

    def line(values: list, pct: bool = False, bold: bool = False) -> None:
        nonlocal row
        for idx, value in enumerate(values, start=1):
            cell = ws.cell(row=row, column=idx, value=value)
            cell.alignment = Alignment(vertical="top", wrap_text=True,
                                       horizontal="left" if idx == 1 or idx == 4 else "center")
            if pct and idx == 2:
                cell.number_format = "0.0%"
            if bold:
                cell.font = Font(bold=True)
        row += 1

    block_title("状态码图例")
    header(["代码", "", "", "含义"])
    for code, meaning in STATES:
        line([code, "", "", meaning])
    row += 1

    block_title("各态计数（填完明细自动更新）")
    header(["状态", "视觉轨", "链路轨", "说明"])
    for code, meaning in STATES:
        line([code, f'=COUNTIF({span("视觉轨", "结果", sheets[0][1])}, "{code}")',
              f'=COUNTIF({span("链路轨", "结果", sheets[1][1])}, "{code}")', meaning])
    line(["未填", f'=COUNTBLANK({span("视觉轨", "结果", sheets[0][1])})',
          f'=COUNTBLANK({span("链路轨", "结果", sheets[1][1])})',
          "任一轨道未填为 0 时，下方比率才可采信"])
    row += 1

    judged = "+".join(f"COUNTA({span(n, '结果', l)})-COUNTBLANK({span(n, '结果', l)})"
                      for n, l in sheets)
    followed = add_sumifs([("结果", "F")], sheets)
    degraded = add_sumifs([("结果", "D")], sheets)
    violated = add_sumifs([("结果", "V")], sheets)
    hard_violated = add_sumifs([("判定强度", "硬"), ("结果", "V")], sheets)
    hard_judged = add_sumifs([("判定强度", "硬")], sheets)
    tmpl_f = add_sumifs([("走模板链路", "是"), ("结果", "F")], sheets)
    tmpl_v = add_sumifs([("走模板链路", "是"), ("结果", "V")], sheets)
    free_f = add_sumifs([("走模板链路", "否"), ("结果", "F")], sheets)
    free_v = add_sumifs([("走模板链路", "否"), ("结果", "V")], sheets)

    block_title("用例级指标")
    header(["指标", "值", "", "口径"])
    line(["已判定用例数", f"={judged}", "", "两张明细表里 结果 列非空的条数，共 %d 条" % total])
    line(["用例级遵从率", f"=IFERROR(({followed}+{degraded})/({judged}),0)", "",
          "(F + D) ÷ 已判定；D 计入遵从是因为按优先级取舍且已告知"])
    line(["违规条数", f"={violated}", "", "V 的绝对条数，优先看链路轨和走模板链路=是 的分桶"])
    line(["硬违规率", f"=IFERROR(({hard_violated})/({hard_judged}),0)", "",
          "只统计 判定强度=硬：回落默认、越界改写、出现禁止项、静默忽略"])
    line(["分层·走模板链路 F/V", f'=IFERROR(CONCATENATE({tmpl_f}," / ",{tmpl_v}),"")', "",
          "这些卡整卡主题由 CardPlan/Tersel 决定，颜色类探针必须与自由生成分开看"])
    line(["分层·自由生成 F/V", f'=IFERROR(CONCATENATE({free_f}," / ",{free_v}),"")', "",
          "这一桶里的 V 才是真·模型不遵从，不被模板默认冒充"])
    line(["静默违规率", "手填", "", "V 里回复未提及该取舍的占比：在 复核说明 标 silent，再由人算"])
    line(["分项级(约束级)遵从率", "手填", "", "C508 三处、C526 四处这类多分项题要按分项记，"
          "本页是用例级口径，不代替像素判分脚本"])
    for scored in range(2, row):
        value = ws.cell(row=scored, column=2).value
        if isinstance(value, str) and value.startswith("=IFERROR(("):
            ws.cell(row=scored, column=2).number_format = "0.0%"
    row += 1

    block_title("维度家族分布")
    header(["维度家族", "条数", "", "口径"])
    for family in FAMILIES:
        parts = [f'COUNTIF({span(name, "测什么", last)}, "{family}*")' for name, last in sheets]
        note = ("按 测什么 前缀归类，链路族只落在链路轨" if family == "链路"
                else "按 测什么 前缀归类")
        line([family, f'={"+".join(parts)}', "", note])
    row += 1

    block_title("截图与固定变量")
    for text in ("每条至少两张：浅色基线（去掉末尾干扰子句）+ 浅色实验；"
                 "C505 / C506 / C511 另加深色一张，两种模式结论不同。",
                 "融球门禁开与关各跑一遍；prdVer 11.9.9.342 / romVersion 7.0 / size 全部固定。",
                 "链路轨不看图判 Template：口径同 taskspec/score_ws_run.py 的 Template(\"<id>\") 匹配，"
                 "图只用来确认卡片出得来、内容没丢。"):
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
        cell = ws.cell(row=row, column=1, value=text)
        cell.alignment = Alignment(vertical="top", wrap_text=True)
        ws.row_dimensions[row].height = 30
        row += 1


def write_notes(wb: Workbook, index: dict) -> None:
    ws = wb.create_sheet("口径")
    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 112
    rows = [
        ("采样口径", rc.SAMPLE_NOTE),
        ("容差与基线", rc.TOLERANCE_NOTE),
        ("分层", rc.LAYER_NOTE),
        ("固定变量", rc.FIX_NOTE),
        ("视觉轨判据层", "渲染 PNG + OCR：色值、文本逐字、几何顺序、留白、截断、基线两轮 diff"),
        ("链路轨判据层", index["judgingPolicy"]),
        ("准入策略", index["validityPolicy"]),
        ("未定标", index["openQuestion"]),
        ("字段说明", "；".join(f"{key}：{value}" for key, value in index["fieldNotes"].items())),
    ]
    for idx, (label, text) in enumerate(rows, start=1):
        head = ws.cell(row=idx, column=1, value=label)
        head.font = Font(bold=True)
        head.alignment = Alignment(vertical="top")
        cell = ws.cell(row=idx, column=2, value=text)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    ws.freeze_panes = "A2"


def main() -> None:
    cases = rc.load_cases()
    index = json.loads(INDEX.read_text(encoding="utf-8"))
    visual = [case_row(item) for item in cases if item["track"] == "visual"]
    chain = [case_row(item) for item in cases if item["track"] != "visual"]

    wb = Workbook()
    ws_visual = wb.active
    ws_visual.title = "视觉轨"
    ws_chain = wb.create_sheet("链路轨")
    style_sheet(ws_visual, visual)
    style_sheet(ws_chain, chain)
    sheets = [(ws_visual.title, ws_visual.max_row), (ws_chain.title, ws_chain.max_row)]
    write_summary(wb, sheets, len(cases))
    write_notes(wb, index)
    wb.save(OUT)
    print(f"写出 {OUT.name}：视觉轨 {len(visual)} 行 / 链路轨 {len(chain)} 行 + 汇总 + 口径")


if __name__ == "__main__":
    main()
