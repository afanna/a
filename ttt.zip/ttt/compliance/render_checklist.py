"""由用例与判定表生成渲染对照表，跑完批对着 PNG 逐条打勾。

读 `visual_axis/manifest.json` 与 `chain_axis/manifest.json`（指令与用例文件同源），
输出 `渲染对照表.md`。用法：python render_checklist.py
"""
from __future__ import annotations

import json
from pathlib import Path

import build_compliance_cases as builder

HERE = Path(__file__).resolve().parent
OUT = HERE / "渲染对照表.md"

SAMPLE_NOTE = (
    "背景取四角内缩约 8vp 与中心共 5 点；色名按 ΔE00 判（≤3 命中、3-8 部分、>8 违规）；"
    "字号用文本框高度分档比较；文案用 OCR 后逐字比对。"
)
TOLERANCE_NOTE = (
    "浅渐变与 20% 白背板按合成色取样，容差放宽一档；"
    "每条建议留一份“去掉干扰子句”的基线截图做对照。"
)
LAYER_NOTE = (
    "`manifest.json` 里 `templatePathAvailable=true` 的条目会走模板链路，"
    "整卡主题由 CardPlan/Tersel 决定；判颜色类探针时按该字段分层统计，"
    "否则模板默认主题会冒充成“模型不遵从”。"
)
FIX_NOTE = (
    "固定 `prdVer/romVersion`（本集 11.9.9.342 / 7.0）、`size`、能力与候选；"
    "融球门禁开与关各跑一遍；浅色与深色各截一次（C505、C506、C511 两种模式结论不同）。"
)

# 按 CASES 原编号给：看哪里 / 通过 / 违规
CHECK = {
    "Q101": {
        "look": "整卡背景（四角内缩 + 中心）",
        "pass": ["背景呈红色系"],
        "fail": ["蓝/紫/暖渐变＝被默认色板覆盖", "只有文字变红＝作用范围错"],
    },
    "Q102": {
        "look": "预警那行文字色 + 整卡背景",
        "pass": ["该行红字", "背景与基线一致"],
        "fail": ["整卡背景被改红（越界）", "该行仍默认色"],
    },
    "Q103": {
        "look": "电量数字那一组",
        "pass": ["数字为红色"],
        "fail": ["数字仍默认色"],
        "note": "数值由 mock 决定，返回不是 20% 时只判色、不判数值",
    },
    "Q104": {
        "look": "背景三点（左上 / 中心 / 右下）",
        "pass": ["紫系", "三点同色"],
        "fail": ["三点色差明显＝没做到纯色不要渐变", "背景非紫"],
    },
    "Q105": {
        "look": "背景色、文字色、两者合成对比度",
        "pass": ["白底 + 近白字（指定色保留）", "另有背板/描边/字号补救，或回复声明可读性风险"],
        "fail": ["文字被改成深灰或黑＝自动加深指定色", "背景被改深"],
    },
    "Q106": {
        "look": "整卡明度 + 文字色配对",
        "pass": ["背景明显偏暗", "文字浅色"],
        "fail": ["仍是浅渐变", "深底深字不可读（P0）"],
    },
    "Q107": {
        "look": "耳机图标区域取色",
        "pass": ["图标保持素材原色"],
        "fail": ["被统一染成单色（尤其整片蓝或白）"],
    },
    "Q108": {
        "look": "背景 / 标题行 / 按钮底 三处分别取样",
        "pass": ["深蓝底 + 白标题 + 浅灰按钮三处同时成立"],
        "fail": ["任一处回落默认"],
        "note": "三处分计，只对上一处不算通过",
    },
    "Q109": {
        "look": "电量数字文本框高度 vs 卡内其他文本",
        "pass": ["电量为卡内最大文本框"],
        "fail": ["与标题或辅助行同高", "放大后导致其他受保护文本截断"],
    },
    "Q110": {
        "look": "主数据块四周",
        "pass": ["闭合描边只圈住时长、热量、心率那块"],
        "fail": ["每个块都加描边（越界）", "完全没有描边"],
    },
    "Q111": {
        "look": "中间底托区域与其下背景",
        "pass": ["底托透出背景色相（按合成色比对，需容差）"],
        "fail": ["完全不透明底托"],
    },
    "Q112": {
        "look": "三块文本的 y 中心排序",
        "pass": ["自上而下为温度、下雨概率、温度范围"],
        "fail": ["任意两项顺序颠倒"],
    },
    "Q113": {
        "look": "标题行与时间行的水平质心",
        "pass": ["标题质心接近内容区中心", "时间左边缘贴合内容区左边"],
        "fail": ["两处同对齐（局部指令当全局）"],
    },
    "Q114": {
        "look": "非背景像素占比 + 最大连续空洞高度",
        "pass": ["两字段占据主要区域且空洞小于 18vp"],
        "fail": ["大片空白", "靠新增无关字段填满（新增内容即违规）"],
    },
    "Q115": {
        "look": "左右两块电量数字",
        "pass": ["两处文本框高度一致且取色 ΔE00≤3"],
        "fail": ["一大一小", "两色不同"],
    },
    "Q116": {
        "look": "中心图形",
        "pass": ["出现圆弧环且弧度对应电量比例"],
        "fail": ["只有百分比文本", "用矩形条替代环"],
    },
    "Q117": {
        "look": "顶部是否有标签条形态",
        "pass": ["无 tab 形态", "天气与日程以分区或两列呈现"],
        "fail": ["出现 tab 栏（照做禁用组件）", "静默只出一种业务（丢内容）"],
        "note": "该条期望是拒答加告知，拒答话术另记一列，不混进像素判定",
    },
    "Q118": {
        "look": "可见入口个数与文案",
        "pass": ["两个入口且文案为一键入会、导航去公司"],
        "fail": ["文案被改写", "硬塞导致重叠或截断"],
        "note": "只出一个入口时，需回复说明 2x2 动作预算，才算正确处置",
    },
    "Q119": {
        "look": "按钮底色 / 端部形状 / 文字色",
        "pass": ["蓝色系底 + 胶囊端 + 白字"],
        "fail": ["蓝底黑字", "方角按钮"],
    },
    "Q120": {
        "look": "开始训练按钮的颜色",
        "pass": ["呈灰色（与主题色明显区分）"],
        "fail": ["仍是强调色"],
    },
    "Q121": {
        "look": "省电模式按钮高度",
        "pass": ["明显大于基线（对照 24vp 下限，接近 40vp 更好）"],
        "fail": ["与辅助小字同高"],
    },
    "Q122": {
        "look": "按钮形态 + 右下角文字",
        "pass": ["无按钮底托或胶囊形态", "右下角出现查看更多"],
        "fail": ["仍有按钮形状", "缺查看更多"],
    },
    "Q123": {
        "look": "全卡图像元素",
        "pass": ["纯文字，无图标、图片、表情图形"],
        "fail": ["仍有图标", "因删图连带删掉查看详情动作"],
    },
    "Q124": {
        "look": "整卡背景",
        "pass": ["绿系背景"],
        "fail": ["蓝/紫/暖默认板"],
        "note": "基线对照：去掉后半句的同卡应出默认蓝",
    },
    "Q125": {
        "look": "六项信息与两个入口的完整度和挤压",
        "pass": ["删次要项并在回复说明", "或回复建议 2x4，且图上无截断"],
        "fail": ["出现省略号、重叠或溢出＝硬塞失败", "六项全在但字号跌破可读档"],
    },
    "Q126": {
        "look": "背景 / 标题 / 按钮 / 图像元素 四处",
        "pass": ["红底 + 白标题 + 蓝按钮 + 无图像元素"],
        "fail": ["蓝底＝默认板覆盖用户", "按钮被刷成红或白＝过度改写", "出现图标",
                 "因对比度不足而改色＝违规"],
        "note": "四处分计，全中才算通过",
    },
    "Q127": {
        "look": "标题行",
        "pass": ["OCR 得到完整长标题、无缺尾省略号（允许换两行）"],
        "fail": ["出现省略号或被裁切", "标题被简化改写"],
    },
    "Q128": {
        "look": "整卡背景 + 温度与风力两块",
        "pass": ["绿系背景", "温度与风力都出现"],
        "fail": ["背景非绿＝口语指令未解析", "漏风力"],
    },
    "Q129": {
        "look": "响应 streamContent 的 Template(\"<id>\") 调用式（不靠图）",
        "pass": ["业务模板 0 命中", "卡片仍可渲染、信息不丢"],
        "fail": ["命中 WeatherOverview 任意一张＝静默忽略用户否决"],
        "note": "先决条件：对照 C533 的 search eligible 非空（复算 6 张）",
    },
    "Q130": {
        "look": "同上",
        "pass": ["无 ScheduleOverview 命中"],
        "fail": ["命中＝静默忽略"],
        "note": "对照 C534 候选非空（4 张）",
    },
    "Q131": {
        "look": "同上",
        "pass": ["无 BatteryOverviewSupport@1 命中"],
        "fail": ["命中＝静默忽略"],
        "note": "该能力只有 1 张同尺寸模板，没有兄弟模板可辩解；对照 C535",
    },
    "Q132": {
        "look": "同上",
        "pass": ["无 CountdownOverview 命中"],
        "fail": ["命中＝静默忽略"],
        "note": "对照 C536 候选非空（4 张）",
    },
    "Q133": {
        "look": "search eligible 与响应 Template 调用式",
        "pass": ["eligible 非空（复算 6 张天气模板）", "不写否决时正常命中模板"],
        "fail": ["eligible 为空＝对照失效，C529 的通过没有意义"],
    },
    "Q134": {
        "look": "同上",
        "pass": ["eligible 非空（复算 4 张日程模板）"],
        "fail": ["eligible 为空＝对照失效"],
    },
    "Q135": {
        "look": "同上",
        "pass": ["eligible 非空（复算 1 张 BatteryOverviewSupport@1）"],
        "fail": ["eligible 为空＝对照失效"],
    },
    "Q136": {
        "look": "同上",
        "pass": ["eligible 非空（复算 4 张倒计时模板）"],
        "fail": ["eligible 为空＝对照失效"],
    },
}


def load_cases() -> list:
    cases = []
    for axis in ("visual_axis", "chain_axis"):
        manifest = json.loads((HERE / axis / "manifest.json").read_text(encoding="utf-8"))
        cases += manifest["cases"]
    return sorted(cases, key=lambda item: item["caseId"])


def bullet(items: list) -> str:
    return "；".join(items)


def row(item: dict) -> str:
    source = item["complianceProof"]["sourceId"]
    check = CHECK[source]
    marks = " ｜ ".join(f"✓ {one}" for one in check["pass"])
    fails = " ｜ ".join(f"✗ {one}" for one in check["fail"])
    note = item["complianceProof"].get("dataValueCaveat") or check.get("note", "")
    return (
        f"| {item['caseId']} | {item['dimension']} | {item['userQuery']} | {check['look']} | "
        f"{marks}；{fails} | {note} |  |"
    )


def main() -> None:
    cases = load_cases()
    lines = [
        "# 渲染对照表",
        "",
        "跑完批后按本表逐条打勾。指令与用例文件同源，改 `build_compliance_cases.py` 后重跑本脚本即可。",
        "",
        f"- 采样口径：{SAMPLE_NOTE}",
        f"- 容差与基线：{TOLERANCE_NOTE}",
        f"- 分层：{LAYER_NOTE}",
        f"- 固定变量：{FIX_NOTE}",
        "- 每条记四态：FOLLOWED / PARTIAL / VIOLATED / PROPER_DEGRADATION；"
        "静态与截图都判不了的记 UNVERIFIABLE，并注明缺什么。",
        "- 结果列只填首字母：F 遵从 / P 部分 / V 违规 / D 合理降级 / U 判不了。",
        "",
        "## 视觉轨（判定层：渲染 PNG 与 OCR）",
        "",
        "| 用例 | 测什么 | 指令 | 看哪里 | 判据（✓通过 / ✗违规） | 备注 | 结果 |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    lines += [row(item) for item in cases if item["track"] == "visual"]
    lines += [
        "",
        "## 链路轨（判定层：响应流与 search 候选，图只用来确认出得来、内容没丢）",
        "",
        "正例与对照成对：先确认对照的 `eligibleCount` 非空，再看正例是否命中模板。",
        "判据口径同 `taskspec/score_ws_run.py` 的 `Template(\"<id>\")` 调用式匹配。",
        "",
        "| 用例 | 测什么 | 指令 | 看哪里 | 判据（✓通过 / ✗违规） | 备注 | 结果 |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    lines += [row(item) for item in cases if item["track"] != "visual"]
    lines += [
        "",
        "## 结果汇总口径",
        "",
        "| 指标 | 算法 |",
        "| --- | --- |",
        "| 约束级遵从率 CCR | FOLLOWED + PROPER_DEGRADATION 的分项数 ÷ 应遵分项总数 |",
        "| 严格全约束通过率 | 一张卡所有分项都 FOLLOWED 或 PROPER_DEGRADATION 才算过（区分度最高）|",
        "| 硬违规率 | strength=hard 的分项中判 VIOLATED 的比例 |",
        "| 静默违规率 | VIOLATED 中回复未提及该取舍的占比（本集最该抓的失败模式）|",
        "| 幻觉率 | 图上出现但指令未要求的元素数 ÷ 图上元素总数 |",
        "| 合理降级率 | 冲突用例中判 PROPER_DEGRADATION 且已告知的比例 |",
        "| 分层 | 以上全部按 track、conflictWith、templatePathAvailable、size 分桶，不合并总分 |",
        "",
    ]
    OUT.write_text("\n".join(lines), encoding="utf-8")
    visual = sum(1 for item in cases if item["track"] == "visual")
    print(f"已写出 {OUT.name}：视觉轨 {visual} 条 / 链路轨 {len(cases) - visual} 条")
    missing = [item["caseId"] for item in cases if item["complianceProof"]["sourceId"] not in CHECK]
    if missing:
        raise SystemExit(f"FAIL 缺判定项：{missing}")
    print("OK 每条用例都有判定项")


if __name__ == "__main__":
    main()
