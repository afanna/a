# 字段轴（零候选探针）

编号范围：Q082–Q334，共 253 条（2026-09-29 重排；`Q318–Q321` 曾是空号，已被 09-29 新增的 19 条探针补齐使用，现无空号）。

## 这一轴断言什么

**每条用例的候选模板恒为空**，所以生产返回任何业务模板都是误触发，不需要先看它返回的是哪个模板。这样"缺主数据 / 数据过多 / 数据过少"这类临界输入一旦出卡片，立刻可判为缺陷。

判定不依赖首层（LLM）怎么解析自然语言——只用与解析无关的门来排除模板：

| 门 | 代码 | 是否与首层解析无关 |
| --- | --- | --- |
| G1 尺寸 | `record.supported_card_sizes ∋ size` | 是 |
| G2 绑定数 | `record.binding_count == 该能力写入根数`（`template_retrieval.py:980`） | 是 |
| G3 必填 | `_template_required_fields_are_available`：`required_paths` 全部落进 `dataModelSchema` 叶子 | 是 |
| G4 显式字段覆盖 | `_record_available_query_paths` + 单模板须覆盖全部 `explicitFields` | **否**，取决于首层实际请求的字段子集 T |
| G5 判别字段 | `_template_query_discriminator_is_requested` | 否 |
| G6 兜底开关 | `BatteryOverviewPercentLevelHero@1` | 否 |

首层请求的 T 满足 ∅ ⊆ T ⊆ `candidateOutputFields`，我们无法控制，所以**只有把模板挡在 G1/G2/G3 上才算铁证**；靠 G4/G5 的构造在首层"少要一个字段"或"一个都不要"时会漏出模板，本轴不采用。

## 两种构造法（2026-10-06）

| 方法 | 条数 | 做法 | 对应临界条件 |
| --- | --- | --- | --- |
| `G3-hitting-set` | 192 | 从原始出参删字段，使该能力**每个**同尺寸模板都至少缺一个必填；候选**必须非空** | 缺少主要数据 / 数据过少 |
| `G2-duplicate-root` | 61 | 保留原始出参，把同一能力**重复写入两个兄弟数据根**（`/data/x` 与 `/data/x2`），全部 `binding_count=1` 模板被 G2 恒挡 | 数据过多 / 冗余数据源 |

`G2-duplicate-root` 用于"G3 挡不住"的能力：存在 `required_paths` 为空的模板（如 `WeatherOverviewHeroTitle@1`、`WeatherOverviewTravelSupport@1`）时，删字段永远挡不住它。若该能力还有 `binding_count>=2` 的模板（全库只有 `WeatherOverviewDualCityFull@1`），在此基础上再删掉它一个必填。

重复数据根合法的前提（已在代码里核实）：`device_capability_resolver._find_write_result_conflict` 只禁**相同或互为父子**的路径，`/data/x` 与 `/data/x2` 是兄弟，不冲突；`preferredWriteResultTo` 不符只是 `warning`（`binding_validator.py:219`），不阻断。

## 构造纪律

- `candidateOutputFields` **必须非空**：清空出参会被 `TaskSpecBuilder` 回退成该能力全部叶子（`candidate_output_fields_ignored` / 全量回退），等于没缺字段——这是假零候选，一律禁止。
- 出参只能取该能力 `outputSchema` 声明过的叶子（`../verify_declared.mjs` 逐条核对）。
- 每条只引入一个变量：要么删字段，要么加重复根，不同时改文案。`G2-duplicate-root` 的出参从改造前备份还原后再加根，保证不与"缺字段"混叠。
- 同输入的对照用例不得雷同：改造曾把 7 组用例压成同一份（同 `userQuery` 同出参），已用 `../dedupe_zero_candidates.py` 换成不同删法，三档口径重复 0。

## 清单侧字段

- `templateId`：该条所属/参照的模板（用于 family↔capability 一致性与统计，**不是"应当触发"的期望**）。
- `defectKind`：`zero-candidate-g3hittingset` / `zero-candidate-g2duplicateroot`。
- `candidateOutputFields`、`candidateDataBindings`（含 `writeResultTo`）、`removedFieldPaths`、`addedDataRoots`、`probeConstruction`、`sourceLabel`。
- `zeroCandidateProof`：本条的零候选证据 —— `construction`（人话）、`method`、`queryIndependent: true`、`rootsAfter`、`possibleBefore`（改造前还可能出模板的清单）、`possibleAfter`（必须全为空）、`gates`（只依据 G1/G2/G3）。

## 复算与验证（都用生产代码，不是另一套规则）

```powershell
cd C:\Users\afan\Desktop\卡片\query\CreateMyCard230\taskspec
python make_zero_candidate_probes.py --apply          # 改造（幂等；备份在 C:\Users\afan\Desktop\卡片\_backup_tm_20260210）
python dedupe_zero_candidates.py --apply              # 消掉改造造成的同输入雷同
python replay_preflight_and_search.py --dir=template_misfire   # 真 preflight + 真 Search：field_axis 253 条"全被排除"
node verify_declared.mjs template_misfire             # 声明核对（出参必须是清单叶子）
python check_service_rejection.py --dir=template_misfire       # 模型/清单/preflight 三层拒绝码
node template_misfire\check_duplicates.mjs            # 三档口径重复数
```

复算结论（2026-10-06）：333 条 preflight 全通过；**field_axis 253 条真实 Search 候选全为空**，每条都以 `no provider template covers capability … and its requested fields` 结束；声明核对、三层拒绝、编号完整性、五类合成痕迹全为 0 问题；三档口径输入重复 0。

## 尚未按此口径改造的两轴

`semantic_axis`（40 条）与 `boundary_axis`（40 条）目前仍是**字段完备**输入：它们测的是"说法误导会不会选错模板"，若削成零候选，任何输出都算误触发，语义扰动本身就不再是可判分的对象（`perturbation_expected.json` 的 `judging.layerWarning` 早就写明这点）。这两轴的处置（转零候选 / 保留"最终采用层"判分并另立指标）待定，未定之前它们不计入"出模板即误触发"的分母。
